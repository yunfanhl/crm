#!/usr/bin/env bash
# 重启 CRM 服务(委托 start.sh)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "$SCRIPT_DIR/start.sh" restart
