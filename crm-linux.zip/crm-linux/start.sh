#!/usr/bin/env bash
# ==========================================================
#  云帆智能客户管理系统 - Linux 启动/停止脚本
#  用法: ./start.sh {start|stop|restart|status|configure}
#  说明:
#   1. 自动加载 jar 同级 .env; 若不存在则自动生成(随机授权主密钥 + 配套敏感配置密文)
#   2. 校验 JDK 17+ 与授权主密钥
#   3. 后台启动, PID 写入 crm.pid, 日志写入 logs/app.log
#   4. 数据库/Redis 等配置通过 .env 或环境变量设置(见 .env.example), 未设置则使用内置默认值
#   5. 首次启动自动建库建表(内置 db/init.sql)
#   6. ./start.sh configure: 已存在 .env 时, 为当前主密钥重新生成配套密文(修复密钥不匹配)
#   7. 每次启动自动校正: .env 主密钥与配套密文不匹配时自动补齐(升级遗留/改过主密钥场景自愈)
# ==========================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# 定位 jar: 脚本与 jar 同级(部署包根目录)
if [ ! -f "$SCRIPT_DIR/crm-system.jar" ]; then
    echo "[错误] 未找到 crm-system.jar, 请确认部署包结构完整" >&2
    exit 1
fi
APP_DIR="$SCRIPT_DIR"

JAR="$APP_DIR/crm-system.jar"
ENV_FILE="$APP_DIR/.env"
LOG_DIR="$APP_DIR/logs"
PID_FILE="$APP_DIR/crm.pid"
PORT="${SERVER_PORT:-8080}"

# 加载 .env(与 jar 同级)
if [ -f "$ENV_FILE" ]; then
    # shellcheck disable=SC1090
    set -a; source "$ENV_FILE"; set +a
fi

# ---- 主密钥指纹: 记录"当前密文是为哪个主密钥生成的", 主密钥变更后可自动重新生成密文 ----
key_fingerprint() {
    local key="$1" out=""
    out="$(printf '%s' "$key" | sha256sum 2>/dev/null | cut -c1-16 || true)"
    if [ -z "$out" ]; then
        out="$(printf '%s' "$key" | shasum -a 256 2>/dev/null | cut -c1-16 || true)"
    fi
    printf '%s' "$out"
}

# 写入/更新主密钥指纹
write_key_fingerprint() {
    local env_file="$1" key="$2" fp
    fp="$(key_fingerprint "$key")"
    [ -n "$fp" ] || return 0
    if grep -qE '^CRM_LICENSE_CIPHER_KEY_FP=' "$env_file" 2>/dev/null; then
        sed -i.bak "s|^CRM_LICENSE_CIPHER_KEY_FP=.*|CRM_LICENSE_CIPHER_KEY_FP=$fp|" "$env_file" && rm -f "$env_file.bak"
    else
        echo "CRM_LICENSE_CIPHER_KEY_FP=$fp" >> "$env_file"
    fi
}

# ---- 为指定主密钥生成配套的敏感配置密文并写入 .env ----
# 代码内置密文由演示主密钥加密, 随机生成的主密钥与之不匹配会导致启动失败;
# 本函数调用 jar 内的 MasterKeySetupTool, 解出内置明文明文后以当前主密钥重新加密。
gen_license_ciphers() {
    local env_file="$1"
    local master_key="$2"
    local java_bin jar_cmd classes_path out new_secret new_file

    if [ -z "$master_key" ]; then
        echo "[警告] 主密钥为空, 跳过配套密文生成" >&2
        return 1
    fi

    java_bin="${JAVA_BIN:-${JAVA_HOME:+$JAVA_HOME/bin/}java}"
    command -v "$java_bin" >/dev/null 2>&1 || java_bin="java"
    command -v "$java_bin" >/dev/null 2>&1 || {
        echo "[警告] 未找到 Java, 无法自动生成配套密文; 请手动确保主密钥与内置密文匹配" >&2
        return 1
    }
    jar_cmd="$(command -v jar 2>/dev/null || true)"
    if [ -z "$jar_cmd" ]; then
        # 与所用 java 同目录的 jar(java 由自动探测得到时 PATH 中未必有 jar)
        jar_cmd="$(cd "$(dirname "$java_bin")" 2>/dev/null && pwd)/jar"
        [ -x "$jar_cmd" ] || jar_cmd=""
    fi
    if [ -z "$jar_cmd" ] && [ -n "${JAVA_HOME:-}" ] && [ -x "$JAVA_HOME/bin/jar" ]; then
        jar_cmd="$JAVA_HOME/bin/jar"
    fi
    if [ -z "$jar_cmd" ]; then
        echo "[警告] 未找到 jar 命令, 无法自动生成配套密文; 请手动确保主密钥与内置密文匹配" >&2
        return 1
    fi

    # 注意: 不声明为 local, trap RETURN 触发时需引用该变量(函数返回时 local 已销毁)
    tmp_dir="$(mktemp -d)"
    trap 'rm -rf "$tmp_dir"' RETURN
    if ! (cd "$tmp_dir" && "$jar_cmd" xf "$JAR" "BOOT-INF/classes" >/dev/null 2>&1); then
        echo "[警告] 解压 jar 类目录失败, 无法自动生成配套密文" >&2
        return 1
    fi
    classes_path="$tmp_dir/BOOT-INF/classes"

    out="$("$java_bin" -cp "$classes_path" com.crm.utils.MasterKeySetupTool "$master_key" 2>/dev/null)" || {
        echo "[警告] 生成配套密文失败, 请手动确保主密钥与内置密文匹配" >&2
        return 1
    }
    new_secret="$(echo "$out" | sed -n 's/^SECRET=//p')"
    new_file="$(echo "$out" | sed -n 's/^FILE=//p')"
    if [ -z "$new_secret" ] || [ -z "$new_file" ]; then
        echo "[警告] 生成配套密文输出异常, 请手动确保主密钥与内置密文匹配" >&2
        return 1
    fi
    # 密文为 Base64, 含 / + =, 用 | 作 sed 分隔符
    sed -i.bak "s|^CRM_LICENSE_SECRET_CIPHER=.*|CRM_LICENSE_SECRET_CIPHER=$new_secret|" "$env_file" && rm -f "$env_file.bak"
    sed -i.bak "s|^CRM_LICENSE_FILE_CIPHER=.*|CRM_LICENSE_FILE_CIPHER=$new_file|" "$env_file" && rm -f "$env_file.bak"
    write_key_fingerprint "$env_file" "$master_key"
    echo "[配置] 已为主密钥生成配套敏感配置密文"
    return 0
}

# ---- 自动生成 .env(无需手动编辑): 复制模板并生成随机授权主密钥 / JWT 密钥 / 配套密文 ----
ensure_env() {
    # force=1 时即使环境变量已提供主密钥也强制生成 .env(configure 场景)
    local force="${1:-0}"
    if [ -f "$ENV_FILE" ]; then
        echo "[配置] .env 已存在: $ENV_FILE"
        return 0
    fi
    if [ "$force" = "0" ] && [ -n "${CRM_LICENSE_MASTER_KEY:-}" ]; then
        # 环境变量已提供主密钥且 .env 不存在: 由环境变量提供主密钥, 跳过生成
        return 0
    fi
    TEMPLATE="$SCRIPT_DIR/.env.example"
    if [ ! -f "$TEMPLATE" ]; then
        echo "[错误] 未找到 .env.example 模板, 无法自动生成配置" >&2
        exit 1
    fi
    cp "$TEMPLATE" "$ENV_FILE"
    if [ -n "${CRM_LICENSE_MASTER_KEY:-}" ]; then
        # 环境变量已提供主密钥: 写入 .env, 并为该主密钥生成配套密文
        MASTER_KEY="$CRM_LICENSE_MASTER_KEY"
    else
        MASTER_KEY="Crm$(openssl rand -hex 16 2>/dev/null || date +%s)"
    fi
    JWT_SECRET="$(openssl rand -hex 32 2>/dev/null || date +%s)"
    # macOS / Linux 兼容的 sed 写法
    sed -i.bak "s/^CRM_LICENSE_MASTER_KEY=.*/CRM_LICENSE_MASTER_KEY=$MASTER_KEY/" "$ENV_FILE" && rm -f "$ENV_FILE.bak"
    sed -i.bak "s/^JWT_SECRET=.*/JWT_SECRET=$JWT_SECRET/" "$ENV_FILE" && rm -f "$ENV_FILE.bak"
    # 生成与主密钥匹配的敏感配置密文, 避免随机主密钥与代码内置密文不匹配导致启动失败
    # 生成失败时回退到内置演示主密钥(代码内置密文由该密钥加密), 保证服务可正常启动
    if ! gen_license_ciphers "$ENV_FILE" "$MASTER_KEY"; then
        echo "[警告] 配套密文自动生成失败, 回退使用内置演示主密钥以保证可启动" >&2
        echo "[警告] 如需自定义主密钥, 请手动确保 CRM_LICENSE_SECRET_CIPHER/FILE_CIPHER 与主密钥匹配" >&2
        sed -i.bak -e "s|^CRM_LICENSE_MASTER_KEY=.*|CRM_LICENSE_MASTER_KEY=Crm2026@MasterKey!X8zQwL9p|" \
                   -e "s|^CRM_LICENSE_SECRET_CIPHER=.*|CRM_LICENSE_SECRET_CIPHER=|" \
                   -e "s|^CRM_LICENSE_FILE_CIPHER=.*|CRM_LICENSE_FILE_CIPHER=|" "$ENV_FILE" && rm -f "$ENV_FILE.bak"
        write_key_fingerprint "$ENV_FILE" "Crm2026@MasterKey!X8zQwL9p"
    fi
    echo "[配置] 已自动生成 $ENV_FILE"
    echo "[配置] 授权主密钥: $MASTER_KEY (请妥善保管, 生成 License 时需使用)"
    echo "[配置] 如需自定义数据库/Redis 等, 可编辑 $ENV_FILE 后重启服务"
    # shellcheck disable=SC1090
    set -a; source "$ENV_FILE"; set +a
}

# ---- 自愈: 保证 .env 中主密钥与配套密文配套(升级遗留 / 手工修改主密钥场景) ----
# 代码内置密文由演示主密钥加密: 使用自定义主密钥却缺少配套密文, 后端会启动失败
# (授权主密钥与配套密文不匹配 / Tag mismatch)。这里在每次启动前自动补齐。
ensure_ciphers() {
    [ -f "$ENV_FILE" ] || return 0

    local secret file fp reason new_master_key
    secret="$(grep -E '^CRM_LICENSE_SECRET_CIPHER=' "$ENV_FILE" 2>/dev/null | tail -1 | cut -d= -f2- || true)"
    file="$(grep -E '^CRM_LICENSE_FILE_CIPHER=' "$ENV_FILE" 2>/dev/null | tail -1 | cut -d= -f2- || true)"
    fp="$(grep -E '^CRM_LICENSE_CIPHER_KEY_FP=' "$ENV_FILE" 2>/dev/null | tail -1 | cut -d= -f2- || true)"

    # .env 中无主密钥: 生成随机主密钥写入 .env
    if [ -z "${CRM_LICENSE_MASTER_KEY:-}" ]; then
        new_master_key="Crm$(openssl rand -hex 16 2>/dev/null || date +%s)"
        sed -i.bak "s|^CRM_LICENSE_MASTER_KEY=.*|CRM_LICENSE_MASTER_KEY=$new_master_key|" "$ENV_FILE" && rm -f "$ENV_FILE.bak"
        CRM_LICENSE_MASTER_KEY="$new_master_key"
        export CRM_LICENSE_MASTER_KEY
        echo "[配置] .env 缺少授权主密钥, 已生成随机主密钥"
    fi

    # 演示主密钥: 与代码内置密文配套, 必须清空 .env 中的自定义密文
    if [ "$CRM_LICENSE_MASTER_KEY" = "Crm2026@MasterKey!X8zQwL9p" ]; then
        if [ -n "$secret" ] || [ -n "$file" ]; then
            sed -i.bak -e "s|^CRM_LICENSE_SECRET_CIPHER=.*|CRM_LICENSE_SECRET_CIPHER=|" \
                       -e "s|^CRM_LICENSE_FILE_CIPHER=.*|CRM_LICENSE_FILE_CIPHER=|" "$ENV_FILE" && rm -f "$ENV_FILE.bak"
            write_key_fingerprint "$ENV_FILE" "Crm2026@MasterKey!X8zQwL9p"
            echo "[配置] 主密钥为内置演示主密钥, 已清空 .env 配套密文(改用代码内置密文)"
        fi
        return 0
    fi

    # 判定是否需要重新生成密文: 密文缺失, 或主密钥已变更(指纹不一致)
    reason=""
    if [ -z "$secret" ] || [ -z "$file" ]; then
        reason=".env 配套密文缺失(升级遗留或手工编辑)"
    elif [ -n "$fp" ] && [ "$fp" != "$(key_fingerprint "$CRM_LICENSE_MASTER_KEY")" ]; then
        reason="授权主密钥已变更, 现有密文不再配套"
    fi
    [ -n "$reason" ] || return 0

    echo "[配置] 检测到 $reason, 正在为当前主密钥生成配套密文..."
    if ! gen_license_ciphers "$ENV_FILE" "$CRM_LICENSE_MASTER_KEY"; then
        echo "[警告] 配套密文生成失败, 回退使用内置演示主密钥以保证可启动" >&2
        sed -i.bak "s|^CRM_LICENSE_MASTER_KEY=.*|CRM_LICENSE_MASTER_KEY=Crm2026@MasterKey!X8zQwL9p|" "$ENV_FILE" && rm -f "$ENV_FILE.bak"
    fi
}

# ---- 启动前准备(.env 自愈 + 主密钥 + JDK 17) ----
# 说明: stop/status 只需操作进程, 不依赖 Java; 因此这些校验只在 start/restart/configure 时执行
JAVA_BIN=""

# 输出 Java 主版本号(如 17); 不可用或解析失败时输出 0
java_major() {
    local bin="$1" major
    [ -n "$bin" ] || { printf '0'; return 0; }
    command -v "$bin" >/dev/null 2>&1 || { printf '0'; return 0; }
    major="$("$bin" -version 2>&1 | awk -F'[\".]' '/version/{print $2; exit}')"
    case "$major" in ''|*[!0-9]*) printf '0' ;; *) printf '%s' "$major" ;; esac
}

# 默认 java 不是 17 时, 在系统常见安装目录中寻找 JDK 17+
find_java17() {
    local dir bin
    for dir in /usr/lib/jvm /usr/java /opt/java /opt /opt/homebrew/opt /usr/local/opt /Library/Java/JavaVirtualMachines; do
        [ -d "$dir" ] || continue
        for bin in "$dir"/*/bin/java "$dir"/*/*/bin/java "$dir"/*/Contents/Home/bin/java; do
            [ -x "$bin" ] || continue
            if [ "$(java_major "$bin")" -ge 17 ]; then
                printf '%s' "$bin"
                return 0
            fi
        done
    done
    printf ''
}

# 确定启动使用的 java: 优先 JAVA_HOME, 其次 PATH 中的 java, 最后自动探测系统内的 JDK 17+
resolve_java() {
    [ -n "$JAVA_BIN" ] && return 0

    JAVA_BIN="${JAVA_HOME:+$JAVA_HOME/bin/}java"
    if [ "$(java_major "$JAVA_BIN")" -lt 17 ]; then
        local found
        found="$(find_java17)"
        if [ -n "$found" ]; then
            echo "[配置] 默认 java 非 17, 已改用检测到 JDK $(java_major "$found"): $found"
            JAVA_BIN="$found"
        fi
    fi

    if [ "$(java_major "$JAVA_BIN")" -lt 17 ]; then
        if ! command -v "$JAVA_BIN" >/dev/null 2>&1; then
            echo "[错误] 未找到 Java, 请先安装 JDK 17+" >&2
        else
            echo "[错误] 需要 JDK 17+, 当前版本: $("$JAVA_BIN" -version 2>&1 | head -1)" >&2
        fi
        echo "[提示] 请设置 JAVA_HOME 指向 JDK 17 安装目录: export JAVA_HOME=/path/to/jdk-17" >&2
        echo "[提示] 也可将该行写入 $ENV_FILE: JAVA_HOME=/path/to/jdk-17" >&2
        exit 1
    fi
}

prepare() {
    # 先定位 JDK: 首次生成 .env 时需要用同一 JDK 生成配套密文
    resolve_java
    ensure_env
    ensure_ciphers

    if [ -z "${CRM_LICENSE_MASTER_KEY:-}" ]; then
        echo "[错误] 缺少授权主密钥 CRM_LICENSE_MASTER_KEY, 系统将拒绝启动" >&2
        exit 1
    fi

    resolve_java
    mkdir -p "$LOG_DIR"
}

JVM_OPTS="-Xms${JVM_XMS:-512m} -Xmx${JVM_XMX:-1024m} -XX:+UseG1GC"

# ---- 子命令 ----
start() {
    if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
        echo "[提示] 服务已在运行 (PID $(cat "$PID_FILE"))"
        return 0
    fi
    echo "[启动] $JAR"
    # shellcheck disable=SC2086
    nohup "$JAVA_BIN" $JVM_OPTS -jar "$JAR" >"$LOG_DIR/app.log" 2>&1 &
    echo $! >"$PID_FILE"
    echo "[启动] PID: $(cat "$PID_FILE"), 日志: $LOG_DIR/app.log"

    for _ in $(seq 1 60); do
        if curl -s -o /dev/null "http://127.0.0.1:$PORT/auth/captcha" 2>/dev/null; then
            echo "[启动] 服务已就绪: http://127.0.0.1:$PORT"
            return 0
        fi
        if ! kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
            echo "[错误] 进程已退出, 请查看日志: $LOG_DIR/app.log" >&2
            return 1
        fi
        sleep 1
    done
    echo "[警告] 等待超时, 请查看日志确认状态: $LOG_DIR/app.log" >&2
    return 1
}

stop() {
    if [ -f "$PID_FILE" ]; then
        PID="$(cat "$PID_FILE")"
        if kill -0 "$PID" 2>/dev/null; then
            echo "[停止] 停止进程 $PID"
            kill "$PID" 2>/dev/null || true
            for _ in $(seq 1 15); do
                kill -0 "$PID" 2>/dev/null || break
                sleep 1
            done
            kill -0 "$PID" 2>/dev/null && kill -9 "$PID" 2>/dev/null || true
        fi
        rm -f "$PID_FILE"
    fi
    # 兜底清理
    pkill -f "crm-system.jar" 2>/dev/null || true
    echo "[停止] 服务已停止"
}

status() {
    if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
        echo "[状态] 运行中 (PID $(cat "$PID_FILE"), 端口 $PORT)"
    else
        echo "[状态] 未运行"
    fi
}

case "${1:-start}" in
    start)     prepare; start ;;
    stop)      stop ;;
    restart)   prepare; stop; sleep 1; start ;;
    status)    status ;;
    configure)
        # force: .env 不存在时也生成(环境变量已有主密钥则写入 .env), 再为其生成配套密文
        resolve_java
        ensure_env force
        # 演示主密钥: 清空配套密文, 使用代码内置密文
        if [ "${CRM_LICENSE_MASTER_KEY:-}" = "Crm2026@MasterKey!X8zQwL9p" ]; then
            sed -i.bak -e "s|^CRM_LICENSE_SECRET_CIPHER=.*|CRM_LICENSE_SECRET_CIPHER=|" \
                       -e "s|^CRM_LICENSE_FILE_CIPHER=.*|CRM_LICENSE_FILE_CIPHER=|" "$ENV_FILE" && rm -f "$ENV_FILE.bak"
            write_key_fingerprint "$ENV_FILE" "Crm2026@MasterKey!X8zQwL9p"
            echo "[配置] 主密钥为内置演示主密钥, 已清空配套密文(使用代码内置密文)"
        elif [ -n "${CRM_LICENSE_MASTER_KEY:-}" ]; then
            if ! gen_license_ciphers "$ENV_FILE" "$CRM_LICENSE_MASTER_KEY"; then
                echo "[警告] 配套密文生成失败, 请确认部署包完整(MasterKeySetupTool 存在)后重试" >&2
            fi
        else
            echo "[配置] .env 中未设置 CRM_LICENSE_MASTER_KEY, 跳过配套密文生成" >&2
        fi
        echo "[配置] 配套密文已更新, 重启服务使其生效..."
        restart
        ;;
    *) echo "用法: $0 {start|stop|restart|status|configure}"; exit 1 ;;
esac
