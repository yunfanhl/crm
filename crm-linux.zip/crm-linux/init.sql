-- =====================================================
-- CRM系统数据库初始化脚本（无演示数据版）
-- 仅包含：建表 + 系统基础数据 + 权限数据，不含任何业务示例/演示数据。
-- 如需演示数据，请改用 init-with-demo.sql 初始化。
-- =====================================================
-- =====================================================
-- CRM系统数据库初始化脚本（完整合并版）
-- 数据库: MySQL 8.0+
-- 字符集: utf8mb4
-- 说明: 本文件已合并所有迁移脚本，可一次性执行。
--       表使用 CREATE TABLE IF NOT EXISTS，新增列使用幂等 ALTER，
--       新增菜单/字典数据使用幂等 INSERT，重复执行安全。
-- 执行: mysql -uroot -p --default-character-set=utf8mb4 < sql/init.sql
-- =====================================================

CREATE DATABASE IF NOT EXISTS `crm_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `crm_db`;

-- 兜底: JDBC 的 createDatabaseIfNotExist=true 可能用 MySQL 服务端默认字符集(Windows 上常为 latin1)
-- 把库先建出来, 导致上面 CREATE DATABASE IF NOT EXISTS no-op 后库仍是 latin1, 后续 CREATE TABLE
-- 的中文 DEFAULT / INSERT 中文被错误转换。显式 ALTER 强制 utf8mb4 修复此问题。
ALTER DATABASE `crm_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

SET NAMES utf8mb4;
-- ==========================================================
-- 商机情报数据源基础表（旧版 init.sql 缺失，导致商机来源/信息来源/网上抓取报错）
-- ==========================================================
-- crm_lead_source
CREATE TABLE IF NOT EXISTS `crm_lead_source` (
  `id` varchar(36) NOT NULL COMMENT '主键',
  `source_name` varchar(100) NOT NULL COMMENT '数据源名称',
  `source_type` varchar(20) NOT NULL DEFAULT 'custom' COMMENT '类型：custom-自定义API demo-内置演示',
  `base_url` varchar(500) DEFAULT NULL COMMENT '接口地址',
  `app_key` varchar(200) DEFAULT NULL COMMENT 'AppKey',
  `app_secret` varchar(200) DEFAULT NULL COMMENT 'AppSecret',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用 0-停用 1-启用',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `last_crawl_time` datetime DEFAULT NULL COMMENT '最近抓取时间',
  `last_result` text COMMENT '最近抓取结果',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '逻辑删除 0-否 1-是',
  PRIMARY KEY (`id`),
  KEY `idx_enabled` (`enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商机抓取数据源';

-- crm_info_source
CREATE TABLE IF NOT EXISTS `crm_info_source` (
  `id` varchar(36) NOT NULL COMMENT '主键',
  `source_name` varchar(100) NOT NULL COMMENT '数据源名称',
  `source_type` varchar(20) NOT NULL DEFAULT 'custom' COMMENT '类型：custom-自定义API demo-内置演示',
  `base_url` varchar(500) DEFAULT NULL COMMENT '接口地址',
  `app_key` varchar(200) DEFAULT NULL COMMENT 'AppKey',
  `app_secret` varchar(200) DEFAULT NULL COMMENT 'AppSecret',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用 0-停用 1-启用',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `last_crawl_time` datetime DEFAULT NULL COMMENT '最近抓取时间',
  `last_result` text COMMENT '最近抓取结果',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '逻辑删除 0-否 1-是',
  PRIMARY KEY (`id`),
  KEY `idx_enabled` (`enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商机抓取数据源';

-- crm_crawl_source
CREATE TABLE IF NOT EXISTS `crm_crawl_source` (
  `id` varchar(36) NOT NULL COMMENT '主键',
  `source_name` varchar(100) NOT NULL COMMENT '数据源名称',
  `source_type` varchar(20) NOT NULL DEFAULT 'custom' COMMENT '类型：custom-自定义API demo-内置演示',
  `base_url` varchar(500) DEFAULT NULL COMMENT '接口地址',
  `app_key` varchar(200) DEFAULT NULL COMMENT 'AppKey',
  `app_secret` varchar(200) DEFAULT NULL COMMENT 'AppSecret',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用 0-停用 1-启用',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `last_crawl_time` datetime DEFAULT NULL COMMENT '最近抓取时间',
  `last_result` text COMMENT '最近抓取结果',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '逻辑删除 0-否 1-是',
  PRIMARY KEY (`id`),
  KEY `idx_enabled` (`enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商机抓取数据源';

-- 信息来源（平台来源）默认数据：企查查开放平台 / 爱企查
-- 幂等：按名称防重，用户删除后重启不会自动复活；密钥留空，需在页面「编辑数据源」中填写后才能抓取真实数据。
INSERT IGNORE INTO `crm_info_source` (`id`, `source_name`, `source_type`, `base_url`, `enabled`, `remark`)
SELECT s.id, s.name, s.type, s.url, 1, s.remark FROM (
  SELECT 'b9d7a13cd67611f1925b1d4813846157' AS id, '企查查开放平台' AS name, 'qichacha' AS type,
         'https://api.qichacha.com/FuzzySearch/GetList' AS url,
         '需在企查查开放平台购买接口服务后填写 Key 与 Secrect' AS remark
  UNION ALL
  SELECT 'b9d7b3cad67611f1925b1d4813846157', '爱企查', 'aiqicha', NULL,
         '需购买云市场爱企查接口后填写接口地址与 APPCODE'
) s
WHERE NOT EXISTS (SELECT 1 FROM `crm_info_source` WHERE `source_name` = s.name);

-- 商机来源（crm_lead_source）默认数据：内置演示源 + 一个开箱可用的网页抓取示例。
-- 幂等：按名称防重，用户删除后重启不会自动复活。新版本页面查询本表，旧版脚本漏了播种导致列表为空。
INSERT IGNORE INTO `crm_lead_source` (`id`, `source_name`, `source_type`, `base_url`, `enabled`, `remark`)
SELECT s.id, s.name, s.type, s.url, 1, s.remark FROM (
  SELECT '6cad02d8-b51c-4755-b41b-4e1feb74c58a' AS id, '内置演示数据' AS name, 'demo' AS type, NULL AS url,
         '开箱即用：生成贴近真实的招投标/项目公告演示数据，无需任何配置' AS remark UNION ALL
  SELECT 'a1f3c2e0-1001-4a2b-8c5d-000000000001', '全国公共资源交易平台', 'demo', NULL,
         '对接全国公共资源交易服务平台，覆盖各省市工程建设、政府采购等公开交易信息' UNION ALL
  SELECT 'a1f3c2e0-1001-4a2b-8c5d-000000000002', '中国政府采购网', 'demo', NULL,
         '对接中国政府采购网，获取中央及地方政府采购公告、中标结果等信息' UNION ALL
  SELECT 'a1f3c2e0-1001-4a2b-8c5d-000000000003', '中国招标投标公共服务平台', 'demo', NULL,
         '对接中国招标投标公共服务平台，覆盖工程、货物、服务类招标公告' UNION ALL
  SELECT 'a1f3c2e0-1001-4a2b-8c5d-000000000004', '企业工商公开信息', 'demo', NULL,
         '对接公开企业工商/招采信息，用于发现潜在客户与项目机会' UNION ALL
  SELECT 'a1f3c2e0-1001-4a2b-8c5d-000000000005', '公开网页示例（中国供应商）', 'web', 'http://cn.china.cn/',
         '示例：公开黄页网页抓取（可替换为任意公开名录列表页）'
) s
WHERE NOT EXISTS (SELECT 1 FROM `crm_lead_source` n WHERE n.`source_name` = s.name);

-- 已有库升级：旧版把商机来源写在 crm_crawl_source，新版改查 crm_lead_source。
-- 将旧表中未删除的数据源（含用户自定义源及其抓取状态）迁移到新表，按名称防重，避免升级后列表变空或配置丢失。
INSERT IGNORE INTO `crm_lead_source` (`id`, `source_name`, `source_type`, `base_url`, `app_key`, `app_secret`, `enabled`, `remark`, `last_crawl_time`, `last_result`, `create_time`, `update_time`, `deleted`)
SELECT o.`id`, o.`source_name`, o.`source_type`, o.`base_url`, o.`app_key`, o.`app_secret`, o.`enabled`, o.`remark`,
       o.`last_crawl_time`, o.`last_result`, o.`create_time`, o.`update_time`, o.`deleted`
FROM `crm_crawl_source` o
WHERE o.`deleted` = 0
  AND NOT EXISTS (SELECT 1 FROM `crm_lead_source` n WHERE n.`source_name` = o.`source_name`);


-- =====================================================
-- 一、系统管理模块
-- =====================================================

-- 1. 系统用户表
CREATE TABLE IF NOT EXISTS `sys_user` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `username`    VARCHAR(50)  NOT NULL,
  `password`    VARCHAR(100) NOT NULL,
  `real_name`   VARCHAR(50)  DEFAULT NULL,
  `phone`       VARCHAR(20)  DEFAULT NULL,
  `email`       VARCHAR(100) DEFAULT NULL,
  `avatar`      VARCHAR(255) DEFAULT NULL,
  `status`      TINYINT      NOT NULL DEFAULT 1,
  `intro_seen`  TINYINT      NOT NULL DEFAULT 0 COMMENT '系统使用须知引导是否已读 0-未读 1-已读（服务端保存）',
  `expire_date` DATE         DEFAULT NULL COMMENT '账号有效期（NULL 表示长期有效，过期后不能登录）',
  `dept_id`     VARCHAR(36)       DEFAULT NULL COMMENT '部门ID',
  `last_login`  DATETIME     DEFAULT NULL,
  `create_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`     TINYINT      NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统用户表';

-- 2. 角色表
CREATE TABLE IF NOT EXISTS `sys_role` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `role_name`   VARCHAR(50) NOT NULL,
  `role_code`   VARCHAR(50) NOT NULL,
  `description` VARCHAR(200) DEFAULT NULL,
  `status`      TINYINT     NOT NULL DEFAULT 1,
  `data_scope`  TINYINT     NOT NULL DEFAULT 1,
  `create_time` DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`     TINYINT     NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_role_code` (`role_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='角色表';

-- 3. 菜单/权限表
CREATE TABLE IF NOT EXISTS `sys_menu` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `parent_id`   VARCHAR(36)       NOT NULL DEFAULT 0 COMMENT '父级ID',
  `menu_name`   VARCHAR(50)  NOT NULL,
  `path`        VARCHAR(200) DEFAULT NULL,
  `component`   VARCHAR(200) DEFAULT NULL,
  `perms`       VARCHAR(100) DEFAULT NULL,
  `icon`        VARCHAR(50)  DEFAULT NULL,
  `menu_type`   CHAR(1)      NOT NULL,
  `sort`        INT          NOT NULL DEFAULT 0,
  `visible`     TINYINT      NOT NULL DEFAULT 1,
  `create_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='菜单/权限表';

-- 4. 用户角色关联表
CREATE TABLE IF NOT EXISTS `sys_user_role` (
  `user_id` VARCHAR(36) NOT NULL COMMENT '用户ID',
  `role_id` VARCHAR(36) NOT NULL COMMENT '角色ID',
  PRIMARY KEY (`user_id`, `role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户角色关联表';

-- 5. 角色菜单关联表
CREATE TABLE IF NOT EXISTS `sys_role_menu` (
  `role_id` VARCHAR(36) NOT NULL COMMENT '角色ID',
  `menu_id` VARCHAR(36) NOT NULL COMMENT '菜单ID',
  PRIMARY KEY (`role_id`, `menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='角色菜单关联表';

-- 6. 部门表
CREATE TABLE IF NOT EXISTS `sys_dept` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `parent_id`   VARCHAR(36)      NOT NULL DEFAULT 0 COMMENT '父级ID',
  `dept_name`   VARCHAR(50) NOT NULL,
  `leader`      VARCHAR(50) DEFAULT NULL,
  `phone`       VARCHAR(20) DEFAULT NULL,
  `sort`        INT         NOT NULL DEFAULT 0,
  `status`      TINYINT     NOT NULL DEFAULT 1,
  `create_time` DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`     TINYINT     NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='部门表';

-- 7. 系统设置表
CREATE TABLE IF NOT EXISTS `sys_setting` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `system_name`     VARCHAR(100) DEFAULT '云帆智能客户管理系统',
  `system_subtitle` VARCHAR(200) DEFAULT 'Customer Relationship Management',
  `login_logo`      VARCHAR(500) DEFAULT NULL,
  `h5_qrcode`       VARCHAR(500) DEFAULT NULL COMMENT '登录页 H5 二维码图片 URL',
  `mp_qrcode`       VARCHAR(500) DEFAULT NULL COMMENT '登录页小程序二维码图片 URL',
  `multi_login`     TINYINT      NOT NULL DEFAULT 0,
  `upload_dir`      VARCHAR(255) DEFAULT './uploads/',
  `feedback_enabled` TINYINT     NOT NULL DEFAULT 0,
  `feedback_rate_limit_max`    INT NOT NULL DEFAULT 10 COMMENT '意见反馈限流：单个IP限流窗口内最大提交次数',
  `feedback_rate_limit_window` INT NOT NULL DEFAULT 10 COMMENT '意见反馈限流窗口（分钟）',
  `feedback_dedupe_hours`      INT NOT NULL DEFAULT 1  COMMENT '意见反馈去重窗口（小时），同内容同提交人在窗口内视为重复',
  `captcha_enabled` TINYINT      NOT NULL DEFAULT 0,
  `theme_color`     VARCHAR(20)  DEFAULT '#8B7DE0',
  `login_config`    TEXT         DEFAULT NULL,
  `ai_enabled`      TINYINT      NOT NULL DEFAULT 0,
  `ai_base_url`     VARCHAR(255) DEFAULT 'https://api.deepseek.com',
  `ai_api_key`      VARCHAR(255) DEFAULT NULL,
  `ai_model`        VARCHAR(100) DEFAULT 'deepseek-chat',
  `ai_temperature`  DOUBLE       NOT NULL DEFAULT 0.7,
  `ai_max_tokens`   INT          NOT NULL DEFAULT 2048,
  `ai_timeout_seconds` INT       NOT NULL DEFAULT 60,
  `ai_system_prompt` TEXT,
  `ai_embedding_base_url` VARCHAR(255) DEFAULT 'https://dashscope.aliyuncs.com/compatible-mode/v1' COMMENT '向量化接口地址(OpenAI 兼容 /embeddings)，默认阿里云百炼',
  `ai_embedding_model`   VARCHAR(100) DEFAULT 'text-embedding-v3' COMMENT '向量化模型',
  `ai_embedding_dim`     INT          NOT NULL DEFAULT 1024 COMMENT '向量维度(需与模型一致)',
  `ai_embedding_api_key` VARCHAR(255) DEFAULT NULL COMMENT '向量化 API Key(与对话 Key 独立，便于使用不同服务商)',
  `current_version` VARCHAR(50)  DEFAULT NULL,
  `upgrade_url`     VARCHAR(500) DEFAULT NULL,
  `sms_channel`         VARCHAR(20)  DEFAULT 'aliyun',
  `sms_access_key_id`   VARCHAR(255) DEFAULT NULL,
  `sms_access_key_secret` VARCHAR(255) DEFAULT NULL,
  `sms_sign_name`       VARCHAR(100) DEFAULT NULL,
  `sms_template_code`   VARCHAR(100) DEFAULT NULL,
  `sms_endpoint`        VARCHAR(255) DEFAULT NULL,
  `face_channel`        VARCHAR(20)  DEFAULT 'aliyun',
  `face_access_key_id`  VARCHAR(255) DEFAULT NULL,
  `face_access_key_secret` VARCHAR(255) DEFAULT NULL,
  `face_local_provider`  VARCHAR(20)  DEFAULT 'compreface' COMMENT '开源人脸服务协议: compreface/insightface',
  `face_local_endpoint`  VARCHAR(255) DEFAULT NULL COMMENT '开源人脸服务地址（内网）',
  `face_local_api_key`   VARCHAR(255) DEFAULT NULL COMMENT '开源人脸服务 API Key',
  `face_local_threshold` DECIMAL(5,2) DEFAULT 0.80 COMMENT '人脸比对阈值 0~1',
  `login_default_accounts_enabled` TINYINT NOT NULL DEFAULT 1 COMMENT '登录页默认账号提示开关 0-关闭 1-开启(部署包默认开启)',
  `demo_data_editable` TINYINT NOT NULL DEFAULT 1 COMMENT '演示数据是否允许修改 0-不允许(只读) 1-允许修改',
  `crawl_enabled` TINYINT NOT NULL DEFAULT 1 COMMENT '商机情报抓取开关 0-关闭 1-开启',
  `crawl_cron` VARCHAR(50) DEFAULT '0 0 8 * * ?' COMMENT '商机情报抓取 cron 表达式',
  `crawl_provider` VARCHAR(20) DEFAULT 'none' COMMENT '商机情报数据源 none-演示数据 custom-自定义接口',
  `crawl_base_url` VARCHAR(500) DEFAULT NULL COMMENT '商机情报第三方数据源接口地址',
  `crawl_app_key` VARCHAR(255) DEFAULT NULL COMMENT '商机情报第三方数据源应用 Key',
  `crawl_app_secret` VARCHAR(255) DEFAULT NULL COMMENT '商机情报第三方数据源应用 Secret',
  `attendance_face_enabled` TINYINT NOT NULL DEFAULT 0 COMMENT '签到是否启用人脸核验 0-关闭 1-开启',
  `attendance_work_time`    VARCHAR(5) NOT NULL DEFAULT '09:00' COMMENT '上班时间（HH:mm，用于判定迟到）',
  `mail_enabled`   TINYINT      NOT NULL DEFAULT 0 COMMENT '邮件提醒开关 0-关闭(模拟发送) 1-开启',
  `mail_host`      VARCHAR(100) DEFAULT NULL COMMENT 'SMTP 服务器地址',
  `mail_port`      INT          DEFAULT 465 COMMENT 'SMTP 端口',
  `mail_ssl`       TINYINT      NOT NULL DEFAULT 1 COMMENT '是否启用 SSL 0-否 1-是',
  `mail_username`  VARCHAR(100) DEFAULT NULL COMMENT 'SMTP 账号（发件邮箱）',
  `mail_password`  VARCHAR(255) DEFAULT NULL COMMENT 'SMTP 密码/授权码',
  `mail_from`      VARCHAR(100) DEFAULT NULL COMMENT '发件人显示名称',
  `mail_provider`  VARCHAR(20)  NOT NULL DEFAULT 'smtp' COMMENT '邮件服务商 smtp/aliyun/tencent',
  `mail_access_key_id`     VARCHAR(128) DEFAULT NULL COMMENT '云邮件 AccessKeyId',
  `mail_access_key_secret` VARCHAR(256) DEFAULT NULL COMMENT '云邮件 AccessKeySecret',
  `mail_region`    VARCHAR(32)  DEFAULT NULL COMMENT '云邮件地域',
  `create_time`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- 已有库升级：为 sys_setting 补充商机抓取配置列（幂等）
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'crawl_enabled');
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'crawl_enabled') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `crawl_enabled` TINYINT NOT NULL DEFAULT 1 COMMENT ''商机情报抓取开关 0-关闭 1-开启''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'crawl_cron') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `crawl_cron` VARCHAR(50) DEFAULT ''0 0 8 * * ?'' COMMENT ''商机情报抓取 cron 表达式''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'crawl_provider') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `crawl_provider` VARCHAR(20) DEFAULT ''none'' COMMENT ''商机情报数据源 none-演示数据 custom-自定义接口''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'crawl_base_url') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `crawl_base_url` VARCHAR(500) DEFAULT NULL COMMENT ''商机情报第三方数据源接口地址''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'crawl_app_key') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `crawl_app_key` VARCHAR(255) DEFAULT NULL COMMENT ''商机情报第三方数据源应用 Key''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'crawl_app_secret') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `crawl_app_secret` VARCHAR(255) DEFAULT NULL COMMENT ''商机情报第三方数据源应用 Secret''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：为 sys_setting 补充考勤打卡配置列（幂等）
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'attendance_face_enabled');
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'attendance_face_enabled') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `attendance_face_enabled` TINYINT NOT NULL DEFAULT 0 COMMENT ''签到是否启用人脸核验 0-关闭 1-开启''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'attendance_work_time') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `attendance_work_time` VARCHAR(5) NOT NULL DEFAULT ''09:00'' COMMENT ''上班时间（HH:mm，用于判定迟到）''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：为 sys_setting 补充登录页二维码配置列（幂等）
-- 老库（2.6.6 之前建的 sys_setting）没有 h5_qrcode / mp_qrcode，登录页查询会报 Unknown column
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'h5_qrcode');
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'h5_qrcode') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `h5_qrcode` VARCHAR(500) DEFAULT NULL COMMENT ''登录页 H5 二维码图片 URL''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'mp_qrcode') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `mp_qrcode` VARCHAR(500) DEFAULT NULL COMMENT ''登录页小程序二维码图片 URL''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：默认主题色统一为紫色（幂等）
-- 旧库建表时列默认值为蓝色 #5B8FD9，导致新部署显示蓝色而非紫色 #8B7DE0。
-- 同时覆盖历史部署可能残留的其它"系统默认蓝"：Element Plus 默认蓝 #409EFF、经典蓝 #3B82F6、Ant Design 蓝 #1890FF。
-- 仅更新这些默认蓝色值，用户自定义的主题色不动。
UPDATE `sys_setting` SET `theme_color` = '#8B7DE0'
WHERE `theme_color` IS NULL OR TRIM(`theme_color`) = ''
   OR UPPER(TRIM(`theme_color`)) IN ('#5B8FD9', '#409EFF', '#3B82F6', '#1890FF');

-- 已有库升级：为 sys_setting 补充意见反馈限流与去重配置列（幂等）
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'feedback_rate_limit_max');
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'feedback_rate_limit_max') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `feedback_rate_limit_max` INT NOT NULL DEFAULT 10 COMMENT ''意见反馈限流：单个IP限流窗口内最大提交次数''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'feedback_rate_limit_window') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `feedback_rate_limit_window` INT NOT NULL DEFAULT 10 COMMENT ''意见反馈限流窗口（分钟）''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'feedback_dedupe_hours') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `feedback_dedupe_hours` INT NOT NULL DEFAULT 1 COMMENT ''意见反馈去重窗口（小时），同内容同提交人在窗口内视为重复''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：为 sys_setting 补充向量化(embedding)配置列（幂等）
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'ai_embedding_base_url');
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'ai_embedding_base_url') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `ai_embedding_base_url` VARCHAR(255) DEFAULT ''https://dashscope.aliyuncs.com/compatible-mode/v1'' COMMENT ''向量化接口地址(OpenAI 兼容 /embeddings)''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'ai_embedding_model') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `ai_embedding_model` VARCHAR(100) DEFAULT ''text-embedding-v3'' COMMENT ''向量化模型''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'ai_embedding_dim') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `ai_embedding_dim` INT NOT NULL DEFAULT 1024 COMMENT ''向量维度(需与模型一致)''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：为 sys_setting 补充独立的向量化 API Key 列（幂等）
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'ai_embedding_api_key');
SET @ddl := IF(@col_exist = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `ai_embedding_api_key` VARCHAR(255) DEFAULT NULL COMMENT ''向量化 API Key(与对话 Key 独立，便于使用不同服务商)'' AFTER `ai_embedding_dim`',
  'SELECT 1');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：为 sys_setting 补充多平台真实发布凭证列（幂等）
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'wechat_appid');
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'wechat_appid') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `wechat_appid` VARCHAR(100) DEFAULT NULL COMMENT ''微信公众号 AppID(真实发布)''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'wechat_appsecret') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `wechat_appsecret` VARCHAR(100) DEFAULT NULL COMMENT ''微信公众号 AppSecret''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'weibo_app_key') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `weibo_app_key` VARCHAR(100) DEFAULT NULL COMMENT ''微博开放平台 App Key''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'weibo_app_secret') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `weibo_app_secret` VARCHAR(100) DEFAULT NULL COMMENT ''微博开放平台 App Secret''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'weibo_access_token') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `weibo_access_token` VARCHAR(255) DEFAULT NULL COMMENT ''微博 access_token(用户授权)''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'publish_plugin_secret') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `publish_plugin_secret` VARCHAR(255) DEFAULT NULL COMMENT ''浏览器插件共享密钥(无API平台Cookie发布用)''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：为 sys_setting 补充各平台必填关键词配置列（幂等）
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'platform_keywords');
SET @ddl := IF(@col_exist = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `platform_keywords` TEXT DEFAULT NULL COMMENT ''各平台必填关键词/必填项/追加策略/自动填标签配置(JSON)'' AFTER `publish_plugin_secret`',
  'SELECT 1');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

-- 知识库文档表：方案/合同/产品手册/客户资料等入库
CREATE TABLE IF NOT EXISTS `knowledge_document` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',
  `title`       VARCHAR(300) NOT NULL COMMENT '文档标题',
  `file_name`   VARCHAR(300) DEFAULT NULL COMMENT '原始文件名',
  `file_type`   VARCHAR(20)  DEFAULT NULL COMMENT '文件类型 pdf/docx/xlsx/txt/md',
  `file_size`   BIGINT       NOT NULL DEFAULT 0 COMMENT '文件大小(字节)',
  `status`      TINYINT      NOT NULL DEFAULT 0 COMMENT '状态 0-处理中 1-已完成 2-失败',
  `chunk_count` INT          NOT NULL DEFAULT 0 COMMENT '切片数量',
  `created_by`  VARCHAR(36)  DEFAULT NULL COMMENT '上传人用户ID',
  `create_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`     TINYINT      NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='知识库文档表';

-- 知识库文档切片表：每个切片正文 + 向量（JSON 数组，检索时用 Java 计算余弦相似度）
CREATE TABLE IF NOT EXISTS `knowledge_chunk` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',
  `doc_id`   VARCHAR(36)  NOT NULL COMMENT '关联 knowledge_document.id',
  `seq`      INT          NOT NULL DEFAULT 0 COMMENT '切片序号',
  `content`  TEXT         NOT NULL COMMENT '切片正文',
  `embedding` TEXT         NULL COMMENT '向量(JSON 数组字符串)，本地知识库模式可为空',
  `create_time` DATETIME  NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_doc_id` (`doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='知识库文档切片表';

-- 已有库升级：knowledge_chunk.embedding 改为可空（本地知识库不做向量化）（幂等）
SET @emb_is_nullable := (SELECT IS_NULLABLE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'knowledge_chunk' AND COLUMN_NAME = 'embedding');
SET @ddl_emb := IF(@emb_is_nullable IS NULL OR @emb_is_nullable = 'YES', 'SELECT 1', 'ALTER TABLE `knowledge_chunk` MODIFY COLUMN `embedding` TEXT NULL COMMENT ''向量(JSON数组字符串)，本地知识库模式可为空''');
PREPARE ddl_emb FROM @ddl_emb;
EXECUTE ddl_emb;
DEALLOCATE PREPARE ddl_emb;

-- 已有库升级：feedback.user_id 由 bigint 改为 varchar(36)，以匹配 sys_user.id(UUID)，修复演示数据导入失败（幂等）
SET @col_type := (SELECT DATA_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'feedback' AND COLUMN_NAME = 'user_id');
SET @ddl := IF(@col_type = 'bigint' OR @col_type = 'int',
  'ALTER TABLE `feedback` MODIFY COLUMN `user_id` VARCHAR(36) DEFAULT NULL COMMENT ''提交用户ID（同 sys_user.id，UUID）''',
  'SELECT 1');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：为 sys_user 逐列补充微信号、人脸列（每列独立幂等判断，
-- 修复旧版用 wechat 存在与否判断整组列导致老库缺 face_feature 的问题）
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_user' AND COLUMN_NAME = 'wechat') = 0,
  'ALTER TABLE `sys_user` ADD COLUMN `wechat` VARCHAR(64) DEFAULT NULL COMMENT ''微信号''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_user' AND COLUMN_NAME = 'face_photo') = 0,
  'ALTER TABLE `sys_user` ADD COLUMN `face_photo` VARCHAR(255) DEFAULT NULL COMMENT ''人脸照片地址''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_user' AND COLUMN_NAME = 'face_feature') = 0,
  'ALTER TABLE `sys_user` ADD COLUMN `face_feature` LONGTEXT DEFAULT NULL COMMENT ''人脸特征向量''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_user' AND COLUMN_NAME = 'face_enrolled_time') = 0,
  'ALTER TABLE `sys_user` ADD COLUMN `face_enrolled_time` DATETIME DEFAULT NULL COMMENT ''人脸录入时间''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;

-- 系统操作日志表
CREATE TABLE IF NOT EXISTS `sys_oper_log` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `module`         VARCHAR(100) DEFAULT NULL,
  `oper_type`      VARCHAR(20)  DEFAULT NULL,
  `description`    VARCHAR(255) DEFAULT NULL,
  `request_method` VARCHAR(10)  DEFAULT NULL,
  `request_uri`    VARCHAR(255) DEFAULT NULL,
  `method`         VARCHAR(500) DEFAULT NULL,
  `params`         TEXT         DEFAULT NULL,
  `oper_user_id`   VARCHAR(36)       DEFAULT NULL COMMENT '操作用户ID',
  `oper_username`  VARCHAR(50)  DEFAULT NULL,
  `oper_ip`        VARCHAR(50)  DEFAULT NULL,
  `status`         TINYINT      NOT NULL DEFAULT 1,
  `error_msg`      TEXT         DEFAULT NULL,
  `cost_time`      BIGINT       NOT NULL DEFAULT 0,
  `create_time`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_oper_username` (`oper_username`),
  KEY `idx_oper_type` (`oper_type`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- =====================================================
-- 二、客户管理模块
-- =====================================================

-- 客户表
CREATE TABLE IF NOT EXISTS `crm_customer` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `customer_name`  VARCHAR(100) NOT NULL,
  `customer_code`  VARCHAR(50)  DEFAULT NULL,
  `industry`       VARCHAR(50)  DEFAULT NULL,
  `customer_level` VARCHAR(20)  DEFAULT NULL,
  `customer_source` VARCHAR(50) DEFAULT NULL,
  `phone`          VARCHAR(20)  DEFAULT NULL,
  `email`          VARCHAR(100) DEFAULT NULL,
  `website`        VARCHAR(200) DEFAULT NULL,
  `address`        VARCHAR(300) DEFAULT NULL,
  `description`    TEXT         DEFAULT NULL,
  `attachments`    TEXT         DEFAULT NULL,
  `owner_id`       VARCHAR(36)       DEFAULT NULL COMMENT '归属人ID',
  `create_by`      VARCHAR(36)       DEFAULT NULL COMMENT '创建人',
  `status`         VARCHAR(20)  NOT NULL DEFAULT 'active',
  `deal_status`    VARCHAR(20)  NOT NULL DEFAULT 'A',
  `credit_code`    VARCHAR(50)  DEFAULT NULL,
  `annual_revenue` DECIMAL(14,2) DEFAULT NULL,
  `employee_count` INT          DEFAULT NULL,
  `create_time`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`        TINYINT      NOT NULL DEFAULT 0,
  `is_demo`        TINYINT      NOT NULL DEFAULT 0 COMMENT '是否演示数据 1-演示数据 0-普通数据',
  `archived`       TINYINT      NOT NULL DEFAULT 0 COMMENT '是否归档 0-正常 1-已归档（归档后默认从列表隐藏）',
  PRIMARY KEY (`id`),
  KEY `idx_owner` (`owner_id`),
  KEY `idx_level` (`customer_level`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- 已有库升级：为 crm_customer 补充归档列（幂等）
SET @cust_archived_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_customer' AND COLUMN_NAME = 'archived');
SET @ddl_cust_archived := IF(@cust_archived_exist = 0,
  'ALTER TABLE `crm_customer` ADD COLUMN `archived` TINYINT NOT NULL DEFAULT 0 COMMENT ''是否归档 0-正常 1-已归档（归档后默认从列表隐藏）''',
  'SELECT 1');
PREPARE ddl_cust_archived FROM @ddl_cust_archived;
EXECUTE ddl_cust_archived;
DEALLOCATE PREPARE ddl_cust_archived;

-- 联系人表
CREATE TABLE IF NOT EXISTS `crm_contact` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `customer_id`  VARCHAR(36)       NOT NULL COMMENT '客户ID',
  `contact_name` VARCHAR(50)  NOT NULL,
  `gender`       CHAR(1)      DEFAULT NULL,
  `position`     VARCHAR(50)  DEFAULT NULL,
  `department`   VARCHAR(50)  DEFAULT NULL,
  `phone`        VARCHAR(20)  DEFAULT NULL,
  `email`        VARCHAR(100) DEFAULT NULL,
  `qq`           VARCHAR(20)  DEFAULT NULL,
  `wechat`       VARCHAR(50)  DEFAULT NULL,
  `is_decision`  TINYINT      NOT NULL DEFAULT 0,
  `remark`       VARCHAR(500) DEFAULT NULL,
  `create_time`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`      TINYINT      NOT NULL DEFAULT 0,
  `is_demo`      TINYINT       NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_customer` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- 销售线索表
CREATE TABLE IF NOT EXISTS `crm_opportunity` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `opp_name`         VARCHAR(100)  DEFAULT NULL COMMENT '线索名称（界面已隐藏，留空）',
  `customer_id`      VARCHAR(36)        DEFAULT NULL COMMENT '客户ID（关联客户后填充；未匹配到已有客户时留空）',
  `customer_name`    VARCHAR(100)  DEFAULT NULL COMMENT '客户名称（手动录入，关联客户后冗余存储）',
  `customer_code`    VARCHAR(50)   DEFAULT NULL COMMENT '客户编号（线索独立编号，可手填；留空自动生成 C+yyyyMMdd+4位当日序号，与客户模块规则一致）',
  `contact_id`       VARCHAR(36)        DEFAULT NULL COMMENT '联系人ID',
  `contact_info`     TEXT          DEFAULT NULL COMMENT '内联联系人信息（JSON，冗余存储）',
  `released`         TINYINT       NOT NULL DEFAULT 0 COMMENT '是否已放入公海：0-否，1-是',

  `estimated_amount` DECIMAL(14,2) NOT NULL DEFAULT 0,
  `stage`            VARCHAR(20)   NOT NULL DEFAULT 'initial',
  `probability`      INT           NOT NULL DEFAULT 10,
  `expected_close`   DATE          DEFAULT NULL,
  `source`           VARCHAR(50)   DEFAULT NULL,
  `description`      TEXT          DEFAULT NULL,
  `owner_id`         VARCHAR(36)        DEFAULT NULL COMMENT '归属人ID',
  `create_time`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`          TINYINT       NOT NULL DEFAULT 0,
  `is_demo`          TINYINT       NOT NULL DEFAULT 0 COMMENT '是否演示数据 1-演示数据 0-普通数据',
  PRIMARY KEY (`id`),
  KEY `idx_customer` (`customer_id`),
  KEY `idx_stage` (`stage`),
  KEY `idx_owner` (`owner_id`),
  KEY `idx_opp_customer_code` (`customer_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- 已有库升级：为 crm_opportunity 补充客户编号列（幂等）
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_opportunity' AND COLUMN_NAME = 'customer_code');
SET @ddl := IF(@col_exist = 0,
  'ALTER TABLE `crm_opportunity` ADD COLUMN `customer_code` VARCHAR(50) DEFAULT NULL COMMENT ''客户编号（线索独立编号，可手填；留空自动生成 C+yyyyMMdd+4位当日序号，与客户模块规则一致）'', ADD KEY `idx_opp_customer_code` (`customer_code`)',
  'SELECT 1');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：crm_opportunity.customer_id 允许为空（客户名称未匹配到已有客户时不自动建档，留空）
SET @cid_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_opportunity' AND COLUMN_NAME = 'customer_id');
SET @ddl_cid := IF(@cid_exist > 0,
  'ALTER TABLE `crm_opportunity` MODIFY COLUMN `customer_id` VARCHAR(36) DEFAULT NULL COMMENT ''客户ID（关联客户后填充；未匹配到已有客户时留空）''',
  'SELECT 1');
PREPARE ddl_cid FROM @ddl_cid;
EXECUTE ddl_cid;
DEALLOCATE PREPARE ddl_cid;

-- 跟进记录表
CREATE TABLE IF NOT EXISTS `crm_follow_up` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `customer_id`   VARCHAR(36)       DEFAULT NULL COMMENT '客户ID',
  `contact_id`    VARCHAR(36)       DEFAULT NULL COMMENT '联系人ID',
  `opportunity_id` VARCHAR(36)      DEFAULT NULL COMMENT '商机ID',
  `follow_type`   VARCHAR(20)  NOT NULL DEFAULT 'phone',
  `content`       TEXT         NOT NULL,
  `next_follow`   DATE         DEFAULT NULL,
  `follow_user`   VARCHAR(36)       DEFAULT NULL COMMENT '跟进人ID',
  `create_time`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`       TINYINT      NOT NULL DEFAULT 0,
  `is_demo`       TINYINT       NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_customer` (`customer_id`),
  KEY `idx_opp` (`opportunity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- =====================================================
-- 三、合同管理模块（含增强：模板/在线签署/短信）
-- =====================================================

-- 合同表
CREATE TABLE IF NOT EXISTS `crm_contract` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `contract_no`    VARCHAR(50)   NOT NULL,
  `contract_name`  VARCHAR(100)  NOT NULL,
  `customer_id`    VARCHAR(36)        NOT NULL COMMENT '客户ID',
  `opportunity_id` VARCHAR(36)        DEFAULT NULL COMMENT '商机ID',
  `amount`         DECIMAL(14,2) NOT NULL DEFAULT 0,
  `sign_date`      DATE          DEFAULT NULL,
  `start_date`     DATE          DEFAULT NULL,
  `end_date`       DATE          DEFAULT NULL,
  `status`         VARCHAR(20)   NOT NULL DEFAULT 'draft',
  `payment_terms`  VARCHAR(200)  DEFAULT NULL,
  `signed_by`      VARCHAR(50)   DEFAULT NULL,
  `owner_id`       VARCHAR(36)        DEFAULT NULL COMMENT '归属人ID',
  `remark`         TEXT          DEFAULT NULL,
  `template_id`    VARCHAR(36)        DEFAULT NULL COMMENT '模板ID',
  `file_url`       VARCHAR(500)  DEFAULT NULL,
  `content`        LONGTEXT      DEFAULT NULL,
  `sign_status`    VARCHAR(20)   DEFAULT 'unsigned',
  `sign_url`       VARCHAR(500)  DEFAULT NULL,
  `signed_time`    DATETIME      DEFAULT NULL,
  `sms_channel`    VARCHAR(20)   DEFAULT NULL,
  `sms_sent`       TINYINT       DEFAULT 0,
  `sms_send_time`  DATETIME      DEFAULT NULL,
  `create_time`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`        TINYINT       NOT NULL DEFAULT 0,
  `is_demo`        TINYINT       NOT NULL DEFAULT 0 COMMENT '是否演示数据 1-演示数据 0-普通数据',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_contract_no` (`contract_no`),
  KEY `idx_customer` (`customer_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- 合同模板表
CREATE TABLE IF NOT EXISTS `crm_contract_template` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `name`        VARCHAR(100) NOT NULL,
  `category`    VARCHAR(50)  DEFAULT NULL,
  `file_url`    VARCHAR(500) DEFAULT NULL,
  `file_name`   VARCHAR(255) DEFAULT NULL,
  `content`     LONGTEXT     DEFAULT NULL,
  `remark`      VARCHAR(255) DEFAULT NULL,
  `create_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- 合同在线签署记录表
CREATE TABLE IF NOT EXISTS `crm_contract_sign` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `contract_id` VARCHAR(36)       NOT NULL COMMENT '合同ID',
  `signer_name` VARCHAR(50)  DEFAULT NULL,
  `signer_phone` VARCHAR(20) DEFAULT NULL,
  `sign_type`   VARCHAR(20)  DEFAULT 'customer',
  `sign_url`    VARCHAR(500) DEFAULT NULL,
  `status`      VARCHAR(20)  DEFAULT 'pending',
  `ip`          VARCHAR(50)  DEFAULT NULL,
  `signed_time` DATETIME     DEFAULT NULL,
  `create_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_contract` (`contract_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- 合同回款记录表（一个合同多笔回款）
CREATE TABLE IF NOT EXISTS `crm_contract_payment` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `contract_id`  VARCHAR(36)    NOT NULL COMMENT '合同ID',
  `amount`       DECIMAL(14,2)  NOT NULL DEFAULT 0.00 COMMENT '回款金额',
  `payment_date` DATE           DEFAULT NULL COMMENT '回款日期',
  `pay_method`   VARCHAR(20)    DEFAULT 'bank' COMMENT '回款方式：bank-银行转账 cash-现金 cheque-支票 other-其他',
  `voucher_no`   VARCHAR(50)    DEFAULT NULL COMMENT '凭证号/银行流水号',
  `remark`       VARCHAR(200)   DEFAULT NULL COMMENT '备注',
  `created_by`   VARCHAR(36)    DEFAULT NULL COMMENT '登记人用户ID',
  `create_time`  DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`  DATETIME       DEFAULT NULL,
  `deleted`      TINYINT        DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_contract` (`contract_id`),
  KEY `idx_payment_date` (`payment_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='合同回款记录表';

-- 合同通知发送记录表（每次发送通知留痕）
CREATE TABLE IF NOT EXISTS `crm_contract_notify_log` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `contract_id`   VARCHAR(36)  NOT NULL COMMENT '合同ID',
  `channels`      VARCHAR(50)  DEFAULT NULL COMMENT '发送渠道：sms,email,site（逗号分隔）',
  `content`       TEXT         DEFAULT NULL COMMENT '通知内容',
  `result`        VARCHAR(20)  DEFAULT 'success' COMMENT '结果：success-全部成功 partial-部分成功 failed-失败',
  `detail`        VARCHAR(500) DEFAULT NULL COMMENT '各渠道发送明细',
  `operator_id`   VARCHAR(36)  DEFAULT NULL COMMENT '操作人ID',
  `operator_name` VARCHAR(50)  DEFAULT NULL COMMENT '操作人姓名',
  `create_time`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_contract` (`contract_id`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='合同通知发送记录表';

-- 任务表
CREATE TABLE IF NOT EXISTS `crm_task` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `task_title`     VARCHAR(200) NOT NULL,
  `task_desc`      TEXT         DEFAULT NULL,
  `priority`       VARCHAR(10)  NOT NULL DEFAULT 'medium',
  `due_date`       DATE         DEFAULT NULL,
  `status`         VARCHAR(10)  NOT NULL DEFAULT 'pending',
  `customer_id`    VARCHAR(36)       DEFAULT NULL COMMENT '客户ID',
  `opportunity_id` VARCHAR(36)       DEFAULT NULL COMMENT '商机ID',
  `owner_id`       VARCHAR(36)       NOT NULL COMMENT '归属人ID',
  `create_by`      VARCHAR(36)       DEFAULT NULL COMMENT '创建人ID（仅创建人或管理员可编辑/删除）',
  `remind_time`    DATETIME     DEFAULT NULL COMMENT '下次提醒时间',
  `reminded`       TINYINT      NOT NULL DEFAULT 0,
  `remind_channel` VARCHAR(50)  DEFAULT NULL COMMENT '提醒渠道: site-站内信 email-邮件 sms-短信(多个用逗号分隔)',
  `remind_count`   INT          NOT NULL DEFAULT 1 COMMENT '提醒次数',
  `remind_interval` INT         NOT NULL DEFAULT 30 COMMENT '多次提醒时的间隔(分钟)',
  `reminded_count` INT          NOT NULL DEFAULT 0 COMMENT '已提醒次数',
  `complete_time`  DATETIME     DEFAULT NULL,
  `create_time`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`        TINYINT      NOT NULL DEFAULT 0,
  `is_demo`        TINYINT      NOT NULL DEFAULT 0 COMMENT '是否演示数据 1-演示数据 0-普通数据',
  PRIMARY KEY (`id`),
  KEY `idx_owner` (`owner_id`),
  KEY `idx_status` (`status`),
  KEY `idx_due_date` (`due_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- 客户日程表（在客户操作中「创建日程」，记录拜访/电话/会议等安排）
CREATE TABLE IF NOT EXISTS `crm_schedule` (
  `id`            VARCHAR(36)   NOT NULL COMMENT '主键ID（UUID）',
  `title`         VARCHAR(200)  NOT NULL COMMENT '日程标题',
  `content`       TEXT          DEFAULT NULL COMMENT '日程内容/备注',
  `customer_id`   VARCHAR(36)   DEFAULT NULL COMMENT '关联客户ID',
  `customer_name` VARCHAR(200)  DEFAULT NULL COMMENT '客户名称(冗余, 便于列表展示)',
  `location`      VARCHAR(200)  DEFAULT NULL COMMENT '地点',
  `start_time`    DATETIME      DEFAULT NULL COMMENT '开始时间',
  `end_time`      DATETIME      DEFAULT NULL COMMENT '结束时间(可空=无明确结束)',
  `all_day`       TINYINT       NOT NULL DEFAULT 0 COMMENT '是否全天 0-否 1-是',
  `remind`        TINYINT       NOT NULL DEFAULT 0 COMMENT '是否提醒 0-否 1-是',
  `remind_time`   DATETIME      DEFAULT NULL COMMENT '下次提醒时间',
  `remind_channel` VARCHAR(50)  DEFAULT NULL COMMENT '提醒渠道: site-站内信 email-邮件 sms-短信(多个用逗号分隔)',
  `remind_count`  INT           NOT NULL DEFAULT 1 COMMENT '提醒次数',
  `remind_interval` INT         NOT NULL DEFAULT 30 COMMENT '多次提醒时的间隔(分钟)',
  `reminded_count` INT          NOT NULL DEFAULT 0 COMMENT '已提醒次数',
  `status`        VARCHAR(20)   NOT NULL DEFAULT 'planned' COMMENT '状态 planned-待进行 done-已完成 cancelled-已取消',
  `owner_id`      VARCHAR(36)   NOT NULL COMMENT '归属人ID',
  `create_time`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`       TINYINT       NOT NULL DEFAULT 0,
  `is_demo`       TINYINT       NOT NULL DEFAULT 0 COMMENT '是否演示数据 1-演示 0-普通',
  PRIMARY KEY (`id`),
  KEY `idx_owner` (`owner_id`),
  KEY `idx_start` (`start_time`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客户日程表';

-- 营销活动表
CREATE TABLE IF NOT EXISTS `crm_marketing_activity` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `activity_name`    VARCHAR(100)  NOT NULL,
  `activity_type`    VARCHAR(30)   DEFAULT 'promotion',
  `channel`          VARCHAR(30)   DEFAULT 'offline',
  `start_date`       DATE          DEFAULT NULL,
  `end_date`         DATE          DEFAULT NULL,
  `budget`           DECIMAL(14,2) DEFAULT 0.00,
  `actual_cost`      DECIMAL(14,2) DEFAULT 0.00,
  `target_customers` INT           DEFAULT 0,
  `actual_customers` INT           DEFAULT 0,
  `status`           VARCHAR(20)   DEFAULT 'planning',
  `owner_id`         VARCHAR(36)        DEFAULT NULL COMMENT '归属人ID',
  `description`      TEXT,
  `remark`           VARCHAR(500)  DEFAULT NULL,
  `create_time`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`          TINYINT       NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_type` (`activity_type`),
  KEY `idx_dates` (`start_date`, `end_date`),
  KEY `idx_owner` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- 已有库升级：营销活动提醒（时间 / 渠道 / 次数 / 间隔 / 已提醒次数）（幂等）
SET @mkt_tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity');
SET @mkt_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'remind_time');
SET @ddl_mkt := IF(@mkt_tbl_exist = 0 OR @mkt_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_marketing_activity` ADD COLUMN `remind_time` DATETIME DEFAULT NULL COMMENT ''提醒时间'' AFTER `remark`');
PREPARE ddl_mkt FROM @ddl_mkt;
EXECUTE ddl_mkt;
DEALLOCATE PREPARE ddl_mkt;
SET @mkt_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'remind_channel');
SET @ddl_mkt := IF(@mkt_tbl_exist = 0 OR @mkt_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_marketing_activity` ADD COLUMN `remind_channel` VARCHAR(50) DEFAULT NULL COMMENT ''提醒渠道: site-站内信 email-邮件 sms-短信(多个用逗号分隔)'' AFTER `remind_time`');
PREPARE ddl_mkt FROM @ddl_mkt;
EXECUTE ddl_mkt;
DEALLOCATE PREPARE ddl_mkt;
SET @mkt_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'remind_count');
SET @ddl_mkt := IF(@mkt_tbl_exist = 0 OR @mkt_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_marketing_activity` ADD COLUMN `remind_count` INT NOT NULL DEFAULT 1 COMMENT ''提醒次数'' AFTER `remind_channel`');
PREPARE ddl_mkt FROM @ddl_mkt;
EXECUTE ddl_mkt;
DEALLOCATE PREPARE ddl_mkt;
SET @mkt_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'remind_interval');
SET @ddl_mkt := IF(@mkt_tbl_exist = 0 OR @mkt_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_marketing_activity` ADD COLUMN `remind_interval` INT NOT NULL DEFAULT 30 COMMENT ''多次提醒时的间隔(分钟)'' AFTER `remind_count`');
PREPARE ddl_mkt FROM @ddl_mkt;
EXECUTE ddl_mkt;
DEALLOCATE PREPARE ddl_mkt;
SET @mkt_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'reminded_count');
SET @ddl_mkt := IF(@mkt_tbl_exist = 0 OR @mkt_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_marketing_activity` ADD COLUMN `reminded_count` INT NOT NULL DEFAULT 0 COMMENT ''已提醒次数'' AFTER `remind_interval`');
PREPARE ddl_mkt FROM @ddl_mkt;
EXECUTE ddl_mkt;
DEALLOCATE PREPARE ddl_mkt;

-- 已有库升级：营销活动权限范围（visible_range / dept_ids / role_ids）（幂等）
SET @mkt_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'visible_range');
SET @ddl_mkt := IF(@mkt_tbl_exist = 0 OR @mkt_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_marketing_activity` ADD COLUMN `visible_range` VARCHAR(20) NOT NULL DEFAULT ''all'' COMMENT ''权限范围: all-全员 dept-指定部门 role-指定角色'' AFTER `remark`');
PREPARE ddl_mkt FROM @ddl_mkt;
EXECUTE ddl_mkt;
DEALLOCATE PREPARE ddl_mkt;
SET @mkt_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'dept_ids');
SET @ddl_mkt := IF(@mkt_tbl_exist = 0 OR @mkt_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_marketing_activity` ADD COLUMN `dept_ids` VARCHAR(500) DEFAULT NULL COMMENT ''可见部门ID(逗号分隔)'' AFTER `visible_range`');
PREPARE ddl_mkt FROM @ddl_mkt;
EXECUTE ddl_mkt;
DEALLOCATE PREPARE ddl_mkt;
SET @mkt_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'role_ids');
SET @ddl_mkt := IF(@mkt_tbl_exist = 0 OR @mkt_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_marketing_activity` ADD COLUMN `role_ids` VARCHAR(500) DEFAULT NULL COMMENT ''可见角色编码(逗号分隔)'' AFTER `dept_ids`');
PREPARE ddl_mkt FROM @ddl_mkt;
EXECUTE ddl_mkt;
DEALLOCATE PREPARE ddl_mkt;

-- 已有库升级：任务权限范围（visible_range / dept_ids / role_ids）（幂等）
SET @task_tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task');
SET @task_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task' AND COLUMN_NAME = 'visible_range');
SET @ddl_task := IF(@task_tbl_exist = 0 OR @task_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_task` ADD COLUMN `visible_range` VARCHAR(20) NOT NULL DEFAULT ''all'' COMMENT ''权限范围: all-全员 dept-指定部门 role-指定角色'' AFTER `owner_id`');
PREPARE ddl_task FROM @ddl_task;
EXECUTE ddl_task;
DEALLOCATE PREPARE ddl_task;
SET @task_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task' AND COLUMN_NAME = 'dept_ids');
SET @ddl_task := IF(@task_tbl_exist = 0 OR @task_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_task` ADD COLUMN `dept_ids` VARCHAR(500) DEFAULT NULL COMMENT ''可见部门ID(逗号分隔)'' AFTER `visible_range`');
PREPARE ddl_task FROM @ddl_task;
EXECUTE ddl_task;
DEALLOCATE PREPARE ddl_task;
SET @task_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task' AND COLUMN_NAME = 'role_ids');
SET @ddl_task := IF(@task_tbl_exist = 0 OR @task_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_task` ADD COLUMN `role_ids` VARCHAR(500) DEFAULT NULL COMMENT ''可见角色编码(逗号分隔)'' AFTER `dept_ids`');
PREPARE ddl_task FROM @ddl_task;
EXECUTE ddl_task;
DEALLOCATE PREPARE ddl_task;

-- 已有库升级：任务创建人 create_by（仅创建人或管理员可编辑/删除）（幂等），存量数据回填为归属人
SET @task_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task' AND COLUMN_NAME = 'create_by');
SET @ddl_task := IF(@task_tbl_exist = 0 OR @task_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_task` ADD COLUMN `create_by` VARCHAR(36) DEFAULT NULL COMMENT ''创建人ID'' AFTER `owner_id`');
PREPARE ddl_task FROM @ddl_task;
EXECUTE ddl_task;
DEALLOCATE PREPARE ddl_task;
UPDATE `crm_task` SET `create_by` = `owner_id` WHERE `create_by` IS NULL AND `owner_id` IS NOT NULL;

-- 营销图文表（AI 图文生成 + 多平台发布）
CREATE TABLE IF NOT EXISTS `crm_content` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `title`         VARCHAR(200) NOT NULL,
  `topic`         VARCHAR(200) DEFAULT NULL,
  `platform`      VARCHAR(200) DEFAULT NULL COMMENT '目标平台编码，逗号分隔（多平台发布支持全选）',
  `content`       LONGTEXT     DEFAULT NULL,
  `cover_url`     VARCHAR(500) DEFAULT NULL,
  `status`        VARCHAR(20)  NOT NULL DEFAULT 'draft',
  `publish_status` TEXT         DEFAULT NULL,
  `create_by`     VARCHAR(36)       DEFAULT NULL COMMENT '创建人ID',
  `create_time`   DATETIME     DEFAULT CURRENT_TIMESTAMP,
  `update_time`   DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`       TINYINT      NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_platform` (`platform`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- 通知公告表
CREATE TABLE IF NOT EXISTS `crm_notice` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `title`        VARCHAR(200) NOT NULL,
  `content`      TEXT         DEFAULT NULL,
  `notice_type`  VARCHAR(20)  NOT NULL DEFAULT 'notice',
  `status`       VARCHAR(20)  NOT NULL DEFAULT 'draft',
  `priority`     VARCHAR(10)  NOT NULL DEFAULT 'medium',
  `publisher_id` VARCHAR(36)       DEFAULT NULL COMMENT '发布人ID',
  `publish_time` DATETIME     DEFAULT NULL,
  `visible_range` VARCHAR(20) NOT NULL DEFAULT 'all',
  `dept_ids`     VARCHAR(500) DEFAULT NULL,
  `role_ids`     VARCHAR(500) DEFAULT NULL,
  `cover_url`    VARCHAR(500) DEFAULT NULL,
  `is_top`       TINYINT      NOT NULL DEFAULT 0,
  `create_time`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`      TINYINT      NOT NULL DEFAULT 0,
  `is_demo`      TINYINT      NOT NULL DEFAULT 0 COMMENT '是否演示数据 1-演示数据 0-普通数据',
  PRIMARY KEY (`id`),
  KEY `idx_type` (`notice_type`),
  KEY `idx_status` (`status`),
  KEY `idx_publisher` (`publisher_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- =====================================================
-- 四、字典管理模块
-- =====================================================

CREATE TABLE IF NOT EXISTS `sys_dict_type` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `dict_name`   VARCHAR(50)  NOT NULL,
  `dict_type`   VARCHAR(50)  NOT NULL,
  `status`      TINYINT      NOT NULL DEFAULT 1,
  `remark`      VARCHAR(200) DEFAULT NULL,
  `create_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dict_type` (`dict_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

CREATE TABLE IF NOT EXISTS `sys_dict_data` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `dict_type`   VARCHAR(50)  NOT NULL,
  `dict_label`  VARCHAR(100) NOT NULL,
  `dict_value`  VARCHAR(100) NOT NULL,
  `css_class`   VARCHAR(50)  DEFAULT NULL,
  `sort`        INT          NOT NULL DEFAULT 0,
  `status`      TINYINT      NOT NULL DEFAULT 1,
  `create_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_dict_type` (`dict_type`),
  -- 唯一约束保证 init.sql 每次启动的 INSERT IGNORE 幂等, 避免重复播种膨胀
  UNIQUE KEY `uk_dict_type_label_value` (`dict_type`, `dict_label`, `dict_value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- =====================================================
-- 五、增强模块：智能问答知识库 + 意见反馈
-- =====================================================

-- 智能问答知识库表（右下角智能问答使用本地知识库匹配）
CREATE TABLE IF NOT EXISTS `knowledge_qa` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `question`    VARCHAR(500) NOT NULL,
  `answer`      TEXT         NOT NULL,
  `category`    VARCHAR(100) DEFAULT NULL,
  `keywords`    VARCHAR(500) DEFAULT NULL,
  `enabled`     TINYINT      NOT NULL DEFAULT 1,
  `hit_count`   INT          NOT NULL DEFAULT 0,
  `create_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`     TINYINT      NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- 意见反馈表
CREATE TABLE IF NOT EXISTS `feedback` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL COMMENT '提交用户ID（同 sys_user.id，UUID）',
  `username` varchar(50) DEFAULT NULL,
  `real_name` varchar(50) DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT 0,
  `reply` varchar(500) DEFAULT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- =====================================================
-- 六、授权与支付模块
-- =====================================================

-- 说明：授权记录由授权服务器（license-admin）统一按机器码存管，主项目不落本地库，
-- 历史授权通过 GET /license/records 从服务器查询，故此处不再创建 sys_license 本地表。

-- =====================================================
-- 七、初始化数据（幂等 INSERT）
-- =====================================================

-- 部门数据
INSERT IGNORE INTO `sys_dept` (`id`, `parent_id`, `dept_name`, `leader`, `phone`, `sort`) VALUES('1fa48be0-846e-4a2c-a8d2-8d8de6bd1274', '9de894ba-ef2b-4256-83b5-ab3bea0271e6',  '总公司',  '张总',  '13800000001',  0), ('9b919493-0d01-4f0c-8cb1-f01558b5db30', '1fa48be0-846e-4a2c-a8d2-8d8de6bd1274',  '销售部',  '李经理',  '13800000002',  1), ('9e39abde-d1f6-4f30-84b5-1d38cc783bb0', '1fa48be0-846e-4a2c-a8d2-8d8de6bd1274',  '市场部',  '王经理',  '13800000003',  2), ('cce1bc90-a9ea-4d85-b7f8-af377034a466', '1fa48be0-846e-4a2c-a8d2-8d8de6bd1274',  '技术部',  '赵经理',  '13800000004',  3)ON DUPLICATE KEY UPDATE `dept_name` = VALUES(`dept_name`), `leader` = VALUES(`leader`), `phone` = VALUES(`phone`);
-- 修复历史种子数据：总公司父节点指向了一个不存在的虚拟 ID，统一归到根 "0"
UPDATE `sys_dept` SET `parent_id` = '0' WHERE `parent_id` = '9de894ba-ef2b-4256-83b5-ab3bea0271e6';

-- 客户迁移菜单（挂在「客户管理」下，用于其它系统客户/联系人/跟进记录的批量导入）

-- 兼容旧数据：菜单名由「客户迁移导入」改为「客户迁移」
UPDATE `sys_menu` SET `menu_name` = '客户迁移' WHERE `id` = '7e1f2a3b-4c5d-4e6f-8a9b-0c1d2e3f4a5b';
-- 兼容旧数据：菜单名由「联系人管理」改为「联系人」
UPDATE `sys_menu` SET `menu_name` = '联系人' WHERE `id` = 'c66185d9-2323-4642-8739-3669079faad9';

-- 升级：注册「客户统计」菜单并授权所有角色（幂等）
INSERT IGNORE INTO `sys_menu` (`id`, `parent_id`, `menu_name`, `path`, `component`, `perms`, `icon`, `menu_type`, `sort`, `visible`) VALUES ('c0de5757-0000-4000-8000-00000000c101', 'bc579656-08bf-4ece-a7f3-12abd34546bf', '客户统计', '/customer/statistics', 'customer/statistics', 'customer:statistics', 'Histogram', 'C', 3, 1);
UPDATE `sys_menu` SET `sort` = 4 WHERE `id` = '2ed78c39-ad08-48e4-8e32-8d5279995e6e' AND `sort` = 3;
UPDATE `sys_menu` SET `sort` = 5 WHERE `id` = 'a88cac82-c8ae-46c0-a882-b450573241a9' AND `sort` = 4;
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`) SELECT r.id, m.id FROM `sys_role` r, `sys_menu` m WHERE m.`perms` = 'customer:statistics' AND NOT EXISTS (SELECT 1 FROM `sys_role_menu` x WHERE x.role_id = r.id AND x.menu_id = m.id);

-- 客户迁移：默认仅授权给超级管理员（其它角色如需开放，可在「系统设置-角色管理」中分配菜单）

-- 已有库升级：客户迁移默认仅超级管理员可见（移除其它角色的授权，幂等）
DELETE FROM `sys_role_menu`
WHERE `menu_id` = '7e1f2a3b-4c5d-4e6f-8a9b-0c1d2e3f4a5b'
  AND `role_id` <> '5e627401-33ef-4ad8-ac15-86a0a3b76d4b';

-- 角色数据
INSERT IGNORE INTO `sys_role` (`id`, `role_name`, `role_code`, `description`) VALUES('5e627401-33ef-4ad8-ac15-86a0a3b76d4b',  '超级管理员',  'admin',  '拥有所有权限'), ('e9c3d346-9453-4798-8b5b-544025454a63',  '销售经理',  'sales_manager',  '销售管理权限'), ('23358b9b-f363-49e3-b0bf-9f8f332b8f91',  '销售员',  'sales',  '基础销售权限'), ('42128721-7865-4a9e-9903-5db1195c36ca',  '市场管理员',  'marketing_admin',  '销售线索管理权限')ON DUPLICATE KEY UPDATE `role_name` = VALUES(`role_name`), `description` = VALUES(`description`);

-- 用户数据 (密码均为 123456 的BCrypt加密)
INSERT IGNORE INTO `sys_user` (`id`, `username`, `password`, `real_name`, `phone`, `email`, `dept_id`) VALUES('e3a5a5d9-ee91-482c-90b5-6b33466eb7e6',  'admin',  '$2b$10$BPpYm8v4hLtXS3DwiQnf1.4BRkYH1jy5weWemJPfzRsLzFjJaIiTy',  '超级管理员',  '13800000001',  'admin@crm.com', '1fa48be0-846e-4a2c-a8d2-8d8de6bd1274'), ('a3578855-6602-4dc7-bb65-c89d861e1150',  'sales01',  '$2b$10$BPpYm8v4hLtXS3DwiQnf1.4BRkYH1jy5weWemJPfzRsLzFjJaIiTy',  '张三',  '13800000002',  'zhangsan@crm.com', '9b919493-0d01-4f0c-8cb1-f01558b5db30'), ('7e9a1491-0adf-4e67-a06d-d7f7f2ff905a',  'sales02',  '$2b$10$BPpYm8v4hLtXS3DwiQnf1.4BRkYH1jy5weWemJPfzRsLzFjJaIiTy',  '李四',  '13800000003',  'lisi@crm.com', '9b919493-0d01-4f0c-8cb1-f01558b5db30'), ('232c070a-8e3a-499e-bddf-44cc22ccc810',  'market01',  '$2b$10$BPpYm8v4hLtXS3DwiQnf1.4BRkYH1jy5weWemJPfzRsLzFjJaIiTy',  '王五',  '13800000004',  'market01@crm.com', '9e39abde-d1f6-4f30-84b5-1d38cc783bb0')ON DUPLICATE KEY UPDATE `username` = VALUES(`username`), `real_name` = VALUES(`real_name`), `phone` = VALUES(`phone`), `email` = VALUES(`email`);

-- 用户角色关联
INSERT IGNORE INTO `sys_user_role` (`user_id`, `role_id`) VALUES('e3a5a5d9-ee91-482c-90b5-6b33466eb7e6', '5e627401-33ef-4ad8-ac15-86a0a3b76d4b'), ('a3578855-6602-4dc7-bb65-c89d861e1150', 'e9c3d346-9453-4798-8b5b-544025454a63'), ('7e9a1491-0adf-4e67-a06d-d7f7f2ff905a', '23358b9b-f363-49e3-b0bf-9f8f332b8f91'), ('232c070a-8e3a-499e-bddf-44cc22ccc810', '42128721-7865-4a9e-9903-5db1195c36ca');

-- 菜单数据（与前端左侧菜单保持一致）
-- 修复历史种子数据：一级菜单父节点指向了一个不存在的虚拟根 ID，统一归到根 "0"
UPDATE `sys_menu` SET `parent_id` = '0' WHERE `parent_id` = '9fd3f510-d365-428f-a2c6-a260d2150ba5';


-- ==========================================================
-- 菜单基础数据（v2.6.7 完整基线：目录 8 + 页面 37 + 按钮 59）
-- 此前缺失导致全新部署只有升级段新增的菜单，侧栏显示不全
-- ==========================================================
INSERT IGNORE INTO `sys_menu` (`id`, `parent_id`, `menu_name`, `path`, `component`, `perms`, `icon`, `menu_type`, `sort`, `visible`, `create_time`, `update_time`) VALUES ('03c241fa-d111-494f-b195-7d0fefbd8377','95712601-b69d-4753-8542-d6577e238030','系统设置','/system/setting','system/setting','system:setting:list','Tools','C',0,1,'2026-10-30 18:31:57','2026-11-03 09:47:46'),('05417629-45e1-4fca-9580-3b5667f0a517','31cb7fad-a793-4e88-8b19-59f2799f4904','销售线索','/opportunity/list','opportunity/list','opportunity:list','Money','C',2,1,'2026-10-30 18:31:57','2026-10-30 18:31:57'),('05496151-edd4-4ec9-828b-4760cc5059a0','a0000000-0000-4000-8000-000000000001','菜单管理','/system/menu','system/menu','system:menu:list','Menu','C',3,1,'2026-10-30 18:31:57','2026-11-02 17:23:34'),('05c31982-5c49-46b2-beb9-a8087d033c61','6bfb7936-2cbc-46cc-b3c4-3a017710f4b4','删除活动',NULL,NULL,'marketing:delete',NULL,'F',3,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('06370b74-181e-44cd-9f0e-b758713a761e','94b9437a-be3d-481e-8e51-3cb2bc710cdc','编辑客户',NULL,NULL,'customer:edit',NULL,'F',2,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('08f640d7-759a-43a3-852c-1e1a41513ae5','998a0054-3db6-4110-8076-4c5a33dc964f','新增公告',NULL,NULL,'notice:add',NULL,'F',1,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('0e99764b-52b8-4fee-96ac-49f14689dbd9','94b9437a-be3d-481e-8e51-3cb2bc710cdc','放入公海',NULL,NULL,'customer:release',NULL,'F',4,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('170ee1fb-daa8-498f-87e5-50cf96f52645','9755d31f-1a2f-4a26-87a6-9e0e0347050d','合同管理','/contract/list','contract/list','contract:list','Document','C',5,1,'2026-10-30 18:31:57','2026-11-03 19:03:16'),('18ae961d-37d2-4e45-a3c2-d333a9ecb3bc','31cb7fad-a793-4e88-8b19-59f2799f4904','商机来源','/opportunity-intel/crawl-source','opportunity/crawlSource','opportunity:crawl','Promotion','C',11,1,'2026-10-30 18:31:57','2026-11-02 12:36:44'),('1bd8b357-0c22-40e3-a9b8-6fa1671a5a35','0','首页','/dashboard','dashboard/index',NULL,'Odometer','C',0,1,'2026-10-30 18:31:57','2026-11-02 11:46:06'),('1c6a600b-b222-4546-9cae-94c592dabf92','05417629-45e1-4fca-9580-3b5667f0a517','删除机会',NULL,NULL,'opportunity:delete',NULL,'F',3,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('1d32fdc6-bf1e-4a8f-9e11-022761606182','bbc9e7f3-de9c-4f73-8c9d-fd72dc137005','编辑字典',NULL,NULL,'system:dict:edit',NULL,'F',2,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('24af04b7-ad01-4ed2-87f5-ef8b3e67e471','170ee1fb-daa8-498f-87e5-50cf96f52645','删除合同',NULL,NULL,'contract:delete',NULL,'F',3,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('28b2ae56-a0d4-416d-b46a-ba505438153c','afb1e278-41d8-4280-bdbf-af4e28e3cb99','新增图文',NULL,NULL,'content:add',NULL,'F',1,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('28c12497-b8eb-43c1-8211-ec6204433c47','94b9437a-be3d-481e-8e51-3cb2bc710cdc','导入客户',NULL,NULL,'customer:import',NULL,'F',4,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('28e40cbf-da57-441d-b142-94dcac83df25','998a0054-3db6-4110-8076-4c5a33dc964f','撤销公告',NULL,NULL,'notice:cancel',NULL,'F',5,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('2978c838-501d-4288-9286-1e6398f2c000','05417629-45e1-4fca-9580-3b5667f0a517','编辑机会',NULL,NULL,'opportunity:edit',NULL,'F',2,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('2b162177-9974-4c94-ae03-3a9e159eb9b6','341e1368-bbd5-41fb-9602-79a8e6121bf1','编辑任务',NULL,NULL,'task:edit',NULL,'F',2,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('2d4635a1-eb07-40d2-a223-f671d772ea31','a88cac82-c8ae-46c0-a882-b450573241a9','删除跟进',NULL,NULL,'followup:delete',NULL,'F',2,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('2ed78c39-ad08-48e4-8e32-8d5279995e6e','bc579656-08bf-4ece-a7f3-12abd34546bf','联系人','/contact/list','contact/list','contact:list','Avatar','C',4,1,'2026-10-30 18:31:57','2026-11-03 17:25:04'),('31305afc-375c-4950-b93d-cafe5160a98c','170ee1fb-daa8-498f-87e5-50cf96f52645','导入合同',NULL,NULL,'contract:import',NULL,'F',4,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('31cb7fad-a793-4e88-8b19-59f2799f4904','0','销售管理',NULL,NULL,NULL,'TrendCharts','M',3,1,'2026-10-30 18:31:57','2026-11-03 19:15:52'),('341e1368-bbd5-41fb-9602-79a8e6121bf1','0','任务提醒','/task/list','task/list','task:list','AlarmClock','C',7,1,'2026-10-30 18:31:57','2026-11-02 11:46:06'),('3ce675c4-7c88-4a19-9693-19b0299ac2f1','bc579656-08bf-4ece-a7f3-12abd34546bf','客户公海','/customer/pool','customer/pool','customer:pool','Ship','C',1,1,'2026-10-30 18:31:57','2026-10-30 18:31:57'),('40c40745-4314-473c-af74-5c97ca99d976','a0000000-0000-4000-8000-000000000001','角色管理','/system/role','system/role','system:role:list','UserFilled','C',2,1,'2026-10-30 18:31:57','2026-11-02 17:23:34'),('40f24b2c-723e-440f-ab7f-525233c51e7b','94b9437a-be3d-481e-8e51-3cb2bc710cdc','查看联系人',NULL,NULL,'customer:contact',NULL,'F',6,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('4553133d-0f29-40a8-8d83-7e1861fad2a2','341e1368-bbd5-41fb-9602-79a8e6121bf1','删除任务',NULL,NULL,'task:delete',NULL,'F',3,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('48d70193-d9f7-4392-ba54-2f119e037018','a88cac82-c8ae-46c0-a882-b450573241a9','新增跟进',NULL,NULL,'followup:add',NULL,'F',1,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('4b339ff5-e05d-4d42-872c-4d472e9015aa','6bfb7936-2cbc-46cc-b3c4-3a017710f4b4','新增活动',NULL,NULL,'marketing:add',NULL,'F',1,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('4cb2d91e-0464-48af-b502-31847258ae29','998a0054-3db6-4110-8076-4c5a33dc964f','删除公告',NULL,NULL,'notice:delete',NULL,'F',3,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('50685a4e-eead-4988-b9a5-d1261badc2e8','31cb7fad-a793-4e88-8b19-59f2799f4904','商机情报','/opportunity-intel/list','opportunity/intel','opportunity:intel','Lightning','C',1,1,'2026-10-30 18:31:57','2026-10-30 18:31:57'),('52db26c7-8350-4c20-8920-3189e068f4bc','9755d31f-1a2f-4a26-87a6-9e0e0347050d','合同模板','/contract/template','contractTemplate/list','contract:template','Files','C',2,1,'2026-10-30 18:31:57','2026-10-30 18:31:57'),('533b9ca5-2e89-4331-b5f7-8791dadff927','170ee1fb-daa8-498f-87e5-50cf96f52645','编辑合同',NULL,NULL,'contract:edit',NULL,'F',2,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('554453ef-b85b-4327-b20f-6747fe4f7047','a0000000-0000-4000-8000-000000000001','用户管理','/system/user','system/user','system:user:list','User','C',1,1,'2026-10-30 18:31:57','2026-11-02 17:23:34'),('5919e24b-ce47-490e-8425-4a63b1899c57','bbc9e7f3-de9c-4f73-8c9d-fd72dc137005','新增字典',NULL,NULL,'system:dict:add',NULL,'F',1,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('5edb990b-14f1-421e-b2b9-97854ca31c22','afb1e278-41d8-4280-bdbf-af4e28e3cb99','删除图文',NULL,NULL,'content:delete',NULL,'F',3,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('66b0d6e2-f276-4de6-b597-c2fdbaf332d2','bc579656-08bf-4ece-a7f3-12abd34546bf','领取客户',NULL,NULL,'customer:claim',NULL,'F',1,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('69987783-01d9-4e66-8610-1532bd445e46','998a0054-3db6-4110-8076-4c5a33dc964f','发布公告',NULL,NULL,'notice:publish',NULL,'F',4,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('6a2c7846-a53b-4112-8e83-3b602e10d04e','d5785049-b4c1-4044-8a5d-f926380ada40','新增部门',NULL,NULL,'system:dept:add',NULL,'F',1,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('6bfb7936-2cbc-46cc-b3c4-3a017710f4b4','be976ef2-3265-457d-8890-6a7ba8510afb','营销活动','/marketing/list','marketing/list','marketing:list','Flag','C',2,1,'2026-10-30 18:31:57','2026-10-30 18:31:57'),('6e7218fb-94f0-4526-9d3e-82a8ba2b5dd0','40c40745-4314-473c-af74-5c97ca99d976','新增角色',NULL,NULL,'system:role:add',NULL,'F',1,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('738b5bb6-096c-4ed4-9dcb-b419daed2c6a','0','本地知识库','/knowledge/list','knowledge/list','knowledge:list','Collection','C',2,1,'2026-10-30 18:31:57','2026-11-03 15:32:35'),('74064fcb-ace8-496f-b92d-f47bd9785e64','998a0054-3db6-4110-8076-4c5a33dc964f','编辑公告',NULL,NULL,'notice:edit',NULL,'F',2,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('7b35afb1-ab79-4b74-92ae-0ef87b60898c','6bfb7936-2cbc-46cc-b3c4-3a017710f4b4','编辑活动',NULL,NULL,'marketing:edit',NULL,'F',2,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('7d995d45-ac5f-4d2e-a825-8f21a6dc301a','95712601-b69d-4753-8542-d6577e238030','操作日志','/system/operLog','system/operLog','system:operlog:list','Memo','C',3,1,'2026-10-30 18:31:57','2026-11-02 17:51:11'),('8002bed2-7cde-48ff-87fa-831ff24ce1eb','2ed78c39-ad08-48e4-8e32-8d5279995e6e','新增联系人',NULL,NULL,'contact:add',NULL,'F',1,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('80e8a65c-9b1d-4171-959f-3c7d604f4012','05417629-45e1-4fca-9580-3b5667f0a517','新增机会',NULL,NULL,'opportunity:add',NULL,'F',1,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('878b9e2a-3030-4419-93d4-c7d0bc9832c1','2ed78c39-ad08-48e4-8e32-8d5279995e6e','编辑联系人',NULL,NULL,'contact:edit',NULL,'F',2,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('8de3d8e9-0b66-40c3-bcf6-9ca303d32a4d','d5785049-b4c1-4044-8a5d-f926380ada40','编辑部门',NULL,NULL,'system:dept:edit',NULL,'F',2,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('94b9437a-be3d-481e-8e51-3cb2bc710cdc','bc579656-08bf-4ece-a7f3-12abd34546bf','我的客户','/customer/list','customer/list','customer:list','UserFilled','C',2,1,'2026-10-30 18:31:57','2026-10-30 18:31:57'),('94db16f9-98cc-49e6-8455-84f8467b80cb','40c40745-4314-473c-af74-5c97ca99d976','删除角色',NULL,NULL,'system:role:delete',NULL,'F',3,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('95712601-b69d-4753-8542-d6577e238030','0','系统管理','/system',NULL,NULL,'Setting','M',99,1,'2026-10-30 18:31:57','2026-11-02 11:46:06'),('96c39b32-1d37-45ed-a6cf-0f35938c2281','50685a4e-eead-4988-b9a5-d1261badc2e8','手动抓取',NULL,NULL,'opportunity:crawl',NULL,'F',1,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('97033740-e0f1-4e1f-afdf-75b187e461e6','94b9437a-be3d-481e-8e51-3cb2bc710cdc','查看公开信息',NULL,NULL,'customer:publicInfo',NULL,'F',7,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('9755d31f-1a2f-4a26-87a6-9e0e0347050d','0','合同管理','/contract',NULL,NULL,'Document','M',5,1,'2026-10-30 18:31:57','2026-11-02 11:46:06'),('998a0054-3db6-4110-8076-4c5a33dc964f','0','通知公告','/notice/list','notice/list','notice:list','Bell','C',8,1,'2026-10-30 18:31:57','2026-11-02 11:46:06'),('a0000000-0000-4000-8000-000000000001','0','用户管理','/usermgmt',NULL,NULL,'User','M',98,1,'2026-11-02 17:06:58','2026-11-02 17:23:34'),('a2cb5f08-76cf-4bea-a8bf-3c2e05f8e3e4','40c40745-4314-473c-af74-5c97ca99d976','配置权限',NULL,NULL,'system:role:grant',NULL,'F',4,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('a8686b6c-f87a-4b91-82e8-0b09e3ab3624','94b9437a-be3d-481e-8e51-3cb2bc710cdc','客户跟进',NULL,NULL,'customer:follow',NULL,'F',3,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('a88cac82-c8ae-46c0-a882-b450573241a9','bc579656-08bf-4ece-a7f3-12abd34546bf','跟进记录','/followup/list','followup/list','followup:list','ChatLineRound','C',5,1,'2026-10-30 18:31:57','2026-11-03 17:25:04'),('a97b39dc-f150-45b3-b04c-9aeb0f9fe439','170ee1fb-daa8-498f-87e5-50cf96f52645','导出合同',NULL,NULL,'contract:export',NULL,'F',5,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e01','0','专家分析','/workbuddy/expert','workbuddy/index','workbuddy:list','Headset','C',1,1,'2026-10-30 18:51:35','2026-11-03 15:32:35'),('aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e03','31cb7fad-a793-4e88-8b19-59f2799f4904','销售排行榜','/contract/rank','contract/rank','contract:rank','Histogram','C',3,1,'2026-10-30 18:51:35','2026-10-30 19:14:08'),('aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e05','be976ef2-3265-457d-8890-6a7ba8510afb','客户群发','/marketing/blast','marketing/blast','content:push','Promotion','C',3,1,'2026-10-30 18:52:23','2026-10-30 18:54:15'),('aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e07','31cb7fad-a793-4e88-8b19-59f2799f4904','销售目标','/contract/target','contract/target','contract:target:list','Aim','C',4,1,'2026-10-30 19:18:48','2026-10-30 19:18:48'),('afb1e278-41d8-4280-bdbf-af4e28e3cb99','be976ef2-3265-457d-8890-6a7ba8510afb','营销图文','/content/list','content/list','content:list','Picture','C',1,1,'2026-10-30 18:31:57','2026-10-30 18:31:57'),('b03875ba-1726-4f37-bee4-6b74a1ab356c','94b9437a-be3d-481e-8e51-3cb2bc710cdc','删除客户',NULL,NULL,'customer:delete',NULL,'F',3,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('b184f608-f719-49bb-a1ac-83ab0bbf1fdd','afb1e278-41d8-4280-bdbf-af4e28e3cb99','发布图文',NULL,NULL,'content:publish',NULL,'F',4,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('b63c3df6-eee4-4eb1-a79e-af09b7ab7dad','40c40745-4314-473c-af74-5c97ca99d976','编辑角色',NULL,NULL,'system:role:edit',NULL,'F',2,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('b8e2c5d1-7f4a-4c39-9a0e-5d6f1c8b3e21','170ee1fb-daa8-498f-87e5-50cf96f52645','合同回款记录',NULL,NULL,'contract:payment',NULL,'F',6,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('bbc9e7f3-de9c-4f73-8c9d-fd72dc137005','95712601-b69d-4753-8542-d6577e238030','字典管理','/system/dict','system/dict','system:dict:list','Collection','C',1,1,'2026-10-30 18:31:57','2026-11-02 17:06:58'),('bc579656-08bf-4ece-a7f3-12abd34546bf','0','客户管理','/customer',NULL,NULL,'User','M',4,1,'2026-10-30 18:31:57','2026-11-02 11:46:06'),('be976ef2-3265-457d-8890-6a7ba8510afb','0','营销管理','/marketing',NULL,NULL,'Promotion','M',6,1,'2026-10-30 18:31:57','2026-11-02 11:46:06'),('bfc7be16-e02f-4724-91b8-fe65b6525ea4','dcaf4b94-6b6b-49dc-89c7-e600c5fc64c1','删除反馈',NULL,NULL,'system:feedback:delete',NULL,'F',2,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('c0de5757-0000-4000-8000-00000000c101','bc579656-08bf-4ece-a7f3-12abd34546bf','客户统计','/customer/statistics','customer/statistics','customer:statistics','Histogram','C',3,1,'2026-11-03 17:25:04','2026-11-03 17:25:04'),('c23c500d-ea43-42bc-bcdf-7115b38e5258','05496151-edd4-4ec9-828b-4760cc5059a0','新增菜单',NULL,NULL,'system:menu:add',NULL,'F',1,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('c5153423-118a-49f5-b670-8a51f90e9a84','341e1368-bbd5-41fb-9602-79a8e6121bf1','完成任务',NULL,NULL,'task:complete',NULL,'F',4,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('c82ca0a8d67f11f1925b1d4813846157','be976ef2-3265-457d-8890-6a7ba8510afb','信息来源','/marketing/crawl-source','opportunity/crawlSource',NULL,'Promotion','C',4,1,'2026-11-02 13:39:33','2026-11-02 13:39:33'),('cc4f7b49-4c22-44ba-b142-9ee0321621be','bbc9e7f3-de9c-4f73-8c9d-fd72dc137005','删除字典',NULL,NULL,'system:dict:delete',NULL,'F',3,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('d409af4b-028f-43b8-b2db-1a38d56e9fbf','94b9437a-be3d-481e-8e51-3cb2bc710cdc','新增客户',NULL,NULL,'customer:add',NULL,'F',1,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('d499192f-caf9-48af-b71e-c0a8f0e28fbb','341e1368-bbd5-41fb-9602-79a8e6121bf1','新增任务',NULL,NULL,'task:add',NULL,'F',1,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('d55a494a-6a07-40c2-ae32-bea01cdfa39b','94b9437a-be3d-481e-8e51-3cb2bc710cdc','导出客户',NULL,NULL,'customer:export',NULL,'F',5,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('d5785049-b4c1-4044-8a5d-f926380ada40','a0000000-0000-4000-8000-000000000001','部门管理','/system/dept','system/dept','system:dept:list','OfficeBuilding','C',4,1,'2026-10-30 18:31:57','2026-11-02 17:23:34'),('db378705-f950-4473-ba10-042a737d8d46','afb1e278-41d8-4280-bdbf-af4e28e3cb99','编辑图文',NULL,NULL,'content:edit',NULL,'F',2,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('dcaf4b94-6b6b-49dc-89c7-e600c5fc64c1','95712601-b69d-4753-8542-d6577e238030','意见反馈','/system/feedback','system/feedback','system:feedback:list','ChatDotRound','C',2,1,'2026-10-30 18:31:57','2026-11-02 17:51:11'),('df0321d7-df8c-4f3c-ae2e-61e2b016dfa9','dcaf4b94-6b6b-49dc-89c7-e600c5fc64c1','处理反馈',NULL,NULL,'system:feedback:handle',NULL,'F',1,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('e085ffc1-35ed-4319-9e2a-696d01719d68','2ed78c39-ad08-48e4-8e32-8d5279995e6e','删除联系人',NULL,NULL,'contact:delete',NULL,'F',3,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('e51ba417-5c7a-4878-af83-4eb0c4dec155','05496151-edd4-4ec9-828b-4760cc5059a0','编辑菜单',NULL,NULL,'system:menu:edit',NULL,'F',2,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('f18576aa-57c7-40e4-b490-366aab6905fe','d5785049-b4c1-4044-8a5d-f926380ada40','删除部门',NULL,NULL,'system:dept:delete',NULL,'F',3,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('f2366f1d-2bcc-46bd-b06d-c1b5b657a02d','95712601-b69d-4753-8542-d6577e238030','运维监控','/system/monitor','system/monitor','system:monitor:list','Monitor','C',4,1,'2026-10-30 18:31:57','2026-11-02 17:51:11'),('f2c1a9b0-0001-4a2c-8d2a-000000000001','0','我的日程','/schedule/list','schedule/list',NULL,'Calendar','C',9,1,'2026-09-29 12:15:44','2026-10-30 21:37:23'),('f2c1a9b0-0002-4a2c-8d2a-000000000002','f2c1a9b0-0009-4a2c-8d2a-000000000009','消息通知','/message/notify','message/notify',NULL,'Message','C',1,1,'2026-09-29 12:15:44','2026-09-29 13:23:24'),('f2c1a9b0-0003-4a2c-8d2a-000000000003','f2c1a9b0-0009-4a2c-8d2a-000000000009','消息模板','/message/template','message/template',NULL,'Document','C',2,1,'2026-09-29 12:15:44','2026-09-29 13:23:24'),('f2c1a9b0-0004-4a2c-8d2a-000000000004','0','考勤管理','/attendance',NULL,NULL,'Clock','M',12,1,'2026-09-29 12:15:44','2026-09-29 13:08:36'),('f2c1a9b0-0005-4a2c-8d2a-000000000005','f2c1a9b0-0004-4a2c-8d2a-000000000004','签到','/attendance/sign','attendance/sign',NULL,'Clock','C',1,1,'2026-09-29 12:15:44','2026-09-29 12:15:44'),('f2c1a9b0-0006-4a2c-8d2a-000000000006','f2c1a9b0-0004-4a2c-8d2a-000000000004','签到管理','/attendance/manage','attendance/manage',NULL,'List','C',2,1,'2026-09-29 12:15:44','2026-09-29 12:15:44'),('f2c1a9b0-0009-4a2c-8d2a-000000000009','0','消息管理',NULL,NULL,NULL,'Bell','M',11,1,'2026-09-29 13:23:24','2026-10-30 21:37:23'),('f2c1a9b0-000a-4a2c-8d2a-00000000000a','f2c1a9b0-0009-4a2c-8d2a-000000000009','我的消息','/message/my','message/my',NULL,'Bell','C',3,1,'2026-09-30 11:16:23','2026-10-07 09:30:39'),('f3c0a9b0-1102-4a2c-8d2a-000000000002','be976ef2-3265-457d-8890-6a7ba8510afb','GEO 中心','/geo/index','geo/index','geo:view','Odometer','C',0,1,'2026-09-30 15:27:24','2026-11-02 18:03:26'),('f3c0a9b0-1103-4a2c-8d2a-000000000003','f3c0a9b0-1102-4a2c-8d2a-000000000002','手动巡检',NULL,NULL,'geo:patrol',NULL,'F',1,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('f3c0a9b0-1104-4a2c-8d2a-000000000004','f3c0a9b0-1102-4a2c-8d2a-000000000002','GEO 配置管理',NULL,NULL,'geo:edit',NULL,'F',2,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('f77057e3-c8d4-4fd7-95ec-b4fe83e0b682','170ee1fb-daa8-498f-87e5-50cf96f52645','新增合同',NULL,NULL,'contract:add',NULL,'F',1,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('f8ffd8cf-76d5-45f5-9f99-be1b78ea46d1','05417629-45e1-4fca-9580-3b5667f0a517','推进阶段',NULL,NULL,'opportunity:stage',NULL,'F',4,1,'2026-11-03 19:17:52','2026-11-03 19:17:52'),('fd325f8b-8a56-483b-bb7b-795c5b651e22','05496151-edd4-4ec9-828b-4760cc5059a0','删除菜单',NULL,NULL,'system:menu:delete',NULL,'F',3,1,'2026-11-03 19:17:52','2026-11-03 19:17:52');

-- 角色授权基线（与菜单基线配套，IGNORE 幂等）
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`) VALUES ('018fa6c1-bbfd-40aa-84fd-08e771236630','05417629-45e1-4fca-9580-3b5667f0a517'),('018fa6c1-bbfd-40aa-84fd-08e771236630','1bd8b357-0c22-40e3-a9b8-6fa1671a5a35'),('018fa6c1-bbfd-40aa-84fd-08e771236630','2ed78c39-ad08-48e4-8e32-8d5279995e6e'),('018fa6c1-bbfd-40aa-84fd-08e771236630','31cb7fad-a793-4e88-8b19-59f2799f4904'),('018fa6c1-bbfd-40aa-84fd-08e771236630','94b9437a-be3d-481e-8e51-3cb2bc710cdc'),('018fa6c1-bbfd-40aa-84fd-08e771236630','a88cac82-c8ae-46c0-a882-b450573241a9'),('018fa6c1-bbfd-40aa-84fd-08e771236630','bc579656-08bf-4ece-a7f3-12abd34546bf'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','05417629-45e1-4fca-9580-3b5667f0a517'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','0e99764b-52b8-4fee-96ac-49f14689dbd9'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','1bd8b357-0c22-40e3-a9b8-6fa1671a5a35'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','1c6a600b-b222-4546-9cae-94c592dabf92'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','2978c838-501d-4288-9286-1e6398f2c000'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','31cb7fad-a793-4e88-8b19-59f2799f4904'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','3ce675c4-7c88-4a19-9693-19b0299ac2f1'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','50685a4e-eead-4988-b9a5-d1261badc2e8'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','66b0d6e2-f276-4de6-b597-c2fdbaf332d2'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','80e8a65c-9b1d-4171-959f-3c7d604f4012'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','94b9437a-be3d-481e-8e51-3cb2bc710cdc'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','96c39b32-1d37-45ed-a6cf-0f35938c2281'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','97033740-e0f1-4e1f-afdf-75b187e461e6'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','a8686b6c-f87a-4b91-82e8-0b09e3ab3624'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e01'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e03'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e05'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','afb1e278-41d8-4280-bdbf-af4e28e3cb99'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','bc579656-08bf-4ece-a7f3-12abd34546bf'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','be976ef2-3265-457d-8890-6a7ba8510afb'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','c0de5757-0000-4000-8000-00000000c101'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','f2c1a9b0-0001-4a2c-8d2a-000000000001'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','f2c1a9b0-0004-4a2c-8d2a-000000000004'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','f2c1a9b0-0005-4a2c-8d2a-000000000005'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','f2c1a9b0-0006-4a2c-8d2a-000000000006'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','f2c1a9b0-0009-4a2c-8d2a-000000000009'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','f2c1a9b0-000a-4a2c-8d2a-00000000000a'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','f3c0a9b0-1102-4a2c-8d2a-000000000002'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','f3c0a9b0-1103-4a2c-8d2a-000000000003'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','f3c0a9b0-1104-4a2c-8d2a-000000000004'),('23358b9b-f363-49e3-b0bf-9f8f332b8f91','f8ffd8cf-76d5-45f5-9f99-be1b78ea46d1'),('42128721-7865-4a9e-9903-5db1195c36ca','05417629-45e1-4fca-9580-3b5667f0a517'),('42128721-7865-4a9e-9903-5db1195c36ca','0e99764b-52b8-4fee-96ac-49f14689dbd9'),('42128721-7865-4a9e-9903-5db1195c36ca','1bd8b357-0c22-40e3-a9b8-6fa1671a5a35'),('42128721-7865-4a9e-9903-5db1195c36ca','1c6a600b-b222-4546-9cae-94c592dabf92'),('42128721-7865-4a9e-9903-5db1195c36ca','2978c838-501d-4288-9286-1e6398f2c000'),('42128721-7865-4a9e-9903-5db1195c36ca','31cb7fad-a793-4e88-8b19-59f2799f4904'),('42128721-7865-4a9e-9903-5db1195c36ca','3ce675c4-7c88-4a19-9693-19b0299ac2f1'),('42128721-7865-4a9e-9903-5db1195c36ca','50685a4e-eead-4988-b9a5-d1261badc2e8'),('42128721-7865-4a9e-9903-5db1195c36ca','66b0d6e2-f276-4de6-b597-c2fdbaf332d2'),('42128721-7865-4a9e-9903-5db1195c36ca','80e8a65c-9b1d-4171-959f-3c7d604f4012'),('42128721-7865-4a9e-9903-5db1195c36ca','94b9437a-be3d-481e-8e51-3cb2bc710cdc'),('42128721-7865-4a9e-9903-5db1195c36ca','96c39b32-1d37-45ed-a6cf-0f35938c2281'),('42128721-7865-4a9e-9903-5db1195c36ca','97033740-e0f1-4e1f-afdf-75b187e461e6'),('42128721-7865-4a9e-9903-5db1195c36ca','a8686b6c-f87a-4b91-82e8-0b09e3ab3624'),('42128721-7865-4a9e-9903-5db1195c36ca','aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e01'),('42128721-7865-4a9e-9903-5db1195c36ca','aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e05'),('42128721-7865-4a9e-9903-5db1195c36ca','afb1e278-41d8-4280-bdbf-af4e28e3cb99'),('42128721-7865-4a9e-9903-5db1195c36ca','bc579656-08bf-4ece-a7f3-12abd34546bf'),('42128721-7865-4a9e-9903-5db1195c36ca','be976ef2-3265-457d-8890-6a7ba8510afb'),('42128721-7865-4a9e-9903-5db1195c36ca','c0de5757-0000-4000-8000-00000000c101'),('42128721-7865-4a9e-9903-5db1195c36ca','f2c1a9b0-0001-4a2c-8d2a-000000000001'),('42128721-7865-4a9e-9903-5db1195c36ca','f2c1a9b0-0004-4a2c-8d2a-000000000004'),('42128721-7865-4a9e-9903-5db1195c36ca','f2c1a9b0-0005-4a2c-8d2a-000000000005'),('42128721-7865-4a9e-9903-5db1195c36ca','f2c1a9b0-0006-4a2c-8d2a-000000000006'),('42128721-7865-4a9e-9903-5db1195c36ca','f2c1a9b0-0009-4a2c-8d2a-000000000009'),('42128721-7865-4a9e-9903-5db1195c36ca','f2c1a9b0-000a-4a2c-8d2a-00000000000a'),('42128721-7865-4a9e-9903-5db1195c36ca','f3c0a9b0-1102-4a2c-8d2a-000000000002'),('42128721-7865-4a9e-9903-5db1195c36ca','f3c0a9b0-1103-4a2c-8d2a-000000000003'),('42128721-7865-4a9e-9903-5db1195c36ca','f3c0a9b0-1104-4a2c-8d2a-000000000004'),('42128721-7865-4a9e-9903-5db1195c36ca','f8ffd8cf-76d5-45f5-9f99-be1b78ea46d1'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','03c241fa-d111-494f-b195-7d0fefbd8377'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','05417629-45e1-4fca-9580-3b5667f0a517'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','05496151-edd4-4ec9-828b-4760cc5059a0'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','05c31982-5c49-46b2-beb9-a8087d033c61'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','06370b74-181e-44cd-9f0e-b758713a761e'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','08f640d7-759a-43a3-852c-1e1a41513ae5'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','0e99764b-52b8-4fee-96ac-49f14689dbd9'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','170ee1fb-daa8-498f-87e5-50cf96f52645'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','18ae961d-37d2-4e45-a3c2-d333a9ecb3bc'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','1bd8b357-0c22-40e3-a9b8-6fa1671a5a35'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','1c6a600b-b222-4546-9cae-94c592dabf92'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','1d32fdc6-bf1e-4a8f-9e11-022761606182'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','24af04b7-ad01-4ed2-87f5-ef8b3e67e471'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','28b2ae56-a0d4-416d-b46a-ba505438153c'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','28c12497-b8eb-43c1-8211-ec6204433c47'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','28e40cbf-da57-441d-b142-94dcac83df25'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','2978c838-501d-4288-9286-1e6398f2c000'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','2b162177-9974-4c94-ae03-3a9e159eb9b6'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','2d4635a1-eb07-40d2-a223-f671d772ea31'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','2ed78c39-ad08-48e4-8e32-8d5279995e6e'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','31305afc-375c-4950-b93d-cafe5160a98c'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','31cb7fad-a793-4e88-8b19-59f2799f4904'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','341e1368-bbd5-41fb-9602-79a8e6121bf1'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','3ce675c4-7c88-4a19-9693-19b0299ac2f1'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','40c40745-4314-473c-af74-5c97ca99d976'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','40f24b2c-723e-440f-ab7f-525233c51e7b'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','4553133d-0f29-40a8-8d83-7e1861fad2a2'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','48d70193-d9f7-4392-ba54-2f119e037018'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','4b339ff5-e05d-4d42-872c-4d472e9015aa'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','4cb2d91e-0464-48af-b502-31847258ae29'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','50685a4e-eead-4988-b9a5-d1261badc2e8'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','52db26c7-8350-4c20-8920-3189e068f4bc'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','533b9ca5-2e89-4331-b5f7-8791dadff927'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','554453ef-b85b-4327-b20f-6747fe4f7047'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','5919e24b-ce47-490e-8425-4a63b1899c57'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','5edb990b-14f1-421e-b2b9-97854ca31c22'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','66b0d6e2-f276-4de6-b597-c2fdbaf332d2'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','69987783-01d9-4e66-8610-1532bd445e46'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','6a2c7846-a53b-4112-8e83-3b602e10d04e'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','6bfb7936-2cbc-46cc-b3c4-3a017710f4b4'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','6e7218fb-94f0-4526-9d3e-82a8ba2b5dd0'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','738b5bb6-096c-4ed4-9dcb-b419daed2c6a'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','74064fcb-ace8-496f-b92d-f47bd9785e64'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','7b35afb1-ab79-4b74-92ae-0ef87b60898c'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','7d995d45-ac5f-4d2e-a825-8f21a6dc301a'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','8002bed2-7cde-48ff-87fa-831ff24ce1eb'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','80e8a65c-9b1d-4171-959f-3c7d604f4012'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','878b9e2a-3030-4419-93d4-c7d0bc9832c1'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','8de3d8e9-0b66-40c3-bcf6-9ca303d32a4d'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','94b9437a-be3d-481e-8e51-3cb2bc710cdc'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','94db16f9-98cc-49e6-8455-84f8467b80cb'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','95712601-b69d-4753-8542-d6577e238030'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','96c39b32-1d37-45ed-a6cf-0f35938c2281'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','97033740-e0f1-4e1f-afdf-75b187e461e6'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','9755d31f-1a2f-4a26-87a6-9e0e0347050d'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','998a0054-3db6-4110-8076-4c5a33dc964f'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','a0000000-0000-4000-8000-000000000001'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','a2cb5f08-76cf-4bea-a8bf-3c2e05f8e3e4'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','a8686b6c-f87a-4b91-82e8-0b09e3ab3624'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','a88cac82-c8ae-46c0-a882-b450573241a9'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','a97b39dc-f150-45b3-b04c-9aeb0f9fe439'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e01'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e03'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e05'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e07'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','afb1e278-41d8-4280-bdbf-af4e28e3cb99'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','b03875ba-1726-4f37-bee4-6b74a1ab356c'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','b184f608-f719-49bb-a1ac-83ab0bbf1fdd'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','b63c3df6-eee4-4eb1-a79e-af09b7ab7dad'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','b8e2c5d1-7f4a-4c39-9a0e-5d6f1c8b3e21'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','bbc9e7f3-de9c-4f73-8c9d-fd72dc137005'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','bc579656-08bf-4ece-a7f3-12abd34546bf'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','be976ef2-3265-457d-8890-6a7ba8510afb'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','bfc7be16-e02f-4724-91b8-fe65b6525ea4'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','c0de5757-0000-4000-8000-00000000c101'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','c23c500d-ea43-42bc-bcdf-7115b38e5258'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','c5153423-118a-49f5-b670-8a51f90e9a84'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','c82ca0a8d67f11f1925b1d4813846157'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','cc4f7b49-4c22-44ba-b142-9ee0321621be'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','d409af4b-028f-43b8-b2db-1a38d56e9fbf'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','d499192f-caf9-48af-b71e-c0a8f0e28fbb'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','d55a494a-6a07-40c2-ae32-bea01cdfa39b'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','d5785049-b4c1-4044-8a5d-f926380ada40'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','db378705-f950-4473-ba10-042a737d8d46'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','dcaf4b94-6b6b-49dc-89c7-e600c5fc64c1'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','df0321d7-df8c-4f3c-ae2e-61e2b016dfa9'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','e085ffc1-35ed-4319-9e2a-696d01719d68'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','e51ba417-5c7a-4878-af83-4eb0c4dec155'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','f18576aa-57c7-40e4-b490-366aab6905fe'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','f2366f1d-2bcc-46bd-b06d-c1b5b657a02d'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','f2c1a9b0-0001-4a2c-8d2a-000000000001'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','f2c1a9b0-0002-4a2c-8d2a-000000000002'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','f2c1a9b0-0003-4a2c-8d2a-000000000003'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','f2c1a9b0-0004-4a2c-8d2a-000000000004'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','f2c1a9b0-0005-4a2c-8d2a-000000000005'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','f2c1a9b0-0006-4a2c-8d2a-000000000006'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','f2c1a9b0-0009-4a2c-8d2a-000000000009'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','f2c1a9b0-000a-4a2c-8d2a-00000000000a'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','f3c0a9b0-1102-4a2c-8d2a-000000000002'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','f3c0a9b0-1103-4a2c-8d2a-000000000003'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','f3c0a9b0-1104-4a2c-8d2a-000000000004'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','f77057e3-c8d4-4fd7-95ec-b4fe83e0b682'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','f8ffd8cf-76d5-45f5-9f99-be1b78ea46d1'),('5e627401-33ef-4ad8-ac15-86a0a3b76d4b','fd325f8b-8a56-483b-bb7b-795c5b651e22'),('8048d2f3-ab75-4c81-9cdb-04f0848dc5b5','05417629-45e1-4fca-9580-3b5667f0a517'),('8048d2f3-ab75-4c81-9cdb-04f0848dc5b5','170ee1fb-daa8-498f-87e5-50cf96f52645'),('8048d2f3-ab75-4c81-9cdb-04f0848dc5b5','18ae961d-37d2-4e45-a3c2-d333a9ecb3bc'),('8048d2f3-ab75-4c81-9cdb-04f0848dc5b5','1bd8b357-0c22-40e3-a9b8-6fa1671a5a35'),('8048d2f3-ab75-4c81-9cdb-04f0848dc5b5','2ed78c39-ad08-48e4-8e32-8d5279995e6e'),('8048d2f3-ab75-4c81-9cdb-04f0848dc5b5','31cb7fad-a793-4e88-8b19-59f2799f4904'),('8048d2f3-ab75-4c81-9cdb-04f0848dc5b5','341e1368-bbd5-41fb-9602-79a8e6121bf1'),('8048d2f3-ab75-4c81-9cdb-04f0848dc5b5','3ce675c4-7c88-4a19-9693-19b0299ac2f1'),('8048d2f3-ab75-4c81-9cdb-04f0848dc5b5','50685a4e-eead-4988-b9a5-d1261badc2e8'),('8048d2f3-ab75-4c81-9cdb-04f0848dc5b5','52db26c7-8350-4c20-8920-3189e068f4bc'),('8048d2f3-ab75-4c81-9cdb-04f0848dc5b5','6bfb7936-2cbc-46cc-b3c4-3a017710f4b4'),('8048d2f3-ab75-4c81-9cdb-04f0848dc5b5','738b5bb6-096c-4ed4-9dcb-b419daed2c6a'),('8048d2f3-ab75-4c81-9cdb-04f0848dc5b5','94b9437a-be3d-481e-8e51-3cb2bc710cdc'),('8048d2f3-ab75-4c81-9cdb-04f0848dc5b5','9755d31f-1a2f-4a26-87a6-9e0e0347050d'),('8048d2f3-ab75-4c81-9cdb-04f0848dc5b5','998a0054-3db6-4110-8076-4c5a33dc964f'),('8048d2f3-ab75-4c81-9cdb-04f0848dc5b5','a88cac82-c8ae-46c0-a882-b450573241a9'),('8048d2f3-ab75-4c81-9cdb-04f0848dc5b5','afb1e278-41d8-4280-bdbf-af4e28e3cb99'),('8048d2f3-ab75-4c81-9cdb-04f0848dc5b5','bc579656-08bf-4ece-a7f3-12abd34546bf'),('8048d2f3-ab75-4c81-9cdb-04f0848dc5b5','be976ef2-3265-457d-8890-6a7ba8510afb'),('8048d2f3-ab75-4c81-9cdb-04f0848dc5b5','f3c0a9b0-1102-4a2c-8d2a-000000000002'),('a31d975f-9f88-4e31-a67f-be3ea8970870','05417629-45e1-4fca-9580-3b5667f0a517'),('a31d975f-9f88-4e31-a67f-be3ea8970870','170ee1fb-daa8-498f-87e5-50cf96f52645'),('a31d975f-9f88-4e31-a67f-be3ea8970870','18ae961d-37d2-4e45-a3c2-d333a9ecb3bc'),('a31d975f-9f88-4e31-a67f-be3ea8970870','1bd8b357-0c22-40e3-a9b8-6fa1671a5a35'),('a31d975f-9f88-4e31-a67f-be3ea8970870','2ed78c39-ad08-48e4-8e32-8d5279995e6e'),('a31d975f-9f88-4e31-a67f-be3ea8970870','31cb7fad-a793-4e88-8b19-59f2799f4904'),('a31d975f-9f88-4e31-a67f-be3ea8970870','341e1368-bbd5-41fb-9602-79a8e6121bf1'),('a31d975f-9f88-4e31-a67f-be3ea8970870','3ce675c4-7c88-4a19-9693-19b0299ac2f1'),('a31d975f-9f88-4e31-a67f-be3ea8970870','50685a4e-eead-4988-b9a5-d1261badc2e8'),('a31d975f-9f88-4e31-a67f-be3ea8970870','52db26c7-8350-4c20-8920-3189e068f4bc'),('a31d975f-9f88-4e31-a67f-be3ea8970870','6bfb7936-2cbc-46cc-b3c4-3a017710f4b4'),('a31d975f-9f88-4e31-a67f-be3ea8970870','738b5bb6-096c-4ed4-9dcb-b419daed2c6a'),('a31d975f-9f88-4e31-a67f-be3ea8970870','94b9437a-be3d-481e-8e51-3cb2bc710cdc'),('a31d975f-9f88-4e31-a67f-be3ea8970870','9755d31f-1a2f-4a26-87a6-9e0e0347050d'),('a31d975f-9f88-4e31-a67f-be3ea8970870','998a0054-3db6-4110-8076-4c5a33dc964f'),('a31d975f-9f88-4e31-a67f-be3ea8970870','a88cac82-c8ae-46c0-a882-b450573241a9'),('a31d975f-9f88-4e31-a67f-be3ea8970870','afb1e278-41d8-4280-bdbf-af4e28e3cb99'),('a31d975f-9f88-4e31-a67f-be3ea8970870','bc579656-08bf-4ece-a7f3-12abd34546bf'),('a31d975f-9f88-4e31-a67f-be3ea8970870','be976ef2-3265-457d-8890-6a7ba8510afb'),('a31d975f-9f88-4e31-a67f-be3ea8970870','f3c0a9b0-1102-4a2c-8d2a-000000000002'),('e9c3d346-9453-4798-8b5b-544025454a63','05417629-45e1-4fca-9580-3b5667f0a517'),('e9c3d346-9453-4798-8b5b-544025454a63','0e99764b-52b8-4fee-96ac-49f14689dbd9'),('e9c3d346-9453-4798-8b5b-544025454a63','1bd8b357-0c22-40e3-a9b8-6fa1671a5a35'),('e9c3d346-9453-4798-8b5b-544025454a63','1c6a600b-b222-4546-9cae-94c592dabf92'),('e9c3d346-9453-4798-8b5b-544025454a63','2978c838-501d-4288-9286-1e6398f2c000'),('e9c3d346-9453-4798-8b5b-544025454a63','31cb7fad-a793-4e88-8b19-59f2799f4904'),('e9c3d346-9453-4798-8b5b-544025454a63','3ce675c4-7c88-4a19-9693-19b0299ac2f1'),('e9c3d346-9453-4798-8b5b-544025454a63','50685a4e-eead-4988-b9a5-d1261badc2e8'),('e9c3d346-9453-4798-8b5b-544025454a63','66b0d6e2-f276-4de6-b597-c2fdbaf332d2'),('e9c3d346-9453-4798-8b5b-544025454a63','80e8a65c-9b1d-4171-959f-3c7d604f4012'),('e9c3d346-9453-4798-8b5b-544025454a63','94b9437a-be3d-481e-8e51-3cb2bc710cdc'),('e9c3d346-9453-4798-8b5b-544025454a63','96c39b32-1d37-45ed-a6cf-0f35938c2281'),('e9c3d346-9453-4798-8b5b-544025454a63','97033740-e0f1-4e1f-afdf-75b187e461e6'),('e9c3d346-9453-4798-8b5b-544025454a63','a8686b6c-f87a-4b91-82e8-0b09e3ab3624'),('e9c3d346-9453-4798-8b5b-544025454a63','aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e01'),('e9c3d346-9453-4798-8b5b-544025454a63','aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e03'),('e9c3d346-9453-4798-8b5b-544025454a63','aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e05'),('e9c3d346-9453-4798-8b5b-544025454a63','aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e07'),('e9c3d346-9453-4798-8b5b-544025454a63','afb1e278-41d8-4280-bdbf-af4e28e3cb99'),('e9c3d346-9453-4798-8b5b-544025454a63','bc579656-08bf-4ece-a7f3-12abd34546bf'),('e9c3d346-9453-4798-8b5b-544025454a63','be976ef2-3265-457d-8890-6a7ba8510afb'),('e9c3d346-9453-4798-8b5b-544025454a63','c0de5757-0000-4000-8000-00000000c101'),('e9c3d346-9453-4798-8b5b-544025454a63','f2c1a9b0-0001-4a2c-8d2a-000000000001'),('e9c3d346-9453-4798-8b5b-544025454a63','f2c1a9b0-0004-4a2c-8d2a-000000000004'),('e9c3d346-9453-4798-8b5b-544025454a63','f2c1a9b0-0005-4a2c-8d2a-000000000005'),('e9c3d346-9453-4798-8b5b-544025454a63','f2c1a9b0-0006-4a2c-8d2a-000000000006'),('e9c3d346-9453-4798-8b5b-544025454a63','f2c1a9b0-0009-4a2c-8d2a-000000000009'),('e9c3d346-9453-4798-8b5b-544025454a63','f2c1a9b0-000a-4a2c-8d2a-00000000000a'),('e9c3d346-9453-4798-8b5b-544025454a63','f3c0a9b0-1102-4a2c-8d2a-000000000002'),('e9c3d346-9453-4798-8b5b-544025454a63','f3c0a9b0-1103-4a2c-8d2a-000000000003'),('e9c3d346-9453-4798-8b5b-544025454a63','f3c0a9b0-1104-4a2c-8d2a-000000000004'),('e9c3d346-9453-4798-8b5b-544025454a63','f8ffd8cf-76d5-45f5-9f99-be1b78ea46d1'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','03c241fa-d111-494f-b195-7d0fefbd8377'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','05417629-45e1-4fca-9580-3b5667f0a517'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','05496151-edd4-4ec9-828b-4760cc5059a0'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','170ee1fb-daa8-498f-87e5-50cf96f52645'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','18ae961d-37d2-4e45-a3c2-d333a9ecb3bc'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','1bd8b357-0c22-40e3-a9b8-6fa1671a5a35'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','2ed78c39-ad08-48e4-8e32-8d5279995e6e'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','31cb7fad-a793-4e88-8b19-59f2799f4904'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','341e1368-bbd5-41fb-9602-79a8e6121bf1'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','3ce675c4-7c88-4a19-9693-19b0299ac2f1'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','40c40745-4314-473c-af74-5c97ca99d976'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','50685a4e-eead-4988-b9a5-d1261badc2e8'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','52db26c7-8350-4c20-8920-3189e068f4bc'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','554453ef-b85b-4327-b20f-6747fe4f7047'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','6bfb7936-2cbc-46cc-b3c4-3a017710f4b4'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','738b5bb6-096c-4ed4-9dcb-b419daed2c6a'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','7d995d45-ac5f-4d2e-a825-8f21a6dc301a'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','94b9437a-be3d-481e-8e51-3cb2bc710cdc'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','95712601-b69d-4753-8542-d6577e238030'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','9755d31f-1a2f-4a26-87a6-9e0e0347050d'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','998a0054-3db6-4110-8076-4c5a33dc964f'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','a0000000-0000-4000-8000-000000000001'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','a88cac82-c8ae-46c0-a882-b450573241a9'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','afb1e278-41d8-4280-bdbf-af4e28e3cb99'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','bbc9e7f3-de9c-4f73-8c9d-fd72dc137005'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','bc579656-08bf-4ece-a7f3-12abd34546bf'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','be976ef2-3265-457d-8890-6a7ba8510afb'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','d5785049-b4c1-4044-8a5d-f926380ada40'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','dcaf4b94-6b6b-49dc-89c7-e600c5fc64c1'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','f2366f1d-2bcc-46bd-b06d-c1b5b657a02d'),('ea3dcf7f-4421-4f55-9740-5bfb8b2473c7','f3c0a9b0-1102-4a2c-8d2a-000000000002');

-- 角色菜单关联 (admin拥有所有权限)


-- 系统设置默认数据（仅当表为空时插入）
INSERT IGNORE INTO `sys_setting` (`id`, `system_name`, `system_subtitle`, `login_logo`, `multi_login`)
SELECT'd3ad4f8d-a328-4fe6-a86f-fedcb9162554',  '云帆智能客户管理系统',  'Customer Relationship Management',  '',  0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `sys_setting`);

-- 播种后再次统一默认主题色为紫色（覆盖旧库 sys_setting 列默认值仍为蓝色的场景）
UPDATE `sys_setting` SET `theme_color` = '#8B7DE0'
WHERE `theme_color` IS NULL OR TRIM(`theme_color`) = ''
   OR UPPER(TRIM(`theme_color`)) IN ('#5B8FD9', '#409EFF', '#3B82F6', '#1890FF');

-- 系统名称修正（兼容旧名称）
UPDATE `sys_setting` SET `system_name` = '云帆智能客户管理系统', `update_time` = CURRENT_TIMESTAMP
WHERE `system_name` IN ('云帆客户管理系统', 'CRM客户关系管理系统');

-- 字典类型
INSERT IGNORE INTO `sys_dict_type` (`id`, `dict_name`, `dict_type`, `remark`) VALUES('215a172f-2b96-4343-9236-c02f5e6c1a28', '客户等级',  'customer_level',  '客户分级管理'), ('412d26d3-a38d-453f-bc09-f3d6239962b4', '客户来源',  'customer_source',  '客户来源渠道'), ('f33c64c1-b002-4e0d-92d7-cdbbab567ec5', '客户状态',  'customer_status',  '客户状态'), ('ca8d04c9-5756-4729-98a1-f22a90c81a10', '行业类型',  'industry',  '行业分类'), ('965157fc-1ce5-4333-b4a6-f5b969ddfe2a', '销售阶段',  'opp_stage',  '销售线索阶段'), ('158ea5ab-ef4e-4e01-84ea-310694f4eda9', '跟进类型',  'follow_type',  '客户跟进方式'), ('e86c4f2a-81c8-4bbd-98d5-a68bbbd1eea0', '合同状态',  'contract_status',  '合同审批状态'), ('9d4a62c9-33ee-407a-9cb5-433840de39b9', '合同模板分类',  'contract_template_category',  '合同模板分类'), ('e64433f9-0114-4ecb-880a-a4f446b6daf5', '客户状态',  'customer_deal_status',  '客户状态')ON DUPLICATE KEY UPDATE `dict_name` = VALUES(`dict_name`);

-- 字典数据
INSERT IGNORE INTO `sys_dict_data` (`id`, `dict_type`, `dict_label`, `dict_value`, `css_class`, `sort`) VALUES('15542f2e-41ee-4b9e-9af6-b13b83061cb8', 'customer_level',  'VIP客户',  'VIP',  'danger',  1), ('ad66489b-b0c4-4be8-8476-ab9a87661c64', 'customer_level',  '重要客户',  '重要',  'warning',  2), ('0069accd-79d8-473a-9903-b36917517f1d', 'customer_level',  '普通客户',  '普通',  'primary',  3), ('b49c591a-6bc7-4702-8620-ec0f3a1e4915', 'customer_level',  '潜在客户',  '潜在',  'info',  4), ('b54c351c-5cb9-4754-804a-260a7a346a66', 'customer_source',  '线上推广',  'online',  NULL,  1), ('e7011826-0596-4167-ba1b-04e2f2798b9d', 'customer_source',  '线下活动',  'offline',  NULL,  2), ('ae640ee8-a8af-4db9-b28d-e866ef04c423', 'customer_source',  '客户转介绍',  'referral',  NULL,  3), ('cae80cf8-b01a-485c-8495-c844e78e889b', 'customer_source',  '主动开发',  'self',  NULL,  4), ('998efc9a-e52a-4693-89f1-f3c81fe6462c', 'customer_status',  '活跃',  'active',  'success',  1), ('49436b86-f4ab-4be0-b8da-117d512323a7', 'customer_status',  '非活跃',  'inactive',  'warning',  2), ('18519251-82ea-4c2f-b5d6-901f2ce928ae', 'customer_status',  '流失',  'lost',  'danger',  3), ('282cc2ff-823d-4c8a-bd8e-540ecef1cbfc', 'industry',  '互联网/IT',  'IT',  NULL,  1), ('6f918b4f-00dc-47ad-9bc8-c6a10af6c86a', 'industry',  '制造业',  'manufacturing',  NULL,  2), ('16aaeac9-b092-4417-9171-62a3cc61ecdd', 'industry',  '金融',  'finance',  NULL,  3), ('92fe1c03-6e86-46c6-aca5-4d5238d26913', 'industry',  '教育',  'education',  NULL,  4), ('28059017-601b-40b3-9bed-d95ceb21665e', 'industry',  '医疗',  'medical',  NULL,  5), ('d35718a6-617f-4531-aa0d-27c50ddb781c', 'industry',  '房地产',  'realestate',  NULL,  6), ('9d911987-13d0-4127-bcc2-b6ab433c38cd', 'opp_stage',  '初步接触',  'initial',  'info',  1), ('b56bfe41-e862-492d-a4a4-098c893161a2', 'opp_stage',  '需求确认',  'qualification',  'primary',  2), ('99265e9d-c162-4dfe-8b69-81fd794ddcd9', 'opp_stage',  '方案报价',  'proposal',  'warning',  3), ('eef28bf1-e6c1-4f92-a896-c248c20750aa', 'opp_stage',  '商务谈判',  'negotiation',  'warning',  4), ('8efaf609-db96-4f84-b312-5e499e4620db', 'opp_stage',  '赢单',  'won',  'success',  5), ('ef94bc98-1237-4ec2-8d67-35036438c854', 'opp_stage',  '输单',  'lost',  'danger',  6), ('60a4f950-749a-4130-869e-ade88be2e4b0', 'follow_type',  '电话',  'phone',  NULL,  1), ('694193c9-462f-4086-9987-c8e24410b976', 'follow_type',  '拜访',  'visit',  NULL,  2), ('70256419-05fb-4023-888d-b2aa8a6e5457', 'follow_type',  '邮件',  'email',  NULL,  3), ('d39d1cfb-aa58-4ed9-ad5f-fb47b8af2553', 'follow_type',  '会议',  'meeting',  NULL,  4), ('2ba6c8fd-eaeb-4499-9915-206c84f718ec', 'follow_type',  '微信',  'wechat',  NULL,  5), ('a5a6f28a-109d-4ce9-9235-50c0e7af1126', 'follow_type',  '其他',  'other',  NULL,  6), ('2f074645-9e1e-4d9f-ae59-248d855425f4', 'contract_status',  '草稿',  'draft',  'info',  1), ('92d37816-5fd3-412e-bb9b-9b3748c150bb', 'contract_status',  '审批中',  'pending',  'warning',  2), ('9bf0fb8b-782b-4fe3-8bee-204a6bcddcdf', 'contract_status',  '已审批',  'approved',  'primary',  3), ('c3adb462-e52b-4fc5-9b8f-1a774dd49885', 'contract_status',  '执行中',  'executing',  'success',  4), ('64dc618a-1209-403c-8c52-894b4b7b0f9a', 'contract_status',  '已完成',  'completed',  'success',  5), ('55a46c33-fdd5-4cbd-9b52-376fb03e72df', 'contract_status',  '已终止',  'terminated',  'danger',  6), ('0f02c7f8-3cf4-491a-b5f5-32c4d6d45429', 'contract_template_category',  '销售合同',  'sales',  NULL,  1), ('eea0008b-184c-416f-a003-8b381ae1605f', 'contract_template_category',  '采购合同',  'purchase',  NULL,  2), ('396cc761-5d71-4aac-b2a0-84c8f2122a58', 'contract_template_category',  '服务合同',  'service',  NULL,  3), ('731e40e0-6825-439a-b866-b62da235d00b', 'contract_template_category',  '租赁合同',  'lease',  NULL,  4), ('b22e56ae-1eb1-4a25-bdce-93f8e9634e66', 'contract_template_category',  '其他',  'other',  NULL,  5), ('cbb48a2d-4bae-4ba2-aa13-ebd44e1c83cd', 'customer_deal_status',  'A：潜在客户',  'A',  'info',  1), ('1f2e8636-caba-4e2c-9a1d-6e302fe4ec2a', 'customer_deal_status',  'B：可跟进客户',  'B',  'primary',  2), ('85df40e6-972a-46ab-936c-d7f52e037607', 'customer_deal_status',  'C：重点跟进客户',  'C',  'warning',  3), ('6be96b2d-cc12-4043-b177-e200929bdf9f', 'customer_deal_status',  'D：拟成交客户',  'D',  'danger',  4), ('f4a43c2e-ef66-4de4-932c-8a31b045d24b', 'customer_deal_status',  'E：合作客户',  'E',  'success',  5), ('75c834ed-7f90-45eb-8d63-d60a265a07e7', 'customer_deal_status',  'F：放弃客户',  'F',  'info',  6)ON DUPLICATE KEY UPDATE `dict_label` = VALUES(`dict_label`);

-- 注：客户/联系人/机会/跟进/合同/任务/公告等示例数据统一在「第九节」中按每表 12 条写入。

-- =====================================================
-- 八、按钮权限数据（幂等，可重复执行）
-- =====================================================

-- 全量按钮权限（幂等：先清后插）
-- 按钮基线改为纯 IGNORE 插入(不再先清空, 避免删掉升级段引入的按钮)
INSERT IGNORE INTO `sys_menu` (`id`, `parent_id`, `menu_name`, `path`, `component`, `perms`, `icon`, `menu_type`, `sort`, `visible`, `create_time`, `update_time`) VALUES
('d409af4b-028f-43b8-b2db-1a38d56e9fbf', '94b9437a-be3d-481e-8e51-3cb2bc710cdc', '新增客户', NULL, NULL, 'customer:add', NULL, 'F', 1, 1, NOW(), NOW()),
('06370b74-181e-44cd-9f0e-b758713a761e', '94b9437a-be3d-481e-8e51-3cb2bc710cdc', '编辑客户', NULL, NULL, 'customer:edit', NULL, 'F', 2, 1, NOW(), NOW()),
('b03875ba-1726-4f37-bee4-6b74a1ab356c', '94b9437a-be3d-481e-8e51-3cb2bc710cdc', '删除客户', NULL, NULL, 'customer:delete', NULL, 'F', 3, 1, NOW(), NOW()),
('28c12497-b8eb-43c1-8211-ec6204433c47', '94b9437a-be3d-481e-8e51-3cb2bc710cdc', '导入客户', NULL, NULL, 'customer:import', NULL, 'F', 4, 1, NOW(), NOW()),
('d55a494a-6a07-40c2-ae32-bea01cdfa39b', '94b9437a-be3d-481e-8e51-3cb2bc710cdc', '导出客户', NULL, NULL, 'customer:export', NULL, 'F', 5, 1, NOW(), NOW()),
('40f24b2c-723e-440f-ab7f-525233c51e7b', '94b9437a-be3d-481e-8e51-3cb2bc710cdc', '查看联系人', NULL, NULL, 'customer:contact', NULL, 'F', 6, 1, NOW(), NOW()),
('a8686b6c-f87a-4b91-82e8-0b09e3ab3624', '94b9437a-be3d-481e-8e51-3cb2bc710cdc', '客户跟进', NULL, NULL, 'customer:follow', NULL, 'F', 3, 1, NOW(), NOW()),
('97033740-e0f1-4e1f-afdf-75b187e461e6', '94b9437a-be3d-481e-8e51-3cb2bc710cdc', '查看公开信息', NULL, NULL, 'customer:publicInfo', NULL, 'F', 7, 1, NOW(), NOW()),
('0e99764b-52b8-4fee-96ac-49f14689dbd9', '94b9437a-be3d-481e-8e51-3cb2bc710cdc', '放入公海', NULL, NULL, 'customer:release', NULL, 'F', 4, 1, NOW(), NOW()),
('66b0d6e2-f276-4de6-b597-c2fdbaf332d2', 'bc579656-08bf-4ece-a7f3-12abd34546bf', '领取客户', NULL, NULL, 'customer:claim', NULL, 'F', 1, 1, NOW(), NOW()),
('8002bed2-7cde-48ff-87fa-831ff24ce1eb', '2ed78c39-ad08-48e4-8e32-8d5279995e6e', '新增联系人', NULL, NULL, 'contact:add', NULL, 'F', 1, 1, NOW(), NOW()),
('878b9e2a-3030-4419-93d4-c7d0bc9832c1', '2ed78c39-ad08-48e4-8e32-8d5279995e6e', '编辑联系人', NULL, NULL, 'contact:edit', NULL, 'F', 2, 1, NOW(), NOW()),
('e085ffc1-35ed-4319-9e2a-696d01719d68', '2ed78c39-ad08-48e4-8e32-8d5279995e6e', '删除联系人', NULL, NULL, 'contact:delete', NULL, 'F', 3, 1, NOW(), NOW()),
('48d70193-d9f7-4392-ba54-2f119e037018', 'a88cac82-c8ae-46c0-a882-b450573241a9', '新增跟进', NULL, NULL, 'followup:add', NULL, 'F', 1, 1, NOW(), NOW()),
('2d4635a1-eb07-40d2-a223-f671d772ea31', 'a88cac82-c8ae-46c0-a882-b450573241a9', '删除跟进', NULL, NULL, 'followup:delete', NULL, 'F', 2, 1, NOW(), NOW()),
('f77057e3-c8d4-4fd7-95ec-b4fe83e0b682', '170ee1fb-daa8-498f-87e5-50cf96f52645', '新增合同', NULL, NULL, 'contract:add', NULL, 'F', 1, 1, NOW(), NOW()),
('533b9ca5-2e89-4331-b5f7-8791dadff927', '170ee1fb-daa8-498f-87e5-50cf96f52645', '编辑合同', NULL, NULL, 'contract:edit', NULL, 'F', 2, 1, NOW(), NOW()),
('24af04b7-ad01-4ed2-87f5-ef8b3e67e471', '170ee1fb-daa8-498f-87e5-50cf96f52645', '删除合同', NULL, NULL, 'contract:delete', NULL, 'F', 3, 1, NOW(), NOW()),
('31305afc-375c-4950-b93d-cafe5160a98c', '170ee1fb-daa8-498f-87e5-50cf96f52645', '导入合同', NULL, NULL, 'contract:import', NULL, 'F', 4, 1, NOW(), NOW()),
('a97b39dc-f150-45b3-b04c-9aeb0f9fe439', '170ee1fb-daa8-498f-87e5-50cf96f52645', '导出合同', NULL, NULL, 'contract:export', NULL, 'F', 5, 1, NOW(), NOW()),
('b8e2c5d1-7f4a-4c39-9a0e-5d6f1c8b3e21', '170ee1fb-daa8-498f-87e5-50cf96f52645', '合同回款记录', NULL, NULL, 'contract:payment', NULL, 'F', 6, 1, NOW(), NOW()),
('d499192f-caf9-48af-b71e-c0a8f0e28fbb', '341e1368-bbd5-41fb-9602-79a8e6121bf1', '新增任务', NULL, NULL, 'task:add', NULL, 'F', 1, 1, NOW(), NOW()),
('2b162177-9974-4c94-ae03-3a9e159eb9b6', '341e1368-bbd5-41fb-9602-79a8e6121bf1', '编辑任务', NULL, NULL, 'task:edit', NULL, 'F', 2, 1, NOW(), NOW()),
('4553133d-0f29-40a8-8d83-7e1861fad2a2', '341e1368-bbd5-41fb-9602-79a8e6121bf1', '删除任务', NULL, NULL, 'task:delete', NULL, 'F', 3, 1, NOW(), NOW()),
('c5153423-118a-49f5-b670-8a51f90e9a84', '341e1368-bbd5-41fb-9602-79a8e6121bf1', '完成任务', NULL, NULL, 'task:complete', NULL, 'F', 4, 1, NOW(), NOW()),
('28b2ae56-a0d4-416d-b46a-ba505438153c', 'afb1e278-41d8-4280-bdbf-af4e28e3cb99', '新增图文', NULL, NULL, 'content:add', NULL, 'F', 1, 1, NOW(), NOW()),
('db378705-f950-4473-ba10-042a737d8d46', 'afb1e278-41d8-4280-bdbf-af4e28e3cb99', '编辑图文', NULL, NULL, 'content:edit', NULL, 'F', 2, 1, NOW(), NOW()),
('5edb990b-14f1-421e-b2b9-97854ca31c22', 'afb1e278-41d8-4280-bdbf-af4e28e3cb99', '删除图文', NULL, NULL, 'content:delete', NULL, 'F', 3, 1, NOW(), NOW()),
('b184f608-f719-49bb-a1ac-83ab0bbf1fdd', 'afb1e278-41d8-4280-bdbf-af4e28e3cb99', '发布图文', NULL, NULL, 'content:publish', NULL, 'F', 4, 1, NOW(), NOW()),
('4b339ff5-e05d-4d42-872c-4d472e9015aa', '6bfb7936-2cbc-46cc-b3c4-3a017710f4b4', '新增活动', NULL, NULL, 'marketing:add', NULL, 'F', 1, 1, NOW(), NOW()),
('7b35afb1-ab79-4b74-92ae-0ef87b60898c', '6bfb7936-2cbc-46cc-b3c4-3a017710f4b4', '编辑活动', NULL, NULL, 'marketing:edit', NULL, 'F', 2, 1, NOW(), NOW()),
('05c31982-5c49-46b2-beb9-a8087d033c61', '6bfb7936-2cbc-46cc-b3c4-3a017710f4b4', '删除活动', NULL, NULL, 'marketing:delete', NULL, 'F', 3, 1, NOW(), NOW()),
('08f640d7-759a-43a3-852c-1e1a41513ae5', '998a0054-3db6-4110-8076-4c5a33dc964f', '新增公告', NULL, NULL, 'notice:add', NULL, 'F', 1, 1, NOW(), NOW()),
('74064fcb-ace8-496f-b92d-f47bd9785e64', '998a0054-3db6-4110-8076-4c5a33dc964f', '编辑公告', NULL, NULL, 'notice:edit', NULL, 'F', 2, 1, NOW(), NOW()),
('4cb2d91e-0464-48af-b502-31847258ae29', '998a0054-3db6-4110-8076-4c5a33dc964f', '删除公告', NULL, NULL, 'notice:delete', NULL, 'F', 3, 1, NOW(), NOW()),
('69987783-01d9-4e66-8610-1532bd445e46', '998a0054-3db6-4110-8076-4c5a33dc964f', '发布公告', NULL, NULL, 'notice:publish', NULL, 'F', 4, 1, NOW(), NOW()),
('28e40cbf-da57-441d-b142-94dcac83df25', '998a0054-3db6-4110-8076-4c5a33dc964f', '撤销公告', NULL, NULL, 'notice:cancel', NULL, 'F', 5, 1, NOW(), NOW()),
('96c39b32-1d37-45ed-a6cf-0f35938c2281', '50685a4e-eead-4988-b9a5-d1261badc2e8', '手动抓取', NULL, NULL, 'opportunity:crawl', NULL, 'F', 1, 1, NOW(), NOW()),
('80e8a65c-9b1d-4171-959f-3c7d604f4012', '05417629-45e1-4fca-9580-3b5667f0a517', '新增机会', NULL, NULL, 'opportunity:add', NULL, 'F', 1, 1, NOW(), NOW()),
('2978c838-501d-4288-9286-1e6398f2c000', '05417629-45e1-4fca-9580-3b5667f0a517', '编辑机会', NULL, NULL, 'opportunity:edit', NULL, 'F', 2, 1, NOW(), NOW()),
('1c6a600b-b222-4546-9cae-94c592dabf92', '05417629-45e1-4fca-9580-3b5667f0a517', '删除机会', NULL, NULL, 'opportunity:delete', NULL, 'F', 3, 1, NOW(), NOW()),
('f8ffd8cf-76d5-45f5-9f99-be1b78ea46d1', '05417629-45e1-4fca-9580-3b5667f0a517', '推进阶段', NULL, NULL, 'opportunity:stage', NULL, 'F', 4, 1, NOW(), NOW()),
('c23c500d-ea43-42bc-bcdf-7115b38e5258', '05496151-edd4-4ec9-828b-4760cc5059a0', '新增菜单', NULL, NULL, 'system:menu:add', NULL, 'F', 1, 1, NOW(), NOW()),
('e51ba417-5c7a-4878-af83-4eb0c4dec155', '05496151-edd4-4ec9-828b-4760cc5059a0', '编辑菜单', NULL, NULL, 'system:menu:edit', NULL, 'F', 2, 1, NOW(), NOW()),
('fd325f8b-8a56-483b-bb7b-795c5b651e22', '05496151-edd4-4ec9-828b-4760cc5059a0', '删除菜单', NULL, NULL, 'system:menu:delete', NULL, 'F', 3, 1, NOW(), NOW()),
('6e7218fb-94f0-4526-9d3e-82a8ba2b5dd0', '40c40745-4314-473c-af74-5c97ca99d976', '新增角色', NULL, NULL, 'system:role:add', NULL, 'F', 1, 1, NOW(), NOW()),
('b63c3df6-eee4-4eb1-a79e-af09b7ab7dad', '40c40745-4314-473c-af74-5c97ca99d976', '编辑角色', NULL, NULL, 'system:role:edit', NULL, 'F', 2, 1, NOW(), NOW()),
('94db16f9-98cc-49e6-8455-84f8467b80cb', '40c40745-4314-473c-af74-5c97ca99d976', '删除角色', NULL, NULL, 'system:role:delete', NULL, 'F', 3, 1, NOW(), NOW()),
('a2cb5f08-76cf-4bea-a8bf-3c2e05f8e3e4', '40c40745-4314-473c-af74-5c97ca99d976', '配置权限', NULL, NULL, 'system:role:grant', NULL, 'F', 4, 1, NOW(), NOW()),
('6a2c7846-a53b-4112-8e83-3b602e10d04e', 'd5785049-b4c1-4044-8a5d-f926380ada40', '新增部门', NULL, NULL, 'system:dept:add', NULL, 'F', 1, 1, NOW(), NOW()),
('8de3d8e9-0b66-40c3-bcf6-9ca303d32a4d', 'd5785049-b4c1-4044-8a5d-f926380ada40', '编辑部门', NULL, NULL, 'system:dept:edit', NULL, 'F', 2, 1, NOW(), NOW()),
('f18576aa-57c7-40e4-b490-366aab6905fe', 'd5785049-b4c1-4044-8a5d-f926380ada40', '删除部门', NULL, NULL, 'system:dept:delete', NULL, 'F', 3, 1, NOW(), NOW()),
('5919e24b-ce47-490e-8425-4a63b1899c57', 'bbc9e7f3-de9c-4f73-8c9d-fd72dc137005', '新增字典', NULL, NULL, 'system:dict:add', NULL, 'F', 1, 1, NOW(), NOW()),
('1d32fdc6-bf1e-4a8f-9e11-022761606182', 'bbc9e7f3-de9c-4f73-8c9d-fd72dc137005', '编辑字典', NULL, NULL, 'system:dict:edit', NULL, 'F', 2, 1, NOW(), NOW()),
('cc4f7b49-4c22-44ba-b142-9ee0321621be', 'bbc9e7f3-de9c-4f73-8c9d-fd72dc137005', '删除字典', NULL, NULL, 'system:dict:delete', NULL, 'F', 3, 1, NOW(), NOW()),
('df0321d7-df8c-4f3c-ae2e-61e2b016dfa9', 'dcaf4b94-6b6b-49dc-89c7-e600c5fc64c1', '处理反馈', NULL, NULL, 'system:feedback:handle', NULL, 'F', 1, 1, NOW(), NOW()),
('bfc7be16-e02f-4724-91b8-fe65b6525ea4', 'dcaf4b94-6b6b-49dc-89c7-e600c5fc64c1', '删除反馈', NULL, NULL, 'system:feedback:delete', NULL, 'F', 2, 1, NOW(), NOW());

-- 销售线索按钮权限（幂等：已存在则不重复插入）
INSERT IGNORE INTO `sys_menu` (`id`, `parent_id`, `menu_name`, `path`, `component`, `perms`, `icon`, `menu_type`, `sort`, `visible`, `create_time`, `update_time`)
SELECT'f046545b-5f36-4696-a594-3ce4afc5a359', '00f80a1f-a436-4c05-af17-82fa5c69fe33',  '新增机会',  NULL,  NULL,  'opportunity:add',  NULL,  'F',  1,  1,  NOW(),  NOW()
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `sys_menu` WHERE `perms` = 'opportunity:add');
INSERT IGNORE INTO `sys_menu` (`id`, `parent_id`, `menu_name`, `path`, `component`, `perms`, `icon`, `menu_type`, `sort`, `visible`, `create_time`, `update_time`)
SELECT'0226e7a5-f05f-429f-9709-ef9d29899844', '00f80a1f-a436-4c05-af17-82fa5c69fe33',  '编辑机会',  NULL,  NULL,  'opportunity:edit',  NULL,  'F',  2,  1,  NOW(),  NOW()
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `sys_menu` WHERE `perms` = 'opportunity:edit');
INSERT IGNORE INTO `sys_menu` (`id`, `parent_id`, `menu_name`, `path`, `component`, `perms`, `icon`, `menu_type`, `sort`, `visible`, `create_time`, `update_time`)
SELECT'adbecdf6-39c1-4ebf-b6fc-2cd80c2c55e3', '00f80a1f-a436-4c05-af17-82fa5c69fe33',  '删除机会',  NULL,  NULL,  'opportunity:delete',  NULL,  'F',  3,  1,  NOW(),  NOW()
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `sys_menu` WHERE `perms` = 'opportunity:delete');
INSERT IGNORE INTO `sys_menu` (`id`, `parent_id`, `menu_name`, `path`, `component`, `perms`, `icon`, `menu_type`, `sort`, `visible`, `create_time`, `update_time`)
SELECT'67a35cfe-9b37-4be9-b221-5bbba2f05b18', '00f80a1f-a436-4c05-af17-82fa5c69fe33',  '推进阶段',  NULL,  NULL,  'opportunity:stage',  NULL,  'F',  4,  1,  NOW(),  NOW()
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `sys_menu` WHERE `perms` = 'opportunity:stage');

-- 修正按钮权限所属父菜单（合同/图文/反馈按钮挂到对应页面菜单下）
UPDATE `sys_menu` SET `parent_id` = (SELECT `id` FROM (SELECT `id` FROM `sys_menu` WHERE `perms` = 'contract:list' LIMIT 1) AS `_t`) WHERE `perms` IN ('contract:add', 'contract:edit', 'contract:delete', 'contract:import', 'contract:export', 'contract:payment')
  AND EXISTS (SELECT 1 FROM (SELECT `id` FROM `sys_menu` WHERE `perms` = 'contract:list' LIMIT 1) AS `_c`);
UPDATE `sys_menu` SET `parent_id` = (SELECT `id` FROM (SELECT `id` FROM `sys_menu` WHERE `perms` = 'content:list' LIMIT 1) AS `_t`) WHERE `perms` IN ('content:add', 'content:edit', 'content:delete', 'content:publish')
  AND EXISTS (SELECT 1 FROM (SELECT `id` FROM `sys_menu` WHERE `perms` = 'content:list' LIMIT 1) AS `_c`);
UPDATE `sys_menu` SET `parent_id` = (SELECT `id` FROM (SELECT `id` FROM `sys_menu` WHERE `perms` = 'system:feedback:list' LIMIT 1) AS `_t`) WHERE `perms` IN ('system:feedback:handle', 'system:feedback:delete')
  AND EXISTS (SELECT 1 FROM (SELECT `id` FROM `sys_menu` WHERE `perms` = 'system:feedback:list' LIMIT 1) AS `_c`);

-- 已有库升级：「系统设置」与「字典管理」同级（系统管理下），并排在字典管理之上（幂等）
UPDATE `sys_menu`
SET `parent_id` = (SELECT `id` FROM (SELECT `id` FROM `sys_menu` WHERE `menu_type` = 'M' AND `menu_name` = '系统管理' LIMIT 1) AS `_sm`),
    `sort` = 0
WHERE `perms` = 'system:setting:list'
  AND EXISTS (SELECT 1 FROM (SELECT `id` FROM `sys_menu` WHERE `menu_type` = 'M' AND `menu_name` = '系统管理' LIMIT 1) AS `_sm2`);

-- 已有库升级：调整系统管理子菜单排序（幂等）
UPDATE `sys_menu` SET `sort` = CASE `menu_name`
  WHEN '系统设置' THEN 0
  WHEN '字典管理' THEN 1
  WHEN '意见反馈' THEN 2
  WHEN '操作日志' THEN 3
  WHEN '运维监控' THEN 4
  ELSE `sort` END
WHERE `parent_id` = (SELECT `id` FROM (SELECT `id` FROM `sys_menu` WHERE `menu_name` = '系统管理' AND `menu_type` = 'M' LIMIT 1) AS `_sm`);

-- 已有库升级：消息管理（含消息通知、消息模板）仅保留给超级管理员，移除销售员/销售经理/市场管理员的权限（幂等）
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT (SELECT `id` FROM `sys_role` WHERE `role_code` = 'admin' LIMIT 1), m.id
FROM (SELECT 'f2c1a9b0-0009-4a2c-8d2a-000000000009' AS id UNION ALL
      SELECT 'f2c1a9b0-0002-4a2c-8d2a-000000000002' UNION ALL
      SELECT 'f2c1a9b0-0003-4a2c-8d2a-000000000003') m;
DELETE FROM `sys_role_menu`
WHERE `menu_id` IN ('f2c1a9b0-0009-4a2c-8d2a-000000000009','f2c1a9b0-0002-4a2c-8d2a-000000000002','f2c1a9b0-0003-4a2c-8d2a-000000000003')
AND `role_id` IN (SELECT `id` FROM `sys_role` WHERE `role_code` IN ('sales','sales_manager','marketing_admin'));

-- 已有库升级：市场管理员移除「客户管理」下的「我的客户/联系人管理/跟进记录」及其按钮权限（幂等）
DELETE FROM `sys_role_menu`
WHERE `role_id` = (SELECT `id` FROM `sys_role` WHERE `role_code` = 'marketing_admin' LIMIT 1)
AND `menu_id` IN (
  SELECT `id` FROM (
    SELECT 'a14043b6-87fc-41ff-abb4-390e99cf5b2f' AS id UNION ALL
    SELECT 'c66185d9-2323-4642-8739-3669079faad9' UNION ALL
    SELECT 'a50dc511-cd79-4056-941a-9f87c45aa2c4' UNION ALL
    SELECT `id` FROM `sys_menu` WHERE `parent_id` IN (
      'a14043b6-87fc-41ff-abb4-390e99cf5b2f',
      'c66185d9-2323-4642-8739-3669079faad9',
      'a50dc511-cd79-4056-941a-9f87c45aa2c4'
    )
  ) t
);

-- 已有库升级：市场管理员移除「我的日程」及其按钮权限（幂等）
DELETE FROM `sys_role_menu`
WHERE `role_id` = (SELECT `id` FROM `sys_role` WHERE `role_code` = 'marketing_admin' LIMIT 1)
AND `menu_id` IN (
  SELECT `id` FROM (
    SELECT 'f2c1a9b0-0001-4a2c-8d2a-000000000001' AS id UNION ALL
    SELECT `id` FROM `sys_menu` WHERE `parent_id` = 'f2c1a9b0-0001-4a2c-8d2a-000000000001'
  ) t
);

-- 移除 AI 助手菜单（页面路由保留，仍可通过 /ai/chat 直接访问）
DELETE FROM `sys_menu` WHERE `perms` = 'system:ai:chat';
DELETE FROM `sys_role_menu` WHERE `menu_id` = (SELECT `id` FROM `sys_menu` WHERE `perms` = 'system:ai:chat');

-- 清理角色菜单中已不存在的记录
DELETE rm FROM `sys_role_menu` rm LEFT JOIN `sys_menu` m ON rm.menu_id = m.id WHERE m.id IS NULL;

-- 给超级管理员绑定全部菜单权限（目录/菜单/按钮）
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT (SELECT `id` FROM `sys_role` WHERE `role_code` = 'admin' LIMIT 1), id FROM `sys_menu` WHERE `menu_type` IN ('M','C','F');

-- 绑定客户公海/跟进/领取/图文/商机菜单权限给所有角色
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT r.id,  m.id FROM `sys_role` r, `sys_menu` m
WHERE m.`perms` IN ('customer:pool', 'customer:follow', 'customer:claim', 'customer:release', 'customer:publicInfo', 'content:list', 'opportunity:intel', 'opportunity:crawl', 'opportunity:list', 'opportunity:add', 'opportunity:edit', 'opportunity:delete', 'opportunity:stage')
AND NOT EXISTS (SELECT 1 FROM `sys_role_menu` x WHERE x.role_id = r.id AND x.menu_id = m.id);

-- 考勤菜单授权给所有角色
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT r.id,  m.id FROM `sys_role` r, `sys_menu` m
WHERE m.`perms` IN ('attendance:sign', 'attendance:manage')
AND NOT EXISTS (SELECT 1 FROM `sys_role_menu` x WHERE x.role_id = r.id AND x.menu_id = m.id);

-- 自动补齐角色授权的父级目录链（防止清理后侧边栏丢目录）
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT DISTINCT rm.`role_id`, m.`parent_id` FROM `sys_role_menu` rm JOIN `sys_menu` m ON rm.`menu_id` = m.`id`
WHERE m.`parent_id` <> '0'
AND NOT EXISTS (SELECT 1 FROM `sys_role_menu` x WHERE x.`role_id` = rm.`role_id` AND x.`menu_id` = m.`parent_id`);
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT DISTINCT rm.`role_id`, g.`parent_id` FROM `sys_role_menu` rm
JOIN `sys_menu` m ON rm.`menu_id` = m.`id` JOIN `sys_menu` g ON g.`id` = m.`parent_id`
WHERE g.`parent_id` <> '0'
AND NOT EXISTS (SELECT 1 FROM `sys_role_menu` x WHERE x.`role_id` = rm.`role_id` AND x.`menu_id` = g.`parent_id`);

-- 首页对所有已授权角色开放
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT DISTINCT rm.`role_id`, (SELECT `id` FROM `sys_menu` WHERE `menu_name` = '首页' AND IFNULL(`parent_id`,'0') = '0' LIMIT 1)
FROM `sys_role_menu` rm;


-- =====================================================
-- 九、商机情报表（网上公开的项目信息 / 招投标信息）
-- =====================================================
CREATE TABLE IF NOT EXISTS `crm_business_opportunity` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键',
  `title`              VARCHAR(500)  NOT NULL COMMENT '标题（项目名称/公告标题）',
  `type`               VARCHAR(20)   NOT NULL DEFAULT 'tender' COMMENT '类型：tender-招投标 project-项目信息',
  `source`             VARCHAR(100)  DEFAULT NULL COMMENT '来源（发布平台/数据源）',
  `source_url`         VARCHAR(1000) DEFAULT NULL COMMENT '原文链接',
  `region`             VARCHAR(100)  DEFAULT NULL COMMENT '地区',
  `industry`           VARCHAR(100)  DEFAULT NULL COMMENT '行业',
  `budget_amount`      DECIMAL(20,2) DEFAULT NULL COMMENT '预算金额（元）',
  `publisher`          VARCHAR(255)  DEFAULT NULL COMMENT '招标人/业主单位',
  `publish_time`       DATETIME      DEFAULT NULL COMMENT '公告发布时间',
  `deadline_time`      DATETIME      DEFAULT NULL COMMENT '截止时间（投标/报名）',
  `procurement_method` VARCHAR(50)   DEFAULT NULL COMMENT '采购方式',
  `project_no`         VARCHAR(100)  DEFAULT NULL COMMENT '项目编号',
  `summary`            TEXT          COMMENT '摘要/项目概况',
  `status`             VARCHAR(20)   NOT NULL DEFAULT 'new' COMMENT '状态：new-新增 following-跟进中 handled-已跟进 abandoned-已放弃',
  `followed_by`        VARCHAR(100)  DEFAULT NULL COMMENT '关注人姓名',
  `followed_time`      DATETIME      DEFAULT NULL COMMENT '关注时间',
  `is_demo`            TINYINT(1)    NOT NULL DEFAULT 0 COMMENT '是否演示数据 0-否 1-是',
  `create_time`        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time`        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted`            TINYINT(1)    NOT NULL DEFAULT 0 COMMENT '逻辑删除 0-否 1-是',
  PRIMARY KEY (`id`),
  KEY `idx_type_status` (`type`, `status`),
  KEY `idx_publish_time` (`publish_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商机情报（公开项目/招投标信息）';

-- 9.1 商机情报-用户已读记录
CREATE TABLE IF NOT EXISTS `crm_business_opportunity_read` (
  `id`             VARCHAR(36) NOT NULL COMMENT '主键',
  `user_id`        VARCHAR(36) NOT NULL COMMENT '用户ID',
  `opportunity_id` VARCHAR(36) NOT NULL COMMENT '商机情报ID',
  `create_time`    DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '首次阅读时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_opportunity` (`user_id`, `opportunity_id`),
  KEY `idx_opportunity_id` (`opportunity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商机情报-用户已读记录';

-- 9.2 签到记录
CREATE TABLE IF NOT EXISTS `crm_attendance` (
  `id`              VARCHAR(36) NOT NULL COMMENT '主键',
  `user_id`         VARCHAR(36) DEFAULT NULL COMMENT '签到用户ID',
  `attendance_date` DATE        DEFAULT NULL COMMENT '签到日期',
  `sign_in_time`    DATETIME    DEFAULT NULL COMMENT '签到时间',
  `sign_in_face`    VARCHAR(500) DEFAULT NULL COMMENT '签到人脸照片地址',
  `sign_in_address` VARCHAR(255) DEFAULT NULL COMMENT '签到地点',
  `sign_out_time`   DATETIME    DEFAULT NULL COMMENT '签退时间',
  `sign_out_face`   VARCHAR(500) DEFAULT NULL COMMENT '签退人脸照片地址',
  `status`          VARCHAR(20)  DEFAULT NULL COMMENT '状态：normal-正常 late-迟到 early-早退',
  `face_verified`   TINYINT      DEFAULT NULL COMMENT '是否人脸核验 0-否 1-是',
  `remark`          VARCHAR(500) DEFAULT NULL COMMENT '备注',
  `create_time`     DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time`     DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted`         TINYINT(1)  NOT NULL DEFAULT 0 COMMENT '逻辑删除 0-否 1-是',
  `is_demo`         TINYINT(1)  NOT NULL DEFAULT 0 COMMENT '是否演示数据 0-否 1-是',
  PRIMARY KEY (`id`),
  KEY `idx_user_date` (`user_id`, `attendance_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='签到记录';

-- 9.3 消息模板
CREATE TABLE IF NOT EXISTS `crm_message_template` (
  `id`            VARCHAR(36) NOT NULL COMMENT '主键',
  `template_code` VARCHAR(100) DEFAULT NULL COMMENT '模板编码（唯一）',
  `template_name` VARCHAR(100) DEFAULT NULL COMMENT '模板名称',
  `channel`       VARCHAR(20)  DEFAULT NULL COMMENT '渠道：sms-短信 email-邮件 site-站内信',
  `biz_type`      VARCHAR(50)  DEFAULT NULL COMMENT '业务类型',
  `title`         VARCHAR(255) DEFAULT NULL COMMENT '消息标题',
  `content`       TEXT         COMMENT '模板内容，支持 ${变量} 占位',
  `remark`        VARCHAR(500) DEFAULT NULL COMMENT '备注',
  `status`        VARCHAR(20)  DEFAULT NULL COMMENT '状态：enabled-启用 disabled-停用',
  `create_time`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted`       TINYINT(1)   NOT NULL DEFAULT 0 COMMENT '逻辑删除 0-否 1-是',
  `is_demo`       TINYINT(1)   NOT NULL DEFAULT 0 COMMENT '是否演示数据 0-否 1-是',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_template_code` (`template_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消息模板';

-- 9.4 消息通知记录
CREATE TABLE IF NOT EXISTS `crm_message` (
  `id`            VARCHAR(36) NOT NULL COMMENT '主键',
  `channel`       VARCHAR(20)  DEFAULT NULL COMMENT '渠道：sms-短信 email-邮件 site-站内信',
  `template_id`   VARCHAR(36)  DEFAULT NULL COMMENT '关联模板ID',
  `template_code` VARCHAR(100) DEFAULT NULL COMMENT '模板编码',
  `receiver`      VARCHAR(255) DEFAULT NULL COMMENT '接收方（手机号/邮箱/用户ID）',
  `receiver_name` VARCHAR(100) DEFAULT NULL COMMENT '接收人姓名',
  `user_id`       VARCHAR(36)  DEFAULT NULL COMMENT '站内信接收用户ID（用于我的消息收件箱）',
  `is_read`       TINYINT(1)   NOT NULL DEFAULT 0 COMMENT '站内信是否已读 0-未读 1-已读',
  `title`         VARCHAR(255) DEFAULT NULL COMMENT '消息标题',
  `content`       TEXT         COMMENT '消息内容',
  `biz_type`      VARCHAR(50)  DEFAULT NULL COMMENT '业务类型',
  `biz_id`        VARCHAR(36)  DEFAULT NULL COMMENT '关联业务ID',
  `status`        VARCHAR(20)  DEFAULT NULL COMMENT '状态：success-成功 fail-失败',
  `fail_reason`   VARCHAR(500) DEFAULT NULL COMMENT '失败原因',
  `send_time`     DATETIME     DEFAULT NULL COMMENT '发送时间',
  `create_time`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted`       TINYINT(1)   NOT NULL DEFAULT 0 COMMENT '逻辑删除 0-否 1-是',
  `is_demo`       TINYINT(1)   NOT NULL DEFAULT 0 COMMENT '是否演示数据 0-否 1-是',
  PRIMARY KEY (`id`),
  KEY `idx_receiver` (`receiver`),
  KEY `idx_biz` (`biz_type`, `biz_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消息通知记录';

-- =====================================================
-- 十、商机抓取数据源（多数据源配置）
-- =====================================================
CREATE TABLE IF NOT EXISTS `crm_crawl_source` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键',
  `source_name`     VARCHAR(100)  NOT NULL COMMENT '数据源名称',
  `source_type`     VARCHAR(20)   NOT NULL DEFAULT 'custom' COMMENT '类型：custom-自定义API demo-内置演示',
  `base_url`        VARCHAR(500)  DEFAULT NULL COMMENT '接口地址',
  `app_key`         VARCHAR(200)  DEFAULT NULL COMMENT 'AppKey',
  `app_secret`      VARCHAR(200)  DEFAULT NULL COMMENT 'AppSecret',
  `enabled`         TINYINT(1)    NOT NULL DEFAULT 1 COMMENT '是否启用 0-停用 1-启用',
  `remark`          VARCHAR(500)  DEFAULT NULL COMMENT '备注',
  `last_crawl_time` DATETIME      DEFAULT NULL COMMENT '最近抓取时间',
  `last_result`     TEXT          COMMENT '最近抓取结果',
  `create_time`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted`         TINYINT(1)    NOT NULL DEFAULT 0 COMMENT '逻辑删除 0-否 1-是',
  PRIMARY KEY (`id`),
  KEY `idx_enabled` (`enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商机抓取数据源';

-- 内置演示数据源（幂等：已有数据源则不重复插入）
INSERT IGNORE INTO `crm_crawl_source` (`id`, `source_name`, `source_type`, `enabled`, `remark`)
SELECT'6cad02d8-b51c-4755-b41b-4e1feb74c58a',  '内置演示数据',  'demo',  1,  '开箱即用：生成贴近真实的招投标/项目公告演示数据，无需任何配置'
WHERE NOT EXISTS (SELECT 1 FROM `crm_crawl_source` WHERE `deleted` = 0);

-- 默认演示数据源：模拟常见公开商机发布平台，零配置即可一键抓取演示数据。
-- 以下均为演示性质（source_type=demo），接入真实数据请新增 custom 类型并填写第三方 API 地址。
INSERT IGNORE INTO `crm_crawl_source` (`id`, `source_name`, `source_type`, `enabled`, `remark`)
SELECT s.id, s.name, 'demo', 1, s.remark FROM (
  SELECT 'a1f3c2e0-1001-4a2b-8c5d-000000000001' AS id, '全国公共资源交易平台' AS name, '对接全国公共资源交易服务平台，覆盖各省市工程建设、政府采购等公开交易信息' AS remark UNION ALL
  SELECT 'a1f3c2e0-1001-4a2b-8c5d-000000000002', '中国政府采购网', '对接中国政府采购网，获取中央及地方政府采购公告、中标结果等信息' UNION ALL
  SELECT 'a1f3c2e0-1001-4a2b-8c5d-000000000003', '中国招标投标公共服务平台', '对接中国招标投标公共服务平台，覆盖工程、货物、服务类招标公告' UNION ALL
  SELECT 'a1f3c2e0-1001-4a2b-8c5d-000000000004', '企业工商公开信息', '对接公开企业工商/招采信息，用于发现潜在客户与项目机会'
) s
WHERE NOT EXISTS (SELECT 1 FROM `crm_crawl_source` WHERE `source_name` = s.name AND `deleted` = 0);

-- =====================================================
-- 十一、数据库定时备份配置（轻量级，单行配置）
-- =====================================================
CREATE TABLE IF NOT EXISTS `sys_backup_config` (
  `id`               VARCHAR(36) NOT NULL COMMENT '主键',
  `enabled`          TINYINT(1)    NOT NULL DEFAULT 0 COMMENT '是否启用定时备份 0-停用 1-启用',
  `cron`             VARCHAR(60)   NOT NULL DEFAULT '0 0 2 * * ?' COMMENT '定时备份 cron 表达式（每天凌晨 2 点）',
  `backup_dir`       VARCHAR(500)  NOT NULL DEFAULT './backups' COMMENT '备份文件存放目录',
  `retention_days`   INT(11)       NOT NULL DEFAULT 7 COMMENT '备份保留天数，超过自动清理',
  `use_mysqldump`    TINYINT(1)    NOT NULL DEFAULT 0 COMMENT '优先使用 mysqldump（0-关，走内置 JDBC 备份）',
  `mysqldump_path`   VARCHAR(500)  DEFAULT NULL COMMENT 'mysqldump 可执行文件路径（留空自动探测）',
  `create_time`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='数据库定时备份配置';

-- 默认备份配置（幂等：已存在则不重复插入）
INSERT IGNORE INTO `sys_backup_config` (`id`, `enabled`, `cron`, `backup_dir`, `retention_days`, `use_mysqldump`)
SELECT 'b1c2d3e4-0001-4a2b-8c5d-000000000001', 0, '0 0 2 * * ?', './backups', 7, 0
WHERE NOT EXISTS (SELECT 1 FROM `sys_backup_config`);

-- =====================================================
-- =====================================================

-- 消息通知记录
CREATE TABLE IF NOT EXISTS crm_message (
  `id` VARCHAR(36) NOT NULL COMMENT '主键',
  channel VARCHAR(20) NOT NULL DEFAULT 'sms' COMMENT '渠道：sms-短信 email-邮件 site-站内信',
  template_id VARCHAR(36) DEFAULT NULL COMMENT '消息模板ID',
  template_code VARCHAR(60) DEFAULT NULL COMMENT '模板编码',
  receiver VARCHAR(200) DEFAULT NULL COMMENT '接收方（手机号/邮箱/用户ID）',
  receiver_name VARCHAR(100) DEFAULT NULL COMMENT '接收人姓名',
  title VARCHAR(200) DEFAULT NULL COMMENT '消息标题',
  content TEXT COMMENT '消息内容',
  biz_type VARCHAR(50) DEFAULT NULL COMMENT '业务类型',
  biz_id VARCHAR(36) DEFAULT NULL COMMENT '关联业务ID',
  status VARCHAR(20) NOT NULL DEFAULT 'success' COMMENT '状态：success-成功 fail-失败',
  fail_reason VARCHAR(500) DEFAULT NULL COMMENT '失败原因',
  send_time DATETIME DEFAULT NULL COMMENT '发送时间',
  create_time DATETIME DEFAULT NULL COMMENT '创建时间',
  update_time DATETIME DEFAULT NULL COMMENT '更新时间',
  deleted TINYINT NOT NULL DEFAULT 0 COMMENT '逻辑删除：0-未删除 1-已删除',
  is_demo TINYINT NOT NULL DEFAULT 0 COMMENT '是否演示数据：1-是 0-否',
  PRIMARY KEY (id),
  KEY idx_channel (channel),
  KEY idx_send_time (send_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消息通知记录';

-- 消息模板
CREATE TABLE IF NOT EXISTS crm_message_template (
  `id` VARCHAR(36) NOT NULL COMMENT '主键',
  template_code VARCHAR(60) NOT NULL COMMENT '模板编码（唯一）',
  template_name VARCHAR(100) NOT NULL COMMENT '模板名称',
  channel VARCHAR(20) NOT NULL DEFAULT 'sms' COMMENT '渠道：sms-短信 email-邮件 site-站内信',
  biz_type VARCHAR(50) DEFAULT NULL COMMENT '业务类型',
  title VARCHAR(200) DEFAULT NULL COMMENT '消息标题（邮件/站内信用）',
  content TEXT NOT NULL COMMENT '模板内容，支持 ${变量} 占位',
  remark VARCHAR(300) DEFAULT NULL COMMENT '备注',
  status VARCHAR(20) NOT NULL DEFAULT 'enabled' COMMENT '状态：enabled-启用 disabled-停用',
  create_time DATETIME DEFAULT NULL COMMENT '创建时间',
  update_time DATETIME DEFAULT NULL COMMENT '更新时间',
  deleted TINYINT NOT NULL DEFAULT 0 COMMENT '逻辑删除：0-未删除 1-已删除',
  is_demo TINYINT NOT NULL DEFAULT 0 COMMENT '是否演示数据：1-是 0-否',
  PRIMARY KEY (id),
  UNIQUE KEY uk_template_code (template_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消息模板';

-- 签到记录
CREATE TABLE IF NOT EXISTS crm_attendance (
  `id` VARCHAR(36) NOT NULL COMMENT '主键',
  user_id VARCHAR(36) NOT NULL COMMENT '签到用户ID',
  attendance_date DATE NOT NULL COMMENT '签到日期',
  sign_in_time DATETIME DEFAULT NULL COMMENT '签到时间',
  sign_in_face VARCHAR(500) DEFAULT NULL COMMENT '签到人脸照片地址',
  sign_in_address VARCHAR(200) DEFAULT NULL COMMENT '签到地点',
  sign_out_time DATETIME DEFAULT NULL COMMENT '签退时间',
  sign_out_face VARCHAR(500) DEFAULT NULL COMMENT '签退人脸照片地址',
  status VARCHAR(20) NOT NULL DEFAULT 'normal' COMMENT '状态：normal-正常 late-迟到 early-早退',
  face_verified TINYINT NOT NULL DEFAULT 0 COMMENT '是否人脸核验：0-否 1-是',
  remark VARCHAR(300) DEFAULT NULL COMMENT '备注',
  create_time DATETIME DEFAULT NULL COMMENT '创建时间',
  update_time DATETIME DEFAULT NULL COMMENT '更新时间',
  deleted TINYINT NOT NULL DEFAULT 0 COMMENT '逻辑删除：0-未删除 1-已删除',
  is_demo TINYINT NOT NULL DEFAULT 0 COMMENT '是否演示数据：1-是 0-否',
  PRIMARY KEY (id),
  KEY idx_user_date (user_id, attendance_date),
  KEY idx_date (attendance_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='签到记录';

-- 补充：侧边栏动态菜单所需菜单项（我的日程/消息/考勤/AI助手/个人信息），与 db/init.sql 保持一致
INSERT IGNORE INTO `sys_menu` (`id`, `parent_id`, `menu_name`, `path`, `component`, `perms`, `icon`, `menu_type`, `sort`, `visible`) VALUES('f2c1a9b0-0001-4a2c-8d2a-000000000001', '0', '我的日程', '/schedule/list', 'schedule/list', NULL, 'Calendar', 'C', 9, 1),
('f2c1a9b0-0009-4a2c-8d2a-000000000009', '0', '消息管理', NULL, NULL, NULL, 'Bell', 'M', 11, 1),
('f2c1a9b0-0002-4a2c-8d2a-000000000002', 'f2c1a9b0-0009-4a2c-8d2a-000000000009', '消息通知', '/message/notify', 'message/notify', NULL, 'Message', 'C', 1, 1),
('f2c1a9b0-0003-4a2c-8d2a-000000000003', 'f2c1a9b0-0009-4a2c-8d2a-000000000009', '消息模板', '/message/template', 'message/template', NULL, 'Document', 'C', 2, 1),
('f2c1a9b0-0004-4a2c-8d2a-000000000004', '0', '考勤管理', '/attendance', NULL, NULL, 'Clock', 'M', 12, 1),
('f2c1a9b0-0005-4a2c-8d2a-000000000005', 'f2c1a9b0-0004-4a2c-8d2a-000000000004', '签到', '/attendance/sign', 'attendance/sign', NULL, 'Clock', 'C', 1, 1),
('f2c1a9b0-0006-4a2c-8d2a-000000000006', 'f2c1a9b0-0004-4a2c-8d2a-000000000004', '签到管理', '/attendance/manage', 'attendance/manage', NULL, 'List', 'C', 2, 1);
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT r.id, m.id FROM `sys_role` r, `sys_menu` m
WHERE m.id IN ('f2c1a9b0-0001-4a2c-8d2a-000000000001','f2c1a9b0-0004-4a2c-8d2a-000000000004','f2c1a9b0-0005-4a2c-8d2a-000000000005','f2c1a9b0-0006-4a2c-8d2a-000000000006','f2c1a9b0-0007-4a2c-8d2a-000000000007','f2c1a9b0-0008-4a2c-8d2a-000000000008')
AND NOT EXISTS (SELECT 1 FROM `sys_role_menu` x WHERE x.role_id = r.id AND x.menu_id = m.id);


-- ==================== 多平台发布中心（参照 CSDN 多平台发布中心） ====================
CREATE TABLE IF NOT EXISTS `crm_content_sync` (
  `id` varchar(36) NOT NULL COMMENT '主键UUID',
  `content_id` varchar(36) NOT NULL COMMENT '图文ID',
  `content_title` varchar(255) DEFAULT NULL COMMENT '图文标题快照',
  `platform_code` varchar(50) NOT NULL COMMENT '平台编码',
  `platform_name` varchar(50) DEFAULT NULL COMMENT '平台名称',
  `status` tinyint DEFAULT 0 COMMENT '0待同步 1同步中 2成功 3失败',
  `adapt_title` varchar(255) DEFAULT NULL COMMENT '适配后标题',
  `result_url` varchar(500) DEFAULT NULL COMMENT '发布后文章链接',
  `result_msg` text DEFAULT NULL COMMENT '结果信息/失败原因/插件适配日志',
  `sync_time` datetime DEFAULT NULL COMMENT '同步完成时间',
  `create_by` varchar(36) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `deleted` tinyint DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_ccs_content_id` (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='图文多平台同步记录表';



INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT r.id, m.id FROM `sys_role` r, `sys_menu` m
WHERE m.`perms` = 'content:sync'
AND NOT EXISTS (SELECT 1 FROM `sys_role_menu` x WHERE x.role_id = r.id AND x.menu_id = m.id);

-- 已有库升级：任务/日程提醒（渠道 / 次数 / 间隔）+ 站内信已读 + 邮件 SMTP 配置（幂等）
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task' AND COLUMN_NAME = 'remind_channel');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_task` ADD COLUMN `remind_channel` VARCHAR(50)  DEFAULT NULL COMMENT ''提醒渠道: site-站内信 email-邮件 sms-短信(多个用逗号分隔)'' AFTER `remind_time`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task' AND COLUMN_NAME = 'remind_count');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_task` ADD COLUMN `remind_count` INT NOT NULL DEFAULT 1 COMMENT ''提醒次数'' AFTER `remind_channel`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task' AND COLUMN_NAME = 'remind_interval');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_task` ADD COLUMN `remind_interval` INT NOT NULL DEFAULT 30 COMMENT ''多次提醒时的间隔(分钟)'' AFTER `remind_count`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task' AND COLUMN_NAME = 'reminded_count');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_task` ADD COLUMN `reminded_count` INT NOT NULL DEFAULT 0 COMMENT ''已提醒次数'' AFTER `remind_interval`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_schedule');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_schedule' AND COLUMN_NAME = 'remind_channel');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_schedule` ADD COLUMN `remind_channel` VARCHAR(50)  DEFAULT NULL COMMENT ''提醒渠道: site-站内信 email-邮件 sms-短信(多个用逗号分隔)'' AFTER `remind_time`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_schedule');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_schedule' AND COLUMN_NAME = 'remind_count');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_schedule` ADD COLUMN `remind_count` INT NOT NULL DEFAULT 1 COMMENT ''提醒次数'' AFTER `remind_channel`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_schedule');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_schedule' AND COLUMN_NAME = 'remind_interval');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_schedule` ADD COLUMN `remind_interval` INT NOT NULL DEFAULT 30 COMMENT ''多次提醒时的间隔(分钟)'' AFTER `remind_count`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_schedule');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_schedule' AND COLUMN_NAME = 'reminded_count');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_schedule` ADD COLUMN `reminded_count` INT NOT NULL DEFAULT 0 COMMENT ''已提醒次数'' AFTER `remind_interval`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_message');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_message' AND COLUMN_NAME = 'user_id');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_message` ADD COLUMN `user_id` VARCHAR(36)  DEFAULT NULL COMMENT ''站内信接收用户ID（用于我的消息收件箱）'' AFTER `receiver_name`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_message');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_message' AND COLUMN_NAME = 'is_read');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_message` ADD COLUMN `is_read` TINYINT(1) NOT NULL DEFAULT 0 COMMENT ''站内信是否已读 0-未读 1-已读'' AFTER `user_id`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'mail_enabled');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `sys_setting` ADD COLUMN `mail_enabled` TINYINT NOT NULL DEFAULT 0 COMMENT ''邮件提醒开关 0-关闭(模拟发送) 1-开启'' AFTER `attendance_work_time`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'mail_host');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `sys_setting` ADD COLUMN `mail_host` VARCHAR(100) DEFAULT NULL COMMENT ''SMTP 服务器地址'' AFTER `mail_enabled`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'mail_port');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `sys_setting` ADD COLUMN `mail_port` INT DEFAULT 465 COMMENT ''SMTP 端口'' AFTER `mail_host`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'mail_ssl');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `sys_setting` ADD COLUMN `mail_ssl` TINYINT NOT NULL DEFAULT 1 COMMENT ''是否启用 SSL 0-否 1-是'' AFTER `mail_port`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'mail_username');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `sys_setting` ADD COLUMN `mail_username` VARCHAR(100) DEFAULT NULL COMMENT ''SMTP 账号（发件邮箱）'' AFTER `mail_ssl`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'mail_password');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `sys_setting` ADD COLUMN `mail_password` VARCHAR(255) DEFAULT NULL COMMENT ''SMTP 密码/授权码'' AFTER `mail_username`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'mail_from');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `sys_setting` ADD COLUMN `mail_from` VARCHAR(100) DEFAULT NULL COMMENT ''发件人显示名称'' AFTER `mail_password`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：为 sys_setting 补充云邮件服务商配置列（旧库缺列会导致查询系统设置报 Unknown column 'mail_provider'）
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'mail_provider');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `sys_setting` ADD COLUMN `mail_provider` VARCHAR(20) NOT NULL DEFAULT ''smtp'' COMMENT ''邮件服务商 smtp/aliyun/tencent'' AFTER `mail_from`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'mail_access_key_id');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `sys_setting` ADD COLUMN `mail_access_key_id` VARCHAR(128) DEFAULT NULL COMMENT ''云邮件 AccessKeyId'' AFTER `mail_provider`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'mail_access_key_secret');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `sys_setting` ADD COLUMN `mail_access_key_secret` VARCHAR(256) DEFAULT NULL COMMENT ''云邮件 AccessKeySecret'' AFTER `mail_access_key_id`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'mail_region');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `sys_setting` ADD COLUMN `mail_region` VARCHAR(32) DEFAULT NULL COMMENT ''云邮件地域'' AFTER `mail_access_key_secret`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：为 sys_setting 补充「首次部署跳过演示数据导入」标记列（幂等）
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'demo_data_skipped');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `sys_setting` ADD COLUMN `demo_data_skipped` TINYINT NOT NULL DEFAULT 0 COMMENT ''首次部署时是否已跳过演示数据导入提示 0-未跳过 1-已跳过'' AFTER `demo_data_editable`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：新增侧边栏「我的消息」菜单（站内信收件箱，任务/日程提醒入口），挂在「消息管理」下，并授权给所有角色（幂等）
INSERT IGNORE INTO `sys_menu` (`id`, `parent_id`, `menu_name`, `path`, `component`, `perms`, `icon`, `menu_type`, `sort`, `visible`) VALUES('f2c1a9b0-000a-4a2c-8d2a-00000000000a', 'f2c1a9b0-0009-4a2c-8d2a-000000000009', '我的消息', '/message/my', 'message/my', NULL, 'Bell', 'C', 3, 1);
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT r.id, m.id FROM `sys_role` r, `sys_menu` m
WHERE m.id = 'f2c1a9b0-000a-4a2c-8d2a-00000000000a'
AND NOT EXISTS (SELECT 1 FROM `sys_role_menu` x WHERE x.role_id = r.id AND x.menu_id = m.id);

-- 已有库升级：将此前已建为顶级菜单的「我的消息」迁移到「消息管理」下（幂等）
UPDATE `sys_menu` SET `parent_id` = 'f2c1a9b0-0009-4a2c-8d2a-000000000009', `sort` = 3
WHERE `id` = 'f2c1a9b0-000a-4a2c-8d2a-00000000000a';

-- 已有库升级：将「消息管理」父菜单授权给所有角色，确保非管理员也能看到其下的「我的消息」收件箱
-- （消息通知/消息模板仍仅授权给超级管理员，详见上方升级块，此处不改动二者）
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT r.id, 'f2c1a9b0-0009-4a2c-8d2a-000000000009' FROM `sys_role` r
WHERE NOT EXISTS (SELECT 1 FROM `sys_role_menu` x WHERE x.role_id = r.id AND x.menu_id = 'f2c1a9b0-0009-4a2c-8d2a-000000000009');

-- ==================== AI-GEO 智能中心（生成式引擎优化） ====================

-- 巡检工作日志
CREATE TABLE IF NOT EXISTS `geo_work_log` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键',
  `run_type` VARCHAR(20) NOT NULL DEFAULT 'manual' COMMENT '触发方式: auto-自动 manual-手动',
  `status` VARCHAR(20) NOT NULL DEFAULT 'running' COMMENT '状态: running/done/failed',
  `engine_count` INT DEFAULT 0 COMMENT '巡检引擎数',
  `keyword_count` INT DEFAULT 0 COMMENT '巡检关键词数',
  `probe_count` INT DEFAULT 0 COMMENT '探测记录数',
  `brand_mentions` INT DEFAULT 0 COMMENT '品牌被提及次数',
  `summary` VARCHAR(500) DEFAULT NULL COMMENT '巡检摘要',
  `report` TEXT COMMENT 'AI 优化建议报告',
  `error_msg` VARCHAR(500) DEFAULT NULL COMMENT '失败原因',
  `create_time` DATETIME DEFAULT NULL COMMENT '创建时间',
  `update_time` DATETIME DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='GEO 巡检工作日志';

-- 引擎探测记录
CREATE TABLE IF NOT EXISTS `geo_probe` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键',
  `log_id` VARCHAR(36) DEFAULT NULL COMMENT '关联 geo_work_log.id',
  `engine` VARCHAR(50) NOT NULL COMMENT 'AI 引擎名称',
  `keyword` VARCHAR(200) NOT NULL COMMENT '监控关键词',
  `mentioned` TINYINT NOT NULL DEFAULT 0 COMMENT '品牌是否被提及 0-否 1-是',
  `rank_pos` INT DEFAULT NULL COMMENT '品牌首次提及位置',
  `sentiment` VARCHAR(10) DEFAULT 'neu' COMMENT '情感倾向: pos/neu/neg',
  `competitors` VARCHAR(500) DEFAULT NULL COMMENT '被提及的竞品（逗号分隔）',
  `citations` VARCHAR(1000) DEFAULT NULL COMMENT '引用链接（逗号分隔）',
  `answer_summary` VARCHAR(1000) DEFAULT NULL COMMENT 'AI 回答摘要',
  `create_time` DATETIME DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_log` (`log_id`),
  KEY `idx_engine` (`engine`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='GEO 引擎探测记录';

-- 监控关键词（话题簇）
CREATE TABLE IF NOT EXISTS `geo_keyword` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键',
  `keyword` VARCHAR(200) NOT NULL COMMENT '关键词',
  `enabled` TINYINT NOT NULL DEFAULT 1 COMMENT '是否启用 1-是 0-否',
  `remark` VARCHAR(300) DEFAULT NULL COMMENT '备注',
  `deleted` TINYINT NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` DATETIME DEFAULT NULL COMMENT '创建时间',
  `update_time` DATETIME DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='GEO 监控关键词';

-- 行动清单
CREATE TABLE IF NOT EXISTS `geo_action` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键',
  `title` VARCHAR(300) NOT NULL COMMENT '行动标题',
  `priority` VARCHAR(10) NOT NULL DEFAULT 'mid' COMMENT '优先级: high/mid/low',
  `status` VARCHAR(20) NOT NULL DEFAULT 'pending' COMMENT '状态: pending/doing/done',
  `source` VARCHAR(20) NOT NULL DEFAULT 'manual' COMMENT '来源: auto-巡检生成 manual-人工',
  `remark` VARCHAR(500) DEFAULT NULL COMMENT '备注',
  `deleted` TINYINT NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` DATETIME DEFAULT NULL COMMENT '创建时间',
  `update_time` DATETIME DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='GEO 行动清单';

-- 品牌事实库
CREATE TABLE IF NOT EXISTS `geo_brand_fact` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键',
  `fact_key` VARCHAR(200) NOT NULL COMMENT '事实条目',
  `fact_value` VARCHAR(1000) DEFAULT NULL COMMENT '标准答案',
  `source` VARCHAR(300) DEFAULT NULL COMMENT '信息来源',
  `deleted` TINYINT NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` DATETIME DEFAULT NULL COMMENT '创建时间',
  `update_time` DATETIME DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='GEO 品牌事实库';

-- 网站审计结果
CREATE TABLE IF NOT EXISTS `geo_site_audit` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键',
  `website` VARCHAR(255) NOT NULL COMMENT '审计的官网地址',
  `robots_ok` TINYINT DEFAULT 0 COMMENT 'robots.txt 是否存在 0/1',
  `llms_txt_ok` TINYINT DEFAULT 0 COMMENT 'llms.txt 是否存在 0/1',
  `meta_ok` TINYINT DEFAULT 0 COMMENT '首页 title/meta 是否完善 0/1',
  `score` INT DEFAULT 0 COMMENT '综合得分 0-100',
  `issues` TEXT COMMENT '问题清单（JSON 数组）',
  `create_time` DATETIME DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='GEO 网站审计结果';

-- sys_setting 幂等加列：GEO 配置
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'geo_brand_name');
SET @ddl := IF(@col_exist = 0, 'ALTER TABLE `sys_setting` ADD COLUMN `geo_brand_name` VARCHAR(100) DEFAULT NULL COMMENT ''GEO:品牌名称''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;

SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'geo_website');
SET @ddl := IF(@col_exist = 0, 'ALTER TABLE `sys_setting` ADD COLUMN `geo_website` VARCHAR(255) DEFAULT NULL COMMENT ''GEO:官网地址''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;

SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'geo_competitors');
SET @ddl := IF(@col_exist = 0, 'ALTER TABLE `sys_setting` ADD COLUMN `geo_competitors` VARCHAR(500) DEFAULT NULL COMMENT ''GEO:竞品列表''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;

SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'geo_engines');
SET @ddl := IF(@col_exist = 0, 'ALTER TABLE `sys_setting` ADD COLUMN `geo_engines` VARCHAR(255) DEFAULT NULL COMMENT ''GEO:模拟探测的AI引擎''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;

SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'geo_auto_enabled');
SET @ddl := IF(@col_exist = 0, 'ALTER TABLE `sys_setting` ADD COLUMN `geo_auto_enabled` TINYINT NOT NULL DEFAULT 0 COMMENT ''GEO:自动巡检开关''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;

SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'geo_patrol_keywords');
SET @ddl := IF(@col_exist = 0, 'ALTER TABLE `sys_setting` ADD COLUMN `geo_patrol_keywords` INT NOT NULL DEFAULT 5 COMMENT ''GEO:每轮巡检关键词数上限''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;

-- 菜单：GEO 智能中心页面 + 按钮权限，归属「营销管理」（幂等）
INSERT IGNORE INTO `sys_menu` (`id`, `parent_id`, `menu_name`, `path`, `component`, `perms`, `icon`, `menu_type`, `sort`, `visible`) VALUES
('f3c0a9b0-1102-4a2c-8d2a-000000000002', 'be976ef2-3265-457d-8890-6a7ba8510afb', 'GEO 中心', '/geo/index', 'geo/index', 'geo:view', 'Odometer', 'C', 0, 1),
('f3c0a9b0-1103-4a2c-8d2a-000000000003', 'f3c0a9b0-1102-4a2c-8d2a-000000000002', '手动巡检', NULL, NULL, 'geo:patrol', NULL, 'F', 1, 1),
('f3c0a9b0-1104-4a2c-8d2a-000000000004', 'f3c0a9b0-1102-4a2c-8d2a-000000000002', 'GEO 配置管理', NULL, NULL, 'geo:edit', NULL, 'F', 2, 1);

-- 已有库升级：把原隐藏的顶级「GEO 智能中心」目录迁移为「营销管理」下的可见页面（幂等）
UPDATE `sys_menu` SET `parent_id`='be976ef2-3265-457d-8890-6a7ba8510afb', `menu_name`='GEO 中心',
  `sort`=0, `visible`=1
WHERE `id`='f3c0a9b0-1102-4a2c-8d2a-000000000002';
DELETE FROM `sys_role_menu` WHERE `menu_id`='f3c0a9b0-1101-4a2c-8d2a-000000000001';
DELETE FROM `sys_menu` WHERE `id`='f3c0a9b0-1101-4a2c-8d2a-000000000001';

-- GEO 菜单授权（幂等）：拥有营销管理的角色均可访问
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT r.id, m.id FROM `sys_role` r, `sys_menu` m
WHERE m.`id` IN ('f3c0a9b0-1102-4a2c-8d2a-000000000002','f3c0a9b0-1103-4a2c-8d2a-000000000003','f3c0a9b0-1104-4a2c-8d2a-000000000004')
AND NOT EXISTS (SELECT 1 FROM `sys_role_menu` x WHERE x.role_id = r.id AND x.menu_id = m.id);

-- 已有库升级：为任务/日程/营销活动补充「发送方式」列（幂等）
-- remind_mode: scheduled-定时发送（按提醒时间调度） immediate-立即发送（保存后立即发一次，不参与调度）
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task' AND COLUMN_NAME = 'remind_mode');
SET @ddl := IF(@col_exist = 0,
  'ALTER TABLE `crm_task` ADD COLUMN `remind_mode` VARCHAR(20) DEFAULT NULL COMMENT ''发送方式 scheduled-定时 immediate-立即'' AFTER `remind_channel`',
  'SELECT 1');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_schedule' AND COLUMN_NAME = 'remind_mode');
SET @ddl := IF(@col_exist = 0,
  'ALTER TABLE `crm_schedule` ADD COLUMN `remind_mode` VARCHAR(20) DEFAULT NULL COMMENT ''发送方式 scheduled-定时 immediate-立即'' AFTER `remind_channel`',
  'SELECT 1');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'remind_mode');
SET @ddl := IF(@col_exist = 0,
  'ALTER TABLE `crm_marketing_activity` ADD COLUMN `remind_mode` VARCHAR(20) DEFAULT NULL COMMENT ''发送方式 scheduled-定时 immediate-立即'' AFTER `remind_channel`',
  'SELECT 1');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：sys_user 增加 intro_seen（系统使用须知已读标记，服务端保存，幂等）
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_user' AND COLUMN_NAME = 'intro_seen');
SET @ddl := IF(@col_exist = 0,
  'ALTER TABLE `sys_user` ADD COLUMN `intro_seen` TINYINT NOT NULL DEFAULT 0 COMMENT ''系统使用须知引导是否已读 0-未读 1-已读（服务端保存）''',
  'SELECT 1');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

-- WorkBuddy 专家分析记录表：保存「提问 -> 专家回答」历史，支持多轮追问(session_id)与业务对象关联
CREATE TABLE IF NOT EXISTS `crm_expert_analysis` (
  `id`              VARCHAR(36)  NOT NULL COMMENT '主键ID（UUID）',
  `expert_id`       VARCHAR(100) DEFAULT NULL COMMENT '专家标识（WorkBuddy 侧专家ID / 本地专家ID）',
  `expert_name`     VARCHAR(100) DEFAULT NULL COMMENT '专家名称',
  `question`        VARCHAR(1000) DEFAULT NULL COMMENT '提问内容',
  `context_summary` TEXT         COMMENT '发送给专家的 CRM 上下文摘要',
  `answer`          LONGTEXT     COMMENT '专家回答内容',
  `session_id`      VARCHAR(100) DEFAULT NULL COMMENT 'WorkBuddy 会话ID（多轮追问回传）',
  `biz_type`        VARCHAR(20)  DEFAULT 'none' COMMENT '关联业务类型 customer-客户 opportunity-商机 none-无',
  `biz_id`          VARCHAR(36)  DEFAULT NULL COMMENT '关联业务ID',
  `biz_name`        VARCHAR(200) DEFAULT NULL COMMENT '关联业务名称（冗余，便于列表展示）',
  `user_id`         VARCHAR(36)  DEFAULT NULL COMMENT '发起人（sys_user.id）',
  `duration_ms`     INT          DEFAULT NULL COMMENT '本次调用耗时（毫秒）',
  `status`          TINYINT      NOT NULL DEFAULT 1 COMMENT '状态 1-成功 0-失败',
  `error_message`   VARCHAR(500) DEFAULT NULL COMMENT '失败原因',
  `create_time`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`         TINYINT      NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_user_time` (`user_id`, `create_time`),
  KEY `idx_biz` (`biz_type`, `biz_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='WorkBuddy 专家分析记录表';

-- 销售目标表：按月份为每个销售设置销售目标金额，用于业绩排行榜的完成率计算
CREATE TABLE IF NOT EXISTS `crm_sales_target` (
  `id`            VARCHAR(36)   NOT NULL COMMENT '主键ID（UUID）',
  `user_id`       VARCHAR(36)   NOT NULL COMMENT '销售人员ID（sys_user.id）',
  `period`        VARCHAR(7)    NOT NULL COMMENT '目标月份 yyyy-MM',
  `target_amount` DECIMAL(14,2) NOT NULL DEFAULT 0 COMMENT '目标金额',
  `remark`        VARCHAR(200)  DEFAULT NULL COMMENT '备注',
  `create_time`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_period` (`user_id`, `period`),
  KEY `idx_period` (`period`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='销售目标表';

-- =====================================================================

-- =====================================================================
-- sys_setting 增加 WorkBuddy 专家分析配置（系统管理 → 系统配置 中维护）
-- 幂等：列已存在时不执行 ALTER（兼容 Spring SQL 初始化脚本逐条解析）
-- =====================================================================
SET @wbSql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE sys_setting ADD COLUMN workbuddy_enabled tinyint NULL COMMENT ''WorkBuddy 开关 0-关 1-开(NULL=沿用 yml)''', 'SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_enabled');
PREPARE wbStmt FROM @wbSql; EXECUTE wbStmt; DEALLOCATE PREPARE wbStmt;
SET @wbSql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE sys_setting ADD COLUMN workbuddy_base_url varchar(500) NULL COMMENT ''WorkBuddy 服务根地址''', 'SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_base_url');
PREPARE wbStmt FROM @wbSql; EXECUTE wbStmt; DEALLOCATE PREPARE wbStmt;
SET @wbSql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE sys_setting ADD COLUMN workbuddy_api_key varchar(500) NULL COMMENT ''WorkBuddy 调用凭证''', 'SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_api_key');
PREPARE wbStmt FROM @wbSql; EXECUTE wbStmt; DEALLOCATE PREPARE wbStmt;
SET @wbSql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE sys_setting ADD COLUMN workbuddy_auth_header varchar(50) NULL COMMENT ''鉴权请求头名称''', 'SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_auth_header');
PREPARE wbStmt FROM @wbSql; EXECUTE wbStmt; DEALLOCATE PREPARE wbStmt;
SET @wbSql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE sys_setting ADD COLUMN workbuddy_auth_scheme varchar(20) NULL COMMENT ''鉴权值前缀''', 'SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_auth_scheme');
PREPARE wbStmt FROM @wbSql; EXECUTE wbStmt; DEALLOCATE PREPARE wbStmt;
SET @wbSql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE sys_setting ADD COLUMN workbuddy_experts_path varchar(200) NULL COMMENT ''专家列表接口路径''', 'SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_experts_path');
PREPARE wbStmt FROM @wbSql; EXECUTE wbStmt; DEALLOCATE PREPARE wbStmt;
SET @wbSql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE sys_setting ADD COLUMN workbuddy_chat_path varchar(200) NULL COMMENT ''调用专家接口路径''', 'SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_chat_path');
PREPARE wbStmt FROM @wbSql; EXECUTE wbStmt; DEALLOCATE PREPARE wbStmt;
SET @wbSql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE sys_setting ADD COLUMN workbuddy_expert_id_field varchar(50) NULL COMMENT ''专家标识字段名''', 'SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_expert_id_field');
PREPARE wbStmt FROM @wbSql; EXECUTE wbStmt; DEALLOCATE PREPARE wbStmt;
SET @wbSql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE sys_setting ADD COLUMN workbuddy_question_field varchar(50) NULL COMMENT ''提问字段名''', 'SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_question_field');
PREPARE wbStmt FROM @wbSql; EXECUTE wbStmt; DEALLOCATE PREPARE wbStmt;
SET @wbSql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE sys_setting ADD COLUMN workbuddy_context_field varchar(50) NULL COMMENT ''上下文字段名''', 'SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_context_field');
PREPARE wbStmt FROM @wbSql; EXECUTE wbStmt; DEALLOCATE PREPARE wbStmt;
SET @wbSql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE sys_setting ADD COLUMN workbuddy_stream tinyint NOT NULL DEFAULT 0 COMMENT ''是否 SSE 流式''', 'SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_stream');
PREPARE wbStmt FROM @wbSql; EXECUTE wbStmt; DEALLOCATE PREPARE wbStmt;
SET @wbSql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE sys_setting ADD COLUMN workbuddy_timeout_seconds int NOT NULL DEFAULT 120 COMMENT ''读取超时(秒)''', 'SELECT 1') FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_timeout_seconds');
PREPARE wbStmt FROM @wbSql; EXECUTE wbStmt; DEALLOCATE PREPARE wbStmt;

-- =====================================================================
-- 新增页面菜单：专家分析 / 销售排行榜 / 客户群发 / 销售目标（幂等）
-- =====================================================================
-- 专家分析（顶级菜单，sort 9）
INSERT IGNORE INTO `sys_menu` (`id`,`parent_id`,`menu_name`,`path`,`component`,`perms`,`icon`,`menu_type`,`sort`,`visible`)
SELECT 'aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e01','0','专家分析','/workbuddy/expert','workbuddy/index','workbuddy:list','Headset','C',1,1
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM (SELECT 1 FROM `sys_menu` WHERE `path`='/workbuddy/expert') t);

-- 销售排行榜（挂在各「销售管理」菜单组下，sort 3）
INSERT IGNORE INTO `sys_menu` (`id`,`parent_id`,`menu_name`,`path`,`component`,`perms`,`icon`,`menu_type`,`sort`,`visible`)
SELECT 'aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e03','31cb7fad-a793-4e88-8b19-59f2799f4904','销售排行榜','/contract/rank','contract/rank','contract:rank','Histogram','C',3,1
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM (SELECT 1 FROM `sys_menu` WHERE `path`='/contract/rank' AND `parent_id`='31cb7fad-a793-4e88-8b19-59f2799f4904') t);

-- 客户群发（挂在各「营销管理」菜单组下，sort 3）
INSERT IGNORE INTO `sys_menu` (`id`,`parent_id`,`menu_name`,`path`,`component`,`perms`,`icon`,`menu_type`,`sort`,`visible`)
SELECT 'aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e05','be976ef2-3265-457d-8890-6a7ba8510afb','客户群发','/marketing/blast','marketing/blast','content:push','Promotion','C',3,1
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM (SELECT 1 FROM `sys_menu` WHERE `path`='/marketing/blast' AND `parent_id`='be976ef2-3265-457d-8890-6a7ba8510afb') t);

-- 销售目标（挂在各「销售管理」菜单组下，sort 4；默认仅超级管理员与销售经理可见）
INSERT IGNORE INTO `sys_menu` (`id`,`parent_id`,`menu_name`,`path`,`component`,`perms`,`icon`,`menu_type`,`sort`,`visible`)
SELECT 'aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e07','31cb7fad-a793-4e88-8b19-59f2799f4904','销售目标','/contract/target','contract/target','contract:target:list','Aim','C',4,1
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM (SELECT 1 FROM `sys_menu` WHERE `path`='/contract/target' AND `parent_id`='31cb7fad-a793-4e88-8b19-59f2799f4904') t);

-- 授权：专家分析 / 销售排行榜 / 客户群发给所有角色；销售目标仅给超级管理员与销售经理
INSERT IGNORE INTO `sys_role_menu` (`role_id`,`menu_id`)
SELECT r.`id`, m.`id` FROM `sys_role` r JOIN `sys_menu` m ON m.`path` IN ('/workbuddy/expert','/contract/rank','/marketing/blast');
INSERT IGNORE INTO `sys_role_menu` (`role_id`,`menu_id`)
SELECT r.`id`, m.`id` FROM `sys_role` r JOIN `sys_menu` m ON m.`path`='/contract/target'
WHERE r.`role_code` IN ('admin','sales_manager');

-- =====================================================================
-- 网上抓取的客户线索（客户群发的数据来源，独立于系统内客户 crm_customer）
-- =====================================================================
CREATE TABLE IF NOT EXISTS crm_web_lead (
  id varchar(36) NOT NULL PRIMARY KEY,
  company_name varchar(200) NOT NULL COMMENT '企业/客户名称',
  contact_name varchar(100) DEFAULT NULL COMMENT '联系人',
  phone varchar(50) DEFAULT NULL COMMENT '手机号',
  email varchar(200) DEFAULT NULL COMMENT '邮箱',
  website varchar(500) DEFAULT NULL COMMENT '官网',
  industry varchar(100) DEFAULT NULL COMMENT '行业',
  region varchar(100) DEFAULT NULL COMMENT '地区',
  source varchar(100) DEFAULT NULL COMMENT '数据来源',
  source_url varchar(1000) DEFAULT NULL COMMENT '来源链接',
  summary text COMMENT '摘要',
  status varchar(20) NOT NULL DEFAULT 'new' COMMENT '状态 new-未联系 contacted-已联系 ignored-已忽略',
  create_time datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  update_time datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted tinyint(1) NOT NULL DEFAULT 0,
  KEY idx_web_lead_company (company_name),
  KEY idx_web_lead_region (region)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='网上抓取的客户线索';

-- ==========================================================
-- 已有库升级：实体新增列自动对齐（逐列幂等，扫描实体与建表差异生成）
-- ==========================================================
-- crm_marketing_activity
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'visible_range') = 0,
  'ALTER TABLE `crm_marketing_activity` ADD COLUMN `visible_range` varchar(20) NOT NULL DEFAULT ''all''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'dept_ids') = 0,
  'ALTER TABLE `crm_marketing_activity` ADD COLUMN `dept_ids` varchar(500) DEFAULT NULL', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'role_ids') = 0,
  'ALTER TABLE `crm_marketing_activity` ADD COLUMN `role_ids` varchar(500) DEFAULT NULL', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'remind_time') = 0,
  'ALTER TABLE `crm_marketing_activity` ADD COLUMN `remind_time` datetime DEFAULT NULL COMMENT ''提醒时间''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'remind_channel') = 0,
  'ALTER TABLE `crm_marketing_activity` ADD COLUMN `remind_channel` varchar(50) DEFAULT NULL COMMENT ''提醒渠道: site-站内信 email-邮件 sms-短信(多个用逗号分隔)''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'remind_mode') = 0,
  'ALTER TABLE `crm_marketing_activity` ADD COLUMN `remind_mode` varchar(20) DEFAULT NULL COMMENT ''发送方式 scheduled-定时 immediate-立即''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'remind_count') = 0,
  'ALTER TABLE `crm_marketing_activity` ADD COLUMN `remind_count` int NOT NULL DEFAULT ''1'' COMMENT ''提醒次数''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'remind_interval') = 0,
  'ALTER TABLE `crm_marketing_activity` ADD COLUMN `remind_interval` int NOT NULL DEFAULT ''30'' COMMENT ''多次提醒时的间隔(分钟)''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'reminded_count') = 0,
  'ALTER TABLE `crm_marketing_activity` ADD COLUMN `reminded_count` int NOT NULL DEFAULT ''0'' COMMENT ''已提醒次数''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
-- crm_schedule
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_schedule' AND COLUMN_NAME = 'remind_mode') = 0,
  'ALTER TABLE `crm_schedule` ADD COLUMN `remind_mode` varchar(20) DEFAULT NULL COMMENT ''发送方式 scheduled-定时 immediate-立即''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
-- crm_task
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task' AND COLUMN_NAME = 'remind_mode') = 0,
  'ALTER TABLE `crm_task` ADD COLUMN `remind_mode` varchar(20) DEFAULT NULL COMMENT ''发送方式 scheduled-定时 immediate-立即''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task' AND COLUMN_NAME = 'visible_range') = 0,
  'ALTER TABLE `crm_task` ADD COLUMN `visible_range` varchar(20) NOT NULL DEFAULT ''all''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task' AND COLUMN_NAME = 'dept_ids') = 0,
  'ALTER TABLE `crm_task` ADD COLUMN `dept_ids` varchar(500) DEFAULT NULL', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task' AND COLUMN_NAME = 'role_ids') = 0,
  'ALTER TABLE `crm_task` ADD COLUMN `role_ids` varchar(500) DEFAULT NULL', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
-- sys_setting
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'demo_data_skipped') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `demo_data_skipped` tinyint NOT NULL DEFAULT ''0'' COMMENT ''首次部署时是否已跳过演示数据导入提示 0-未跳过 1-已跳过''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'wechat_appid') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `wechat_appid` varchar(100) DEFAULT NULL COMMENT ''微信公众号 AppID(真实发布)''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'wechat_appsecret') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `wechat_appsecret` varchar(100) DEFAULT NULL COMMENT ''微信公众号 AppSecret''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'weibo_app_key') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `weibo_app_key` varchar(100) DEFAULT NULL COMMENT ''微博开放平台 App Key''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'weibo_app_secret') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `weibo_app_secret` varchar(100) DEFAULT NULL COMMENT ''微博开放平台 App Secret''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'weibo_access_token') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `weibo_access_token` varchar(255) DEFAULT NULL COMMENT ''微博 access_token(用户授权)''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'publish_plugin_secret') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `publish_plugin_secret` varchar(255) DEFAULT NULL COMMENT ''浏览器插件共享密钥(无API平台Cookie发布用)''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'platform_keywords') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `platform_keywords` text DEFAULT NULL COMMENT ''各平台必填关键词/必填项/追加策略/自动填标签配置(JSON)''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'geo_brand_name') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `geo_brand_name` varchar(100) DEFAULT NULL COMMENT ''GEO:品牌名称''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'geo_website') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `geo_website` varchar(255) DEFAULT NULL COMMENT ''GEO:官网地址''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'geo_competitors') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `geo_competitors` varchar(500) DEFAULT NULL COMMENT ''GEO:竞品列表''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'geo_engines') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `geo_engines` varchar(255) DEFAULT NULL COMMENT ''GEO:模拟探测的AI引擎''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'geo_auto_enabled') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `geo_auto_enabled` tinyint NOT NULL DEFAULT ''0'' COMMENT ''GEO:自动巡检开关''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'geo_patrol_keywords') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `geo_patrol_keywords` int NOT NULL DEFAULT ''5'' COMMENT ''GEO:每轮巡检关键词数上限''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_enabled') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `workbuddy_enabled` tinyint DEFAULT NULL', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_base_url') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `workbuddy_base_url` varchar(500) DEFAULT NULL', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_api_key') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `workbuddy_api_key` varchar(500) DEFAULT NULL', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_auth_header') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `workbuddy_auth_header` varchar(50) DEFAULT NULL', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_auth_scheme') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `workbuddy_auth_scheme` varchar(20) DEFAULT NULL', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_experts_path') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `workbuddy_experts_path` varchar(200) DEFAULT NULL', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_chat_path') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `workbuddy_chat_path` varchar(200) DEFAULT NULL', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_expert_id_field') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `workbuddy_expert_id_field` varchar(50) DEFAULT NULL', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_question_field') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `workbuddy_question_field` varchar(50) DEFAULT NULL', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_context_field') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `workbuddy_context_field` varchar(50) DEFAULT NULL', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_stream') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `workbuddy_stream` tinyint NOT NULL DEFAULT ''0''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'workbuddy_timeout_seconds') = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `workbuddy_timeout_seconds` int NOT NULL DEFAULT ''120''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
-- sys_user
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_user' AND COLUMN_NAME = 'wechat') = 0,
  'ALTER TABLE `sys_user` ADD COLUMN `wechat` varchar(64) DEFAULT NULL COMMENT ''微信号''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_user' AND COLUMN_NAME = 'face_photo') = 0,
  'ALTER TABLE `sys_user` ADD COLUMN `face_photo` varchar(255) DEFAULT NULL COMMENT ''人脸照片地址''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_user' AND COLUMN_NAME = 'face_feature') = 0,
  'ALTER TABLE `sys_user` ADD COLUMN `face_feature` longtext DEFAULT NULL COMMENT ''人脸特征向量''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;
SET @ddl := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_user' AND COLUMN_NAME = 'face_enrolled_time') = 0,
  'ALTER TABLE `sys_user` ADD COLUMN `face_enrolled_time` datetime DEFAULT NULL COMMENT ''人脸录入时间''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;

-- ==========================================================
-- 已有库升级：菜单完整性自愈（幂等）——修复侧栏菜单显示不全
-- 原因：断链菜单（parent_id 指向不存在的父级）会从侧边栏消失
-- ==========================================================

-- 1) 断链的目录/页面菜单归到顶级（父级不存在时）
UPDATE `sys_menu` SET `parent_id` = '0'
WHERE `parent_id` <> '0' AND `menu_type` IN ('M','C')
  AND `parent_id` NOT IN (SELECT `id` FROM (SELECT `id` FROM `sys_menu`) AS `_m1`);

-- 2) 断链的按钮权限归到顶级（保证权限码不丢）
UPDATE `sys_menu` SET `parent_id` = '0'
WHERE `parent_id` <> '0' AND `menu_type` = 'F'
  AND `parent_id` NOT IN (SELECT `id` FROM (SELECT `id` FROM `sys_menu`) AS `_m2`);

-- 3) 超级管理员绑定全部菜单（目录/页面/按钮）
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT (SELECT `id` FROM `sys_role` WHERE `role_code` = 'admin' LIMIT 1), id
FROM `sys_menu` WHERE `menu_type` IN ('M','C','F');

-- 4) admin 账号与超管角色绑定兜底
INSERT IGNORE INTO `sys_user_role` (`user_id`, `role_id`)
SELECT u.id, r.id FROM `sys_user` u, `sys_role` r
WHERE u.`username` = 'admin' AND r.`role_code` = 'admin'
  AND NOT EXISTS (SELECT 1 FROM `sys_user_role` x WHERE x.user_id = u.id AND x.role_id = r.id);

-- 5) 补齐角色菜单的父级目录链（防断链再次出现）
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT DISTINCT rm.`role_id`, m.`parent_id` FROM `sys_role_menu` rm JOIN `sys_menu` m ON rm.`menu_id` = m.`id`
WHERE m.`parent_id` <> '0'
  AND NOT EXISTS (SELECT 1 FROM `sys_role_menu` x WHERE x.`role_id` = rm.`role_id` AND x.`menu_id` = m.`parent_id`);
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT DISTINCT rm.`role_id`, g.`parent_id` FROM `sys_role_menu` rm
JOIN `sys_menu` m ON rm.`menu_id` = m.`id` JOIN `sys_menu` g ON g.`id` = m.`parent_id`
WHERE g.`parent_id` <> '0'
  AND NOT EXISTS (SELECT 1 FROM `sys_role_menu` x WHERE x.`role_id` = rm.`role_id` AND x.`menu_id` = g.`parent_id`);

-- 已有库升级：「商机来源」菜单默认不分配给市场管理员 / 销售经理 / 销售员（幂等，含子按钮）
DELETE FROM `sys_role_menu`
WHERE `role_id` IN (SELECT `id` FROM `sys_role` WHERE `role_code` IN ('marketing_admin','sales_manager','sales'))
AND `menu_id` IN (
  SELECT `id` FROM (
    SELECT '18ae961d-37d2-4e45-a3c2-d333a9ecb3bc' AS id UNION ALL
    SELECT `id` FROM `sys_menu` WHERE `parent_id` = '18ae961d-37d2-4e45-a3c2-d333a9ecb3bc'
  ) t
);

-- 已有库升级：市场管理员（marketing_admin）不显示「销售排行榜」菜单（幂等，含子按钮）
DELETE FROM `sys_role_menu`
WHERE `role_id` = (SELECT `id` FROM `sys_role` WHERE `role_code` = 'marketing_admin' LIMIT 1)
AND `menu_id` IN (
  SELECT `id` FROM (
    SELECT 'aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e03' AS id UNION ALL
    SELECT `id` FROM `sys_menu` WHERE `parent_id` = 'aa1e2c00-6b11-4d2e-9a01-9c0f1b7d4e03'
  ) t
);
