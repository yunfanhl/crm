-- =====================================================
-- CRM系统数据库初始化脚本（无演示数据版）
-- 仅包含：建表 + 系统基础数据 + 权限数据，不含任何业务示例/演示数据。
-- 如需演示数据，请改用 init-with-demo.sql 初始化。
-- =====================================================
-- =====================================================
-- CRM系统数据库初始化脚本（完整合并版）
-- 数据库: MySQL 8.0+
-- 字符集: utf8mb4
-- 说明: 本文件已合并所有迁移脚本，可一次性执行。
--       表使用 CREATE TABLE IF NOT EXISTS，新增列使用幂等 ALTER，
--       新增菜单/字典数据使用幂等 INSERT，重复执行安全。
-- 执行: mysql -uroot -p --default-character-set=utf8mb4 < sql/init.sql
-- =====================================================

CREATE DATABASE IF NOT EXISTS `crm_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `crm_db`;

-- 兜底: JDBC 的 createDatabaseIfNotExist=true 可能用 MySQL 服务端默认字符集(Windows 上常为 latin1)
-- 把库先建出来, 导致上面 CREATE DATABASE IF NOT EXISTS no-op 后库仍是 latin1, 后续 CREATE TABLE
-- 的中文 DEFAULT / INSERT 中文被错误转换。显式 ALTER 强制 utf8mb4 修复此问题。
ALTER DATABASE `crm_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

SET NAMES utf8mb4;

-- =====================================================
-- 一、系统管理模块
-- =====================================================

-- 1. 系统用户表
CREATE TABLE IF NOT EXISTS `sys_user` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `username`    VARCHAR(50)  NOT NULL,
  `password`    VARCHAR(100) NOT NULL,
  `real_name`   VARCHAR(50)  DEFAULT NULL,
  `phone`       VARCHAR(20)  DEFAULT NULL,
  `email`       VARCHAR(100) DEFAULT NULL,
  `avatar`      VARCHAR(255) DEFAULT NULL,
  `status`      TINYINT      NOT NULL DEFAULT 1,
  `intro_seen`  TINYINT      NOT NULL DEFAULT 0 COMMENT '系统使用须知引导是否已读 0-未读 1-已读（服务端保存）',
  `expire_date` DATE         DEFAULT NULL COMMENT '账号有效期（NULL 表示长期有效，过期后不能登录）',
  `dept_id`     VARCHAR(36)       DEFAULT NULL COMMENT '部门ID',
  `last_login`  DATETIME     DEFAULT NULL,
  `create_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`     TINYINT      NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统用户表';

-- 2. 角色表
CREATE TABLE IF NOT EXISTS `sys_role` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `role_name`   VARCHAR(50) NOT NULL,
  `role_code`   VARCHAR(50) NOT NULL,
  `description` VARCHAR(200) DEFAULT NULL,
  `status`      TINYINT     NOT NULL DEFAULT 1,
  `data_scope`  TINYINT     NOT NULL DEFAULT 1,
  `create_time` DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`     TINYINT     NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_role_code` (`role_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='角色表';

-- 3. 菜单/权限表
CREATE TABLE IF NOT EXISTS `sys_menu` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `parent_id`   VARCHAR(36)       NOT NULL DEFAULT 0 COMMENT '父级ID',
  `menu_name`   VARCHAR(50)  NOT NULL,
  `path`        VARCHAR(200) DEFAULT NULL,
  `component`   VARCHAR(200) DEFAULT NULL,
  `perms`       VARCHAR(100) DEFAULT NULL,
  `icon`        VARCHAR(50)  DEFAULT NULL,
  `menu_type`   CHAR(1)      NOT NULL,
  `sort`        INT          NOT NULL DEFAULT 0,
  `visible`     TINYINT      NOT NULL DEFAULT 1,
  `create_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='菜单/权限表';

-- 4. 用户角色关联表
CREATE TABLE IF NOT EXISTS `sys_user_role` (
  `user_id` VARCHAR(36) NOT NULL COMMENT '用户ID',
  `role_id` VARCHAR(36) NOT NULL COMMENT '角色ID',
  PRIMARY KEY (`user_id`, `role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户角色关联表';

-- 5. 角色菜单关联表
CREATE TABLE IF NOT EXISTS `sys_role_menu` (
  `role_id` VARCHAR(36) NOT NULL COMMENT '角色ID',
  `menu_id` VARCHAR(36) NOT NULL COMMENT '菜单ID',
  PRIMARY KEY (`role_id`, `menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='角色菜单关联表';

-- 6. 部门表
CREATE TABLE IF NOT EXISTS `sys_dept` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `parent_id`   VARCHAR(36)      NOT NULL DEFAULT 0 COMMENT '父级ID',
  `dept_name`   VARCHAR(50) NOT NULL,
  `leader`      VARCHAR(50) DEFAULT NULL,
  `phone`       VARCHAR(20) DEFAULT NULL,
  `sort`        INT         NOT NULL DEFAULT 0,
  `status`      TINYINT     NOT NULL DEFAULT 1,
  `create_time` DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`     TINYINT     NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='部门表';

-- 7. 系统设置表
CREATE TABLE IF NOT EXISTS `sys_setting` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `system_name`     VARCHAR(100) DEFAULT '云帆智能客户管理系统',
  `system_subtitle` VARCHAR(200) DEFAULT 'Customer Relationship Management',
  `login_logo`      VARCHAR(500) DEFAULT NULL,
  `h5_qrcode`       VARCHAR(500) DEFAULT NULL COMMENT '登录页 H5 二维码图片 URL',
  `mp_qrcode`       VARCHAR(500) DEFAULT NULL COMMENT '登录页小程序二维码图片 URL',
  `multi_login`     TINYINT      NOT NULL DEFAULT 0,
  `upload_dir`      VARCHAR(255) DEFAULT './uploads/',
  `feedback_enabled` TINYINT     NOT NULL DEFAULT 0,
  `feedback_rate_limit_max`    INT NOT NULL DEFAULT 10 COMMENT '意见反馈限流：单个IP限流窗口内最大提交次数',
  `feedback_rate_limit_window` INT NOT NULL DEFAULT 10 COMMENT '意见反馈限流窗口（分钟）',
  `feedback_dedupe_hours`      INT NOT NULL DEFAULT 1  COMMENT '意见反馈去重窗口（小时），同内容同提交人在窗口内视为重复',
  `captcha_enabled` TINYINT      NOT NULL DEFAULT 0,
  `theme_color`     VARCHAR(20)  DEFAULT '#5B8FD9',
  `login_config`    TEXT         DEFAULT NULL,
  `ai_enabled`      TINYINT      NOT NULL DEFAULT 0,
  `ai_base_url`     VARCHAR(255) DEFAULT 'https://api.deepseek.com',
  `ai_api_key`      VARCHAR(255) DEFAULT NULL,
  `ai_model`        VARCHAR(100) DEFAULT 'deepseek-chat',
  `ai_temperature`  DOUBLE       NOT NULL DEFAULT 0.7,
  `ai_max_tokens`   INT          NOT NULL DEFAULT 2048,
  `ai_timeout_seconds` INT       NOT NULL DEFAULT 60,
  `ai_system_prompt` TEXT,
  `ai_embedding_base_url` VARCHAR(255) DEFAULT 'https://dashscope.aliyuncs.com/compatible-mode/v1' COMMENT '向量化接口地址(OpenAI 兼容 /embeddings)，默认阿里云百炼',
  `ai_embedding_model`   VARCHAR(100) DEFAULT 'text-embedding-v3' COMMENT '向量化模型',
  `ai_embedding_dim`     INT          NOT NULL DEFAULT 1024 COMMENT '向量维度(需与模型一致)',
  `ai_embedding_api_key` VARCHAR(255) DEFAULT NULL COMMENT '向量化 API Key(与对话 Key 独立，便于使用不同服务商)',
  `current_version` VARCHAR(50)  DEFAULT NULL,
  `upgrade_url`     VARCHAR(500) DEFAULT NULL,
  `sms_channel`         VARCHAR(20)  DEFAULT 'aliyun',
  `sms_access_key_id`   VARCHAR(255) DEFAULT NULL,
  `sms_access_key_secret` VARCHAR(255) DEFAULT NULL,
  `sms_sign_name`       VARCHAR(100) DEFAULT NULL,
  `sms_template_code`   VARCHAR(100) DEFAULT NULL,
  `sms_endpoint`        VARCHAR(255) DEFAULT NULL,
  `face_channel`        VARCHAR(20)  DEFAULT 'aliyun',
  `face_access_key_id`  VARCHAR(255) DEFAULT NULL,
  `face_access_key_secret` VARCHAR(255) DEFAULT NULL,
  `login_default_accounts_enabled` TINYINT NOT NULL DEFAULT 1 COMMENT '登录页默认账号提示开关 0-关闭 1-开启(部署包默认开启)',
  `demo_data_editable` TINYINT NOT NULL DEFAULT 1 COMMENT '演示数据是否允许修改 0-不允许(只读) 1-允许修改',
  `crawl_enabled` TINYINT NOT NULL DEFAULT 1 COMMENT '商机情报抓取开关 0-关闭 1-开启',
  `crawl_cron` VARCHAR(50) DEFAULT '0 0 8 * * ?' COMMENT '商机情报抓取 cron 表达式',
  `crawl_provider` VARCHAR(20) DEFAULT 'none' COMMENT '商机情报数据源 none-演示数据 custom-自定义接口',
  `crawl_base_url` VARCHAR(500) DEFAULT NULL COMMENT '商机情报第三方数据源接口地址',
  `crawl_app_key` VARCHAR(255) DEFAULT NULL COMMENT '商机情报第三方数据源应用 Key',
  `crawl_app_secret` VARCHAR(255) DEFAULT NULL COMMENT '商机情报第三方数据源应用 Secret',
  `attendance_face_enabled` TINYINT NOT NULL DEFAULT 0 COMMENT '签到是否启用人脸核验 0-关闭 1-开启',
  `attendance_work_time`    VARCHAR(5) NOT NULL DEFAULT '09:00' COMMENT '上班时间（HH:mm，用于判定迟到）',
  `mail_enabled`   TINYINT      NOT NULL DEFAULT 0 COMMENT '邮件提醒开关 0-关闭(模拟发送) 1-开启',
  `mail_host`      VARCHAR(100) DEFAULT NULL COMMENT 'SMTP 服务器地址',
  `mail_port`      INT          DEFAULT 465 COMMENT 'SMTP 端口',
  `mail_ssl`       TINYINT      NOT NULL DEFAULT 1 COMMENT '是否启用 SSL 0-否 1-是',
  `mail_username`  VARCHAR(100) DEFAULT NULL COMMENT 'SMTP 账号（发件邮箱）',
  `mail_password`  VARCHAR(255) DEFAULT NULL COMMENT 'SMTP 密码/授权码',
  `mail_from`      VARCHAR(100) DEFAULT NULL COMMENT '发件人显示名称',
  `create_time`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- 已有库升级：为 sys_setting 补充商机抓取配置列（幂等）
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'crawl_enabled');
SET @ddl := IF(@col_exist = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `crawl_enabled` TINYINT NOT NULL DEFAULT 1 COMMENT ''商机情报抓取开关 0-关闭 1-开启'', ADD COLUMN `crawl_cron` VARCHAR(50) DEFAULT ''0 0 8 * * ?'' COMMENT ''商机情报抓取 cron 表达式'', ADD COLUMN `crawl_provider` VARCHAR(20) DEFAULT ''none'' COMMENT ''商机情报数据源 none-演示数据 custom-自定义接口'', ADD COLUMN `crawl_base_url` VARCHAR(500) DEFAULT NULL COMMENT ''商机情报第三方数据源接口地址'', ADD COLUMN `crawl_app_key` VARCHAR(255) DEFAULT NULL COMMENT ''商机情报第三方数据源应用 Key'', ADD COLUMN `crawl_app_secret` VARCHAR(255) DEFAULT NULL COMMENT ''商机情报第三方数据源应用 Secret''',
  'SELECT 1');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：为 sys_setting 补充考勤打卡配置列（幂等）
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'attendance_face_enabled');
SET @ddl := IF(@col_exist = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `attendance_face_enabled` TINYINT NOT NULL DEFAULT 0 COMMENT ''签到是否启用人脸核验 0-关闭 1-开启'', ADD COLUMN `attendance_work_time` VARCHAR(5) NOT NULL DEFAULT ''09:00'' COMMENT ''上班时间（HH:mm，用于判定迟到）''',
  'SELECT 1');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：为 sys_setting 补充意见反馈限流与去重配置列（幂等）
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'feedback_rate_limit_max');
SET @ddl := IF(@col_exist = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `feedback_rate_limit_max` INT NOT NULL DEFAULT 10 COMMENT ''意见反馈限流：单个IP限流窗口内最大提交次数'', ADD COLUMN `feedback_rate_limit_window` INT NOT NULL DEFAULT 10 COMMENT ''意见反馈限流窗口（分钟）'', ADD COLUMN `feedback_dedupe_hours` INT NOT NULL DEFAULT 1 COMMENT ''意见反馈去重窗口（小时），同内容同提交人在窗口内视为重复''',
  'SELECT 1');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：为 sys_setting 补充向量化(embedding)配置列（幂等）
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'ai_embedding_base_url');
SET @ddl := IF(@col_exist = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `ai_embedding_base_url` VARCHAR(255) DEFAULT ''https://dashscope.aliyuncs.com/compatible-mode/v1'' COMMENT ''向量化接口地址(OpenAI 兼容 /embeddings)'' AFTER `ai_system_prompt`, ADD COLUMN `ai_embedding_model` VARCHAR(100) DEFAULT ''text-embedding-v3'' COMMENT ''向量化模型'' AFTER `ai_embedding_base_url`, ADD COLUMN `ai_embedding_dim` INT NOT NULL DEFAULT 1024 COMMENT ''向量维度(需与模型一致)'' AFTER `ai_embedding_model`',
  'SELECT 1');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：为 sys_setting 补充独立的向量化 API Key 列（幂等）
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'ai_embedding_api_key');
SET @ddl := IF(@col_exist = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `ai_embedding_api_key` VARCHAR(255) DEFAULT NULL COMMENT ''向量化 API Key(与对话 Key 独立，便于使用不同服务商)'' AFTER `ai_embedding_dim`',
  'SELECT 1');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：为 sys_setting 补充多平台真实发布凭证列（幂等）
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'wechat_appid');
SET @ddl := IF(@col_exist = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `wechat_appid` VARCHAR(100) DEFAULT NULL COMMENT ''微信公众号 AppID(真实发布)'' AFTER `ai_embedding_api_key`, ADD COLUMN `wechat_appsecret` VARCHAR(100) DEFAULT NULL COMMENT ''微信公众号 AppSecret'' AFTER `wechat_appid`, ADD COLUMN `weibo_app_key` VARCHAR(100) DEFAULT NULL COMMENT ''微博开放平台 App Key'' AFTER `wechat_appsecret`, ADD COLUMN `weibo_app_secret` VARCHAR(100) DEFAULT NULL COMMENT ''微博开放平台 App Secret'' AFTER `weibo_app_key`, ADD COLUMN `weibo_access_token` VARCHAR(255) DEFAULT NULL COMMENT ''微博 access_token(用户授权)'' AFTER `weibo_app_secret`, ADD COLUMN `publish_plugin_secret` VARCHAR(255) DEFAULT NULL COMMENT ''浏览器插件共享密钥(无API平台Cookie发布用)'' AFTER `weibo_access_token`',
  'SELECT 1');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：为 sys_setting 补充各平台必填关键词配置列（幂等）
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'platform_keywords');
SET @ddl := IF(@col_exist = 0,
  'ALTER TABLE `sys_setting` ADD COLUMN `platform_keywords` TEXT DEFAULT NULL COMMENT ''各平台必填关键词/必填项/追加策略/自动填标签配置(JSON)'' AFTER `publish_plugin_secret`',
  'SELECT 1');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

-- 知识库文档表：方案/合同/产品手册/客户资料等入库
CREATE TABLE IF NOT EXISTS `knowledge_document` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',
  `title`       VARCHAR(300) NOT NULL COMMENT '文档标题',
  `file_name`   VARCHAR(300) DEFAULT NULL COMMENT '原始文件名',
  `file_type`   VARCHAR(20)  DEFAULT NULL COMMENT '文件类型 pdf/docx/xlsx/txt/md',
  `file_size`   BIGINT       NOT NULL DEFAULT 0 COMMENT '文件大小(字节)',
  `status`      TINYINT      NOT NULL DEFAULT 0 COMMENT '状态 0-处理中 1-已完成 2-失败',
  `chunk_count` INT          NOT NULL DEFAULT 0 COMMENT '切片数量',
  `created_by`  VARCHAR(36)  DEFAULT NULL COMMENT '上传人用户ID',
  `create_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`     TINYINT      NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='知识库文档表';

-- 知识库文档切片表：每个切片正文 + 向量（JSON 数组，检索时用 Java 计算余弦相似度）
CREATE TABLE IF NOT EXISTS `knowledge_chunk` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',
  `doc_id`   VARCHAR(36)  NOT NULL COMMENT '关联 knowledge_document.id',
  `seq`      INT          NOT NULL DEFAULT 0 COMMENT '切片序号',
  `content`  TEXT         NOT NULL COMMENT '切片正文',
  `embedding` TEXT         NULL COMMENT '向量(JSON 数组字符串)，本地知识库模式可为空',
  `create_time` DATETIME  NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_doc_id` (`doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='知识库文档切片表';

-- 已有库升级：knowledge_chunk.embedding 改为可空（本地知识库不做向量化）（幂等）
SET @emb_is_nullable := (SELECT IS_NULLABLE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'knowledge_chunk' AND COLUMN_NAME = 'embedding');
SET @ddl_emb := IF(@emb_is_nullable IS NULL OR @emb_is_nullable = 'YES', 'SELECT 1', 'ALTER TABLE `knowledge_chunk` MODIFY COLUMN `embedding` TEXT NULL COMMENT ''向量(JSON数组字符串)，本地知识库模式可为空''');
PREPARE ddl_emb FROM @ddl_emb;
EXECUTE ddl_emb;
DEALLOCATE PREPARE ddl_emb;

-- 已有库升级：feedback.user_id 由 bigint 改为 varchar(36)，以匹配 sys_user.id(UUID)，修复演示数据导入失败（幂等）
SET @col_type := (SELECT DATA_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'feedback' AND COLUMN_NAME = 'user_id');
SET @ddl := IF(@col_type = 'bigint' OR @col_type = 'int',
  'ALTER TABLE `feedback` MODIFY COLUMN `user_id` VARCHAR(36) DEFAULT NULL COMMENT ''提交用户ID（同 sys_user.id，UUID）''',
  'SELECT 1');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：为 sys_user 补充微信号、人脸照片列（幂等）
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_user' AND COLUMN_NAME = 'wechat');
SET @ddl := IF(@col_exist = 0,
  'ALTER TABLE `sys_user` ADD COLUMN `wechat` VARCHAR(64) DEFAULT NULL COMMENT ''微信号'', ADD COLUMN `face_photo` VARCHAR(255) DEFAULT NULL COMMENT ''人脸照片地址''',
  'SELECT 1');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

-- 系统操作日志表
CREATE TABLE IF NOT EXISTS `sys_oper_log` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `module`         VARCHAR(100) DEFAULT NULL,
  `oper_type`      VARCHAR(20)  DEFAULT NULL,
  `description`    VARCHAR(255) DEFAULT NULL,
  `request_method` VARCHAR(10)  DEFAULT NULL,
  `request_uri`    VARCHAR(255) DEFAULT NULL,
  `method`         VARCHAR(500) DEFAULT NULL,
  `params`         TEXT         DEFAULT NULL,
  `oper_user_id`   VARCHAR(36)       DEFAULT NULL COMMENT '操作用户ID',
  `oper_username`  VARCHAR(50)  DEFAULT NULL,
  `oper_ip`        VARCHAR(50)  DEFAULT NULL,
  `status`         TINYINT      NOT NULL DEFAULT 1,
  `error_msg`      TEXT         DEFAULT NULL,
  `cost_time`      BIGINT       NOT NULL DEFAULT 0,
  `create_time`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_oper_username` (`oper_username`),
  KEY `idx_oper_type` (`oper_type`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- =====================================================
-- 二、客户管理模块
-- =====================================================

-- 客户表
CREATE TABLE IF NOT EXISTS `crm_customer` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `customer_name`  VARCHAR(100) NOT NULL,
  `customer_code`  VARCHAR(50)  DEFAULT NULL,
  `industry`       VARCHAR(50)  DEFAULT NULL,
  `customer_level` VARCHAR(20)  DEFAULT NULL,
  `customer_source` VARCHAR(50) DEFAULT NULL,
  `phone`          VARCHAR(20)  DEFAULT NULL,
  `email`          VARCHAR(100) DEFAULT NULL,
  `website`        VARCHAR(200) DEFAULT NULL,
  `address`        VARCHAR(300) DEFAULT NULL,
  `description`    TEXT         DEFAULT NULL,
  `attachments`    TEXT         DEFAULT NULL,
  `owner_id`       VARCHAR(36)       DEFAULT NULL COMMENT '归属人ID',
  `create_by`      VARCHAR(36)       DEFAULT NULL COMMENT '创建人',
  `status`         VARCHAR(20)  NOT NULL DEFAULT 'active',
  `deal_status`    VARCHAR(20)  NOT NULL DEFAULT 'A',
  `credit_code`    VARCHAR(50)  DEFAULT NULL,
  `annual_revenue` DECIMAL(14,2) DEFAULT NULL,
  `employee_count` INT          DEFAULT NULL,
  `create_time`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`        TINYINT      NOT NULL DEFAULT 0,
  `is_demo`        TINYINT      NOT NULL DEFAULT 0 COMMENT '是否演示数据 1-演示数据 0-普通数据',
  `archived`       TINYINT      NOT NULL DEFAULT 0 COMMENT '是否归档 0-正常 1-已归档（归档后默认从列表隐藏）',
  PRIMARY KEY (`id`),
  KEY `idx_owner` (`owner_id`),
  KEY `idx_level` (`customer_level`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- 已有库升级：为 crm_customer 补充归档列（幂等）
SET @cust_archived_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_customer' AND COLUMN_NAME = 'archived');
SET @ddl_cust_archived := IF(@cust_archived_exist = 0,
  'ALTER TABLE `crm_customer` ADD COLUMN `archived` TINYINT NOT NULL DEFAULT 0 COMMENT ''是否归档 0-正常 1-已归档（归档后默认从列表隐藏）''',
  'SELECT 1');
PREPARE ddl_cust_archived FROM @ddl_cust_archived;
EXECUTE ddl_cust_archived;
DEALLOCATE PREPARE ddl_cust_archived;

-- 联系人表
CREATE TABLE IF NOT EXISTS `crm_contact` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `customer_id`  VARCHAR(36)       NOT NULL COMMENT '客户ID',
  `contact_name` VARCHAR(50)  NOT NULL,
  `gender`       CHAR(1)      DEFAULT NULL,
  `position`     VARCHAR(50)  DEFAULT NULL,
  `department`   VARCHAR(50)  DEFAULT NULL,
  `phone`        VARCHAR(20)  DEFAULT NULL,
  `email`        VARCHAR(100) DEFAULT NULL,
  `qq`           VARCHAR(20)  DEFAULT NULL,
  `wechat`       VARCHAR(50)  DEFAULT NULL,
  `is_decision`  TINYINT      NOT NULL DEFAULT 0,
  `remark`       VARCHAR(500) DEFAULT NULL,
  `create_time`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`      TINYINT      NOT NULL DEFAULT 0,
  `is_demo`      TINYINT       NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_customer` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- 销售线索表
CREATE TABLE IF NOT EXISTS `crm_opportunity` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `opp_name`         VARCHAR(100)  DEFAULT NULL COMMENT '线索名称（界面已隐藏，留空）',
  `customer_id`      VARCHAR(36)        DEFAULT NULL COMMENT '客户ID（关联客户后填充；未匹配到已有客户时留空）',
  `customer_name`    VARCHAR(100)  DEFAULT NULL COMMENT '客户名称（手动录入，关联客户后冗余存储）',
  `customer_code`    VARCHAR(50)   DEFAULT NULL COMMENT '客户编号（线索独立编号，可手填；留空自动生成 C+yyyyMMdd+4位当日序号，与客户模块规则一致）',
  `contact_id`       VARCHAR(36)        DEFAULT NULL COMMENT '联系人ID',
  `contact_info`     TEXT          DEFAULT NULL COMMENT '内联联系人信息（JSON，冗余存储）',
  `released`         TINYINT       NOT NULL DEFAULT 0 COMMENT '是否已放入公海：0-否，1-是',

  `estimated_amount` DECIMAL(14,2) NOT NULL DEFAULT 0,
  `stage`            VARCHAR(20)   NOT NULL DEFAULT 'initial',
  `probability`      INT           NOT NULL DEFAULT 10,
  `expected_close`   DATE          DEFAULT NULL,
  `source`           VARCHAR(50)   DEFAULT NULL,
  `description`      TEXT          DEFAULT NULL,
  `owner_id`         VARCHAR(36)        DEFAULT NULL COMMENT '归属人ID',
  `create_time`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`          TINYINT       NOT NULL DEFAULT 0,
  `is_demo`          TINYINT       NOT NULL DEFAULT 0 COMMENT '是否演示数据 1-演示数据 0-普通数据',
  PRIMARY KEY (`id`),
  KEY `idx_customer` (`customer_id`),
  KEY `idx_stage` (`stage`),
  KEY `idx_owner` (`owner_id`),
  KEY `idx_opp_customer_code` (`customer_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- 已有库升级：为 crm_opportunity 补充客户编号列（幂等）
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_opportunity' AND COLUMN_NAME = 'customer_code');
SET @ddl := IF(@col_exist = 0,
  'ALTER TABLE `crm_opportunity` ADD COLUMN `customer_code` VARCHAR(50) DEFAULT NULL COMMENT ''客户编号（线索独立编号，可手填；留空自动生成 C+yyyyMMdd+4位当日序号，与客户模块规则一致）'', ADD KEY `idx_opp_customer_code` (`customer_code`)',
  'SELECT 1');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：crm_opportunity.customer_id 允许为空（客户名称未匹配到已有客户时不自动建档，留空）
SET @cid_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_opportunity' AND COLUMN_NAME = 'customer_id');
SET @ddl_cid := IF(@cid_exist > 0,
  'ALTER TABLE `crm_opportunity` MODIFY COLUMN `customer_id` VARCHAR(36) DEFAULT NULL COMMENT ''客户ID（关联客户后填充；未匹配到已有客户时留空）''',
  'SELECT 1');
PREPARE ddl_cid FROM @ddl_cid;
EXECUTE ddl_cid;
DEALLOCATE PREPARE ddl_cid;

-- 跟进记录表
CREATE TABLE IF NOT EXISTS `crm_follow_up` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `customer_id`   VARCHAR(36)       DEFAULT NULL COMMENT '客户ID',
  `contact_id`    VARCHAR(36)       DEFAULT NULL COMMENT '联系人ID',
  `opportunity_id` VARCHAR(36)      DEFAULT NULL COMMENT '商机ID',
  `follow_type`   VARCHAR(20)  NOT NULL DEFAULT 'phone',
  `content`       TEXT         NOT NULL,
  `next_follow`   DATE         DEFAULT NULL,
  `follow_user`   VARCHAR(36)       DEFAULT NULL COMMENT '跟进人ID',
  `create_time`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`       TINYINT      NOT NULL DEFAULT 0,
  `is_demo`       TINYINT       NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_customer` (`customer_id`),
  KEY `idx_opp` (`opportunity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- =====================================================
-- 三、合同管理模块（含增强：模板/在线签署/短信）
-- =====================================================

-- 合同表
CREATE TABLE IF NOT EXISTS `crm_contract` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `contract_no`    VARCHAR(50)   NOT NULL,
  `contract_name`  VARCHAR(100)  NOT NULL,
  `customer_id`    VARCHAR(36)        NOT NULL COMMENT '客户ID',
  `opportunity_id` VARCHAR(36)        DEFAULT NULL COMMENT '商机ID',
  `amount`         DECIMAL(14,2) NOT NULL DEFAULT 0,
  `sign_date`      DATE          DEFAULT NULL,
  `start_date`     DATE          DEFAULT NULL,
  `end_date`       DATE          DEFAULT NULL,
  `status`         VARCHAR(20)   NOT NULL DEFAULT 'draft',
  `payment_terms`  VARCHAR(200)  DEFAULT NULL,
  `signed_by`      VARCHAR(50)   DEFAULT NULL,
  `owner_id`       VARCHAR(36)        DEFAULT NULL COMMENT '归属人ID',
  `remark`         TEXT          DEFAULT NULL,
  `template_id`    VARCHAR(36)        DEFAULT NULL COMMENT '模板ID',
  `file_url`       VARCHAR(500)  DEFAULT NULL,
  `content`        LONGTEXT      DEFAULT NULL,
  `sign_status`    VARCHAR(20)   DEFAULT 'unsigned',
  `sign_url`       VARCHAR(500)  DEFAULT NULL,
  `signed_time`    DATETIME      DEFAULT NULL,
  `sms_channel`    VARCHAR(20)   DEFAULT NULL,
  `sms_sent`       TINYINT       DEFAULT 0,
  `sms_send_time`  DATETIME      DEFAULT NULL,
  `create_time`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`        TINYINT       NOT NULL DEFAULT 0,
  `is_demo`        TINYINT       NOT NULL DEFAULT 0 COMMENT '是否演示数据 1-演示数据 0-普通数据',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_contract_no` (`contract_no`),
  KEY `idx_customer` (`customer_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- 合同模板表
CREATE TABLE IF NOT EXISTS `crm_contract_template` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `name`        VARCHAR(100) NOT NULL,
  `category`    VARCHAR(50)  DEFAULT NULL,
  `file_url`    VARCHAR(500) DEFAULT NULL,
  `file_name`   VARCHAR(255) DEFAULT NULL,
  `content`     LONGTEXT     DEFAULT NULL,
  `remark`      VARCHAR(255) DEFAULT NULL,
  `create_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- 合同在线签署记录表
CREATE TABLE IF NOT EXISTS `crm_contract_sign` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `contract_id` VARCHAR(36)       NOT NULL COMMENT '合同ID',
  `signer_name` VARCHAR(50)  DEFAULT NULL,
  `signer_phone` VARCHAR(20) DEFAULT NULL,
  `sign_type`   VARCHAR(20)  DEFAULT 'customer',
  `sign_url`    VARCHAR(500) DEFAULT NULL,
  `status`      VARCHAR(20)  DEFAULT 'pending',
  `ip`          VARCHAR(50)  DEFAULT NULL,
  `signed_time` DATETIME     DEFAULT NULL,
  `create_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_contract` (`contract_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- 任务表
CREATE TABLE IF NOT EXISTS `crm_task` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `task_title`     VARCHAR(200) NOT NULL,
  `task_desc`      TEXT         DEFAULT NULL,
  `priority`       VARCHAR(10)  NOT NULL DEFAULT 'medium',
  `due_date`       DATE         DEFAULT NULL,
  `status`         VARCHAR(10)  NOT NULL DEFAULT 'pending',
  `customer_id`    VARCHAR(36)       DEFAULT NULL COMMENT '客户ID',
  `opportunity_id` VARCHAR(36)       DEFAULT NULL COMMENT '商机ID',
  `owner_id`       VARCHAR(36)       NOT NULL COMMENT '归属人ID',
  `create_by`      VARCHAR(36)       DEFAULT NULL COMMENT '创建人ID（仅创建人或管理员可编辑/删除）',
  `remind_time`    DATETIME     DEFAULT NULL COMMENT '下次提醒时间',
  `reminded`       TINYINT      NOT NULL DEFAULT 0,
  `remind_channel` VARCHAR(50)  DEFAULT NULL COMMENT '提醒渠道: site-站内信 email-邮件 sms-短信(多个用逗号分隔)',
  `remind_count`   INT          NOT NULL DEFAULT 1 COMMENT '提醒次数',
  `remind_interval` INT         NOT NULL DEFAULT 30 COMMENT '多次提醒时的间隔(分钟)',
  `reminded_count` INT          NOT NULL DEFAULT 0 COMMENT '已提醒次数',
  `complete_time`  DATETIME     DEFAULT NULL,
  `create_time`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`        TINYINT      NOT NULL DEFAULT 0,
  `is_demo`        TINYINT      NOT NULL DEFAULT 0 COMMENT '是否演示数据 1-演示数据 0-普通数据',
  PRIMARY KEY (`id`),
  KEY `idx_owner` (`owner_id`),
  KEY `idx_status` (`status`),
  KEY `idx_due_date` (`due_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- 客户日程表（在客户操作中「创建日程」，记录拜访/电话/会议等安排）
CREATE TABLE IF NOT EXISTS `crm_schedule` (
  `id`            VARCHAR(36)   NOT NULL COMMENT '主键ID（UUID）',
  `title`         VARCHAR(200)  NOT NULL COMMENT '日程标题',
  `content`       TEXT          DEFAULT NULL COMMENT '日程内容/备注',
  `customer_id`   VARCHAR(36)   DEFAULT NULL COMMENT '关联客户ID',
  `customer_name` VARCHAR(200)  DEFAULT NULL COMMENT '客户名称(冗余, 便于列表展示)',
  `location`      VARCHAR(200)  DEFAULT NULL COMMENT '地点',
  `start_time`    DATETIME      DEFAULT NULL COMMENT '开始时间',
  `end_time`      DATETIME      DEFAULT NULL COMMENT '结束时间(可空=无明确结束)',
  `all_day`       TINYINT       NOT NULL DEFAULT 0 COMMENT '是否全天 0-否 1-是',
  `remind`        TINYINT       NOT NULL DEFAULT 0 COMMENT '是否提醒 0-否 1-是',
  `remind_time`   DATETIME      DEFAULT NULL COMMENT '下次提醒时间',
  `remind_channel` VARCHAR(50)  DEFAULT NULL COMMENT '提醒渠道: site-站内信 email-邮件 sms-短信(多个用逗号分隔)',
  `remind_count`  INT           NOT NULL DEFAULT 1 COMMENT '提醒次数',
  `remind_interval` INT         NOT NULL DEFAULT 30 COMMENT '多次提醒时的间隔(分钟)',
  `reminded_count` INT          NOT NULL DEFAULT 0 COMMENT '已提醒次数',
  `status`        VARCHAR(20)   NOT NULL DEFAULT 'planned' COMMENT '状态 planned-待进行 done-已完成 cancelled-已取消',
  `owner_id`      VARCHAR(36)   NOT NULL COMMENT '归属人ID',
  `create_time`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`       TINYINT       NOT NULL DEFAULT 0,
  `is_demo`       TINYINT       NOT NULL DEFAULT 0 COMMENT '是否演示数据 1-演示 0-普通',
  PRIMARY KEY (`id`),
  KEY `idx_owner` (`owner_id`),
  KEY `idx_start` (`start_time`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客户日程表';

-- 营销活动表
CREATE TABLE IF NOT EXISTS `crm_marketing_activity` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `activity_name`    VARCHAR(100)  NOT NULL,
  `activity_type`    VARCHAR(30)   DEFAULT 'promotion',
  `channel`          VARCHAR(30)   DEFAULT 'offline',
  `start_date`       DATE          DEFAULT NULL,
  `end_date`         DATE          DEFAULT NULL,
  `budget`           DECIMAL(14,2) DEFAULT 0.00,
  `actual_cost`      DECIMAL(14,2) DEFAULT 0.00,
  `target_customers` INT           DEFAULT 0,
  `actual_customers` INT           DEFAULT 0,
  `status`           VARCHAR(20)   DEFAULT 'planning',
  `owner_id`         VARCHAR(36)        DEFAULT NULL COMMENT '归属人ID',
  `description`      TEXT,
  `remark`           VARCHAR(500)  DEFAULT NULL,
  `create_time`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`          TINYINT       NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_type` (`activity_type`),
  KEY `idx_dates` (`start_date`, `end_date`),
  KEY `idx_owner` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- 已有库升级：营销活动提醒（时间 / 渠道 / 次数 / 间隔 / 已提醒次数）（幂等）
SET @mkt_tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity');
SET @mkt_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'remind_time');
SET @ddl_mkt := IF(@mkt_tbl_exist = 0 OR @mkt_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_marketing_activity` ADD COLUMN `remind_time` DATETIME DEFAULT NULL COMMENT ''提醒时间'' AFTER `remark`');
PREPARE ddl_mkt FROM @ddl_mkt;
EXECUTE ddl_mkt;
DEALLOCATE PREPARE ddl_mkt;
SET @mkt_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'remind_channel');
SET @ddl_mkt := IF(@mkt_tbl_exist = 0 OR @mkt_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_marketing_activity` ADD COLUMN `remind_channel` VARCHAR(50) DEFAULT NULL COMMENT ''提醒渠道: site-站内信 email-邮件 sms-短信(多个用逗号分隔)'' AFTER `remind_time`');
PREPARE ddl_mkt FROM @ddl_mkt;
EXECUTE ddl_mkt;
DEALLOCATE PREPARE ddl_mkt;
SET @mkt_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'remind_count');
SET @ddl_mkt := IF(@mkt_tbl_exist = 0 OR @mkt_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_marketing_activity` ADD COLUMN `remind_count` INT NOT NULL DEFAULT 1 COMMENT ''提醒次数'' AFTER `remind_channel`');
PREPARE ddl_mkt FROM @ddl_mkt;
EXECUTE ddl_mkt;
DEALLOCATE PREPARE ddl_mkt;
SET @mkt_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'remind_interval');
SET @ddl_mkt := IF(@mkt_tbl_exist = 0 OR @mkt_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_marketing_activity` ADD COLUMN `remind_interval` INT NOT NULL DEFAULT 30 COMMENT ''多次提醒时的间隔(分钟)'' AFTER `remind_count`');
PREPARE ddl_mkt FROM @ddl_mkt;
EXECUTE ddl_mkt;
DEALLOCATE PREPARE ddl_mkt;
SET @mkt_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'reminded_count');
SET @ddl_mkt := IF(@mkt_tbl_exist = 0 OR @mkt_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_marketing_activity` ADD COLUMN `reminded_count` INT NOT NULL DEFAULT 0 COMMENT ''已提醒次数'' AFTER `remind_interval`');
PREPARE ddl_mkt FROM @ddl_mkt;
EXECUTE ddl_mkt;
DEALLOCATE PREPARE ddl_mkt;

-- 已有库升级：营销活动权限范围（visible_range / dept_ids / role_ids）（幂等）
SET @mkt_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'visible_range');
SET @ddl_mkt := IF(@mkt_tbl_exist = 0 OR @mkt_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_marketing_activity` ADD COLUMN `visible_range` VARCHAR(20) NOT NULL DEFAULT ''all'' COMMENT ''权限范围: all-全员 dept-指定部门 role-指定角色'' AFTER `remark`');
PREPARE ddl_mkt FROM @ddl_mkt;
EXECUTE ddl_mkt;
DEALLOCATE PREPARE ddl_mkt;
SET @mkt_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'dept_ids');
SET @ddl_mkt := IF(@mkt_tbl_exist = 0 OR @mkt_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_marketing_activity` ADD COLUMN `dept_ids` VARCHAR(500) DEFAULT NULL COMMENT ''可见部门ID(逗号分隔)'' AFTER `visible_range`');
PREPARE ddl_mkt FROM @ddl_mkt;
EXECUTE ddl_mkt;
DEALLOCATE PREPARE ddl_mkt;
SET @mkt_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'role_ids');
SET @ddl_mkt := IF(@mkt_tbl_exist = 0 OR @mkt_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_marketing_activity` ADD COLUMN `role_ids` VARCHAR(500) DEFAULT NULL COMMENT ''可见角色编码(逗号分隔)'' AFTER `dept_ids`');
PREPARE ddl_mkt FROM @ddl_mkt;
EXECUTE ddl_mkt;
DEALLOCATE PREPARE ddl_mkt;

-- 已有库升级：任务权限范围（visible_range / dept_ids / role_ids）（幂等）
SET @task_tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task');
SET @task_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task' AND COLUMN_NAME = 'visible_range');
SET @ddl_task := IF(@task_tbl_exist = 0 OR @task_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_task` ADD COLUMN `visible_range` VARCHAR(20) NOT NULL DEFAULT ''all'' COMMENT ''权限范围: all-全员 dept-指定部门 role-指定角色'' AFTER `owner_id`');
PREPARE ddl_task FROM @ddl_task;
EXECUTE ddl_task;
DEALLOCATE PREPARE ddl_task;
SET @task_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task' AND COLUMN_NAME = 'dept_ids');
SET @ddl_task := IF(@task_tbl_exist = 0 OR @task_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_task` ADD COLUMN `dept_ids` VARCHAR(500) DEFAULT NULL COMMENT ''可见部门ID(逗号分隔)'' AFTER `visible_range`');
PREPARE ddl_task FROM @ddl_task;
EXECUTE ddl_task;
DEALLOCATE PREPARE ddl_task;
SET @task_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task' AND COLUMN_NAME = 'role_ids');
SET @ddl_task := IF(@task_tbl_exist = 0 OR @task_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_task` ADD COLUMN `role_ids` VARCHAR(500) DEFAULT NULL COMMENT ''可见角色编码(逗号分隔)'' AFTER `dept_ids`');
PREPARE ddl_task FROM @ddl_task;
EXECUTE ddl_task;
DEALLOCATE PREPARE ddl_task;

-- 已有库升级：任务创建人 create_by（仅创建人或管理员可编辑/删除）（幂等），存量数据回填为归属人
SET @task_col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task' AND COLUMN_NAME = 'create_by');
SET @ddl_task := IF(@task_tbl_exist = 0 OR @task_col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_task` ADD COLUMN `create_by` VARCHAR(36) DEFAULT NULL COMMENT ''创建人ID'' AFTER `owner_id`');
PREPARE ddl_task FROM @ddl_task;
EXECUTE ddl_task;
DEALLOCATE PREPARE ddl_task;
UPDATE `crm_task` SET `create_by` = `owner_id` WHERE `create_by` IS NULL AND `owner_id` IS NOT NULL;

-- 营销图文表（AI 图文生成 + 多平台发布）
CREATE TABLE IF NOT EXISTS `crm_content` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `title`         VARCHAR(200) NOT NULL,
  `topic`         VARCHAR(200) DEFAULT NULL,
  `platform`      VARCHAR(200) DEFAULT NULL COMMENT '目标平台编码，逗号分隔（多平台发布支持全选）',
  `content`       LONGTEXT     DEFAULT NULL,
  `cover_url`     VARCHAR(500) DEFAULT NULL,
  `status`        VARCHAR(20)  NOT NULL DEFAULT 'draft',
  `publish_status` TEXT         DEFAULT NULL,
  `create_by`     VARCHAR(36)       DEFAULT NULL COMMENT '创建人ID',
  `create_time`   DATETIME     DEFAULT CURRENT_TIMESTAMP,
  `update_time`   DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`       TINYINT      NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_platform` (`platform`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- 通知公告表
CREATE TABLE IF NOT EXISTS `crm_notice` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `title`        VARCHAR(200) NOT NULL,
  `content`      TEXT         DEFAULT NULL,
  `notice_type`  VARCHAR(20)  NOT NULL DEFAULT 'notice',
  `status`       VARCHAR(20)  NOT NULL DEFAULT 'draft',
  `priority`     VARCHAR(10)  NOT NULL DEFAULT 'medium',
  `publisher_id` VARCHAR(36)       DEFAULT NULL COMMENT '发布人ID',
  `publish_time` DATETIME     DEFAULT NULL,
  `visible_range` VARCHAR(20) NOT NULL DEFAULT 'all',
  `dept_ids`     VARCHAR(500) DEFAULT NULL,
  `role_ids`     VARCHAR(500) DEFAULT NULL,
  `cover_url`    VARCHAR(500) DEFAULT NULL,
  `is_top`       TINYINT      NOT NULL DEFAULT 0,
  `create_time`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`      TINYINT      NOT NULL DEFAULT 0,
  `is_demo`      TINYINT      NOT NULL DEFAULT 0 COMMENT '是否演示数据 1-演示数据 0-普通数据',
  PRIMARY KEY (`id`),
  KEY `idx_type` (`notice_type`),
  KEY `idx_status` (`status`),
  KEY `idx_publisher` (`publisher_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- =====================================================
-- 四、字典管理模块
-- =====================================================

CREATE TABLE IF NOT EXISTS `sys_dict_type` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `dict_name`   VARCHAR(50)  NOT NULL,
  `dict_type`   VARCHAR(50)  NOT NULL,
  `status`      TINYINT      NOT NULL DEFAULT 1,
  `remark`      VARCHAR(200) DEFAULT NULL,
  `create_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dict_type` (`dict_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

CREATE TABLE IF NOT EXISTS `sys_dict_data` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `dict_type`   VARCHAR(50)  NOT NULL,
  `dict_label`  VARCHAR(100) NOT NULL,
  `dict_value`  VARCHAR(100) NOT NULL,
  `css_class`   VARCHAR(50)  DEFAULT NULL,
  `sort`        INT          NOT NULL DEFAULT 0,
  `status`      TINYINT      NOT NULL DEFAULT 1,
  `create_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_dict_type` (`dict_type`),
  -- 唯一约束保证 init.sql 每次启动的 INSERT IGNORE 幂等, 避免重复播种膨胀
  UNIQUE KEY `uk_dict_type_label_value` (`dict_type`, `dict_label`, `dict_value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- =====================================================
-- 五、增强模块：智能问答知识库 + 意见反馈
-- =====================================================

-- 智能问答知识库表（右下角智能问答使用本地知识库匹配）
CREATE TABLE IF NOT EXISTS `knowledge_qa` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键ID（UUID）',

  `question`    VARCHAR(500) NOT NULL,
  `answer`      TEXT         NOT NULL,
  `category`    VARCHAR(100) DEFAULT NULL,
  `keywords`    VARCHAR(500) DEFAULT NULL,
  `enabled`     TINYINT      NOT NULL DEFAULT 1,
  `hit_count`   INT          NOT NULL DEFAULT 0,
  `create_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`     TINYINT      NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- 意见反馈表
CREATE TABLE IF NOT EXISTS `feedback` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `user_id` varchar(36) DEFAULT NULL COMMENT '提交用户ID（同 sys_user.id，UUID）',
  `username` varchar(50) DEFAULT NULL,
  `real_name` varchar(50) DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT 0,
  `reply` varchar(500) DEFAULT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置表';

-- =====================================================
-- 六、授权与支付模块
-- =====================================================

-- 说明：授权记录由授权服务器（license-admin）统一按机器码存管，主项目不落本地库，
-- 历史授权通过 GET /license/records 从服务器查询，故此处不再创建 sys_license 本地表。

-- =====================================================
-- 七、初始化数据（幂等 INSERT）
-- =====================================================

-- 部门数据
INSERT IGNORE INTO `sys_dept` (`id`, `parent_id`, `dept_name`, `leader`, `phone`, `sort`) VALUES('1fa48be0-846e-4a2c-a8d2-8d8de6bd1274', '9de894ba-ef2b-4256-83b5-ab3bea0271e6',  '总公司',  '张总',  '13800000001',  0), ('9b919493-0d01-4f0c-8cb1-f01558b5db30', '1fa48be0-846e-4a2c-a8d2-8d8de6bd1274',  '销售部',  '李经理',  '13800000002',  1), ('9e39abde-d1f6-4f30-84b5-1d38cc783bb0', '1fa48be0-846e-4a2c-a8d2-8d8de6bd1274',  '市场部',  '王经理',  '13800000003',  2), ('cce1bc90-a9ea-4d85-b7f8-af377034a466', '1fa48be0-846e-4a2c-a8d2-8d8de6bd1274',  '技术部',  '赵经理',  '13800000004',  3)ON DUPLICATE KEY UPDATE `dept_name` = VALUES(`dept_name`), `leader` = VALUES(`leader`), `phone` = VALUES(`phone`);
-- 修复历史种子数据：总公司父节点指向了一个不存在的虚拟 ID，统一归到根 "0"
UPDATE `sys_dept` SET `parent_id` = '0' WHERE `parent_id` = '9de894ba-ef2b-4256-83b5-ab3bea0271e6';

-- 客户迁移菜单（挂在「客户管理」下，用于其它系统客户/联系人/跟进记录的批量导入）
INSERT IGNORE INTO `sys_menu` (`id`, `parent_id`, `menu_name`, `path`, `component`, `perms`, `icon`, `menu_type`, `sort`, `visible`) VALUES
('7e1f2a3b-4c5d-4e6f-8a9b-0c1d2e3f4a5b', '253c54e7-0335-4950-9238-58e889ca6efe', '客户迁移', '/customer/migrate', 'customer/migrate', NULL, 'Upload', 'C', 9, 1);
-- 兼容旧数据：菜单名由「客户迁移导入」改为「客户迁移」
UPDATE `sys_menu` SET `menu_name` = '客户迁移' WHERE `id` = '7e1f2a3b-4c5d-4e6f-8a9b-0c1d2e3f4a5b';
-- 兼容旧数据：菜单名由「联系人管理」改为「联系人」
UPDATE `sys_menu` SET `menu_name` = '联系人' WHERE `id` = 'c66185d9-2323-4642-8739-3669079faad9';

-- 客户迁移：默认仅授权给超级管理员（其它角色如需开放，可在「系统设置-角色管理」中分配菜单）
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`) VALUES
('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', '7e1f2a3b-4c5d-4e6f-8a9b-0c1d2e3f4a5b');
-- 已有库升级：客户迁移默认仅超级管理员可见（移除其它角色的授权，幂等）
DELETE FROM `sys_role_menu`
WHERE `menu_id` = '7e1f2a3b-4c5d-4e6f-8a9b-0c1d2e3f4a5b'
  AND `role_id` <> '5e627401-33ef-4ad8-ac15-86a0a3b76d4b';

-- 角色数据
INSERT IGNORE INTO `sys_role` (`id`, `role_name`, `role_code`, `description`) VALUES('5e627401-33ef-4ad8-ac15-86a0a3b76d4b',  '超级管理员',  'admin',  '拥有所有权限'), ('e9c3d346-9453-4798-8b5b-544025454a63',  '销售经理',  'sales_manager',  '销售管理权限'), ('23358b9b-f363-49e3-b0bf-9f8f332b8f91',  '销售员',  'sales',  '基础销售权限'), ('42128721-7865-4a9e-9903-5db1195c36ca',  '市场管理员',  'marketing_admin',  '销售线索管理权限')ON DUPLICATE KEY UPDATE `role_name` = VALUES(`role_name`), `description` = VALUES(`description`);

-- 用户数据 (密码均为 123456 的BCrypt加密)
INSERT IGNORE INTO `sys_user` (`id`, `username`, `password`, `real_name`, `phone`, `email`, `dept_id`) VALUES('e3a5a5d9-ee91-482c-90b5-6b33466eb7e6',  'admin',  '$2b$10$BPpYm8v4hLtXS3DwiQnf1.4BRkYH1jy5weWemJPfzRsLzFjJaIiTy',  '超级管理员',  '13800000001',  'admin@crm.com', '1fa48be0-846e-4a2c-a8d2-8d8de6bd1274'), ('a3578855-6602-4dc7-bb65-c89d861e1150',  'sales01',  '$2b$10$BPpYm8v4hLtXS3DwiQnf1.4BRkYH1jy5weWemJPfzRsLzFjJaIiTy',  '张三',  '13800000002',  'zhangsan@crm.com', '9b919493-0d01-4f0c-8cb1-f01558b5db30'), ('7e9a1491-0adf-4e67-a06d-d7f7f2ff905a',  'sales02',  '$2b$10$BPpYm8v4hLtXS3DwiQnf1.4BRkYH1jy5weWemJPfzRsLzFjJaIiTy',  '李四',  '13800000003',  'lisi@crm.com', '9b919493-0d01-4f0c-8cb1-f01558b5db30'), ('232c070a-8e3a-499e-bddf-44cc22ccc810',  'market01',  '$2b$10$BPpYm8v4hLtXS3DwiQnf1.4BRkYH1jy5weWemJPfzRsLzFjJaIiTy',  '王五',  '13800000004',  'market01@crm.com', '9e39abde-d1f6-4f30-84b5-1d38cc783bb0')ON DUPLICATE KEY UPDATE `username` = VALUES(`username`), `real_name` = VALUES(`real_name`), `phone` = VALUES(`phone`), `email` = VALUES(`email`);

-- 用户角色关联
INSERT IGNORE INTO `sys_user_role` (`user_id`, `role_id`) VALUES('e3a5a5d9-ee91-482c-90b5-6b33466eb7e6', '5e627401-33ef-4ad8-ac15-86a0a3b76d4b'), ('a3578855-6602-4dc7-bb65-c89d861e1150', 'e9c3d346-9453-4798-8b5b-544025454a63'), ('7e9a1491-0adf-4e67-a06d-d7f7f2ff905a', '23358b9b-f363-49e3-b0bf-9f8f332b8f91'), ('232c070a-8e3a-499e-bddf-44cc22ccc810', '42128721-7865-4a9e-9903-5db1195c36ca');

-- 菜单数据（与前端左侧菜单保持一致）
INSERT IGNORE INTO `sys_menu` (`id`, `parent_id`, `menu_name`, `path`, `component`, `perms`, `icon`, `menu_type`, `sort`, `visible`) VALUES('32254054-d06e-44d3-b3ed-3dc56c497a52', '9fd3f510-d365-428f-a2c6-a260d2150ba5',  '首页',  '/dashboard',  'dashboard/index',  NULL,  'Odometer',  'C',  1,  1), ('253c54e7-0335-4950-9238-58e889ca6efe', '9fd3f510-d365-428f-a2c6-a260d2150ba5',  '客户管理',  '/customer',  NULL,  NULL,  'User',  'M',  2,  1), ('a14043b6-87fc-41ff-abb4-390e99cf5b2f', '253c54e7-0335-4950-9238-58e889ca6efe',  '我的客户',  '/customer/list',  'customer/list',  'customer:list',  'UserFilled',  'C',  2,  1), ('3e545ae3-00b3-4d9a-8912-af227b04518f', '253c54e7-0335-4950-9238-58e889ca6efe',  '客户公海',  '/customer/pool',  'customer/pool',  'customer:pool',  'Ship',  'C',  1,  1), ('c66185d9-2323-4642-8739-3669079faad9', '253c54e7-0335-4950-9238-58e889ca6efe',  '联系人',  '/contact/list',  'contact/list',  'contact:list',  'Avatar',  'C',  3,  1), ('a50dc511-cd79-4056-941a-9f87c45aa2c4', '253c54e7-0335-4950-9238-58e889ca6efe',  '跟进记录',  '/followup/list',  'followup/list',  'followup:list',  'ChatLineRound',  'C',  4,  1), ('4cdf4c3c-9bc9-44fa-8f2c-f1213d601745', '9fd3f510-d365-428f-a2c6-a260d2150ba5',  '合同管理',  '/contract',  NULL,  NULL,  'Document',  'M',  3,  1), ('d6650d7b-5ec9-4887-a447-485b44f9c0f0', '4cdf4c3c-9bc9-44fa-8f2c-f1213d601745',  '合同管理',  '/contract/list',  'contract/list',  'contract:list',  'Document',  'C',  1,  1), ('0ba448af-e80d-4bd6-92f3-185511cce92f', '4cdf4c3c-9bc9-44fa-8f2c-f1213d601745',  '合同模板',  '/contract/template',  'contractTemplate/list',  'contract:template',  'Files',  'C',  2,  1), ('84f13cac-1c67-4c2f-b786-c9708f5c2fc4', '9fd3f510-d365-428f-a2c6-a260d2150ba5',  '营销管理',  '/marketing',  NULL,  NULL,  'Promotion',  'M',  4,  1), ('a21bb764-e333-4bad-80ab-fd6881853497', '84f13cac-1c67-4c2f-b786-c9708f5c2fc4',  '营销活动',  '/marketing/list',  'marketing/list',  'marketing:list',  'Flag', 'C', 2, 1), ('cd5d2fa0-f6bb-44c0-a34e-8b6e28836502', '84f13cac-1c67-4c2f-b786-c9708f5c2fc4',  '营销图文',  '/content/list',  'content/list',  'content:list',  'Picture', 'C', 1, 1), ('fc7b5f7e-14fa-4c5b-ae87-dde461317811', '9fd3f510-d365-428f-a2c6-a260d2150ba5',  '任务提醒',  '/task/list',  'task/list',  'task:list',  'AlarmClock',  'C',  5,  1), ('1d678e1d-b09d-49a6-ab66-eda360fb07d9', '9fd3f510-d365-428f-a2c6-a260d2150ba5',  '通知公告',  '/notice/list',  'notice/list',  'notice:list',  'Bell',  'C',  6,  1), ('04ee23a1-6207-4565-987e-22217d20657b', '0',  '知识库',  '/knowledge/list',  'knowledge/list',  'knowledge:list',  'Collection',  'C',  8,  1), ('ee14fd01-edb9-4043-865f-5ebbe7cdd8ed', '9fd3f510-d365-428f-a2c6-a260d2150ba5',  '系统管理',  '/system',  NULL,  NULL,  'Setting',  'M',  99,  1), ('897cdd17-d8e2-4d23-9704-7365be7fde7c', 'ee14fd01-edb9-4043-865f-5ebbe7cdd8ed',  '用户管理',  '/system/user',  'system/user',  'system:user:list',  'User',  'C',  1,  1), ('3f0b6b2d-36ca-461e-8d24-c045205866d7', 'ee14fd01-edb9-4043-865f-5ebbe7cdd8ed',  '角色管理',  '/system/role',  'system/role',  'system:role:list',  'UserFilled',  'C',  2,  1), ('9d0fd96c-062d-4595-ad90-f2a4609724e9', 'ee14fd01-edb9-4043-865f-5ebbe7cdd8ed',  '菜单管理',  '/system/menu',  'system/menu',  'system:menu:list',  'Menu',  'C',  3,  1), ('8d55b2f8-e91a-410f-b252-01bce68df51f', 'ee14fd01-edb9-4043-865f-5ebbe7cdd8ed',  '部门管理',  '/system/dept',  'system/dept',  'system:dept:list',  'OfficeBuilding',  'C',  4,  1), ('dcd6b123-79e6-4af3-8cec-7fc8bbf0e902', 'ee14fd01-edb9-4043-865f-5ebbe7cdd8ed',  '字典管理',  '/system/dict',  'system/dict',  'system:dict:list',  'Collection',  'C',  5,  1), ('1f9d76a9-adfb-41a5-9b59-dc9d5fb1f829', 'ee14fd01-edb9-4043-865f-5ebbe7cdd8ed',  '系统设置',  '/system/setting',  'system/setting',  'system:setting:list',  'Tools',  'C',  6,  1), ('13f7d6a3-2ef3-4087-aa6a-11ec9c6541df', 'ee14fd01-edb9-4043-865f-5ebbe7cdd8ed',  '意见反馈',  '/system/feedback',  'system/feedback',  'system:feedback:list',  'ChatDotRound',  'C',  7,  1), ('63aa8a74-4c2a-4866-9922-82a4ed8c3f43', 'ee14fd01-edb9-4043-865f-5ebbe7cdd8ed',  '操作日志',  '/system/operLog',  'system/operLog',  'system:operlog:list',  'Memo',  'C',  8,  1), ('49edf83d-de7a-42fb-a531-8ff0dbcf9849', 'ee14fd01-edb9-4043-865f-5ebbe7cdd8ed',  '运维监控',  '/system/monitor',  'system/monitor',  'system:monitor:list',  'Monitor',  'C',  9,  1), ('d17d18a6-14bd-4f17-9e1d-839d29322191', '9fd3f510-d365-428f-a2c6-a260d2150ba5',  '销售管理',  NULL,  NULL,  NULL,  'TrendCharts',  'M',  1,  1), ('00f80a1f-a436-4c05-af17-82fa5c69fe33', 'd17d18a6-14bd-4f17-9e1d-839d29322191',  '销售线索',  '/opportunity/list',  'opportunity/list',  'opportunity:list',  'Money',  'C',  2,  1), ('5daf90d3-a96f-4fc4-bc9f-7f1f76c30686', 'ee14fd01-edb9-4043-865f-5ebbe7cdd8ed',  '商机抓取',  '/opportunity-intel/crawl-source',  'opportunity/crawlSource',  'opportunity:crawl',  'Promotion',  'C',  11,  1), ('2531c39a-8401-49ed-97cd-0787dfc1fb0e', 'd17d18a6-14bd-4f17-9e1d-839d29322191',  '商机情报',  '/opportunity-intel/list',  'opportunity/intel',  'opportunity:intel',  'Lightning',  'C',  1,  1)ON DUPLICATE KEY UPDATE `parent_id` = VALUES(`parent_id`), `menu_name` = VALUES(`menu_name`), `path` = VALUES(`path`), `component` = VALUES(`component`), `perms` = VALUES(`perms`), `icon` = VALUES(`icon`), `menu_type` = VALUES(`menu_type`), `sort` = VALUES(`sort`), `visible` = VALUES(`visible`);
-- 修复历史种子数据：一级菜单父节点指向了一个不存在的虚拟根 ID，统一归到根 "0"
UPDATE `sys_menu` SET `parent_id` = '0' WHERE `parent_id` = '9fd3f510-d365-428f-a2c6-a260d2150ba5';

-- 角色菜单关联 (admin拥有所有权限)
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`) VALUES('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', '32254054-d06e-44d3-b3ed-3dc56c497a52'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', '253c54e7-0335-4950-9238-58e889ca6efe'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', 'a14043b6-87fc-41ff-abb4-390e99cf5b2f'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', 'c66185d9-2323-4642-8739-3669079faad9'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', 'd17d18a6-14bd-4f17-9e1d-839d29322191'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', '00f80a1f-a436-4c05-af17-82fa5c69fe33'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', 'a50dc511-cd79-4056-941a-9f87c45aa2c4'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', '4cdf4c3c-9bc9-44fa-8f2c-f1213d601745'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', 'ee14fd01-edb9-4043-865f-5ebbe7cdd8ed'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', '897cdd17-d8e2-4d23-9704-7365be7fde7c'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', '3f0b6b2d-36ca-461e-8d24-c045205866d7'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', '9d0fd96c-062d-4595-ad90-f2a4609724e9'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', '8d55b2f8-e91a-410f-b252-01bce68df51f'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', 'dcd6b123-79e6-4af3-8cec-7fc8bbf0e902'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', '1f9d76a9-adfb-41a5-9b59-dc9d5fb1f829'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', 'fc7b5f7e-14fa-4c5b-ae87-dde461317811'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', '84f13cac-1c67-4c2f-b786-c9708f5c2fc4'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', 'a21bb764-e333-4bad-80ab-fd6881853497'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', '1d678e1d-b09d-49a6-ab66-eda360fb07d9'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', '3e545ae3-00b3-4d9a-8912-af227b04518f'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', 'd6650d7b-5ec9-4887-a447-485b44f9c0f0'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', '0ba448af-e80d-4bd6-92f3-185511cce92f'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', 'cd5d2fa0-f6bb-44c0-a34e-8b6e28836502'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', '04ee23a1-6207-4565-987e-22217d20657b'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', '13f7d6a3-2ef3-4087-aa6a-11ec9c6541df'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', '63aa8a74-4c2a-4866-9922-82a4ed8c3f43'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', '49edf83d-de7a-42fb-a531-8ff0dbcf9849'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', '27de55ad-2942-4ee8-bd09-71ad043188de'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', '5daf90d3-a96f-4fc4-bc9f-7f1f76c30686'), ('5e627401-33ef-4ad8-ac15-86a0a3b76d4b', '2531c39a-8401-49ed-97cd-0787dfc1fb0e'), ('e9c3d346-9453-4798-8b5b-544025454a63', '32254054-d06e-44d3-b3ed-3dc56c497a52'), ('e9c3d346-9453-4798-8b5b-544025454a63', '253c54e7-0335-4950-9238-58e889ca6efe'), ('e9c3d346-9453-4798-8b5b-544025454a63', 'a14043b6-87fc-41ff-abb4-390e99cf5b2f'), ('e9c3d346-9453-4798-8b5b-544025454a63', 'c66185d9-2323-4642-8739-3669079faad9'), ('e9c3d346-9453-4798-8b5b-544025454a63', 'd17d18a6-14bd-4f17-9e1d-839d29322191'), ('e9c3d346-9453-4798-8b5b-544025454a63', '00f80a1f-a436-4c05-af17-82fa5c69fe33'), ('e9c3d346-9453-4798-8b5b-544025454a63', 'a50dc511-cd79-4056-941a-9f87c45aa2c4'), ('e9c3d346-9453-4798-8b5b-544025454a63', '4cdf4c3c-9bc9-44fa-8f2c-f1213d601745'), ('e9c3d346-9453-4798-8b5b-544025454a63', 'fc7b5f7e-14fa-4c5b-ae87-dde461317811'), ('e9c3d346-9453-4798-8b5b-544025454a63', '84f13cac-1c67-4c2f-b786-c9708f5c2fc4'), ('e9c3d346-9453-4798-8b5b-544025454a63', 'a21bb764-e333-4bad-80ab-fd6881853497'), ('e9c3d346-9453-4798-8b5b-544025454a63', '1d678e1d-b09d-49a6-ab66-eda360fb07d9'), ('e9c3d346-9453-4798-8b5b-544025454a63', '3e545ae3-00b3-4d9a-8912-af227b04518f'), ('e9c3d346-9453-4798-8b5b-544025454a63', 'd6650d7b-5ec9-4887-a447-485b44f9c0f0'), ('e9c3d346-9453-4798-8b5b-544025454a63', '0ba448af-e80d-4bd6-92f3-185511cce92f'), ('e9c3d346-9453-4798-8b5b-544025454a63', 'cd5d2fa0-f6bb-44c0-a34e-8b6e28836502'), ('e9c3d346-9453-4798-8b5b-544025454a63', '04ee23a1-6207-4565-987e-22217d20657b'), ('e9c3d346-9453-4798-8b5b-544025454a63', '5daf90d3-a96f-4fc4-bc9f-7f1f76c30686'), ('e9c3d346-9453-4798-8b5b-544025454a63', '2531c39a-8401-49ed-97cd-0787dfc1fb0e'), ('23358b9b-f363-49e3-b0bf-9f8f332b8f91', '32254054-d06e-44d3-b3ed-3dc56c497a52'), ('23358b9b-f363-49e3-b0bf-9f8f332b8f91', '253c54e7-0335-4950-9238-58e889ca6efe'), ('23358b9b-f363-49e3-b0bf-9f8f332b8f91', 'a14043b6-87fc-41ff-abb4-390e99cf5b2f'), ('23358b9b-f363-49e3-b0bf-9f8f332b8f91', 'c66185d9-2323-4642-8739-3669079faad9'), ('23358b9b-f363-49e3-b0bf-9f8f332b8f91', 'd17d18a6-14bd-4f17-9e1d-839d29322191'), ('23358b9b-f363-49e3-b0bf-9f8f332b8f91', '00f80a1f-a436-4c05-af17-82fa5c69fe33'), ('23358b9b-f363-49e3-b0bf-9f8f332b8f91', 'a50dc511-cd79-4056-941a-9f87c45aa2c4'), ('23358b9b-f363-49e3-b0bf-9f8f332b8f91', '4cdf4c3c-9bc9-44fa-8f2c-f1213d601745'), ('23358b9b-f363-49e3-b0bf-9f8f332b8f91', 'fc7b5f7e-14fa-4c5b-ae87-dde461317811'), ('23358b9b-f363-49e3-b0bf-9f8f332b8f91', '84f13cac-1c67-4c2f-b786-c9708f5c2fc4'), ('23358b9b-f363-49e3-b0bf-9f8f332b8f91', 'a21bb764-e333-4bad-80ab-fd6881853497'), ('23358b9b-f363-49e3-b0bf-9f8f332b8f91', '1d678e1d-b09d-49a6-ab66-eda360fb07d9'), ('23358b9b-f363-49e3-b0bf-9f8f332b8f91', '3e545ae3-00b3-4d9a-8912-af227b04518f'), ('23358b9b-f363-49e3-b0bf-9f8f332b8f91', 'd6650d7b-5ec9-4887-a447-485b44f9c0f0'), ('23358b9b-f363-49e3-b0bf-9f8f332b8f91', '0ba448af-e80d-4bd6-92f3-185511cce92f'), ('23358b9b-f363-49e3-b0bf-9f8f332b8f91', 'cd5d2fa0-f6bb-44c0-a34e-8b6e28836502'), ('23358b9b-f363-49e3-b0bf-9f8f332b8f91', '04ee23a1-6207-4565-987e-22217d20657b'), ('23358b9b-f363-49e3-b0bf-9f8f332b8f91', '5daf90d3-a96f-4fc4-bc9f-7f1f76c30686'), ('23358b9b-f363-49e3-b0bf-9f8f332b8f91', '2531c39a-8401-49ed-97cd-0787dfc1fb0e'), ('42128721-7865-4a9e-9903-5db1195c36ca', '32254054-d06e-44d3-b3ed-3dc56c497a52'), ('42128721-7865-4a9e-9903-5db1195c36ca', '253c54e7-0335-4950-9238-58e889ca6efe'), ('42128721-7865-4a9e-9903-5db1195c36ca', 'a14043b6-87fc-41ff-abb4-390e99cf5b2f'), ('42128721-7865-4a9e-9903-5db1195c36ca', 'c66185d9-2323-4642-8739-3669079faad9'), ('42128721-7865-4a9e-9903-5db1195c36ca', 'd17d18a6-14bd-4f17-9e1d-839d29322191'), ('42128721-7865-4a9e-9903-5db1195c36ca', '00f80a1f-a436-4c05-af17-82fa5c69fe33'), ('42128721-7865-4a9e-9903-5db1195c36ca', 'a50dc511-cd79-4056-941a-9f87c45aa2c4');

-- 系统设置默认数据（仅当表为空时插入）
INSERT IGNORE INTO `sys_setting` (`id`, `system_name`, `system_subtitle`, `login_logo`, `multi_login`)
SELECT'd3ad4f8d-a328-4fe6-a86f-fedcb9162554',  '云帆智能客户管理系统',  'Customer Relationship Management',  '',  0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `sys_setting`);

-- 系统名称修正（兼容旧名称）
UPDATE `sys_setting` SET `system_name` = '云帆智能客户管理系统', `update_time` = CURRENT_TIMESTAMP
WHERE `system_name` IN ('云帆客户管理系统', 'CRM客户关系管理系统');

-- 字典类型
INSERT IGNORE INTO `sys_dict_type` (`id`, `dict_name`, `dict_type`, `remark`) VALUES('215a172f-2b96-4343-9236-c02f5e6c1a28', '客户等级',  'customer_level',  '客户分级管理'), ('412d26d3-a38d-453f-bc09-f3d6239962b4', '客户来源',  'customer_source',  '客户来源渠道'), ('f33c64c1-b002-4e0d-92d7-cdbbab567ec5', '客户状态',  'customer_status',  '客户状态'), ('ca8d04c9-5756-4729-98a1-f22a90c81a10', '行业类型',  'industry',  '行业分类'), ('965157fc-1ce5-4333-b4a6-f5b969ddfe2a', '销售阶段',  'opp_stage',  '销售线索阶段'), ('158ea5ab-ef4e-4e01-84ea-310694f4eda9', '跟进类型',  'follow_type',  '客户跟进方式'), ('e86c4f2a-81c8-4bbd-98d5-a68bbbd1eea0', '合同状态',  'contract_status',  '合同审批状态'), ('9d4a62c9-33ee-407a-9cb5-433840de39b9', '合同模板分类',  'contract_template_category',  '合同模板分类'), ('e64433f9-0114-4ecb-880a-a4f446b6daf5', '客户状态',  'customer_deal_status',  '客户状态')ON DUPLICATE KEY UPDATE `dict_name` = VALUES(`dict_name`);

-- 字典数据
INSERT IGNORE INTO `sys_dict_data` (`id`, `dict_type`, `dict_label`, `dict_value`, `css_class`, `sort`) VALUES('15542f2e-41ee-4b9e-9af6-b13b83061cb8', 'customer_level',  'VIP客户',  'VIP',  'danger',  1), ('ad66489b-b0c4-4be8-8476-ab9a87661c64', 'customer_level',  '重要客户',  '重要',  'warning',  2), ('0069accd-79d8-473a-9903-b36917517f1d', 'customer_level',  '普通客户',  '普通',  'primary',  3), ('b49c591a-6bc7-4702-8620-ec0f3a1e4915', 'customer_level',  '潜在客户',  '潜在',  'info',  4), ('b54c351c-5cb9-4754-804a-260a7a346a66', 'customer_source',  '线上推广',  'online',  NULL,  1), ('e7011826-0596-4167-ba1b-04e2f2798b9d', 'customer_source',  '线下活动',  'offline',  NULL,  2), ('ae640ee8-a8af-4db9-b28d-e866ef04c423', 'customer_source',  '客户转介绍',  'referral',  NULL,  3), ('cae80cf8-b01a-485c-8495-c844e78e889b', 'customer_source',  '主动开发',  'self',  NULL,  4), ('998efc9a-e52a-4693-89f1-f3c81fe6462c', 'customer_status',  '活跃',  'active',  'success',  1), ('49436b86-f4ab-4be0-b8da-117d512323a7', 'customer_status',  '非活跃',  'inactive',  'warning',  2), ('18519251-82ea-4c2f-b5d6-901f2ce928ae', 'customer_status',  '流失',  'lost',  'danger',  3), ('282cc2ff-823d-4c8a-bd8e-540ecef1cbfc', 'industry',  '互联网/IT',  'IT',  NULL,  1), ('6f918b4f-00dc-47ad-9bc8-c6a10af6c86a', 'industry',  '制造业',  'manufacturing',  NULL,  2), ('16aaeac9-b092-4417-9171-62a3cc61ecdd', 'industry',  '金融',  'finance',  NULL,  3), ('92fe1c03-6e86-46c6-aca5-4d5238d26913', 'industry',  '教育',  'education',  NULL,  4), ('28059017-601b-40b3-9bed-d95ceb21665e', 'industry',  '医疗',  'medical',  NULL,  5), ('d35718a6-617f-4531-aa0d-27c50ddb781c', 'industry',  '房地产',  'realestate',  NULL,  6), ('9d911987-13d0-4127-bcc2-b6ab433c38cd', 'opp_stage',  '初步接触',  'initial',  'info',  1), ('b56bfe41-e862-492d-a4a4-098c893161a2', 'opp_stage',  '需求确认',  'qualification',  'primary',  2), ('99265e9d-c162-4dfe-8b69-81fd794ddcd9', 'opp_stage',  '方案报价',  'proposal',  'warning',  3), ('eef28bf1-e6c1-4f92-a896-c248c20750aa', 'opp_stage',  '商务谈判',  'negotiation',  'warning',  4), ('8efaf609-db96-4f84-b312-5e499e4620db', 'opp_stage',  '赢单',  'won',  'success',  5), ('ef94bc98-1237-4ec2-8d67-35036438c854', 'opp_stage',  '输单',  'lost',  'danger',  6), ('60a4f950-749a-4130-869e-ade88be2e4b0', 'follow_type',  '电话',  'phone',  NULL,  1), ('694193c9-462f-4086-9987-c8e24410b976', 'follow_type',  '拜访',  'visit',  NULL,  2), ('70256419-05fb-4023-888d-b2aa8a6e5457', 'follow_type',  '邮件',  'email',  NULL,  3), ('d39d1cfb-aa58-4ed9-ad5f-fb47b8af2553', 'follow_type',  '会议',  'meeting',  NULL,  4), ('2ba6c8fd-eaeb-4499-9915-206c84f718ec', 'follow_type',  '微信',  'wechat',  NULL,  5), ('a5a6f28a-109d-4ce9-9235-50c0e7af1126', 'follow_type',  '其他',  'other',  NULL,  6), ('2f074645-9e1e-4d9f-ae59-248d855425f4', 'contract_status',  '草稿',  'draft',  'info',  1), ('92d37816-5fd3-412e-bb9b-9b3748c150bb', 'contract_status',  '审批中',  'pending',  'warning',  2), ('9bf0fb8b-782b-4fe3-8bee-204a6bcddcdf', 'contract_status',  '已审批',  'approved',  'primary',  3), ('c3adb462-e52b-4fc5-9b8f-1a774dd49885', 'contract_status',  '执行中',  'executing',  'success',  4), ('64dc618a-1209-403c-8c52-894b4b7b0f9a', 'contract_status',  '已完成',  'completed',  'success',  5), ('55a46c33-fdd5-4cbd-9b52-376fb03e72df', 'contract_status',  '已终止',  'terminated',  'danger',  6), ('0f02c7f8-3cf4-491a-b5f5-32c4d6d45429', 'contract_template_category',  '销售合同',  'sales',  NULL,  1), ('eea0008b-184c-416f-a003-8b381ae1605f', 'contract_template_category',  '采购合同',  'purchase',  NULL,  2), ('396cc761-5d71-4aac-b2a0-84c8f2122a58', 'contract_template_category',  '服务合同',  'service',  NULL,  3), ('731e40e0-6825-439a-b866-b62da235d00b', 'contract_template_category',  '租赁合同',  'lease',  NULL,  4), ('b22e56ae-1eb1-4a25-bdce-93f8e9634e66', 'contract_template_category',  '其他',  'other',  NULL,  5), ('cbb48a2d-4bae-4ba2-aa13-ebd44e1c83cd', 'customer_deal_status',  'A：潜在客户',  'A',  'info',  1), ('1f2e8636-caba-4e2c-9a1d-6e302fe4ec2a', 'customer_deal_status',  'B：可跟进客户',  'B',  'primary',  2), ('85df40e6-972a-46ab-936c-d7f52e037607', 'customer_deal_status',  'C：重点跟进客户',  'C',  'warning',  3), ('6be96b2d-cc12-4043-b177-e200929bdf9f', 'customer_deal_status',  'D：拟成交客户',  'D',  'danger',  4), ('f4a43c2e-ef66-4de4-932c-8a31b045d24b', 'customer_deal_status',  'E：合作客户',  'E',  'success',  5), ('75c834ed-7f90-45eb-8d63-d60a265a07e7', 'customer_deal_status',  'F：放弃客户',  'F',  'info',  6)ON DUPLICATE KEY UPDATE `dict_label` = VALUES(`dict_label`);

-- 注：客户/联系人/机会/跟进/合同/任务/公告等示例数据统一在「第九节」中按每表 12 条写入。

-- =====================================================
-- 八、按钮权限数据（幂等，可重复执行）
-- =====================================================

-- 先清理旧按钮权限，保证幂等
DELETE FROM `sys_menu` WHERE `menu_type` = 'F';

INSERT IGNORE INTO `sys_menu` (`id`, `parent_id`, `menu_name`, `path`, `component`, `perms`, `icon`, `menu_type`, `sort`, `visible`, `create_time`, `update_time`) VALUES('32254054-d06e-44d3-b3ed-3dc56c497a52', 'a14043b6-87fc-41ff-abb4-390e99cf5b2f',  '新增客户',  NULL,  NULL,  'customer:add',  NULL,  'F',  1,  1,  NOW(),  NOW()), ('253c54e7-0335-4950-9238-58e889ca6efe', 'a14043b6-87fc-41ff-abb4-390e99cf5b2f',  '编辑客户',  NULL,  NULL,  'customer:edit',  NULL,  'F',  2,  1,  NOW(),  NOW()), ('a14043b6-87fc-41ff-abb4-390e99cf5b2f', 'a14043b6-87fc-41ff-abb4-390e99cf5b2f',  '删除客户',  NULL,  NULL,  'customer:delete',  NULL,  'F',  3,  1,  NOW(),  NOW()), ('c66185d9-2323-4642-8739-3669079faad9', 'a14043b6-87fc-41ff-abb4-390e99cf5b2f',  '导入客户',  NULL,  NULL,  'customer:import',  NULL,  'F',  4,  1,  NOW(),  NOW()), ('d17d18a6-14bd-4f17-9e1d-839d29322191', 'a14043b6-87fc-41ff-abb4-390e99cf5b2f',  '导出客户',  NULL,  NULL,  'customer:export',  NULL,  'F',  5,  1,  NOW(),  NOW()), ('00f80a1f-a436-4c05-af17-82fa5c69fe33', 'a14043b6-87fc-41ff-abb4-390e99cf5b2f',  '查看联系人',  NULL,  NULL,  'customer:contact',  NULL,  'F',  6,  1,  NOW(),  NOW()), ('a50dc511-cd79-4056-941a-9f87c45aa2c4', 'a14043b6-87fc-41ff-abb4-390e99cf5b2f',  '客户跟进',  NULL,  NULL,  'customer:follow',  NULL,  'F',  3,  1,  NOW(),  NOW()), ('4cdf4c3c-9bc9-44fa-8f2c-f1213d601745', 'a14043b6-87fc-41ff-abb4-390e99cf5b2f',  '查看公开信息',  NULL,  NULL,  'customer:publicInfo',  NULL,  'F',  7,  1,  NOW(),  NOW()), ('ee14fd01-edb9-4043-865f-5ebbe7cdd8ed', 'a14043b6-87fc-41ff-abb4-390e99cf5b2f',  '放入公海',  NULL,  NULL,  'customer:release',  NULL,  'F',  4,  1,  NOW(),  NOW()), ('897cdd17-d8e2-4d23-9704-7365be7fde7c', '253c54e7-0335-4950-9238-58e889ca6efe',  '领取客户',  NULL,  NULL,  'customer:claim',  NULL,  'F',  1,  1,  NOW(),  NOW()), ('3f0b6b2d-36ca-461e-8d24-c045205866d7', 'c66185d9-2323-4642-8739-3669079faad9',  '新增联系人',  NULL,  NULL,  'contact:add',  NULL,  'F',  1,  1,  NOW(),  NOW()), ('9d0fd96c-062d-4595-ad90-f2a4609724e9', 'c66185d9-2323-4642-8739-3669079faad9',  '编辑联系人',  NULL,  NULL,  'contact:edit',  NULL,  'F',  2,  1,  NOW(),  NOW()), ('8d55b2f8-e91a-410f-b252-01bce68df51f', 'c66185d9-2323-4642-8739-3669079faad9',  '删除联系人',  NULL,  NULL,  'contact:delete',  NULL,  'F',  3,  1,  NOW(),  NOW()), ('dcd6b123-79e6-4af3-8cec-7fc8bbf0e902', 'a50dc511-cd79-4056-941a-9f87c45aa2c4',  '新增跟进',  NULL,  NULL,  'followup:add',  NULL,  'F',  1,  1,  NOW(),  NOW()), ('1f9d76a9-adfb-41a5-9b59-dc9d5fb1f829', 'a50dc511-cd79-4056-941a-9f87c45aa2c4',  '删除跟进',  NULL,  NULL,  'followup:delete',  NULL,  'F',  2,  1,  NOW(),  NOW()), ('d160f3f7-2a26-4ad3-b1fe-ce540cd4e176', 'd6650d7b-5ec9-4887-a447-485b44f9c0f0',  '新增合同',  NULL,  NULL,  'contract:add',  NULL,  'F',  1,  1,  NOW(),  NOW()), ('fc7b5f7e-14fa-4c5b-ae87-dde461317811', 'd6650d7b-5ec9-4887-a447-485b44f9c0f0',  '编辑合同',  NULL,  NULL,  'contract:edit',  NULL,  'F',  2,  1,  NOW(),  NOW()), ('84f13cac-1c67-4c2f-b786-c9708f5c2fc4', 'd6650d7b-5ec9-4887-a447-485b44f9c0f0',  '删除合同',  NULL,  NULL,  'contract:delete',  NULL,  'F',  3,  1,  NOW(),  NOW()), ('a21bb764-e333-4bad-80ab-fd6881853497', 'd6650d7b-5ec9-4887-a447-485b44f9c0f0',  '导入合同',  NULL,  NULL,  'contract:import',  NULL,  'F',  4,  1,  NOW(),  NOW()), ('1d678e1d-b09d-49a6-ab66-eda360fb07d9', 'd6650d7b-5ec9-4887-a447-485b44f9c0f0',  '导出合同',  NULL,  NULL,  'contract:export',  NULL,  'F',  5,  1,  NOW(),  NOW()), ('3e545ae3-00b3-4d9a-8912-af227b04518f', '897cdd17-d8e2-4d23-9704-7365be7fde7c',  '新增用户',  NULL,  NULL,  'system:user:add',  NULL,  'F',  1,  1,  NOW(),  NOW()), ('d6650d7b-5ec9-4887-a447-485b44f9c0f0', '897cdd17-d8e2-4d23-9704-7365be7fde7c',  '编辑用户',  NULL,  NULL,  'system:user:edit',  NULL,  'F',  2,  1,  NOW(),  NOW()), ('0ba448af-e80d-4bd6-92f3-185511cce92f', '897cdd17-d8e2-4d23-9704-7365be7fde7c',  '删除用户',  NULL,  NULL,  'system:user:delete',  NULL,  'F',  3,  1,  NOW(),  NOW()), ('cd5d2fa0-f6bb-44c0-a34e-8b6e28836502', '897cdd17-d8e2-4d23-9704-7365be7fde7c',  '重置密码',  NULL,  NULL,  'system:user:resetPwd',  NULL,  'F',  4,  1,  NOW(),  NOW()), ('04ee23a1-6207-4565-987e-22217d20657b', '897cdd17-d8e2-4d23-9704-7365be7fde7c',  '导入用户',  NULL,  NULL,  'system:user:import',  NULL,  'F',  5,  1,  NOW(),  NOW()), ('13f7d6a3-2ef3-4087-aa6a-11ec9c6541df', '897cdd17-d8e2-4d23-9704-7365be7fde7c',  '导出用户',  NULL,  NULL,  'system:user:export',  NULL,  'F',  6,  1,  NOW(),  NOW()), ('63aa8a74-4c2a-4866-9922-82a4ed8c3f43', '3f0b6b2d-36ca-461e-8d24-c045205866d7',  '新增角色',  NULL,  NULL,  'system:role:add',  NULL,  'F',  1,  1,  NOW(),  NOW()), ('49edf83d-de7a-42fb-a531-8ff0dbcf9849', '3f0b6b2d-36ca-461e-8d24-c045205866d7',  '编辑角色',  NULL,  NULL,  'system:role:edit',  NULL,  'F',  2,  1,  NOW(),  NOW()), ('27de55ad-2942-4ee8-bd09-71ad043188de', '3f0b6b2d-36ca-461e-8d24-c045205866d7',  '删除角色',  NULL,  NULL,  'system:role:delete',  NULL,  'F',  3,  1,  NOW(),  NOW()), ('5daf90d3-a96f-4fc4-bc9f-7f1f76c30686', '3f0b6b2d-36ca-461e-8d24-c045205866d7',  '配置权限',  NULL,  NULL,  'system:role:perm',  NULL,  'F',  4,  1,  NOW(),  NOW()), ('2531c39a-8401-49ed-97cd-0787dfc1fb0e', '9d0fd96c-062d-4595-ad90-f2a4609724e9',  '新增菜单',  NULL,  NULL,  'system:menu:add',  NULL,  'F',  1,  1,  NOW(),  NOW()), ('42c1e9ca-8798-47ef-b530-062919a87da2', '9d0fd96c-062d-4595-ad90-f2a4609724e9',  '编辑菜单',  NULL,  NULL,  'system:menu:edit',  NULL,  'F',  2,  1,  NOW(),  NOW()), ('03eab5af-4610-458c-bac6-9539692887e6', '9d0fd96c-062d-4595-ad90-f2a4609724e9',  '删除菜单',  NULL,  NULL,  'system:menu:delete',  NULL,  'F',  3,  1,  NOW(),  NOW()), ('048e1bd7-c505-42e1-97a3-c3f44d120c0d', '8d55b2f8-e91a-410f-b252-01bce68df51f',  '新增部门',  NULL,  NULL,  'system:dept:add',  NULL,  'F',  1,  1,  NOW(),  NOW()), ('b0e3a654-0d9f-4877-a147-17ee1fcb7160', '8d55b2f8-e91a-410f-b252-01bce68df51f',  '编辑部门',  NULL,  NULL,  'system:dept:edit',  NULL,  'F',  2,  1,  NOW(),  NOW()), ('6c3c9d04-573f-4950-881e-76f0a688a9ed', '8d55b2f8-e91a-410f-b252-01bce68df51f',  '删除部门',  NULL,  NULL,  'system:dept:delete',  NULL,  'F',  3,  1,  NOW(),  NOW()), ('1c08cd25-e8ff-4088-b5d6-aee79b5755cc', 'dcd6b123-79e6-4af3-8cec-7fc8bbf0e902',  '新增字典',  NULL,  NULL,  'system:dict:add',  NULL,  'F',  1,  1,  NOW(),  NOW()), ('107d5ebc-54ac-4b17-a026-e5c467d588b9', 'dcd6b123-79e6-4af3-8cec-7fc8bbf0e902',  '编辑字典',  NULL,  NULL,  'system:dict:edit',  NULL,  'F',  2,  1,  NOW(),  NOW()), ('3b3b44cf-edab-4134-8971-6bdf46111a0f', 'dcd6b123-79e6-4af3-8cec-7fc8bbf0e902',  '删除字典',  NULL,  NULL,  'system:dict:delete',  NULL,  'F',  3,  1,  NOW(),  NOW()), ('f12607dc-e721-4d4a-b7e6-23eb7f85730a', '13f7d6a3-2ef3-4087-aa6a-11ec9c6541df',  '处理反馈',  NULL,  NULL,  'system:feedback:handle',  NULL,  'F',  1,  1,  NOW(),  NOW()), ('99a60f82-78a7-4a43-8aec-02513f1f8337', '13f7d6a3-2ef3-4087-aa6a-11ec9c6541df',  '删除反馈',  NULL,  NULL,  'system:feedback:delete',  NULL,  'F',  2,  1,  NOW(),  NOW()), ('a32e0e7f-00bc-456c-8a09-6351ae1dc5fd', 'fc7b5f7e-14fa-4c5b-ae87-dde461317811',  '新增任务',  NULL,  NULL,  'task:add',  NULL,  'F',  1,  1,  NOW(),  NOW()), ('22ac3303-63fd-4c9a-8833-e7c416e5aea6', 'fc7b5f7e-14fa-4c5b-ae87-dde461317811',  '编辑任务',  NULL,  NULL,  'task:edit',  NULL,  'F',  2,  1,  NOW(),  NOW()), ('8b0b999c-b1f5-44de-8c64-d7f6a260cee8', 'fc7b5f7e-14fa-4c5b-ae87-dde461317811',  '删除任务',  NULL,  NULL,  'task:delete',  NULL,  'F',  3,  1,  NOW(),  NOW()), ('9ddbf051-36e6-4f80-bdcf-b3559337e6e1', 'fc7b5f7e-14fa-4c5b-ae87-dde461317811',  '完成任务',  NULL,  NULL,  'task:complete',  NULL,  'F',  4,  1,  NOW(),  NOW()), ('42cf1129-607f-4364-b06b-d331c8f4d4bc', 'cd5d2fa0-f6bb-44c0-a34e-8b6e28836502',  '新增图文',  NULL,  NULL,  'content:add',  NULL,  'F',  1,  0,  NOW(),  NOW()), ('f960c827-2bcb-452e-87c8-03261bed8f39', 'cd5d2fa0-f6bb-44c0-a34e-8b6e28836502',  '编辑图文',  NULL,  NULL,  'content:edit',  NULL,  'F',  2,  0,  NOW(),  NOW()), ('3eb6603b-b693-4c44-938c-2c45ba28c0d2', 'cd5d2fa0-f6bb-44c0-a34e-8b6e28836502',  '删除图文',  NULL,  NULL,  'content:delete',  NULL,  'F',  3,  0,  NOW(),  NOW()), ('d78fe393-7f62-42c9-b617-c88a006823bd', 'cd5d2fa0-f6bb-44c0-a34e-8b6e28836502',  '发布图文',  NULL,  NULL,  'content:publish',  NULL,  'F',  4,  0,  NOW(),  NOW()), ('76a0b14f-4cd6-466a-bd98-79dbff0753c2', 'a21bb764-e333-4bad-80ab-fd6881853497',  '新增活动',  NULL,  NULL,  'marketing:add',  NULL,  'F',  1,  1,  NOW(),  NOW()), ('8c6e303c-73ce-40e6-be59-26889a9ec6b0', 'a21bb764-e333-4bad-80ab-fd6881853497',  '编辑活动',  NULL,  NULL,  'marketing:edit',  NULL,  'F',  2,  1,  NOW(),  NOW()), ('383c7282-5e0a-45d2-8a6c-e87f536d616d', 'a21bb764-e333-4bad-80ab-fd6881853497',  '删除活动',  NULL,  NULL,  'marketing:delete',  NULL,  'F',  3,  1,  NOW(),  NOW()), ('c4ab26ec-38a4-4687-9e5b-6dbd102bc0af', '1d678e1d-b09d-49a6-ab66-eda360fb07d9',  '新增公告',  NULL,  NULL,  'notice:add',  NULL,  'F',  1,  1,  NOW(),  NOW()), ('9b0366b4-d244-497f-9bc7-fb36f19d8808', '1d678e1d-b09d-49a6-ab66-eda360fb07d9',  '编辑公告',  NULL,  NULL,  'notice:edit',  NULL,  'F',  2,  1,  NOW(),  NOW()), ('8eb0c8af-3b9b-40b8-99fd-ca011273372f', '1d678e1d-b09d-49a6-ab66-eda360fb07d9',  '删除公告',  NULL,  NULL,  'notice:delete',  NULL,  'F',  3,  1,  NOW(),  NOW()), ('584b80f0-6e88-4cfc-add7-75df110ec490', '1d678e1d-b09d-49a6-ab66-eda360fb07d9',  '发布公告',  NULL,  NULL,  'notice:publish',  NULL,  'F',  4,  1,  NOW(),  NOW()), ('edb64013-fbb2-4b94-ad99-50af8c62d2bc', '1d678e1d-b09d-49a6-ab66-eda360fb07d9',  '撤销公告',  NULL,  NULL,  'notice:cancel',  NULL,  'F',  5,  1,  NOW(),  NOW()), ('05213257-aaca-4905-a938-f85a95cd3073', '2531c39a-8401-49ed-97cd-0787dfc1fb0e',  '手动抓取',  NULL,  NULL,  'opportunity:crawl',  NULL,  'F',  1,  1,  NOW(),  NOW());

-- 销售线索按钮权限（幂等：已存在则不重复插入）
INSERT INTO `sys_menu` (`id`, `parent_id`, `menu_name`, `path`, `component`, `perms`, `icon`, `menu_type`, `sort`, `visible`, `create_time`, `update_time`)
SELECT'f046545b-5f36-4696-a594-3ce4afc5a359', '00f80a1f-a436-4c05-af17-82fa5c69fe33',  '新增机会',  NULL,  NULL,  'opportunity:add',  NULL,  'F',  1,  1,  NOW(),  NOW()
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `sys_menu` WHERE `perms` = 'opportunity:add');
INSERT INTO `sys_menu` (`id`, `parent_id`, `menu_name`, `path`, `component`, `perms`, `icon`, `menu_type`, `sort`, `visible`, `create_time`, `update_time`)
SELECT'0226e7a5-f05f-429f-9709-ef9d29899844', '00f80a1f-a436-4c05-af17-82fa5c69fe33',  '编辑机会',  NULL,  NULL,  'opportunity:edit',  NULL,  'F',  2,  1,  NOW(),  NOW()
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `sys_menu` WHERE `perms` = 'opportunity:edit');
INSERT INTO `sys_menu` (`id`, `parent_id`, `menu_name`, `path`, `component`, `perms`, `icon`, `menu_type`, `sort`, `visible`, `create_time`, `update_time`)
SELECT'adbecdf6-39c1-4ebf-b6fc-2cd80c2c55e3', '00f80a1f-a436-4c05-af17-82fa5c69fe33',  '删除机会',  NULL,  NULL,  'opportunity:delete',  NULL,  'F',  3,  1,  NOW(),  NOW()
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `sys_menu` WHERE `perms` = 'opportunity:delete');
INSERT INTO `sys_menu` (`id`, `parent_id`, `menu_name`, `path`, `component`, `perms`, `icon`, `menu_type`, `sort`, `visible`, `create_time`, `update_time`)
SELECT'67a35cfe-9b37-4be9-b221-5bbba2f05b18', '00f80a1f-a436-4c05-af17-82fa5c69fe33',  '推进阶段',  NULL,  NULL,  'opportunity:stage',  NULL,  'F',  4,  1,  NOW(),  NOW()
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `sys_menu` WHERE `perms` = 'opportunity:stage');

-- 修正按钮权限所属父菜单（合同/图文/反馈按钮挂到对应页面菜单下）
UPDATE `sys_menu` SET `parent_id` = (SELECT `id` FROM (SELECT `id` FROM `sys_menu` WHERE `perms` = 'contract:list' LIMIT 1) AS `_t`) WHERE `perms` IN ('contract:add', 'contract:edit', 'contract:delete', 'contract:import', 'contract:export');
UPDATE `sys_menu` SET `parent_id` = (SELECT `id` FROM (SELECT `id` FROM `sys_menu` WHERE `perms` = 'content:list' LIMIT 1) AS `_t`) WHERE `perms` IN ('content:add', 'content:edit', 'content:delete', 'content:publish');
UPDATE `sys_menu` SET `parent_id` = (SELECT `id` FROM (SELECT `id` FROM `sys_menu` WHERE `perms` = 'system:feedback:list' LIMIT 1) AS `_t`) WHERE `perms` IN ('system:feedback:handle', 'system:feedback:delete');

-- 已有库升级：调整系统管理子菜单排序，将「系统设置」置于「用户管理」之前（幂等）
UPDATE `sys_menu` SET `sort` = CASE `menu_name`
  WHEN '系统设置' THEN 1
  WHEN '用户管理' THEN 2
  WHEN '角色管理' THEN 3
  WHEN '菜单管理' THEN 4
  WHEN '部门管理' THEN 5
  WHEN '字典管理' THEN 6
  ELSE `sort` END
WHERE `parent_id` = 'ee14fd01-edb9-4043-865f-5ebbe7cdd8ed';

-- 已有库升级：新增顶级「用户管理」分组，将用户/角色/菜单/部门管理移入，原「用户管理」改名「用户列表」（幂等）
INSERT INTO `sys_menu` (`id`, `parent_id`, `menu_name`, `path`, `component`, `perms`, `icon`, `menu_type`, `sort`, `visible`, `create_time`, `update_time`)
SELECT 'c0a8e1f2-7b3d-4c9a-9f6e-2d4b6c8a1e3f', '0', '用户管理', NULL, NULL, NULL, 'User', 'M', 95, 1, NOW(), NOW()
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `sys_menu` WHERE `id` = 'c0a8e1f2-7b3d-4c9a-9f6e-2d4b6c8a1e3f');
UPDATE `sys_menu` SET `menu_name` = '用户列表' WHERE `id` = '897cdd17-d8e2-4d23-9704-7365be7fde7c';
UPDATE `sys_menu` SET `parent_id` = 'c0a8e1f2-7b3d-4c9a-9f6e-2d4b6c8a1e3f', `sort` = CASE `id`
  WHEN '897cdd17-d8e2-4d23-9704-7365be7fde7c' THEN 1
  WHEN '3f0b6b2d-36ca-461e-8d24-c045205866d7' THEN 2
  WHEN '9d0fd96c-062d-4595-ad90-f2a4609724e9' THEN 3
  WHEN '8d55b2f8-e91a-410f-b252-01bce68df51f' THEN 4 END
WHERE `id` IN ('897cdd17-d8e2-4d23-9704-7365be7fde7c','3f0b6b2d-36ca-461e-8d24-c045205866d7','9d0fd96c-062d-4595-ad90-f2a4609724e9','8d55b2f8-e91a-410f-b252-01bce68df51f');

-- 已有库升级：将新建顶级「用户管理」分组授权给超级管理员（幂等）
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT (SELECT `id` FROM `sys_role` WHERE `role_code` = 'admin' LIMIT 1), 'c0a8e1f2-7b3d-4c9a-9f6e-2d4b6c8a1e3f';

-- 已有库升级：消息管理（含消息通知、消息模板）仅保留给超级管理员，移除销售员/销售经理/市场管理员的权限（幂等）
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT (SELECT `id` FROM `sys_role` WHERE `role_code` = 'admin' LIMIT 1), m.id
FROM (SELECT 'f2c1a9b0-0009-4a2c-8d2a-000000000009' AS id UNION ALL
      SELECT 'f2c1a9b0-0002-4a2c-8d2a-000000000002' UNION ALL
      SELECT 'f2c1a9b0-0003-4a2c-8d2a-000000000003') m;
DELETE FROM `sys_role_menu`
WHERE `menu_id` IN ('f2c1a9b0-0009-4a2c-8d2a-000000000009','f2c1a9b0-0002-4a2c-8d2a-000000000002','f2c1a9b0-0003-4a2c-8d2a-000000000003')
AND `role_id` IN (SELECT `id` FROM `sys_role` WHERE `role_code` IN ('sales','sales_manager','marketing_admin'));

-- 已有库升级：市场管理员移除「客户管理」下的「我的客户/联系人管理/跟进记录」及其按钮权限（幂等）
DELETE FROM `sys_role_menu`
WHERE `role_id` = (SELECT `id` FROM `sys_role` WHERE `role_code` = 'marketing_admin' LIMIT 1)
AND `menu_id` IN (
  SELECT `id` FROM (
    SELECT 'a14043b6-87fc-41ff-abb4-390e99cf5b2f' AS id UNION ALL
    SELECT 'c66185d9-2323-4642-8739-3669079faad9' UNION ALL
    SELECT 'a50dc511-cd79-4056-941a-9f87c45aa2c4' UNION ALL
    SELECT `id` FROM `sys_menu` WHERE `parent_id` IN (
      'a14043b6-87fc-41ff-abb4-390e99cf5b2f',
      'c66185d9-2323-4642-8739-3669079faad9',
      'a50dc511-cd79-4056-941a-9f87c45aa2c4'
    )
  ) t
);

-- 已有库升级：市场管理员移除「我的日程」及其按钮权限（幂等）
DELETE FROM `sys_role_menu`
WHERE `role_id` = (SELECT `id` FROM `sys_role` WHERE `role_code` = 'marketing_admin' LIMIT 1)
AND `menu_id` IN (
  SELECT `id` FROM (
    SELECT 'f2c1a9b0-0001-4a2c-8d2a-000000000001' AS id UNION ALL
    SELECT `id` FROM `sys_menu` WHERE `parent_id` = 'f2c1a9b0-0001-4a2c-8d2a-000000000001'
  ) t
);

-- 移除 AI 助手菜单（页面路由保留，仍可通过 /ai/chat 直接访问）
DELETE FROM `sys_menu` WHERE `perms` = 'system:ai:chat';
DELETE FROM `sys_role_menu` WHERE `menu_id` = (SELECT `id` FROM `sys_menu` WHERE `perms` = 'system:ai:chat');

-- 清理角色菜单中已不存在的记录
DELETE rm FROM `sys_role_menu` rm LEFT JOIN `sys_menu` m ON rm.menu_id = m.id WHERE m.id IS NULL;

-- 给超级管理员（role_id=1）绑定全部按钮权限
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT (SELECT `id` FROM `sys_role` WHERE `role_code` = 'admin' LIMIT 1), id FROM `sys_menu` WHERE `menu_type` = 'F';

-- 绑定客户公海/跟进/领取/图文/商机菜单权限给所有角色
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT r.id,  m.id FROM `sys_role` r, `sys_menu` m
WHERE m.`perms` IN ('customer:pool', 'customer:follow', 'customer:claim', 'customer:release', 'customer:publicInfo', 'content:list', 'opportunity:intel', 'opportunity:crawl', 'opportunity:list', 'opportunity:add', 'opportunity:edit', 'opportunity:delete', 'opportunity:stage')
AND NOT EXISTS (SELECT 1 FROM `sys_role_menu` x WHERE x.role_id = r.id AND x.menu_id = m.id);

-- 考勤菜单授权给所有角色
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT r.id,  m.id FROM `sys_role` r, `sys_menu` m
WHERE m.`perms` IN ('attendance:sign', 'attendance:manage')
AND NOT EXISTS (SELECT 1 FROM `sys_role_menu` x WHERE x.role_id = r.id AND x.menu_id = m.id);

-- =====================================================
-- 九、商机情报表（网上公开的项目信息 / 招投标信息）
-- =====================================================
CREATE TABLE IF NOT EXISTS `crm_business_opportunity` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键',
  `title`              VARCHAR(500)  NOT NULL COMMENT '标题（项目名称/公告标题）',
  `type`               VARCHAR(20)   NOT NULL DEFAULT 'tender' COMMENT '类型：tender-招投标 project-项目信息',
  `source`             VARCHAR(100)  DEFAULT NULL COMMENT '来源（发布平台/数据源）',
  `source_url`         VARCHAR(1000) DEFAULT NULL COMMENT '原文链接',
  `region`             VARCHAR(100)  DEFAULT NULL COMMENT '地区',
  `industry`           VARCHAR(100)  DEFAULT NULL COMMENT '行业',
  `budget_amount`      DECIMAL(20,2) DEFAULT NULL COMMENT '预算金额（元）',
  `publisher`          VARCHAR(255)  DEFAULT NULL COMMENT '招标人/业主单位',
  `publish_time`       DATETIME      DEFAULT NULL COMMENT '公告发布时间',
  `deadline_time`      DATETIME      DEFAULT NULL COMMENT '截止时间（投标/报名）',
  `procurement_method` VARCHAR(50)   DEFAULT NULL COMMENT '采购方式',
  `project_no`         VARCHAR(100)  DEFAULT NULL COMMENT '项目编号',
  `summary`            TEXT          COMMENT '摘要/项目概况',
  `status`             VARCHAR(20)   NOT NULL DEFAULT 'new' COMMENT '状态：new-新增 following-跟进中 handled-已跟进 abandoned-已放弃',
  `followed_by`        VARCHAR(100)  DEFAULT NULL COMMENT '关注人姓名',
  `followed_time`      DATETIME      DEFAULT NULL COMMENT '关注时间',
  `is_demo`            TINYINT(1)    NOT NULL DEFAULT 0 COMMENT '是否演示数据 0-否 1-是',
  `create_time`        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time`        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted`            TINYINT(1)    NOT NULL DEFAULT 0 COMMENT '逻辑删除 0-否 1-是',
  PRIMARY KEY (`id`),
  KEY `idx_type_status` (`type`, `status`),
  KEY `idx_publish_time` (`publish_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商机情报（公开项目/招投标信息）';

-- 9.1 商机情报-用户已读记录
CREATE TABLE IF NOT EXISTS `crm_business_opportunity_read` (
  `id`             VARCHAR(36) NOT NULL COMMENT '主键',
  `user_id`        VARCHAR(36) NOT NULL COMMENT '用户ID',
  `opportunity_id` VARCHAR(36) NOT NULL COMMENT '商机情报ID',
  `create_time`    DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '首次阅读时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_opportunity` (`user_id`, `opportunity_id`),
  KEY `idx_opportunity_id` (`opportunity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商机情报-用户已读记录';

-- 9.2 签到记录
CREATE TABLE IF NOT EXISTS `crm_attendance` (
  `id`              VARCHAR(36) NOT NULL COMMENT '主键',
  `user_id`         VARCHAR(36) DEFAULT NULL COMMENT '签到用户ID',
  `attendance_date` DATE        DEFAULT NULL COMMENT '签到日期',
  `sign_in_time`    DATETIME    DEFAULT NULL COMMENT '签到时间',
  `sign_in_face`    VARCHAR(500) DEFAULT NULL COMMENT '签到人脸照片地址',
  `sign_in_address` VARCHAR(255) DEFAULT NULL COMMENT '签到地点',
  `sign_out_time`   DATETIME    DEFAULT NULL COMMENT '签退时间',
  `sign_out_face`   VARCHAR(500) DEFAULT NULL COMMENT '签退人脸照片地址',
  `status`          VARCHAR(20)  DEFAULT NULL COMMENT '状态：normal-正常 late-迟到 early-早退',
  `face_verified`   TINYINT      DEFAULT NULL COMMENT '是否人脸核验 0-否 1-是',
  `remark`          VARCHAR(500) DEFAULT NULL COMMENT '备注',
  `create_time`     DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time`     DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted`         TINYINT(1)  NOT NULL DEFAULT 0 COMMENT '逻辑删除 0-否 1-是',
  `is_demo`         TINYINT(1)  NOT NULL DEFAULT 0 COMMENT '是否演示数据 0-否 1-是',
  PRIMARY KEY (`id`),
  KEY `idx_user_date` (`user_id`, `attendance_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='签到记录';

-- 9.3 消息模板
CREATE TABLE IF NOT EXISTS `crm_message_template` (
  `id`            VARCHAR(36) NOT NULL COMMENT '主键',
  `template_code` VARCHAR(100) DEFAULT NULL COMMENT '模板编码（唯一）',
  `template_name` VARCHAR(100) DEFAULT NULL COMMENT '模板名称',
  `channel`       VARCHAR(20)  DEFAULT NULL COMMENT '渠道：sms-短信 email-邮件 site-站内信',
  `biz_type`      VARCHAR(50)  DEFAULT NULL COMMENT '业务类型',
  `title`         VARCHAR(255) DEFAULT NULL COMMENT '消息标题',
  `content`       TEXT         COMMENT '模板内容，支持 ${变量} 占位',
  `remark`        VARCHAR(500) DEFAULT NULL COMMENT '备注',
  `status`        VARCHAR(20)  DEFAULT NULL COMMENT '状态：enabled-启用 disabled-停用',
  `create_time`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted`       TINYINT(1)   NOT NULL DEFAULT 0 COMMENT '逻辑删除 0-否 1-是',
  `is_demo`       TINYINT(1)   NOT NULL DEFAULT 0 COMMENT '是否演示数据 0-否 1-是',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_template_code` (`template_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消息模板';

-- 9.4 消息通知记录
CREATE TABLE IF NOT EXISTS `crm_message` (
  `id`            VARCHAR(36) NOT NULL COMMENT '主键',
  `channel`       VARCHAR(20)  DEFAULT NULL COMMENT '渠道：sms-短信 email-邮件 site-站内信',
  `template_id`   VARCHAR(36)  DEFAULT NULL COMMENT '关联模板ID',
  `template_code` VARCHAR(100) DEFAULT NULL COMMENT '模板编码',
  `receiver`      VARCHAR(255) DEFAULT NULL COMMENT '接收方（手机号/邮箱/用户ID）',
  `receiver_name` VARCHAR(100) DEFAULT NULL COMMENT '接收人姓名',
  `user_id`       VARCHAR(36)  DEFAULT NULL COMMENT '站内信接收用户ID（用于我的消息收件箱）',
  `is_read`       TINYINT(1)   NOT NULL DEFAULT 0 COMMENT '站内信是否已读 0-未读 1-已读',
  `title`         VARCHAR(255) DEFAULT NULL COMMENT '消息标题',
  `content`       TEXT         COMMENT '消息内容',
  `biz_type`      VARCHAR(50)  DEFAULT NULL COMMENT '业务类型',
  `biz_id`        VARCHAR(36)  DEFAULT NULL COMMENT '关联业务ID',
  `status`        VARCHAR(20)  DEFAULT NULL COMMENT '状态：success-成功 fail-失败',
  `fail_reason`   VARCHAR(500) DEFAULT NULL COMMENT '失败原因',
  `send_time`     DATETIME     DEFAULT NULL COMMENT '发送时间',
  `create_time`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted`       TINYINT(1)   NOT NULL DEFAULT 0 COMMENT '逻辑删除 0-否 1-是',
  `is_demo`       TINYINT(1)   NOT NULL DEFAULT 0 COMMENT '是否演示数据 0-否 1-是',
  PRIMARY KEY (`id`),
  KEY `idx_receiver` (`receiver`),
  KEY `idx_biz` (`biz_type`, `biz_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消息通知记录';

-- =====================================================
-- 十、商机抓取数据源（多数据源配置）
-- =====================================================
CREATE TABLE IF NOT EXISTS `crm_crawl_source` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键',
  `source_name`     VARCHAR(100)  NOT NULL COMMENT '数据源名称',
  `source_type`     VARCHAR(20)   NOT NULL DEFAULT 'custom' COMMENT '类型：custom-自定义API demo-内置演示',
  `base_url`        VARCHAR(500)  DEFAULT NULL COMMENT '接口地址',
  `app_key`         VARCHAR(200)  DEFAULT NULL COMMENT 'AppKey',
  `app_secret`      VARCHAR(200)  DEFAULT NULL COMMENT 'AppSecret',
  `enabled`         TINYINT(1)    NOT NULL DEFAULT 1 COMMENT '是否启用 0-停用 1-启用',
  `remark`          VARCHAR(500)  DEFAULT NULL COMMENT '备注',
  `last_crawl_time` DATETIME      DEFAULT NULL COMMENT '最近抓取时间',
  `last_result`     TEXT          COMMENT '最近抓取结果',
  `create_time`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted`         TINYINT(1)    NOT NULL DEFAULT 0 COMMENT '逻辑删除 0-否 1-是',
  PRIMARY KEY (`id`),
  KEY `idx_enabled` (`enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商机抓取数据源';

-- 内置演示数据源（幂等：已有数据源则不重复插入）
INSERT INTO `crm_crawl_source` (`id`, `source_name`, `source_type`, `enabled`, `remark`)
SELECT'6cad02d8-b51c-4755-b41b-4e1feb74c58a',  '内置演示数据',  'demo',  1,  '开箱即用：生成贴近真实的招投标/项目公告演示数据，无需任何配置'
WHERE NOT EXISTS (SELECT 1 FROM `crm_crawl_source` WHERE `deleted` = 0);

-- 默认演示数据源：模拟常见公开商机发布平台，零配置即可一键抓取演示数据。
-- 以下均为演示性质（source_type=demo），接入真实数据请新增 custom 类型并填写第三方 API 地址。
INSERT INTO `crm_crawl_source` (`id`, `source_name`, `source_type`, `enabled`, `remark`)
SELECT s.id, s.name, 'demo', 1, s.remark FROM (
  SELECT 'a1f3c2e0-1001-4a2b-8c5d-000000000001' AS id, '全国公共资源交易平台' AS name, '对接全国公共资源交易服务平台，覆盖各省市工程建设、政府采购等公开交易信息' AS remark UNION ALL
  SELECT 'a1f3c2e0-1001-4a2b-8c5d-000000000002', '中国政府采购网', '对接中国政府采购网，获取中央及地方政府采购公告、中标结果等信息' UNION ALL
  SELECT 'a1f3c2e0-1001-4a2b-8c5d-000000000003', '中国招标投标公共服务平台', '对接中国招标投标公共服务平台，覆盖工程、货物、服务类招标公告' UNION ALL
  SELECT 'a1f3c2e0-1001-4a2b-8c5d-000000000004', '企业工商公开信息', '对接公开企业工商/招采信息，用于发现潜在客户与项目机会'
) s
WHERE NOT EXISTS (SELECT 1 FROM `crm_crawl_source` WHERE `source_name` = s.name AND `deleted` = 0);

-- =====================================================
-- 十一、数据库定时备份配置（轻量级，单行配置）
-- =====================================================
CREATE TABLE IF NOT EXISTS `sys_backup_config` (
  `id`               VARCHAR(36) NOT NULL COMMENT '主键',
  `enabled`          TINYINT(1)    NOT NULL DEFAULT 0 COMMENT '是否启用定时备份 0-停用 1-启用',
  `cron`             VARCHAR(60)   NOT NULL DEFAULT '0 0 2 * * ?' COMMENT '定时备份 cron 表达式（每天凌晨 2 点）',
  `backup_dir`       VARCHAR(500)  NOT NULL DEFAULT './backups' COMMENT '备份文件存放目录',
  `retention_days`   INT(11)       NOT NULL DEFAULT 7 COMMENT '备份保留天数，超过自动清理',
  `use_mysqldump`    TINYINT(1)    NOT NULL DEFAULT 0 COMMENT '优先使用 mysqldump（0-关，走内置 JDBC 备份）',
  `mysqldump_path`   VARCHAR(500)  DEFAULT NULL COMMENT 'mysqldump 可执行文件路径（留空自动探测）',
  `create_time`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='数据库定时备份配置';

-- 默认备份配置（幂等：已存在则不重复插入）
INSERT INTO `sys_backup_config` (`id`, `enabled`, `cron`, `backup_dir`, `retention_days`, `use_mysqldump`)
SELECT 'b1c2d3e4-0001-4a2b-8c5d-000000000001', 0, '0 0 2 * * ?', './backups', 7, 0
WHERE NOT EXISTS (SELECT 1 FROM `sys_backup_config`);

-- =====================================================
-- =====================================================

-- 消息通知记录
CREATE TABLE IF NOT EXISTS crm_message (
  `id` VARCHAR(36) NOT NULL COMMENT '主键',
  channel VARCHAR(20) NOT NULL DEFAULT 'sms' COMMENT '渠道：sms-短信 email-邮件 site-站内信',
  template_id VARCHAR(36) DEFAULT NULL COMMENT '消息模板ID',
  template_code VARCHAR(60) DEFAULT NULL COMMENT '模板编码',
  receiver VARCHAR(200) DEFAULT NULL COMMENT '接收方（手机号/邮箱/用户ID）',
  receiver_name VARCHAR(100) DEFAULT NULL COMMENT '接收人姓名',
  title VARCHAR(200) DEFAULT NULL COMMENT '消息标题',
  content TEXT COMMENT '消息内容',
  biz_type VARCHAR(50) DEFAULT NULL COMMENT '业务类型',
  biz_id VARCHAR(36) DEFAULT NULL COMMENT '关联业务ID',
  status VARCHAR(20) NOT NULL DEFAULT 'success' COMMENT '状态：success-成功 fail-失败',
  fail_reason VARCHAR(500) DEFAULT NULL COMMENT '失败原因',
  send_time DATETIME DEFAULT NULL COMMENT '发送时间',
  create_time DATETIME DEFAULT NULL COMMENT '创建时间',
  update_time DATETIME DEFAULT NULL COMMENT '更新时间',
  deleted TINYINT NOT NULL DEFAULT 0 COMMENT '逻辑删除：0-未删除 1-已删除',
  is_demo TINYINT NOT NULL DEFAULT 0 COMMENT '是否演示数据：1-是 0-否',
  PRIMARY KEY (id),
  KEY idx_channel (channel),
  KEY idx_send_time (send_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消息通知记录';

-- 消息模板
CREATE TABLE IF NOT EXISTS crm_message_template (
  `id` VARCHAR(36) NOT NULL COMMENT '主键',
  template_code VARCHAR(60) NOT NULL COMMENT '模板编码（唯一）',
  template_name VARCHAR(100) NOT NULL COMMENT '模板名称',
  channel VARCHAR(20) NOT NULL DEFAULT 'sms' COMMENT '渠道：sms-短信 email-邮件 site-站内信',
  biz_type VARCHAR(50) DEFAULT NULL COMMENT '业务类型',
  title VARCHAR(200) DEFAULT NULL COMMENT '消息标题（邮件/站内信用）',
  content TEXT NOT NULL COMMENT '模板内容，支持 ${变量} 占位',
  remark VARCHAR(300) DEFAULT NULL COMMENT '备注',
  status VARCHAR(20) NOT NULL DEFAULT 'enabled' COMMENT '状态：enabled-启用 disabled-停用',
  create_time DATETIME DEFAULT NULL COMMENT '创建时间',
  update_time DATETIME DEFAULT NULL COMMENT '更新时间',
  deleted TINYINT NOT NULL DEFAULT 0 COMMENT '逻辑删除：0-未删除 1-已删除',
  is_demo TINYINT NOT NULL DEFAULT 0 COMMENT '是否演示数据：1-是 0-否',
  PRIMARY KEY (id),
  UNIQUE KEY uk_template_code (template_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消息模板';

-- 签到记录
CREATE TABLE IF NOT EXISTS crm_attendance (
  `id` VARCHAR(36) NOT NULL COMMENT '主键',
  user_id VARCHAR(36) NOT NULL COMMENT '签到用户ID',
  attendance_date DATE NOT NULL COMMENT '签到日期',
  sign_in_time DATETIME DEFAULT NULL COMMENT '签到时间',
  sign_in_face VARCHAR(500) DEFAULT NULL COMMENT '签到人脸照片地址',
  sign_in_address VARCHAR(200) DEFAULT NULL COMMENT '签到地点',
  sign_out_time DATETIME DEFAULT NULL COMMENT '签退时间',
  sign_out_face VARCHAR(500) DEFAULT NULL COMMENT '签退人脸照片地址',
  status VARCHAR(20) NOT NULL DEFAULT 'normal' COMMENT '状态：normal-正常 late-迟到 early-早退',
  face_verified TINYINT NOT NULL DEFAULT 0 COMMENT '是否人脸核验：0-否 1-是',
  remark VARCHAR(300) DEFAULT NULL COMMENT '备注',
  create_time DATETIME DEFAULT NULL COMMENT '创建时间',
  update_time DATETIME DEFAULT NULL COMMENT '更新时间',
  deleted TINYINT NOT NULL DEFAULT 0 COMMENT '逻辑删除：0-未删除 1-已删除',
  is_demo TINYINT NOT NULL DEFAULT 0 COMMENT '是否演示数据：1-是 0-否',
  PRIMARY KEY (id),
  KEY idx_user_date (user_id, attendance_date),
  KEY idx_date (attendance_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='签到记录';

-- 补充：侧边栏动态菜单所需菜单项（我的日程/消息/考勤/AI助手/个人信息），与 db/init.sql 保持一致
INSERT IGNORE INTO `sys_menu` (`id`, `parent_id`, `menu_name`, `path`, `component`, `perms`, `icon`, `menu_type`, `sort`, `visible`) VALUES
('f2c1a9b0-0001-4a2c-8d2a-000000000001', '0', '我的日程', '/schedule/list', 'schedule/list', NULL, 'Calendar', 'C', 7, 1),
('f2c1a9b0-0009-4a2c-8d2a-000000000009', '0', '消息管理', NULL, NULL, NULL, 'Bell', 'M', 10, 1), ('f2c1a9b0-0002-4a2c-8d2a-000000000002', 'f2c1a9b0-0009-4a2c-8d2a-000000000009', '消息通知', '/message/notify', 'message/notify', NULL, 'Message', 'C', 1, 1),
('f2c1a9b0-0003-4a2c-8d2a-000000000003', 'f2c1a9b0-0009-4a2c-8d2a-000000000009', '消息模板', '/message/template', 'message/template', NULL, 'Document', 'C', 2, 1),
('f2c1a9b0-0004-4a2c-8d2a-000000000004', '0', '考勤管理', '/attendance', NULL, NULL, 'Clock', 'M', 11, 1),
('f2c1a9b0-0005-4a2c-8d2a-000000000005', 'f2c1a9b0-0004-4a2c-8d2a-000000000004', '签到', '/attendance/sign', 'attendance/sign', NULL, 'Clock', 'C', 1, 1),
('f2c1a9b0-0006-4a2c-8d2a-000000000006', 'f2c1a9b0-0004-4a2c-8d2a-000000000004', '签到管理', '/attendance/manage', 'attendance/manage', NULL, 'List', 'C', 2, 1);
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT r.id, m.id FROM `sys_role` r, `sys_menu` m
WHERE m.id IN ('f2c1a9b0-0001-4a2c-8d2a-000000000001','f2c1a9b0-0004-4a2c-8d2a-000000000004','f2c1a9b0-0005-4a2c-8d2a-000000000005','f2c1a9b0-0006-4a2c-8d2a-000000000006','f2c1a9b0-0007-4a2c-8d2a-000000000007','f2c1a9b0-0008-4a2c-8d2a-000000000008')
AND NOT EXISTS (SELECT 1 FROM `sys_role_menu` x WHERE x.role_id = r.id AND x.menu_id = m.id);


-- ==================== 多平台发布中心（参照 CSDN 多平台发布中心） ====================
CREATE TABLE IF NOT EXISTS `crm_content_sync` (
  `id` varchar(36) NOT NULL COMMENT '主键UUID',
  `content_id` varchar(36) NOT NULL COMMENT '图文ID',
  `content_title` varchar(255) DEFAULT NULL COMMENT '图文标题快照',
  `platform_code` varchar(50) NOT NULL COMMENT '平台编码',
  `platform_name` varchar(50) DEFAULT NULL COMMENT '平台名称',
  `status` tinyint DEFAULT 0 COMMENT '0待同步 1同步中 2成功 3失败',
  `adapt_title` varchar(255) DEFAULT NULL COMMENT '适配后标题',
  `result_url` varchar(500) DEFAULT NULL COMMENT '发布后文章链接',
  `result_msg` text DEFAULT NULL COMMENT '结果信息/失败原因/插件适配日志',
  `sync_time` datetime DEFAULT NULL COMMENT '同步完成时间',
  `create_by` varchar(36) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `deleted` tinyint DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_ccs_content_id` (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='图文多平台同步记录表';



INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT r.id, m.id FROM `sys_role` r, `sys_menu` m
WHERE m.`perms` = 'content:sync'
AND NOT EXISTS (SELECT 1 FROM `sys_role_menu` x WHERE x.role_id = r.id AND x.menu_id = m.id);

-- 已有库升级：任务/日程提醒（渠道 / 次数 / 间隔）+ 站内信已读 + 邮件 SMTP 配置（幂等）
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task' AND COLUMN_NAME = 'remind_channel');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_task` ADD COLUMN `remind_channel` VARCHAR(50)  DEFAULT NULL COMMENT ''提醒渠道: site-站内信 email-邮件 sms-短信(多个用逗号分隔)'' AFTER `remind_time`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task' AND COLUMN_NAME = 'remind_count');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_task` ADD COLUMN `remind_count` INT NOT NULL DEFAULT 1 COMMENT ''提醒次数'' AFTER `remind_channel`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task' AND COLUMN_NAME = 'remind_interval');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_task` ADD COLUMN `remind_interval` INT NOT NULL DEFAULT 30 COMMENT ''多次提醒时的间隔(分钟)'' AFTER `remind_count`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task' AND COLUMN_NAME = 'reminded_count');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_task` ADD COLUMN `reminded_count` INT NOT NULL DEFAULT 0 COMMENT ''已提醒次数'' AFTER `remind_interval`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_schedule');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_schedule' AND COLUMN_NAME = 'remind_channel');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_schedule` ADD COLUMN `remind_channel` VARCHAR(50)  DEFAULT NULL COMMENT ''提醒渠道: site-站内信 email-邮件 sms-短信(多个用逗号分隔)'' AFTER `remind_time`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_schedule');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_schedule' AND COLUMN_NAME = 'remind_count');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_schedule` ADD COLUMN `remind_count` INT NOT NULL DEFAULT 1 COMMENT ''提醒次数'' AFTER `remind_channel`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_schedule');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_schedule' AND COLUMN_NAME = 'remind_interval');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_schedule` ADD COLUMN `remind_interval` INT NOT NULL DEFAULT 30 COMMENT ''多次提醒时的间隔(分钟)'' AFTER `remind_count`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_schedule');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_schedule' AND COLUMN_NAME = 'reminded_count');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_schedule` ADD COLUMN `reminded_count` INT NOT NULL DEFAULT 0 COMMENT ''已提醒次数'' AFTER `remind_interval`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_message');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_message' AND COLUMN_NAME = 'user_id');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_message` ADD COLUMN `user_id` VARCHAR(36)  DEFAULT NULL COMMENT ''站内信接收用户ID（用于我的消息收件箱）'' AFTER `receiver_name`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_message');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_message' AND COLUMN_NAME = 'is_read');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `crm_message` ADD COLUMN `is_read` TINYINT(1) NOT NULL DEFAULT 0 COMMENT ''站内信是否已读 0-未读 1-已读'' AFTER `user_id`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'mail_enabled');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `sys_setting` ADD COLUMN `mail_enabled` TINYINT NOT NULL DEFAULT 0 COMMENT ''邮件提醒开关 0-关闭(模拟发送) 1-开启'' AFTER `attendance_work_time`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'mail_host');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `sys_setting` ADD COLUMN `mail_host` VARCHAR(100) DEFAULT NULL COMMENT ''SMTP 服务器地址'' AFTER `mail_enabled`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'mail_port');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `sys_setting` ADD COLUMN `mail_port` INT DEFAULT 465 COMMENT ''SMTP 端口'' AFTER `mail_host`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'mail_ssl');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `sys_setting` ADD COLUMN `mail_ssl` TINYINT NOT NULL DEFAULT 1 COMMENT ''是否启用 SSL 0-否 1-是'' AFTER `mail_port`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'mail_username');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `sys_setting` ADD COLUMN `mail_username` VARCHAR(100) DEFAULT NULL COMMENT ''SMTP 账号（发件邮箱）'' AFTER `mail_ssl`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'mail_password');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `sys_setting` ADD COLUMN `mail_password` VARCHAR(255) DEFAULT NULL COMMENT ''SMTP 密码/授权码'' AFTER `mail_username`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'mail_from');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `sys_setting` ADD COLUMN `mail_from` VARCHAR(100) DEFAULT NULL COMMENT ''发件人显示名称'' AFTER `mail_password`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：为 sys_setting 补充「首次部署跳过演示数据导入」标记列（幂等）
SET @tbl_exist := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting');
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'demo_data_skipped');
SET @ddl := IF(@tbl_exist = 0 OR @col_exist > 0, 'SELECT 1', 'ALTER TABLE `sys_setting` ADD COLUMN `demo_data_skipped` TINYINT NOT NULL DEFAULT 0 COMMENT ''首次部署时是否已跳过演示数据导入提示 0-未跳过 1-已跳过'' AFTER `demo_data_editable`');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：新增侧边栏「我的消息」菜单（站内信收件箱，任务/日程提醒入口），挂在「消息管理」下，并授权给所有角色（幂等）
INSERT IGNORE INTO `sys_menu` (`id`, `parent_id`, `menu_name`, `path`, `component`, `perms`, `icon`, `menu_type`, `sort`, `visible`) VALUES
('f2c1a9b0-000a-4a2c-8d2a-00000000000a', 'f2c1a9b0-0009-4a2c-8d2a-000000000009', '我的消息', '/message/my', 'message/my', NULL, 'Bell', 'C', 3, 1);
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT r.id, m.id FROM `sys_role` r, `sys_menu` m
WHERE m.id = 'f2c1a9b0-000a-4a2c-8d2a-00000000000a'
AND NOT EXISTS (SELECT 1 FROM `sys_role_menu` x WHERE x.role_id = r.id AND x.menu_id = m.id);

-- 已有库升级：将此前已建为顶级菜单的「我的消息」迁移到「消息管理」下（幂等）
UPDATE `sys_menu` SET `parent_id` = 'f2c1a9b0-0009-4a2c-8d2a-000000000009', `sort` = 3
WHERE `id` = 'f2c1a9b0-000a-4a2c-8d2a-00000000000a';

-- 已有库升级：将「消息管理」父菜单授权给所有角色，确保非管理员也能看到其下的「我的消息」收件箱
-- （消息通知/消息模板仍仅授权给超级管理员，详见上方升级块，此处不改动二者）
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT r.id, 'f2c1a9b0-0009-4a2c-8d2a-000000000009' FROM `sys_role` r
WHERE NOT EXISTS (SELECT 1 FROM `sys_role_menu` x WHERE x.role_id = r.id AND x.menu_id = 'f2c1a9b0-0009-4a2c-8d2a-000000000009');

-- ==================== AI-GEO 智能中心（生成式引擎优化） ====================

-- 巡检工作日志
CREATE TABLE IF NOT EXISTS `geo_work_log` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键',
  `run_type` VARCHAR(20) NOT NULL DEFAULT 'manual' COMMENT '触发方式: auto-自动 manual-手动',
  `status` VARCHAR(20) NOT NULL DEFAULT 'running' COMMENT '状态: running/done/failed',
  `engine_count` INT DEFAULT 0 COMMENT '巡检引擎数',
  `keyword_count` INT DEFAULT 0 COMMENT '巡检关键词数',
  `probe_count` INT DEFAULT 0 COMMENT '探测记录数',
  `brand_mentions` INT DEFAULT 0 COMMENT '品牌被提及次数',
  `summary` VARCHAR(500) DEFAULT NULL COMMENT '巡检摘要',
  `report` TEXT COMMENT 'AI 优化建议报告',
  `error_msg` VARCHAR(500) DEFAULT NULL COMMENT '失败原因',
  `create_time` DATETIME DEFAULT NULL COMMENT '创建时间',
  `update_time` DATETIME DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='GEO 巡检工作日志';

-- 引擎探测记录
CREATE TABLE IF NOT EXISTS `geo_probe` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键',
  `log_id` VARCHAR(36) DEFAULT NULL COMMENT '关联 geo_work_log.id',
  `engine` VARCHAR(50) NOT NULL COMMENT 'AI 引擎名称',
  `keyword` VARCHAR(200) NOT NULL COMMENT '监控关键词',
  `mentioned` TINYINT NOT NULL DEFAULT 0 COMMENT '品牌是否被提及 0-否 1-是',
  `rank_pos` INT DEFAULT NULL COMMENT '品牌首次提及位置',
  `sentiment` VARCHAR(10) DEFAULT 'neu' COMMENT '情感倾向: pos/neu/neg',
  `competitors` VARCHAR(500) DEFAULT NULL COMMENT '被提及的竞品（逗号分隔）',
  `citations` VARCHAR(1000) DEFAULT NULL COMMENT '引用链接（逗号分隔）',
  `answer_summary` VARCHAR(1000) DEFAULT NULL COMMENT 'AI 回答摘要',
  `create_time` DATETIME DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_log` (`log_id`),
  KEY `idx_engine` (`engine`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='GEO 引擎探测记录';

-- 监控关键词（话题簇）
CREATE TABLE IF NOT EXISTS `geo_keyword` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键',
  `keyword` VARCHAR(200) NOT NULL COMMENT '关键词',
  `enabled` TINYINT NOT NULL DEFAULT 1 COMMENT '是否启用 1-是 0-否',
  `remark` VARCHAR(300) DEFAULT NULL COMMENT '备注',
  `deleted` TINYINT NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` DATETIME DEFAULT NULL COMMENT '创建时间',
  `update_time` DATETIME DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='GEO 监控关键词';

-- 行动清单
CREATE TABLE IF NOT EXISTS `geo_action` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键',
  `title` VARCHAR(300) NOT NULL COMMENT '行动标题',
  `priority` VARCHAR(10) NOT NULL DEFAULT 'mid' COMMENT '优先级: high/mid/low',
  `status` VARCHAR(20) NOT NULL DEFAULT 'pending' COMMENT '状态: pending/doing/done',
  `source` VARCHAR(20) NOT NULL DEFAULT 'manual' COMMENT '来源: auto-巡检生成 manual-人工',
  `remark` VARCHAR(500) DEFAULT NULL COMMENT '备注',
  `deleted` TINYINT NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` DATETIME DEFAULT NULL COMMENT '创建时间',
  `update_time` DATETIME DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='GEO 行动清单';

-- 品牌事实库
CREATE TABLE IF NOT EXISTS `geo_brand_fact` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键',
  `fact_key` VARCHAR(200) NOT NULL COMMENT '事实条目',
  `fact_value` VARCHAR(1000) DEFAULT NULL COMMENT '标准答案',
  `source` VARCHAR(300) DEFAULT NULL COMMENT '信息来源',
  `deleted` TINYINT NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` DATETIME DEFAULT NULL COMMENT '创建时间',
  `update_time` DATETIME DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='GEO 品牌事实库';

-- 网站审计结果
CREATE TABLE IF NOT EXISTS `geo_site_audit` (
  `id` VARCHAR(36) NOT NULL COMMENT '主键',
  `website` VARCHAR(255) NOT NULL COMMENT '审计的官网地址',
  `robots_ok` TINYINT DEFAULT 0 COMMENT 'robots.txt 是否存在 0/1',
  `llms_txt_ok` TINYINT DEFAULT 0 COMMENT 'llms.txt 是否存在 0/1',
  `meta_ok` TINYINT DEFAULT 0 COMMENT '首页 title/meta 是否完善 0/1',
  `score` INT DEFAULT 0 COMMENT '综合得分 0-100',
  `issues` TEXT COMMENT '问题清单（JSON 数组）',
  `create_time` DATETIME DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='GEO 网站审计结果';

-- sys_setting 幂等加列：GEO 配置
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'geo_brand_name');
SET @ddl := IF(@col_exist = 0, 'ALTER TABLE `sys_setting` ADD COLUMN `geo_brand_name` VARCHAR(100) DEFAULT NULL COMMENT ''GEO:品牌名称''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;

SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'geo_website');
SET @ddl := IF(@col_exist = 0, 'ALTER TABLE `sys_setting` ADD COLUMN `geo_website` VARCHAR(255) DEFAULT NULL COMMENT ''GEO:官网地址''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;

SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'geo_competitors');
SET @ddl := IF(@col_exist = 0, 'ALTER TABLE `sys_setting` ADD COLUMN `geo_competitors` VARCHAR(500) DEFAULT NULL COMMENT ''GEO:竞品列表''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;

SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'geo_engines');
SET @ddl := IF(@col_exist = 0, 'ALTER TABLE `sys_setting` ADD COLUMN `geo_engines` VARCHAR(255) DEFAULT NULL COMMENT ''GEO:模拟探测的AI引擎''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;

SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'geo_auto_enabled');
SET @ddl := IF(@col_exist = 0, 'ALTER TABLE `sys_setting` ADD COLUMN `geo_auto_enabled` TINYINT NOT NULL DEFAULT 0 COMMENT ''GEO:自动巡检开关''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;

SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_setting' AND COLUMN_NAME = 'geo_patrol_keywords');
SET @ddl := IF(@col_exist = 0, 'ALTER TABLE `sys_setting` ADD COLUMN `geo_patrol_keywords` INT NOT NULL DEFAULT 5 COMMENT ''GEO:每轮巡检关键词数上限''', 'SELECT 1');
PREPARE ddl_stmt FROM @ddl; EXECUTE ddl_stmt; DEALLOCATE PREPARE ddl_stmt;

-- 菜单：顶级目录「GEO 智能中心」+ 页面 + 按钮权限（幂等）
INSERT IGNORE INTO `sys_menu` (`id`, `parent_id`, `menu_name`, `path`, `component`, `perms`, `icon`, `menu_type`, `sort`, `visible`) VALUES
('f3c0a9b0-1101-4a2c-8d2a-000000000001', '0', 'GEO 智能中心', '/geo', NULL, NULL, 'DataAnalysis', 'M', 8, 0),
('f3c0a9b0-1102-4a2c-8d2a-000000000002', 'f3c0a9b0-1101-4a2c-8d2a-000000000001', '智能中心', '/geo/index', 'geo/index', 'geo:view', 'Odometer', 'C', 1, 0),
('f3c0a9b0-1103-4a2c-8d2a-000000000003', 'f3c0a9b0-1102-4a2c-8d2a-000000000002', '手动巡检', NULL, NULL, 'geo:patrol', NULL, 'F', 1, 1),
('f3c0a9b0-1104-4a2c-8d2a-000000000004', 'f3c0a9b0-1102-4a2c-8d2a-000000000002', 'GEO 配置管理', NULL, NULL, 'geo:edit', NULL, 'F', 2, 1);

-- GEO 菜单授权给所有角色（幂等）
INSERT IGNORE INTO `sys_role_menu` (`role_id`, `menu_id`)
SELECT r.id, m.id FROM `sys_role` r, `sys_menu` m
WHERE m.`id` IN ('f3c0a9b0-1101-4a2c-8d2a-000000000001','f3c0a9b0-1102-4a2c-8d2a-000000000002','f3c0a9b0-1103-4a2c-8d2a-000000000003','f3c0a9b0-1104-4a2c-8d2a-000000000004')
AND NOT EXISTS (SELECT 1 FROM `sys_role_menu` x WHERE x.role_id = r.id AND x.menu_id = m.id);

-- 已有库升级：为任务/日程/营销活动补充「发送方式」列（幂等）
-- remind_mode: scheduled-定时发送（按提醒时间调度） immediate-立即发送（保存后立即发一次，不参与调度）
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_task' AND COLUMN_NAME = 'remind_mode');
SET @ddl := IF(@col_exist = 0,
  'ALTER TABLE `crm_task` ADD COLUMN `remind_mode` VARCHAR(20) DEFAULT NULL COMMENT ''发送方式 scheduled-定时 immediate-立即'' AFTER `remind_channel`',
  'SELECT 1');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_schedule' AND COLUMN_NAME = 'remind_mode');
SET @ddl := IF(@col_exist = 0,
  'ALTER TABLE `crm_schedule` ADD COLUMN `remind_mode` VARCHAR(20) DEFAULT NULL COMMENT ''发送方式 scheduled-定时 immediate-立即'' AFTER `remind_channel`',
  'SELECT 1');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'crm_marketing_activity' AND COLUMN_NAME = 'remind_mode');
SET @ddl := IF(@col_exist = 0,
  'ALTER TABLE `crm_marketing_activity` ADD COLUMN `remind_mode` VARCHAR(20) DEFAULT NULL COMMENT ''发送方式 scheduled-定时 immediate-立即'' AFTER `remind_channel`',
  'SELECT 1');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;

-- 已有库升级：sys_user 增加 intro_seen（系统使用须知已读标记，服务端保存，幂等）
SET @col_exist := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_user' AND COLUMN_NAME = 'intro_seen');
SET @ddl := IF(@col_exist = 0,
  'ALTER TABLE `sys_user` ADD COLUMN `intro_seen` TINYINT NOT NULL DEFAULT 0 COMMENT ''系统使用须知引导是否已读 0-未读 1-已读（服务端保存）''',
  'SELECT 1');
PREPARE ddl_stmt FROM @ddl;
EXECUTE ddl_stmt;
DEALLOCATE PREPARE ddl_stmt;
