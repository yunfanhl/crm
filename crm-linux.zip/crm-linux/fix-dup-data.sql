-- ==========================================================
-- 修复 CRM 库中重复播种产生的冗余数据（全表通用）
-- 根因: init.sql / init-with-demo.sql 对目标表执行 INSERT IGNORE 播种,
--       但部分表没有唯一约束, IGNORE 只忽略主键冲突, 导致每次重启/重跑
--       都会把种子数据重复插入一份(字典曾达 22 倍、演示客户 8 倍等)。
-- 修复: 1) 关联重定向: 引用"将被删除重复客户"的联系人/机会/跟进/合同/任务
--          改挂到保留客户(同客户编号最早 id), 避免产生孤儿;
--        2) 内容级去重: 各业务表按唯一内容组合删除冗余, 保留每组最早一条;
--        3) sys_dict_data 补唯一索引, 保证后续 init.sql 重启幂等。
-- 用法: mysql -uroot -p<密码> <库名> < fix-dup-data.sql
-- 幂等: 可重复执行; 已干净/新库执行无副作用。
-- ==========================================================

USE `crm_db`;

-- ---------- 1) 引用重定向(重复客户组的非最早 id 行将被删除, 子业务先改挂) ----------
UPDATE `crm_contact` c JOIN (
  SELECT d.id AS del_id, m.keep_id FROM `crm_customer` d
  JOIN (SELECT customer_code, MIN(id) AS keep_id FROM `crm_customer` GROUP BY customer_code) m ON d.customer_code = m.customer_code
  JOIN (SELECT customer_code FROM `crm_customer` GROUP BY customer_code HAVING COUNT(*) > 1) dd ON dd.customer_code = d.customer_code
  WHERE d.id <> m.keep_id) t ON c.customer_id = t.del_id
SET c.customer_id = t.keep_id;
UPDATE `crm_opportunity` o JOIN (
  SELECT d.id AS del_id, m.keep_id FROM `crm_customer` d
  JOIN (SELECT customer_code, MIN(id) AS keep_id FROM `crm_customer` GROUP BY customer_code) m ON d.customer_code = m.customer_code
  JOIN (SELECT customer_code FROM `crm_customer` GROUP BY customer_code HAVING COUNT(*) > 1) dd ON dd.customer_code = d.customer_code
  WHERE d.id <> m.keep_id) t ON o.customer_id = t.del_id
SET o.customer_id = t.keep_id;
UPDATE `crm_follow_up` f JOIN (
  SELECT d.id AS del_id, m.keep_id FROM `crm_customer` d
  JOIN (SELECT customer_code, MIN(id) AS keep_id FROM `crm_customer` GROUP BY customer_code) m ON d.customer_code = m.customer_code
  JOIN (SELECT customer_code FROM `crm_customer` GROUP BY customer_code HAVING COUNT(*) > 1) dd ON dd.customer_code = d.customer_code
  WHERE d.id <> m.keep_id) t ON f.customer_id = t.del_id
SET f.customer_id = t.keep_id;
UPDATE `crm_contract` c JOIN (
  SELECT d.id AS del_id, m.keep_id FROM `crm_customer` d
  JOIN (SELECT customer_code, MIN(id) AS keep_id FROM `crm_customer` GROUP BY customer_code) m ON d.customer_code = m.customer_code
  JOIN (SELECT customer_code FROM `crm_customer` GROUP BY customer_code HAVING COUNT(*) > 1) dd ON dd.customer_code = d.customer_code
  WHERE d.id <> m.keep_id) t ON c.customer_id = t.del_id
SET c.customer_id = t.keep_id;
UPDATE `crm_task` k JOIN (
  SELECT d.id AS del_id, m.keep_id FROM `crm_customer` d
  JOIN (SELECT customer_code, MIN(id) AS keep_id FROM `crm_customer` GROUP BY customer_code) m ON d.customer_code = m.customer_code
  JOIN (SELECT customer_code FROM `crm_customer` GROUP BY customer_code HAVING COUNT(*) > 1) dd ON dd.customer_code = d.customer_code
  WHERE d.id <> m.keep_id) t ON k.customer_id = t.del_id
SET k.customer_id = t.keep_id;

-- ---------- 2) 内容级去重(保留每组最早一条) ----------
DELETE c FROM `crm_customer` c JOIN (
  SELECT customer_code, MIN(id) AS keep_id FROM `crm_customer` GROUP BY customer_code HAVING COUNT(*) > 1) d
  ON c.customer_code = d.customer_code AND c.id <> d.keep_id;
DELETE c FROM `crm_contact` c JOIN (
  SELECT customer_id, contact_name, phone, MIN(id) AS keep_id FROM `crm_contact`
  GROUP BY customer_id, contact_name, phone HAVING COUNT(*) > 1) d
  ON c.customer_id = d.customer_id AND c.contact_name = d.contact_name AND c.phone <=> d.phone AND c.id <> d.keep_id;
DELETE o FROM `crm_opportunity` o JOIN (
  SELECT customer_id, contact_id, estimated_amount, MIN(id) AS keep_id FROM `crm_opportunity`
  GROUP BY customer_id, contact_id, estimated_amount HAVING COUNT(*) > 1) d
  ON o.customer_id = d.customer_id AND o.contact_id <=> d.contact_id AND o.estimated_amount = d.estimated_amount AND o.id <> d.keep_id;
DELETE f FROM `crm_follow_up` f JOIN (
  SELECT customer_id, follow_user, content, MIN(id) AS keep_id FROM `crm_follow_up`
  GROUP BY customer_id, follow_user, content HAVING COUNT(*) > 1) d
  ON f.customer_id = d.customer_id AND f.follow_user <=> d.follow_user AND f.content = d.content AND f.id <> d.keep_id;
DELETE t FROM `crm_contract` t JOIN (
  SELECT contract_no, MIN(id) AS keep_id FROM `crm_contract` GROUP BY contract_no HAVING COUNT(*) > 1) d
  ON t.contract_no = d.contract_no AND t.id <> d.keep_id;
DELETE k FROM `crm_task` k JOIN (
  SELECT task_title, owner_id, remind_time, MIN(id) AS keep_id FROM `crm_task`
  GROUP BY task_title, owner_id, remind_time HAVING COUNT(*) > 1) d
  ON k.task_title = d.task_title AND k.owner_id = d.owner_id AND k.remind_time <=> d.remind_time AND k.id <> d.keep_id;
DELETE n FROM `crm_notice` n JOIN (
  SELECT title, content, MIN(id) AS keep_id FROM `crm_notice` GROUP BY title, content HAVING COUNT(*) > 1) d
  ON n.title = d.title AND n.content = d.content AND n.id <> d.keep_id;
DELETE t FROM `crm_contract_template` t JOIN (
  SELECT name, category, MIN(id) AS keep_id FROM `crm_contract_template` GROUP BY name, category HAVING COUNT(*) > 1) d
  ON t.name = d.name AND t.category = d.category AND t.id <> d.keep_id;
DELETE s FROM `crm_contract_sign` s JOIN (
  SELECT contract_id, signer_name, signer_phone, MIN(id) AS keep_id FROM `crm_contract_sign`
  GROUP BY contract_id, signer_name, signer_phone HAVING COUNT(*) > 1) d
  ON s.contract_id = d.contract_id AND s.signer_name = d.signer_name AND s.signer_phone <=> d.signer_phone AND s.id <> d.keep_id;
DELETE a FROM `crm_marketing_activity` a JOIN (
  SELECT activity_name, activity_type, owner_id, MIN(id) AS keep_id FROM `crm_marketing_activity`
  GROUP BY activity_name, activity_type, owner_id HAVING COUNT(*) > 1) d
  ON a.activity_name = d.activity_name AND a.activity_type = d.activity_type AND a.owner_id <=> d.owner_id AND a.id <> d.keep_id;
DELETE cc FROM `crm_content` cc JOIN (
  SELECT title, platform, MIN(id) AS keep_id FROM `crm_content` GROUP BY title, platform HAVING COUNT(*) > 1) d
  ON cc.title = d.title AND cc.platform <=> d.platform AND cc.id <> d.keep_id;
DELETE q FROM `knowledge_qa` q JOIN (
  SELECT question, answer, MIN(id) AS keep_id FROM `knowledge_qa` GROUP BY question, answer HAVING COUNT(*) > 1) d
  ON q.question = d.question AND q.answer = d.answer AND q.id <> d.keep_id;
DELETE fb FROM `feedback` fb JOIN (
  SELECT content, username, MIN(id) AS keep_id FROM `feedback` GROUP BY content, username HAVING COUNT(*) > 1) d
  ON fb.content = d.content AND fb.username <=> d.username AND fb.id <> d.keep_id;
DELETE dd FROM `sys_dict_data` dd JOIN (
  SELECT dict_type, dict_label, dict_value, MIN(id) AS keep_id FROM `sys_dict_data`
  GROUP BY dict_type, dict_label, dict_value HAVING COUNT(*) > 1) d
  ON dd.dict_type = d.dict_type AND dd.dict_label = d.dict_label AND dd.dict_value = d.dict_value AND dd.id <> d.keep_id;

-- ---------- 3) sys_dict_data 补唯一索引(缺失才加), 保证重启幂等 ----------
SET @has_idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sys_dict_data' AND INDEX_NAME = 'uk_dict_type_label_value');
SET @ddl := IF(@has_idx = 0,
  'ALTER TABLE `sys_dict_data` ADD UNIQUE KEY `uk_dict_type_label_value` (`dict_type`, `dict_label`, `dict_value`)',
  'SELECT 1');
PREPARE s FROM @ddl;
EXECUTE s;
DEALLOCATE PREPARE s;

-- ---------- 4) 核对: 应无重复组 ----------
SELECT 'crm_customer' tbl, COUNT(*) total, COUNT(DISTINCT customer_code) uniq FROM `crm_customer`
UNION ALL SELECT 'crm_contact', COUNT(*), COUNT(DISTINCT CONCAT(customer_id, '|', contact_name, '|', phone)) FROM `crm_contact`
UNION ALL SELECT 'crm_opportunity', COUNT(*), COUNT(DISTINCT CONCAT(customer_id, '|', contact_id, '|', estimated_amount)) FROM `crm_opportunity`
UNION ALL SELECT 'crm_follow_up', COUNT(*), COUNT(DISTINCT CONCAT(customer_id, '|', follow_user, '|', content)) FROM `crm_follow_up`
UNION ALL SELECT 'crm_contract', COUNT(*), COUNT(DISTINCT contract_no) FROM `crm_contract`
UNION ALL SELECT 'crm_task', COUNT(*), COUNT(DISTINCT CONCAT(task_title, '|', owner_id, '|', remind_time)) FROM `crm_task`
UNION ALL SELECT 'crm_notice', COUNT(*), COUNT(DISTINCT CONCAT(title, '|', content)) FROM `crm_notice`
UNION ALL SELECT 'crm_contract_template', COUNT(*), COUNT(DISTINCT CONCAT(name, '|', category)) FROM `crm_contract_template`
UNION ALL SELECT 'crm_contract_sign', COUNT(*), COUNT(DISTINCT CONCAT(contract_id, '|', signer_name, '|', signer_phone)) FROM `crm_contract_sign`
UNION ALL SELECT 'crm_marketing_activity', COUNT(*), COUNT(DISTINCT CONCAT(activity_name, '|', activity_type, '|', owner_id)) FROM `crm_marketing_activity`
UNION ALL SELECT 'crm_content', COUNT(*), COUNT(DISTINCT CONCAT(title, '|', platform)) FROM `crm_content`
UNION ALL SELECT 'knowledge_qa', COUNT(*), COUNT(DISTINCT CONCAT(question, '|', answer)) FROM `knowledge_qa`
UNION ALL SELECT 'feedback', COUNT(*), COUNT(DISTINCT CONCAT(content, '|', username)) FROM `feedback`
UNION ALL SELECT 'sys_dict_data', COUNT(*), COUNT(DISTINCT CONCAT(dict_type, '|', dict_label, '|', dict_value)) FROM `sys_dict_data`;
