# 云帆智能客户管理系统 - Linux 部署说明

## 1. 环境要求

| 组件 | 版本 | 说明 |
|------|------|------|
| JDK | 17+ | 运行后端 jar（内嵌前端静态资源与 Tomcat）；系统装了多个 JDK 时请正确配置 `JAVA_HOME` |
| MySQL | 8.0+ | 业务数据库 `crm_db`（首次启动自动建库建表，无需手动导入 SQL） |
| Redis | 6.0+ | 验证码 / 会话缓存 |
| Nginx | 可选 | 80 端口反代 / HTTPS（不装也可直接用 8080 端口访问） |

## 2. 目录结构

```
crm-system-<版本>/
├── crm-system.jar        # 后端可执行包(内嵌前端页面、默认配置与建表 SQL)
├── application.yml             # 部署配置(数据库连接等在此修改, 修改后重启生效)
├── init.sql                    # 建库建表 SQL(自动建表已内置, 供手动初始化/审计)
├── demo-data.sql               # 可选: 演示业务数据(每个功能 15 条, 建表完成后按需导入)
├── VERSION
├── start.sh                    # 启动/停止/重启/状态/配置
├── stop.sh
├── restart.sh
├── crm.service                 # systemd 服务单元(生产推荐)
├── .env.example                # 环境变量模板(授权主密钥/JWT/Redis 等; 数据库连接见 application.yml)
├── nginx/crm-nginx.conf        # Nginx 反向代理配置示例
└── README.md                   # 本说明
```

## 3. 部署步骤

### 3.1 放置部署包

```bash
mkdir -p /opt/crm && cp -r crm-system-<版本>/* /opt/crm/
```

> `start.sh` 首次启动会自动生成 `.env`（含随机授权主密钥与配套密文），无需手动编辑。

### 3.2 启动

```bash
cd /opt/crm
bash start.sh start       # 首次启动自动建库建表、生成配置并启动(日志: logs/app.log, PID: crm.pid)
bash start.sh status      # 查看状态
bash start.sh restart     # 重启
bash start.sh configure   # 仅生成/查看 .env 配置, 不启动
```

启动完成后访问: `http://<服务器IP>:8080`

> **配置优先级（高 → 低）**：
> 1. 包根 `application.yml`（Spring Boot 自动加载，修改后重启生效，推荐常规参数）
> 2. jar 内置默认值
>
> 未设置项使用内置默认值（Redis `localhost:6379` 无密码）。
>
> **修改数据库连接**：统一编辑包根 `application.yml` 的 `spring.datasource` 段——
> `password` 为数据库密码，`url` 为地址/端口/库名，`username` 为账号（默认 `localhost:3306/crm_db`、root/root），
> 保存后 `bash start.sh restart` 生效。注意与 MySQL 实际账号密码保持一致。
>
> **数据库初始化**：应用首次启动自动建库建表，无需手动导入。包根 `init.sql` 为完整建表脚本，
> 供手工初始化其他环境或审计表结构使用：`mysql -uroot -p < init.sql`
>
> **可选测试数据**：新部署默认不含业务数据。如需预置演示客户/线索/合同等测试数据，
> 待建表完成后执行（建议空库/演示环境）：
>
> ```bash
> mysql -uroot -p crm_db --default-character-set=utf8mb4 < demo-data.sql
> ```
>
> 脚本内置幂等防重，可重复执行不会翻倍；若历史库演示数据已膨胀，用 `fix-dup-data.sql` 清理。

### 3.3 使用 systemd 守护进程（生产推荐）

```bash
# 先运行一次, 自动生成 /opt/crm/.env(随机授权主密钥)
bash /opt/crm/start.sh start

useradd -r -s /sbin/nologin crm
mkdir -p /var/log/crm && chown -R crm:crm /opt/crm /var/log/crm
cp /opt/crm/crm.service /etc/systemd/system/crm.service
systemctl daemon-reload
systemctl enable --now crm
systemctl status crm
```

> 若将 jar 放在其他路径，请同步修改 `crm.service` 中的 `WorkingDirectory`、`ExecStart`、`EnvironmentFile` 路径。

## 4. Nginx 反代（可选，用于 80 端口 / HTTPS）

```bash
cp /opt/crm/nginx/crm-nginx.conf /etc/nginx/conf.d/crm.conf
# 按需修改 server_name、/uploads 目录
nginx -t && nginx -s reload
```

## 5. 登录账号

| 账号 | 密码 | 角色 |
|------|------|------|
| `admin` | `123456` | 超级管理员 |
| `sales01` | `123456` | 销售经理 |
| `sales02` | `123456` | 销售员 |

> 登录页**默认展示上述内置账号提示**（点击标签即可填充账号密码，本部署包默认开启）；如需隐藏，
> 登录后进入 系统管理 → 系统设置 → 功能开关，关闭「登录页默认账号提示」即可。

> 生产环境请登录后立即修改默认密码。

## 6. 授权激活

系统为 License 授权模式：

- 首次登录后按弹窗提示"免费试用"（14 天）或上传正式 License Key
- 授权记录管理：`admin` 登录 → 系统管理 → 授权管理（查看/生成 License）
- 机器码基于部署机器的**硬件序列号 + MAC 地址**生成，请确保部署机器硬件稳定，更换机器需重新申请授权

## 7. 常见问题

| 问题 | 处理 |
|------|------|
| 启动即退出，日志提示缺少主密钥 | 检查 `.env` 中 `CRM_LICENSE_MASTER_KEY` 是否已设置 |
| 连接数据库失败 | 检查包根 `application.yml` 的 `spring.datasource`（url/username/password）与 MySQL 授权 |
| Redis 连接失败 | 检查 `.env` 中 `REDIS_HOST/REDIS_PORT/REDIS_PASSWORD` |
| 端口被占用 | 修改 `.env` 中 `SERVER_PORT` |
| 提示“需要 JDK 17+”（本机已装 JDK 17） | 默认 `java` 指向了旧版本：在 `.env` 中加一行 `JAVA_HOME=/usr/lib/jvm/jdk-17`（路径按实际修改），或 `export JAVA_HOME=...` 后再执行；脚本也会自动扫描 `/usr/lib/jvm`、`/usr/java`、`/opt` 下的 JDK 17+ |
| 忘记日志位置 | 手动启动日志 `logs/app.log`；systemd 日志 `/var/log/crm/app.log` |

### 7.1 Redis 连接失败 / 应用启动即退

- **现象**：`bash start.sh start` 后应用很快退出，`logs/app.log` 末尾出现
  `Caused by: java.net.ConnectException: Connection refused: localhost/127.0.0.1:6379`
  （或 `io.lettuce.core.RedisConnectionException: Unable to connect to localhost/...:6379`）。
- **原因**：**Redis 未安装或未启动**。Redis 是本系统硬依赖（登录态、会话、缓存均依赖它），
  启动阶段 `WebMvcConfig` 读取系统配置时连不上 Redis 会中断 Spring 容器初始化。
- **解决**：安装并启动 Redis：
  - `sudo apt install redis-server -y && sudo systemctl enable --now redis-server`
    （验证 `redis-cli ping` → `PONG`）
  - 容器 / 编译安装：启动 `redis-server` 并确保监听 `6379`。
  - Redis 在其它机器或改了端口/密码：编辑 `.env` 的 `REDIS_HOST/REDIS_PORT/REDIS_PASSWORD` 后
    `bash start.sh restart`（或 `systemctl restart crm`）。
- **说明（2.6.1+）**：自 2.6.1 起 `RedisService` 已对 Redis 不可用做降级——`get` 失败返回 `null` 走数据库兜底、
  `set/delete` 等降级为 no-op，因此**应用可正常启动且能扛住运行期 Redis 抖动**；但登录、会话、缓存
  仍需要 Redis 真正在运行，否则登录写入被忽略、`isTokenValid` 校验失败，登录仍通不过。日志里若出现
  `Redis 不可用, 已降级处理...` 即表示已触发降级（功能会受限），请先确保 Redis 已启动。
