// 弹窗：展示连接状态与待发布任务；后端地址与密钥由后台自动获取，无需手动配置。
const STORE = chrome.storage.local;

function $(id) { return document.getElementById(id); }

function getStore(keys) {
  return new Promise((resolve) => STORE.get(keys, resolve));
}

function setTip(msg, cls) {
  const el = $('connTip');
  el.textContent = msg;
  el.className = 'tip ' + (cls || 'info');
}

function esc(s) {
  return (s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

function renderJobs(jobs, error) {
  const box = $('jobs');
  $('badge').textContent = jobs ? jobs.length : 0;
  if (error) {
    box.innerHTML = '<div class="empty">' + esc(error) + '</div>';
    return;
  }
  if (!jobs || !jobs.length) {
    box.innerHTML = '<div class="empty">暂无待发布任务</div>';
    return;
  }
  box.innerHTML = '';
  jobs.forEach((job) => {
    const div = document.createElement('div');
    div.className = 'job';
    div.innerHTML =
      '<div class="t">' + esc(job.title || '(无标题)') + '</div>' +
      '<div class="p">' + esc(job.platformName || job.platformCode) +
      (job.requireCover ? ' · 需封面' : '') + '</div>';
    const btn = document.createElement('button');
    btn.className = 'btn-primary';
    btn.textContent = '去发布';
    btn.style.cssText = 'cursor:pointer;border:none;border-radius:6px;padding:7px 12px;font-size:13px;background:#409eff;color:#fff;';
    btn.addEventListener('click', () => openPublish(job));
    div.appendChild(btn);
    box.appendChild(div);
  });
}

function openPublish(job) {
  chrome.runtime.sendMessage({ type: 'openPublish', job }, (resp) => {
    if (resp && resp.ok) window.close();
  });
}

/** 展示连接状态：后台每次轮询都会自动同步密钥 */
async function refreshStatus() {
  const { jobsError, secret } = await getStore(['jobsError', 'secret']);
  if (jobsError) {
    setTip('后端连接异常：' + jobsError, 'err');
  } else if (secret) {
    setTip('已连接后端，密钥已自动同步（无需手动配置）', 'ok');
  } else {
    setTip('后端未配置插件共享密钥（系统设置 → 平台发布凭证），当前以无密钥模式运行', 'info');
  }
}

async function refreshJobs() {
  chrome.runtime.sendMessage({ type: 'refresh' }, () => {
    setTimeout(async () => {
      const { jobs, jobsError } = await getStore(['jobs', 'jobsError']);
      renderJobs(jobs || [], jobsError || '');
      refreshStatus();
    }, 400);
  });
}

$('refresh').addEventListener('click', refreshJobs);

// 打开弹窗即触发一次后台自动配置 + 拉取
chrome.runtime.sendMessage({ type: 'ensureConfig' }, () => {
  refreshJobs();
});
