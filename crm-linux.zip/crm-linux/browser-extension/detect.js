// 注入到 CRM Web 页面（与后端同源）：向页面暴露插件安装标记，供前端检测插件是否已安装。
// 说明：Chrome/Edge 不允许网页直接安装扩展，此处仅提供「检测」能力；
// 页面检测到标记即认为插件已安装，并可读取版本号。
(function () {
  const VERSION =
    typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getManifest
      ? chrome.runtime.getManifest().version
      : '';

  function mark() {
    document.documentElement.setAttribute('data-crm-plugin', VERSION);
  }
  if (document.documentElement) {
    mark();
  } else {
    document.addEventListener('DOMContentLoaded', mark);
  }

  // 自动识别 CRM 部署地址：CRM 前端启动时会在 <html> 上标记 data-crm-app="1"，
  // 插件检测到该标记后把当前站点地址写入插件配置（backendUrl），
  // 这样插件无需手动填写后端地址即可从任意域名的 CRM 拉取发布任务。
  function bindCrmSite() {
    try {
      var origin = location.origin;
      chrome.storage.local.get(['backendUrl'], function (cfg) {
        // 已配置过后端地址则不再用「页面源」覆盖：开发环境下页面源是前端端口(:5173)，
        // 并非后端地址(:8080)，覆盖会导致插件拉取密钥失败。后端地址统一由 CRM 页面下发的
        // crm-plugin-config 事件设置（开发环境指向真实后端 8080）。
        if (cfg && cfg.backendUrl) return;
        chrome.storage.local.set({ backendUrl: origin });
      });
    } catch (e) { /* 忽略存储异常 */ }
  }
  if (document.documentElement && document.documentElement.hasAttribute('data-crm-app')) {
    bindCrmSite();
  }
  // data-crm-app 由前端 JS 在启动后才设置，需监听属性变化兜底
  if (typeof MutationObserver !== 'undefined' && document.documentElement) {
    new MutationObserver(function (muts, obs) {
      if (document.documentElement.hasAttribute('data-crm-app')) {
        obs.disconnect();
        bindCrmSite();
      }
    }).observe(document.documentElement, { attributes: true, attributeFilter: ['data-crm-app'] });
  }

  // 页面可派发 crm-plugin-ping 事件主动探测，插件以 crm-plugin-pong 应答版本号
  window.addEventListener('crm-plugin-ping', function () {
    window.dispatchEvent(new CustomEvent('crm-plugin-pong', { detail: VERSION }));
  });

  // 页面可派发 crm-plugin-poll 事件，让插件用自身保存的后端地址/密钥做一次真实拉取，
  // 用于系统内「测试连接」按钮端到端校验插件 → 后端是否连通。
  window.addEventListener('crm-plugin-poll', function () {
    chrome.storage.local.get(['backendUrl', 'secret'], function (cfg) {
      var backendUrl = (cfg && cfg.backendUrl) || 'http://localhost:8080';
      var secret = (cfg && cfg.secret) || '';
      fetch(backendUrl.replace(/\/$/, '') + '/api/plugin/sync/pending?secret=' + encodeURIComponent(secret), {
        method: 'GET'
      })
        .then(function (resp) {
          return resp.json().catch(function () { return {}; }).then(function (data) {
            return {
              ok: resp.ok && data.code === 200,
              msg: data.message || ('HTTP ' + resp.status),
              count: (data.data || []).length,
              backendUrl: backendUrl
            };
          });
        })
        .catch(function (e) {
          return { ok: false, msg: e.message, count: 0, backendUrl: backendUrl };
        })
        .then(function (detail) {
          window.dispatchEvent(new CustomEvent('crm-plugin-poll-result', { detail: detail }));
        });
    });
  });

  // 页面下发配置：CRM 页面登录后调用 /api/plugin/secret 拿到密钥，再通过 postMessage 下发，
  // 避免密钥通过无鉴权的 /api/plugin/auto-config 泄露（公网部署已默认关闭该接口）。
  window.addEventListener('message', function (e) {
    var d = e.data;
    if (!d || d.type !== 'crm-plugin-config') return;
    var cfg = { backendUrl: d.backendUrl || location.origin };
    if (typeof d.secret === 'string' && d.secret) cfg.secret = d.secret;
    chrome.storage.local.set(cfg);
  });

  // 页面派发 crm-plugin-autopublish 事件：通知插件后台开始自动发布队列（对应「开始同步」一键发布）
  window.addEventListener('crm-plugin-autopublish', function (e) {
    var detail = e.detail || {};
    var respond = function (resp) {
      window.dispatchEvent(new CustomEvent('crm-plugin-autopublish-result', { detail: resp || { started: false, msg: '无响应' } }));
    };
    try {
      chrome.runtime.sendMessage({ type: 'autoPublish', recordIds: detail.recordIds || [] }, function (resp) {
        if (chrome.runtime.lastError) {
          respond({ started: false, msg: '插件通信失败：' + chrome.runtime.lastError.message + '（插件可能刚更新，请刷新本页面后重试）' });
          return;
        }
        respond(resp);
      });
    } catch (err) {
      // 扩展重载后旧 content script 失效（Extension context invalidated）
      respond({ started: false, msg: '插件已更新但本页面仍是旧实例，请刷新页面（F5）后重试' });
    }
  });
})();
