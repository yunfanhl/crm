// 小红书 creator 页 main-world 早期补丁（document_start + MAIN world，先于页面自身脚本执行）：
// 包装 Element.prototype.attachShadow 强制 mode:'open'。小红书把发布栏/图片编辑等组件放在
// closed shadow root 里（el.shadowRoot 为 null），content script 的任何 DOM 扫描都看不见，
// 曾导致「发布」按钮永远找不到（v1.9.79-82 连续 4 版实证）。强制 open 后，deepQueryAll 等普通
// 扫描即可穿透；CDP 穿透点击降级为兜底通道。
// 只作用于 creator.xiaohongshu.com，不影响其他站点。
(function () {
  if (window.__crmShadowOpenPatched) return;
  window.__crmShadowOpenPatched = 1;
  try {
    const orig = Element.prototype.attachShadow;
    Element.prototype.attachShadow = function (init) {
      try {
        init = Object.assign({}, init || {}, { mode: 'open' });
      } catch (e) { /* ignore */ }
      return orig.call(this, init);
    };
  } catch (e) { /* ignore */ }
})();
