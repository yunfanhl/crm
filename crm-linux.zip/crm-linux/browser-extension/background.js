// 后台：定时拉取待发布任务、维护角标；自动获取密钥（免手动配置）；按指令自动/手动发布。
const STORE = chrome.storage.local;
const DEFAULT_BACKEND = 'http://localhost:8080';

function getStore(keys) {
  return new Promise((resolve) => STORE.get(keys, resolve));
}

// activeJob 供 content script 填充正文用（整键存储）
async function writeActiveJob(job) { return STORE.set({ activeJob: job }); }

// 后台是 service worker，无 DOMParser/FileReader：正文图片用 arrayBuffer → base64 内联，
// 使 https 平台页能正常显示 http://localhost 的图片（否则被混合内容策略拦截成裂图）
function bufferToBase64(buf) {
  let binary = '';
  const bytes = new Uint8Array(buf);
  const CH = 0x8000;
  for (let i = 0; i < bytes.length; i += CH) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
  }
  return btoa(binary);
}

async function inlineJobImages(job, backendUrl) {
  if (!job || !job.contentHtml || job.contentHtml.indexOf('<img') < 0) return job;
  const re = /(<img[^>]+src\s*=\s*["'])([^"']+)(["'])/gi;
  const srcs = [];
  job.contentHtml.replace(re, (m, a, src) => { srcs.push(src); return m; });
  for (const raw of Array.from(new Set(srcs.map((s) => s.trim()).filter(Boolean)))) {
    if (/^data:/i.test(raw)) continue;
    let url = raw;
    if (url.indexOf('//') === 0) url = 'https:' + url;
    else if (url.indexOf('/') === 0) url = (backendUrl || DEFAULT_BACKEND).replace(/\/$/, '') + url;
    try {
      const resp = await fetch(url, { referrerPolicy: 'no-referrer' });
      if (!resp.ok) continue;
      const buf = await resp.arrayBuffer();
      const mime = (resp.headers.get('content-type') || 'image/jpeg').split(';')[0].trim();
      const dataUrl = 'data:' + mime + ';base64,' + bufferToBase64(buf);
      job.contentHtml = job.contentHtml.split(raw).join(dataUrl);
    } catch (e) { /* 单张失败不影响其余 */ }
  }
  return job;
}

/** 自动配置：后端地址默认本机 8080，密钥每次轮询时从后端自动同步（系统设置改密钥无需动插件） */
async function getConfig() {
  const { backendUrl, secret } = await getStore(['backendUrl', 'secret']);
  const url = backendUrl || DEFAULT_BACKEND;
  try {
    const resp = await fetch(url.replace(/\/$/, '') + '/api/plugin/auto-config', { method: 'GET' });
    const data = await resp.json().catch(() => ({}));
    // 仅当后端返回非空密钥时才覆盖（auto-config 关闭时返回 secret:""，若直接覆盖
    // 会把 CRM 页面通过 postMessage 下发的有效密钥清空，导致「插件共享密钥不正确」）
    if (resp.ok && data.code === 200 && data.data && typeof data.data.secret === 'string' && data.data.secret) {
      await STORE.set({ backendUrl: url, secret: data.data.secret });
      return { backendUrl: url, secret: data.data.secret };
    }
  } catch (e) { /* 后端不可达时用已存值兜底 */ }
  return { backendUrl: url, secret: secret || '' };
}

async function fetchJobs() {
  const { backendUrl, secret } = await getConfig();
  try {
    const resp = await fetch(backendUrl.replace(/\/$/, '') + '/api/plugin/sync/pending?secret=' + encodeURIComponent(secret || ''), {
      method: 'GET'
    });
    const data = await resp.json().catch(() => ({}));
    if (resp.ok && data.code === 200) {
      const jobs = data.data || [];
      for (const j of jobs) { try { await inlineJobImages(j, backendUrl); } catch (e) { /* 内联失败不阻塞 */ } }
      await STORE.set({ jobs, jobsError: '' });
      chrome.action.setBadgeText({ text: jobs.length ? String(jobs.length) : '' });
      chrome.action.setBadgeBackgroundColor({ color: '#409eff' });
    } else {
      await STORE.set({ jobsError: data.message || ('HTTP ' + resp.status) });
      chrome.action.setBadgeText({ text: '!' });
      chrome.action.setBadgeBackgroundColor({ color: '#f56c6c' });
    }
  } catch (e) {
    await STORE.set({ jobsError: '无法连接后端：' + e.message });
    chrome.action.setBadgeText({ text: '!' });
    chrome.action.setBadgeBackgroundColor({ color: '#f56c6c' });
  }
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create('pollJobs', { periodInMinutes: 0.5 });
  fetchJobs();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'pollJobs') fetchJobs();
});

// ==================== CDP 文件选择拦截（编辑器图片上传终局方案，v1.8.0） ====================
// content script 的合成点击没有 user activation，页面弹不出文件选择框；部分编辑器图片
// 上传入口也不暴露常驻 file input（51CTO 实测）。这里用 chrome.debugger：
//   1) Page.setInterceptFileChooserDialog：页面请求打开文件框时不弹系统窗口，改为回报
//      Page.fileChooserOpened（含目标 input 的 backendNodeId）
//   2) Input.dispatchMouseEvent：发浏览器级真实点击（trusted，等效真人操作）
//   3) DOM.setFileInputFiles：把图片文件（先经 downloads 落盘拿绝对路径）直接设进该
//      input，页面 change 监听器随即正常上传 —— 即 Puppeteer elementHandle.uploadFile 机制
// 使用后必须 crmCdpDetach：解除拦截（否则用户所有文件选择都会被拦）并清理临时文件。
const cdpSessions = {};
const cdpSleep = (ms) => new Promise((r) => setTimeout(r, ms));

// 自动发布页的「离开此网站吗？」抑制脚本：经 Page.addScriptToEvaluateOnNewDocument
// 注入到该标签页的每个新文档（发布→跳转编辑页→更新→回文章页全程有效），
// 拦截 beforeunload/unload 监听注册——知乎等编辑页的「未保存更改」保护不再注册，
// 页面自行跳转时就不会弹「离开此网站吗？」挂住流程。仅在自动发布的标签页生效。
const CDP_BLOCK_UNLOAD_SRC = '(function(){try{var o=EventTarget.prototype.addEventListener;EventTarget.prototype.addEventListener=function(t,f,c){if(t==="beforeunload"||t==="unload")return;return o.call(this,t,f,c)};window.onbeforeunload=null}catch(e){}})();';

function cdpCmd(tabId, method, params) {
  return new Promise((resolve, reject) => {
    chrome.debugger.sendCommand({ tabId }, method, params || {}, (r) => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(r);
    });
  });
}

async function cdpEnsureAttached(tabId) {
  // MV3 service worker 会在长流程中途休眠重启，重启后 cdpSessions 映射丢失，
  // 但旧 debugger 会话仍挂在标签页上——此时 attach 报 already attached，
  // 若直接抛错会让后续所有 CDP 调用（标签/封面）全部失败。
  // 已映射会话先探活，不可用则清掉重来；attach 报 already attached 则复用旧会话。
  if (cdpSessions[tabId] && cdpSessions[tabId].attached) {
    try { await cdpCmd(tabId, 'Runtime.evaluate', { expression: '1' }); return; }
    catch (e) { cdpSessions[tabId] = null; }
  }
  try {
    await new Promise((resolve, reject) => {
      chrome.debugger.attach({ tabId }, '1.3', () => chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError.message)) : resolve());
    });
  } catch (e) {
    const m = String((e && e.message) || e);
    if (!/already attached/i.test(m)) throw e;
    await cdpCmd(tabId, 'Runtime.evaluate', { expression: '1' }); // 旧会话仍可用
  }
  await cdpCmd(tabId, 'Page.enable');
  await cdpCmd(tabId, 'DOM.enable');
  try { await cdpCmd(tabId, 'Network.enable'); } catch (e) { /* ignore */ }
  // 关键：启用文件选择框拦截，否则 trusted 点击后弹的是真实系统窗口，
  // Page.fileChooserOpened 永远不会回报，DOM.setFileInputFiles 无从谈起
  try { await cdpCmd(tabId, 'Page.setInterceptFileChooserDialog', { enabled: true }); } catch (e) { /* ignore */ }
  cdpSessions[tabId] = { attached: true, files: {}, dlIds: [], reqs: [] };
}

chrome.debugger.onEvent.addListener((src, method, params) => {
  // JS 对话框（beforeunload「离开此网站吗？」/confirm/prompt）无条件自动接受：
  // 编辑页的 beforeunload handler 往往在抑制脚本注入前就已注册，拦不住注册
  // 就只能拦弹窗本身，否则点「更新」后的跳转会被弹窗挂住。凡挂了调试器的
  // 标签页都是自动化流程内的页面，接受是安全默认值。
  if (method === 'Page.javascriptDialogOpening' && src.tabId) {
    chrome.debugger.sendCommand({ tabId: src.tabId }, 'Page.handleJavaScriptDialog', { accept: true }, () => void chrome.runtime.lastError);
    console.log('[CRM后台] 已自动接受页面对话框：' + ((params && params.message) || method));
    return;
  }
  if (!src.tabId || !cdpSessions[src.tabId]) return;
  if (method === 'Page.fileChooserOpened') {
    cdpSessions[src.tabId].chooser = params || {};
  } else if (method === 'Network.requestWillBeSent') {
    const url = (params && params.request && params.request.url) || '';
    if (/upload|attach|image|file|media|img/i.test(url)) cdpSessions[src.tabId].reqs.push(url.slice(0, 160));
  }
});

const cdpFileCache = {}; // fileKey -> { path, name, dlId, keep }（跨消息复用；detach 时统一清理，keep 的除外）
async function cdpDownloadToPath(dataUrl, fileKey, keep) {
  // keep（手动接管模式预下载）不走缓存复用：旧记录的文件可能已被上轮 detach 删除
  if (!keep && cdpFileCache[fileKey]) return cdpFileCache[fileKey].path;
  const dlId = await new Promise((resolve, reject) => {
    chrome.downloads.download({ url: dataUrl, filename: 'crm-tmp-' + (fileKey || 'img') + '.jpg', conflictAction: 'uniquify' }, (id) => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(id);
    });
  });
  const filePath = await new Promise((resolve, reject) => {
    const timer = setTimeout(() => { chrome.downloads.onChanged.removeListener(h); reject(new Error('临时图片下载超时')); }, 30000);
    const h = (d) => {
      if (d.id === dlId && d.state && d.state.current === 'complete') {
        clearTimeout(timer);
        chrome.downloads.onChanged.removeListener(h);
        chrome.downloads.search({ id: dlId }, (items) => {
          if (items && items[0] && items[0].filename) resolve(items[0].filename);
          else reject(new Error('下载记录未找到'));
        });
      }
    };
    chrome.downloads.onChanged.addListener(h);
  });
  cdpFileCache[fileKey] = { path: filePath, name: (filePath.split(/[\\/]/).pop() || ''), dlId, keep: !!keep };
  return filePath;
}

async function cdpClickAndSet(tabId, msg) {
  await cdpEnsureAttached(tabId);
  const s = cdpSessions[tabId];
  s.chooser = null;
  s.reqs.length = 0;
  const opts = { x: msg.x, y: msg.y, button: 'left', clickCount: 1 };
  await cdpCmd(tabId, 'Input.dispatchMouseEvent', Object.assign({ type: 'mousePressed' }, opts));
  await cdpCmd(tabId, 'Input.dispatchMouseEvent', Object.assign({ type: 'mouseReleased' }, opts));
  const st = Date.now();
  while (Date.now() - st < 1500 && !s.chooser) await cdpSleep(120);
  if (!s.chooser || !s.chooser.backendNodeId) return { ok: false, reqs: s.reqs.slice(0, 8) };
  const filePath = await cdpDownloadToPath(msg.dataUrl, msg.fileKey);
  const backendNodeId = s.chooser.backendNodeId;
  await cdpCmd(tabId, 'DOM.setFileInputFiles', { files: [filePath], backendNodeId });
  // 关键：DOM.setFileInputFiles 只设文件不派发事件，页面上传组件（监听 input/change）不会动。
  // 经 DOM.resolveNode + Runtime.callFunctionOn 在页面上下文对 input 显式派发 input+change
  try {
    const obj = await cdpCmd(tabId, 'DOM.resolveNode', { backendNodeId });
    if (obj && obj.object && obj.object.objectId) {
      await cdpCmd(tabId, 'Runtime.callFunctionOn', {
        objectId: obj.object.objectId,
        functionDeclaration: 'function(){var el=this;["input","change"].forEach(function(t){try{el.dispatchEvent(new Event(t,{bubbles:true}))}catch(e){}});}',
        returnByValue: true
      });
    }
  } catch (e) { /* ignore */ }
  // 诊断：回报被拦截 input 的节点属性（供精确定位复用）与点击后的上传相关请求
  let nodeAttrs = '';
  try {
    const d = await cdpCmd(tabId, 'DOM.describeNode', { backendNodeId, depth: 0 });
    if (d && d.node) nodeAttrs = (d.node.nodeName + ' ' + (d.node.attributes || []).join(' ')).slice(0, 300);
  } catch (e) { /* ignore */ }
  return { ok: true, intercepted: true, nodeAttrs, reqs: s.reqs.slice(0, 8) };
}

/** 直写模式：不做点击/选择框拦截，直接把文件写入页面（含上传弹窗）里的 input[type=file]。
 *  百家号上传弹窗的 input 不一定经全局 file chooser 暴露（拦截常扑空），
 *  但元素存在即可 setFileInputFiles + 派发 input/change（页面组件会自动上传） */
async function cdpSetFileDirect(tabId, msg) {
  await cdpEnsureAttached(tabId);
  const filePath = await cdpDownloadToPath(msg.dataUrl, msg.fileKey);
  const doc = await cdpCmd(tabId, 'DOM.getDocument', { depth: -1, pierce: true });
  const root = doc && doc.root && doc.root.nodeId;
  if (!root) return { ok: false, message: 'DOM.getDocument 失败' };
  // 自己遍历整棵树（含 shadow root）：DOM.querySelectorAll 不穿透 shadow DOM，
  // 而百家号上传弹窗的输入框可能就在影子 root 里
  const inputs = [];
  const walk = (node) => {
    if (!node || typeof node !== 'object') return;
    const attrs = node.attributes || [];
    if (node.nodeName === 'INPUT') {
      let type = '', accept = '';
      for (let i = 0; i + 1 < attrs.length; i += 2) {
        if (String(attrs[i]).toLowerCase() === 'type') type = String(attrs[i + 1] || '').toLowerCase();
        if (String(attrs[i]).toLowerCase() === 'accept') accept = String(attrs[i + 1] || '');
      }
      if (type === 'file') inputs.push({ nodeId: node.nodeId, accept });
    }
    for (const c of (node.children || [])) walk(c);
    for (const s of (node.shadowRoots || [])) walk(s);
  };
  walk(root);
  const ids = inputs.map((x) => x.nodeId);
  if (!ids.length) return { ok: false, message: '页面无 input[type=file]（弹窗未挂载）' };
  // 按 accept 过滤：页面可能同时挂载视频投稿的 file input（把图片写进去会被平台
  // 以「视频格式不正确」拒绝，v1.9.55 实测）。优先 image 类，其次无 accept 限制，
  // 绝不写 video-only 的 input
  const infos = inputs;
  const isVideo = (acc) => /video|\.mp4|\.mov|\.mkv|\.avi|\.flv|\.mpeg|\.ogg|\.vob|\.webm|\.wmv|\.rmvb/i.test(acc);
  const isImage = (acc) => /image|\.(jpe?g|png|gif|webp|bmp)/i.test(acc);
  const groups = [
    infos.filter((x) => isImage(x.accept)),
    infos.filter((x) => !x.accept && !isVideo(x.accept)),
    infos.filter((x) => !isVideo(x.accept))
  ];
  let lastErr = null;
  for (const group of groups) {
    // 同组内后挂载的优先（上传弹窗的 input 通常在文档后面）
    for (const info of group.slice().reverse()) {
      try {
        await cdpCmd(tabId, 'DOM.setFileInputFiles', { files: [filePath], nodeId: info.nodeId });
        try {
          const obj = await cdpCmd(tabId, 'DOM.resolveNode', { nodeId: info.nodeId });
          if (obj && obj.object && obj.object.objectId) {
            await cdpCmd(tabId, 'Runtime.callFunctionOn', {
              objectId: obj.object.objectId,
              functionDeclaration: 'function(){var el=this;["input","change"].forEach(function(t){try{el.dispatchEvent(new Event(t,{bubbles:true}))}catch(e){}});}',
              returnByValue: true
            });
          }
        } catch (e) { /* ignore */ }
        return { ok: true, direct: true, accept: info.accept || '(无)', candidates: ids.length };
      } catch (e) { lastErr = e; }
    }
  }
  return {
    ok: false,
    message: '无可用的图片 file input（accept: '
      + infos.map((x) => x.accept || '无').join(' | ').slice(0, 200) + '）'
      + (lastErr ? '；' + lastErr.message : '')
  };
}

async function cdpDetach(tabId) {
  const s = cdpSessions[tabId];
  if (s) {
    try { await cdpCmd(tabId, 'Page.setInterceptFileChooserDialog', { enabled: false }); } catch (e) { /* ignore */ }
    try { await new Promise((r) => chrome.debugger.detach({ tabId }, () => { void chrome.runtime.lastError; r(); })); } catch (e) { /* ignore */ }
    delete cdpSessions[tabId];
  }
  // 清理临时图片（下载记录 + 磁盘文件）；keep 标记的（手动接管模式预下载，供用户在
  // 文件选择框里手动选中）只清缓存记录，不删磁盘文件
  for (const key of Object.keys(cdpFileCache)) {
    const f = cdpFileCache[key];
    if (!f.keep && f.dlId) {
      try { chrome.downloads.removeFile(f.dlId, () => void chrome.runtime.lastError); } catch (e) { /* ignore */ }
      try { chrome.downloads.remove(f.dlId, () => void chrome.runtime.lastError); } catch (e) { /* ignore */ }
    }
    delete cdpFileCache[key];
  }
}

// 断开所有调试会话（发布全部结束后调用）：撤掉浏览器顶部「已开始调试此浏览器」横幅。
// 除插件登记的 cdpSessions 外再扫一遍全部 debuggee 兜底（Service Worker 重启后
// 登记表丢失、但会话仍挂着的也一并断开；用户手开的 DevTools 会话 detach 会报错，静默忽略）
async function detachAllDebuggers() {
  for (const id of Object.keys(cdpSessions).map(Number)) {
    try { await cdpDetach(id); } catch (e) { /* ignore */ }
  }
  try {
    chrome.debugger.getTargets((targets) => {
      for (const t of targets || []) {
        if (t.attached && typeof t.tabId === 'number') {
          try { chrome.debugger.detach({ tabId: t.tabId }, () => void chrome.runtime.lastError); } catch (e) { /* ignore */ }
        }
      }
    });
  } catch (e) { /* ignore */ }
}

// ==================== 自动发布队列 ====================
// 由 CRM 页面点击「开始同步」触发：逐个打开平台创作页，填充并自动点击发布，
// 由内容脚本回报结束后继续下一个；单个任务超时则跳过继续，避免整队卡死。
const AUTO_TIMEOUT_MS = 120000;
let autoTimer = null;

async function startAutoPublish(recordIds) {
  const { backendUrl, secret } = await getConfig();
  try {
    const resp = await fetch(backendUrl.replace(/\/$/, '') + '/api/plugin/sync/pending?secret=' + encodeURIComponent(secret || ''), { method: 'GET' });
    const data = await resp.json().catch(() => ({}));
    if (!(resp.ok && data.code === 200)) return { started: false, msg: data.message || ('HTTP ' + resp.status) };
    let jobs = data.data || [];
    if (recordIds && recordIds.length) jobs = jobs.filter(j => recordIds.includes(j.recordId));
    if (!jobs.length) return { started: false, msg: '当前没有待发布任务' };
    await STORE.set({ jobs, jobsError: '', autoRun: { queue: jobs, index: 0, total: jobs.length } });
    runNextAuto();
    return { started: true, count: jobs.length };
  } catch (e) {
    return { started: false, msg: e.message };
  }
}

/** 后端查询：某同步任务是否已被用户在前端「多平台同步」页点「取消」（status=5）。
 *  失败时保守返回 false（网络抖动不该误杀正在进行的任务）。 */
async function checkCancelledBackend(recordId) {
  if (!recordId) return false;
  try {
    const { backendUrl, secret } = await getConfig();
    const url = backendUrl.replace(/\/$/, '') + '/api/plugin/sync/cancelled?secret='
      + encodeURIComponent(secret || '') + '&recordId=' + encodeURIComponent(recordId);
    const resp = await fetch(url);
    const data = await resp.json().catch(() => ({}));
    return !!(data && data.data && data.data.cancelled);
  } catch (e) {
    return false;
  }
}

async function runNextAuto() {
  const { autoRun } = await getStore(['autoRun']);
  if (!autoRun || autoRun.index >= autoRun.queue.length) {
    await STORE.remove('autoRun');
    // 队列全部结束：断开所有调试会话，撤掉「已开始调试此浏览器」横幅
    //（失败/知乎等保留未关的标签页上，横幅不清理会一直挂着）
    try { await detachAllDebuggers(); } catch (e) { /* ignore */ }
    fetchJobs();
    return;
  }
  const job = Object.assign({}, autoRun.queue[autoRun.index], { autoPublish: true });
  // 开创作页标签前先查取消：用户在队列执行途中点「取消」，这里再晚一步就是
  // 「标签页已经弹出来了」——必须拦在 chrome.tabs.create 之前，已取消的直接跳过。
  if (await checkCancelledBackend(job.recordId)) {
    console.warn('[CRM后台] 任务已取消，跳过不开创作页：' + job.recordId + '（' + (job.platformName || job.platformCode || '') + '）');
    await STORE.set({ autoRun: Object.assign({}, autoRun, { index: autoRun.index + 1 }) });
    setTimeout(runNextAuto, 300);
    return;
  }
  await STORE.set({ autoRun: Object.assign({}, autoRun, { index: autoRun.index + 1 }) });
  await writeActiveJob(job);
  chrome.action.setBadgeText({ text: (autoRun.index + 1) + '/' + autoRun.total });
  chrome.action.setBadgeBackgroundColor({ color: '#409eff' });
  chrome.tabs.create({ url: job.publishUrl || 'about:blank', active: true });
  // 超时保护：无论成功与否都继续下一个任务
  if (autoTimer) clearTimeout(autoTimer);
  autoTimer = setTimeout(runNextAuto, AUTO_TIMEOUT_MS);
}

// 51CTO 图片直传（抓包复刻页面编辑器三步上传链路）：
// ① POST /getUploadSign（upload_type=image，带 Cookie）→ data.sign；
// ② POST /getUploadConfig（upload_type/upload_sign/ext/name）→ COS POST policy 凭证
//    （key/policy/x-amz-algorithm/x-amz-credential/X-Amz-Date/x-amz-signature + 桶 url）；
// ③ 把图片以 multipart POST 到桶地址（file 必须最后一个字段），204 即成功，
//    图片地址 = url + '/' + key。全程无需文件选择框/CDP/用户手动操作。
async function cto51ApiUploadImage(dataUrl, nameHint) {
  const m = /^data:([^;,]+)(;base64)?,(.*)$/i.exec(dataUrl || '');
  if (!m) throw new Error('图片 dataUrl 无效');
  const mime = (m[1] || 'image/jpeg').toLowerCase();
  const extMap = { 'image/jpeg': 'jpg', 'image/jpg': 'jpg', 'image/png': 'png', 'image/gif': 'gif', 'image/webp': 'webp', 'image/svg+xml': 'svg' };
  const ext = extMap[mime] || 'jpg';
  const name = ((nameHint || ('crm-img-' + Date.now())).replace(/\.[a-z0-9]+$/i, '')) + '.' + ext;
  const bin = atob(m[3]);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const blob = new Blob([bytes], { type: mime });
  if (blob.size > 10485760) throw new Error('图片超过 51CTO 10M 上限');
  // ① 签名（fetch 字符串 body 默认 Content-Type 是 text/plain，服务端不解析会报「参数错误」，
  //    必须显式声明表单类型；X-Requested-With 模拟页面 XHR 请求特征）
  const formHeaders = { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest' };
  const fd1 = new URLSearchParams();
  fd1.set('upload_type', 'image');
  const r1 = await fetch('https://blog.51cto.com/getUploadSign', { method: 'POST', credentials: 'include', headers: formHeaders, body: fd1.toString() });
  const j1 = await r1.json().catch(() => null);
  if (!j1 || j1.code !== 0 || !j1.data || !j1.data.sign) throw new Error('getUploadSign 失败：' + ((j1 && j1.msg) || ('HTTP ' + r1.status)));
  // ② 上传配置（对象 key 与签名凭证）
  const fd2 = new URLSearchParams();
  fd2.set('upload_type', 'image');
  fd2.set('upload_sign', j1.data.sign);
  fd2.set('ext', mime);
  fd2.set('name', name);
  const r2 = await fetch('https://blog.51cto.com/getUploadConfig', { method: 'POST', credentials: 'include', headers: formHeaders, body: fd2.toString() });
  const j2 = await r2.json().catch(() => null);
  const d2 = j2 && j2.data;
  const f2 = d2 && (d2.fields || d2);
  if (!d2 || !d2.url || !f2 || !f2.key || !f2.policy) throw new Error('getUploadConfig 失败：' + ((j2 && j2.msg) || ('HTTP ' + r2.status)));
  // ③ COS 表单直传（按服务端返回的 fields 原样提交，file 必须最后一个字段）
  const fd3 = new FormData();
  Object.keys(f2).forEach((k) => { if (k !== 'file' && f2[k] != null) fd3.append(k, String(f2[k])); });
  if (!Object.keys(f2).some((k) => k.toLowerCase() === 'content-type')) fd3.append('content-type', mime);
  fd3.append('file', blob, name);
  const r3 = await fetch(d2.url, { method: 'POST', credentials: 'omit', body: fd3 });
  if (r3.status !== 200 && r3.status !== 204) throw new Error('COS 上传失败：HTTP ' + r3.status);
  return d2.url.replace(/\/+$/, '') + '/' + f2.key;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'autoPublish') {
    startAutoPublish(msg.recordIds || []).then((r) => sendResponse(r));
    return true;
  }
  if (msg && msg.type === 'crmCdpClickAndSet' && sender.tab && typeof sender.tab.id === 'number') {
    cdpClickAndSet(sender.tab.id, msg).then((r) => sendResponse(r)).catch((e) => sendResponse({ ok: false, message: e.message }));
    return true;
  }
  // CDP 直写 file input（不点击、不拦截选择框）
  if (msg && msg.type === 'crmCdpSetFileDirect' && sender.tab && typeof sender.tab.id === 'number') {
    cdpSetFileDirect(sender.tab.id, msg).then((r) => sendResponse(r)).catch((e) => sendResponse({ ok: false, message: e.message }));
    return true;
  }
  // CDP 可信单击（无文件）：用于标签联想等只认真实鼠标/键盘事件的组件
  if (msg && msg.type === 'crmCdpClick' && sender.tab && typeof sender.tab.id === 'number') {
    (async () => {
      try {
        await cdpEnsureAttached(sender.tab.id);
        await cdpCmd(sender.tab.id, 'Input.dispatchMouseEvent', { type: 'mousePressed', x: msg.x, y: msg.y, button: 'left', clickCount: 1 });
        await cdpSleep(60);
        await cdpCmd(sender.tab.id, 'Input.dispatchMouseEvent', { type: 'mouseReleased', x: msg.x, y: msg.y, button: 'left', clickCount: 1 });
        sendResponse({ ok: true });
      } catch (e) { sendResponse({ ok: false, message: (e && e.message) || String(e) }); }
    })();
    return true;
  }
  // CDP 穿透查找文本坐标：小红书发布按钮疑似位于 closed shadow root（el.shadowRoot 为 null，
  // content script 任何 DOM 扫描都不可见，v1.9.79 实测），只有 CDP DOM.performSearch 能穿透。
  // 返回所有命中文本的包围盒中心坐标（视口 CSS 像素，可直接喂 Input.dispatchMouseEvent）
  if (msg && msg.type === 'crmCdpFindText' && sender.tab && typeof sender.tab.id === 'number') {
    (async () => {
      try {
        await cdpEnsureAttached(sender.tab.id);
        await cdpCmd(sender.tab.id, 'DOM.enable', {});
        const q = String(msg.text || '');
        const s = await cdpCmd(sender.tab.id, 'DOM.performSearch', { query: q });
        if (!s || !s.searchId || !s.resultCount) { sendResponse({ ok: true, hits: [] }); return; }
        const cnt = Math.min(s.resultCount, 80);
        const gr = await cdpCmd(sender.tab.id, 'DOM.getSearchResults', { searchId: s.searchId, fromIndex: 0, toIndex: cnt });
        const hits = [];
        for (const nid of (gr.nodeIds || [])) {
          try {
            const bm = await cdpCmd(sender.tab.id, 'DOM.getBoxModel', { nodeId: nid });
            const c = bm && bm.model && bm.model.content;
            if (!c || c.length < 8) continue;
            const xs = [c[0], c[2], c[4], c[6]], ys = [c[1], c[3], c[5], c[7]];
            const w = Math.round(Math.max.apply(null, xs) - Math.min.apply(null, xs));
            const h = Math.round(Math.max.apply(null, ys) - Math.min.apply(null, ys));
            hits.push({ x: Math.round((Math.max.apply(null, xs) + Math.min.apply(null, xs)) / 2), y: Math.round((Math.max.apply(null, ys) + Math.min.apply(null, ys)) / 2), w, h });
          } catch (e) { /* ignore */ }
        }
        try { await cdpCmd(sender.tab.id, 'DOM.discardSearchResults', { searchId: s.searchId }); } catch (e) { /* ignore */ }
        sendResponse({ ok: true, hits });
      } catch (e) { sendResponse({ ok: false, message: (e && e.message) || String(e) }); }
    })();
    return true;
  }
  // CDP 穿透查找文本并可信点击（单次 attach 内完成）：v1.9.80 实测 find 与 click 分两条消息
  // 中途 debugger 掉线导致点击失败；且部分命中点在视口外（右侧预览区隐藏模板）点了个寂寞。
  // 这里一次完成：performSearch（穿透 closed shadow root）→ 按视口/底部区域过滤 → Input 可信点击
  if (msg && msg.type === 'crmCdpFindTextClick' && sender.tab && typeof sender.tab.id === 'number') {
    (async () => {
      const tabId = sender.tab.id;
      try {
        await cdpEnsureAttached(tabId);
        await cdpCmd(tabId, 'DOM.enable', {});
        // 视口尺寸：坐标过滤需要（CDP 坐标 = 视口 CSS 像素）
        let vw = 1280, vh = 800;
        try {
          const lm = await cdpCmd(tabId, 'Page.getLayoutMetrics', {});
          const csv = (lm && (lm.cssVisualViewport || lm.cssLayoutViewport || lm.layoutViewport)) || {};
          vw = csv.clientWidth || vw; vh = csv.clientHeight || vh;
        } catch (e) { /* ignore */ }
        const s = await cdpCmd(tabId, 'DOM.performSearch', { query: String(msg.text || '发布') });
        if (!s || !s.searchId || !s.resultCount) { sendResponse({ ok: true, hits: [], clicked: null, message: '无文本命中' }); return; }
        const cnt = Math.min(s.resultCount, 80);
        const gr = await cdpCmd(tabId, 'DOM.getSearchResults', { searchId: s.searchId, fromIndex: 0, toIndex: cnt });
        const hits = [];
        for (const nid of (gr.nodeIds || [])) {
          try {
            const bm = await cdpCmd(tabId, 'DOM.getBoxModel', { nodeId: nid });
            const c = bm && bm.model && bm.model.content;
            if (!c || c.length < 8) continue;
            const xs = [c[0], c[2], c[4], c[6]], ys = [c[1], c[3], c[5], c[7]];
            const w = Math.round(Math.max.apply(null, xs) - Math.min.apply(null, xs));
            const h = Math.round(Math.max.apply(null, ys) - Math.min.apply(null, ys));
            hits.push({ x: Math.round((Math.max.apply(null, xs) + Math.min.apply(null, xs)) / 2), y: Math.round((Math.max.apply(null, ys) + Math.min.apply(null, ys)) / 2), w, h });
          } catch (e) { /* ignore */ }
        }
        try { await cdpCmd(tabId, 'DOM.discardSearchResults', { searchId: s.searchId }); } catch (e) { /* ignore */ }
        // 底部按钮过滤：视口内、底部区域、按钮尺寸；取最靠下的
        const minY = typeof msg.minY === 'number' ? msg.minY : 250;
        const cands = hits
          .filter((h) => h.x >= 8 && h.x <= vw - 8 && h.y >= minY && h.y <= vh - 8
            && h.h >= 20 && h.h <= 100 && h.w >= 30 && h.w <= 320)
          .sort((a, b) => b.y - a.y);
        if (!cands.length) { sendResponse({ ok: true, hits, clicked: null, vw, vh, message: '命中点均不在底部按钮区域' }); return; }
        const c = cands[0];
        await cdpCmd(tabId, 'Input.dispatchMouseEvent', { type: 'mousePressed', x: c.x, y: c.y, button: 'left', clickCount: 1 });
        await cdpSleep(60);
        await cdpCmd(tabId, 'Input.dispatchMouseEvent', { type: 'mouseReleased', x: c.x, y: c.y, button: 'left', clickCount: 1 });
        sendResponse({ ok: true, clicked: c, candidates: cands.slice(0, 6), vw, vh, hits: hits.length });
      } catch (e) { sendResponse({ ok: false, message: (e && e.message) || String(e) }); }
    })();
    return true;
  }
  // CDP 可信键入（Input.insertText 触发真实 input 事件，Vue/React 组件均可感知）
  if (msg && msg.type === 'crmCdpType' && sender.tab && typeof sender.tab.id === 'number') {
    (async () => {
      try {
        await cdpEnsureAttached(sender.tab.id);
        if (msg.selectAll) {
          // macOS 全选是 Cmd(Meta=4)，Windows/Linux 是 Ctrl(2)；Mac 上 Ctrl+A 是
          // 「移到行首」而非全选 → 编辑器没被选中，Delete 删不掉任何东西 → 草稿里
          // 旧图旧文每次重新发布都累加。按平台取修饰键，并显式指定 selectAll 命令。
          const isMac = /Mac|iPhone|iPad|Macintosh/i.test((navigator && navigator.userAgent) || '');
          const mod = isMac ? 4 : 2;
          await cdpCmd(sender.tab.id, 'Input.dispatchKeyEvent', { type: 'keyDown', modifiers: mod, key: 'a', code: 'KeyA', windowsVirtualKeyCode: 65, commands: ['selectAll'] });
          await cdpCmd(sender.tab.id, 'Input.dispatchKeyEvent', { type: 'keyUp', modifiers: 0, key: 'a', code: 'KeyA', windowsVirtualKeyCode: 65 });
          await cdpCmd(sender.tab.id, 'Input.dispatchKeyEvent', { type: 'keyDown', key: 'Delete', code: 'Delete', windowsVirtualKeyCode: 46 });
          await cdpCmd(sender.tab.id, 'Input.dispatchKeyEvent', { type: 'keyUp', key: 'Delete', code: 'Delete', windowsVirtualKeyCode: 46 });
          await cdpSleep(80);
        }
        if (msg.mode === 'keys') {
          // 逐字符真实按键（byte-design Select 等组件只认完整键盘事件序列）
          const text = String(msg.text || '');
          for (const ch of text) {
            if (ch === '\n' || ch === '\r') {
              // 回车：用于确认联想高亮项
              await cdpCmd(sender.tab.id, 'Input.dispatchKeyEvent', { type: 'rawKeyDown', key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13, text: '\r' });
              await cdpCmd(sender.tab.id, 'Input.dispatchKeyEvent', { type: 'keyUp', key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13 });
            } else if (ch === '\u2196') {
              // Shift+Home：选中扩展到行首（配合 Shift+End 整行选中占位符）
              await cdpCmd(sender.tab.id, 'Input.dispatchKeyEvent', { type: 'keyDown', modifiers: 8, key: 'Home', code: 'Home', windowsVirtualKeyCode: 36 });
              await cdpCmd(sender.tab.id, 'Input.dispatchKeyEvent', { type: 'keyUp', modifiers: 0, key: 'Home', code: 'Home', windowsVirtualKeyCode: 36 });
            } else if (ch === '\u2198') {
              // Shift+End：选中扩展到行尾（占位符独占一行 → 整行选区 = token）
              await cdpCmd(sender.tab.id, 'Input.dispatchKeyEvent', { type: 'keyDown', modifiers: 8, key: 'End', code: 'End', windowsVirtualKeyCode: 35 });
              await cdpCmd(sender.tab.id, 'Input.dispatchKeyEvent', { type: 'keyUp', modifiers: 0, key: 'End', code: 'End', windowsVirtualKeyCode: 35 });
            } else if (ch === '\u2192') {
              // 右向扩选（Shift+ArrowRight）：Draft 选中占位符整段后直接粘贴图片替换
              await cdpCmd(sender.tab.id, 'Input.dispatchKeyEvent', { type: 'rawKeyDown', modifiers: 8, key: 'ArrowRight', code: 'ArrowRight' });
              await cdpCmd(sender.tab.id, 'Input.dispatchKeyEvent', { type: 'keyUp', modifiers: 0, key: 'ArrowRight', code: 'ArrowRight' });
            } else {
              await cdpCmd(sender.tab.id, 'Input.dispatchKeyEvent', { type: 'keyDown', key: ch, text: ch, unmodifiedText: ch });
              await cdpCmd(sender.tab.id, 'Input.dispatchKeyEvent', { type: 'keyUp', key: ch });
            }
            await cdpSleep(50);
          }
        } else {
          await cdpCmd(sender.tab.id, 'Input.insertText', { text: String(msg.text || '') });
        }
        sendResponse({ ok: true });
      } catch (e) { sendResponse({ ok: false, message: (e && e.message) || String(e) }); }
    })();
    return true;
  }
  if (msg && msg.type === 'crmCdpDownload') {
    (async () => {
      try {
        await cdpDownloadToPath(msg.dataUrl, msg.fileKey);
        sendResponse({ ok: true, name: cdpFileCache[msg.fileKey].name });
      } catch (e) { sendResponse({ ok: false, message: e.message }); }
    })();
    return true;
  }
  if (msg && msg.type === 'crmCto51Upload') {
    (async () => {
      try {
        const url = await cto51ApiUploadImage(msg.dataUrl, msg.name);
        sendResponse({ ok: true, url });
      } catch (e) { sendResponse({ ok: false, message: (e && e.message) || String(e) }); }
    })();
    return true;
  }
  // 手动接管模式预下载：下载后保留磁盘文件（不被后续 detach 清理），供用户在
  // 系统文件选择框里手动选中
  if (msg && msg.type === 'crmKeepDownload') {
    (async () => {
      try {
        await cdpDownloadToPath(msg.dataUrl, msg.fileKey, true);
        sendResponse({ ok: true, name: cdpFileCache[msg.fileKey].name });
      } catch (e) { sendResponse({ ok: false, message: e.message }); }
    })();
    return true;
  }
  if (msg && msg.type === 'crmCdpDetach' && sender.tab && typeof sender.tab.id === 'number') {
    cdpDetach(sender.tab.id).then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: true }));
    return true;
  }
  if (msg && msg.type === 'crmCdpBlockUnload' && sender.tab && typeof sender.tab.id === 'number') {
    (async () => {
      try {
        await cdpEnsureAttached(sender.tab.id);
        await cdpCmd(sender.tab.id, 'Page.addScriptToEvaluateOnNewDocument', { source: CDP_BLOCK_UNLOAD_SRC });
        sendResponse({ ok: true });
      } catch (e) { sendResponse({ ok: false, message: (e && e.message) || String(e) }); }
    })();
    return true;
  }
  if (msg && msg.type === 'ensureConfig') {
    getConfig().then((c) => sendResponse({ ok: true, backendUrl: c.backendUrl, hasSecret: !!c.secret }));
    return true;
  }
  if (msg && msg.type === 'checkCancel' && msg.recordId) {
    // 内容脚本轮询任务是否已被用户在前端「多平台同步」页点「取消」。
    // 经 Service Worker 代发（平台页面 fetch 会被 CORS 拦），命中后让内容脚本
    // 停手并关掉创作页标签，避免继续往已取消的记录里写内容。
    checkCancelledBackend(msg.recordId).then((cancelled) => sendResponse({ ok: true, cancelled }))
      .catch((e) => sendResponse({ ok: false, cancelled: false, message: (e && e.message) || String(e) }));
    return true;
  }
  if (msg && msg.type === 'autoDone') {
    if (autoTimer) { clearTimeout(autoTimer); autoTimer = null; }
    // 自动发布成功后由后台关闭创作页标签（页面脚本无权关闭非自己打开的窗口）。
    // 例外：知乎编辑页挂有「未保存更改」beforeunload 保护，自动关页会弹
    // 「离开此网站吗？」并挂住页面——知乎的标签页保留，由用户手动关闭
    if (msg.closeTab && sender && sender.tab && typeof sender.tab.id === 'number'
        && !/zhihu\.com/i.test(sender.tab.url || '')) {
      setTimeout(() => { try { chrome.tabs.remove(sender.tab.id); } catch (e) { /* ignore */ } }, 1500);
    }
    // 单任务收尾即断开该标签的调试会话：知乎等保留打开的标签页，顶部
    // 「已开始调试此浏览器」横幅不应挂着（后续如需 CDP，内容脚本会按需重新 attach）
    if (sender && sender.tab && typeof sender.tab.id === 'number') {
      try { cdpDetach(sender.tab.id); } catch (e) { /* ignore */ }
    }
    setTimeout(runNextAuto, 1200);
    sendResponse({ ok: true });
    return true;
  }
  if (msg && msg.type === 'openPublish') {
    // 弹窗传入的是完整任务（含正文/图片），直接写入 activeJob
    (async () => {
      const job = msg.job;
      await writeActiveJob(job);
      chrome.tabs.create({ url: job.publishUrl || 'about:blank' }, (tab) => {
        // 给一点时间写入 activeJob，已先于打开写入，这里仅兜底
        writeActiveJob(job);
        sendResponse({ ok: true, tabId: tab.id });
      });
    })();
    return true; // 异步响应
  }
  if (msg && msg.type === 'fetchImage') {
    // 后台代取图片转 data URL：https 平台页会拦截 http://localhost 的混合内容图片，转 base64 后内联可正常显示。
    // no-referrer：多数图床防盗链校验 Referer，带第三方 Referer 会被 403，空 Referer 通常放行
    (async () => {
      try {
        let url = msg.url;
        // 相对路径以 CRM 后端为基准解析
        if (url && url.startsWith('/')) {
          const cfg = await getConfig();
          url = cfg.backendUrl.replace(/\/$/, '') + url;
        }
        const resp = await fetch(url, { referrerPolicy: 'no-referrer' });
        if (!resp.ok) return sendResponse({ ok: false, message: 'HTTP ' + resp.status });
        const blob = await resp.blob();
        const dataUrl = await new Promise((res) => {
          const fr = new FileReader();
          fr.onload = () => res(fr.result);
          fr.onerror = () => res(null);
          fr.readAsDataURL(blob);
        });
        sendResponse({ ok: !!dataUrl, dataUrl });
      } catch (e) {
        sendResponse({ ok: false, message: e.message });
      }
    })();
    return true;
  }
  if (msg && msg.type === 'report') {
    // 由后台代发回传请求：内容脚本处于平台页面上下文，跨域 fetch 会被 CORS 拦截
    (async () => {
      const { backendUrl, secret } = await getConfig();
      try {
        const resp = await fetch(backendUrl.replace(/\/$/, '') + '/api/plugin/sync/report', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(Object.assign({ secret: secret }, msg.payload || {}))
        });
        const data = await resp.json().catch(() => ({}));
        sendResponse({ ok: resp.ok && data.code === 200, message: data.message || ('HTTP ' + resp.status) });
      } catch (e) {
        sendResponse({ ok: false, message: e.message });
      }
    })();
    return true;
  }
  if (msg && msg.type === 'fetchUrl') {
    // 后台代取页面源码：用于校验候选文章链接是否真实可访问（平台页存在跨域限制）
    (async () => {
      try {
        const resp = await fetch(msg.url, { referrerPolicy: 'no-referrer', redirect: 'follow' });
        const text = await resp.text().catch(() => '');
        sendResponse({ ok: resp.ok, status: resp.status, url: resp.url || msg.url, text: (text || '').slice(0, 300000) });
      } catch (e) {
        sendResponse({ ok: false, status: 0, message: e.message, text: '' });
      }
    })();
    return true;
  }
  if (msg && msg.type === 'refresh') {
    fetchJobs().then(() => sendResponse({ ok: true }));
    return true;
  }
});
