// 平台适配：用于在各平台创作页自动填充 CRM 待发布内容（标题 / 正文）。
//
// 设计要点（各平台创作页 DOM 频繁变化，因此以「鲁棒」优先）：
// 1. 候选选择器列表：按命中概率排序，逐个尝试，任一命中即可；
// 2. 轮询等待：编辑器多为异步渲染（SPA/懒加载），等待其出现再写入，而不是注入即填；
// 3. iframe 兜底：UEditor / TinyMCE 等富文本正文位于同源 iframe 中，需一并查找；
// 4. 多策略写入：优先触发框架受控的 input/change 事件，失败则退化为直接写值；
// 5. 失败回落：平台特化选择器未命中时，继续尝试通用选择器；仍失败则由悬浮栏提供手动复制。
(function () {
  const CRM = (window.CRM_PLUGIN = window.CRM_PLUGIN || {});
  // 版本自检：在平台页 Console 打印当前实际运行的插件版本（排查"浏览器里还是旧版"）
  try {
    console.log('[CRM插件] 内容脚本已注入，运行版本 v' + (chrome.runtime && chrome.runtime.getManifest ? chrome.runtime.getManifest().version : '未知'));
  } catch (e) { /* ignore */ }
  // 版本混杂检测：扩展刷新后 Chrome 会向已打开的标签页重新注入新脚本，
  // 旧脚本的 autoSubmit 仍驻留页面并抢先响应 → 两套逻辑并存、行为诡异。
  // 驻留标记 CRM_PLUGIN.ver 是首个注入脚本的版本；与本次版本不同即混杂，大声报警。
  try {
    const myVer = (chrome.runtime && chrome.runtime.getManifest ? chrome.runtime.getManifest().version : '?');
    if (CRM.ver && CRM.ver !== myVer) {
      console.error('[CRM插件] ⚠ 检测到新旧两版脚本在本页共存（驻留 v' + CRM.ver + ' + 本次 v' + myVer
        + '），旧逻辑会干扰发布！请关闭本标签页，从 CRM 页面重新点「开始同步」');
    } else if (CRM.ver === myVer) {
      console.warn('[CRM插件] 本页脚本重复注入（v' + myVer + '），若行为异常请关闭页面重开');
    }
    CRM.ver = myVer;
  } catch (e) { /* ignore */ }
  // 日志收集：把 [CRM插件] 前缀的 console 输出收集到 CRM.debugLog，
  // 随发布结果回传 CRM 后台（发布跳转后 Console 日志会丢，靠这个排查）
  try {
    const dbg = (CRM.debugLog = CRM.debugLog || []);
    ['log', 'warn', 'error'].forEach((level) => {
      const orig = console[level];
      console[level] = function () {
        try {
          const line = Array.prototype.map.call(arguments, (a) => {
            if (typeof a === 'string') return a;
            try { return JSON.stringify(a); } catch (e2) { return String(a); }
          }).join(' ');
          if (line.indexOf('[CRM插件]') >= 0) {
            dbg.push('[' + level + '] ' + line);
            if (dbg.length > 300) dbg.splice(0, dbg.length - 300);
          }
        } catch (e2) { /* ignore */ }
        return orig.apply(console, arguments);
      };
    });
  } catch (e) { /* ignore */ }

  // 平台 code -> 创作页 host（用于判断当前页是否属于该任务）
  CRM.hosts = {
    xiaohongshu: 'creator.xiaohongshu.com',
    douyin_image: 'creator.douyin.com',
    douyin_article: 'creator.douyin.com',
    zhihu: 'zhuanlan.zhihu.com',
    juejin: 'juejin.cn',
    baijiahao: 'baijiahao.baidu.com',
    sohu: 'mp.sohu.com',
    oschina: 'my.oschina.net',
    cnblogs: 'i.cnblogs.com',
    cto51: 'blog.51cto.com',
    // CSDN 有两个创作页：新版富文本（首选，contenteditable，HTML/图片粘贴更稳）
    // 与 Markdown 编辑器（CodeMirror，合成事件难改其内部 state），两者都放行
    csdn: ['mp.csdn.net', 'editor.csdn.net']
  };

  // 抖音图文 / 抖音长文共用一套选择器
  const DOUYIN_CFG = {
    title: [
      'input[placeholder*="标题"]',
      'textarea[placeholder*="标题"]',
      '[class*="title-input"] input',
      '[class*="TitleInput"] input',
      '[class*="title"] input'
    ],
    content: [
      '.ProseMirror',
      '[data-slate-editor="true"]',
      '[contenteditable="true"]'
    ]
  };

  // 各平台「标题 / 正文」候选选择器
  const SELECTORS = {
    xiaohongshu: {
      title: [
        'textarea[placeholder*="标题"]',
        'input[placeholder*="标题"]',
        '#post-title',
        '[class*="title-input"] input',
        '[class*="TitleInput"] input'
      ],
      content: [
        '.ql-editor[contenteditable="true"]',
        '[data-slate-editor="true"]',
        'div[contenteditable="true"]',
        'p[contenteditable="true"]'
      ]
    },
    zhihu: {
      title: [
        'input[placeholder*="标题"]',
        'textarea[placeholder*="标题"]',
        '.WriteIndex-titleInput',
        '[class*="Title"] input'
      ],
      content: [
        '.DraftEditor-editorContainer [contenteditable="true"]',
        '.public-DraftEditor-content',
        '[contenteditable="true"]'
      ]
    },
    oschina: {
      title: [
        'input[placeholder*="文章标题"]',
        'input[placeholder*="标题"]',
        'textarea[placeholder*="标题"]',
        '[placeholder*="标题"]'
      ],
      content: [
        '.w-e-text[contenteditable="true"]',
        'div[contenteditable="true"]',
        '[contenteditable="true"]'
      ]
    },
    douyin_image: DOUYIN_CFG,
    douyin_article: DOUYIN_CFG,
    juejin: {
      title: [
        'input[placeholder*="标题"]',
        '#article-title',
        '.title-input input',
        '[class*="TitleInput"] input'
      ],
      content: [
        // 新版编辑器为富文本 coreditor（medium-editor 系，editor-content 容器）；
        // 页面里可能残留隐藏的 .CodeMirror（旧 markdown 组件），放最后兜底
        '.editor-content',
        '.coreditor-content-medium-editor-container [contenteditable="true"]',
        '[contenteditable="true"]',
        '.bytemd-editor [contenteditable="true"]',
        '.cm-content[contenteditable="true"]',
        '.CodeMirror'
      ]
    },
    baijiahao: {
      // 新版编辑器（builder/rc/edit）为 Slate 框架：标题/正文均带 data-slate-editor，
      // placeholder 位于 data-slate-placeholder 属性（CSS ::before 显示）
      title: [
        '[data-slate-placeholder*="标题"]',
        'input[placeholder*="标题"]',
        'textarea[placeholder*="标题"]',
        '[contenteditable="true"][placeholder*="标题"]',
        '[contenteditable="true"][data-placeholder*="标题"]',
        '[data-slate-placeholder]',
        '[placeholder*="标题"]',
        '[data-placeholder*="标题"]',
        '.title-input input',
        '[class*="ArticleTitle"] input',
        '[class*="title"] input'
      ],
      // 正文为 Slate 编辑器，排除标题框（同为 contenteditable + data-slate-editor）。
      // 注意：data-slate-placeholder 只在编辑框为空时存在——标题一旦有字，:not 排除即失效，
      // querySelector 按 DOM 序会先命中标题框 → 正文整篇写进标题（v1.9.x 实测事故）。
      // 因此 fillContent 用 titleCounterRe（标题旁的「N/64」计数器）逐个候选排除标题框；
      // 旧版 UEditor 正文位于同源 iframe 内，由 frame 兜底逻辑命中
      titleCounterRe: /\d+\s*\/\s*64(?!\d)/,
      content: [
        '[data-slate-editor="true"]:not([data-slate-placeholder*="标题"]):not([data-slate-placeholder])',
        '[contenteditable="true"]:not([placeholder*="标题"]):not([data-placeholder*="标题"]):not([data-slate-placeholder])',
        '.ueditor-body'
      ]
    },
    sohu: {
      title: [
        'input[placeholder*="标题"]',
        'textarea[placeholder*="标题"]',
        'input[name="title"]',
        '#title',
        '[class*="title"] input'
      ],
      // 搜狐号编辑器为 UEditor：正文在 id=ueditor_0 的同源 iframe 内，
      // 且页面为 SPA、编辑器渲染晚 → 优先查 iframe，写入后校验并按需重试
      frameFirst: true,
      content: [
        '#ueditor_0',
        '.ueditor-body',
        '[contenteditable="true"]',
        '.ql-editor'
      ]
    },
    cnblogs: {
      title: [
        '#post-title',
        'input[name="postTitle"]',
        '#txtTitle',
        'input[placeholder*="标题"]'
      ],
      // TinyMCE 正文位于 iframe 内的 contenteditable body，由 frame 兜底逻辑命中
      content: [
        '[contenteditable="true"]',
        '#tinymce',
        '.mce-content-body',
        'textarea[name="postBody"]'
      ]
    },
    csdn: {
      title: [
        '#txt_title',
        'input[placeholder*="标题"]',
        '[class*="title"] input',
        '[class*="article-bar"] input',
        'input[name="title"]'
      ],
      // 新版富文本创作页（mp_blog/creation/editor）正文为 contenteditable 富文本（非 CodeMirror）：
      // 优先命中富文本正文容器，避免误写到标题等其它可编辑元素；
      // .cm-content 兜底旧的 Markdown 编辑器
      content: [
        '.w-e-text-container [contenteditable="true"]',
        '[data-slate-editor="true"]',
        '[class*="editor-content"] [contenteditable="true"]',
        '.cm-content[contenteditable="true"]',
        '[contenteditable="true"]',
        '#content'
      ]
    },
    cto51: {
      title: [
        'input[placeholder*="标题"]',
        'textarea[placeholder*="标题"]',
        'input[name="title"]',
        'input[name="postTitle"]',
        '#title',
        '#post-title',
        '[class*="title" i] input',
        '[class*="title" i] textarea'
      ],
      content: [
        '[class*="ke-content" i]',
        '[class*="editor" i] [contenteditable="true"]',
        '[class*="content" i] [contenteditable="true"]',
        '[contenteditable="true"]'
      ]
    }
  };

  // 通用兜底选择器（平台特化未命中时使用）
  const GENERIC_CFG = {
    title: [
      'input[placeholder*="标题"]',
      'textarea[placeholder*="标题"]',
      'input[placeholder*="title" i]',
      '#title',
      '#txt_title',
      'input[name="title"]',
      '[class*="title"] input',
      '[class*="Title"] input'
    ],
    content: [
      '[contenteditable="true"]',
      '.ql-editor',
      '.cm-content',
      '.CodeMirror',
      'textarea[name="content"]',
      'textarea[name="body"]',
      '#content'
    ]
  };

  // ==================== 基础工具 ====================

  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  /** 收集页面中指向「已发布文章详情页」的链接（排除创作/编辑/预览页） */
  function collectArticleLinks(d) {
    const out = [];
    try {
      Array.from(d.querySelectorAll('a[href]')).forEach((a) => {
        const href = (a.href || '').trim();
        if (!/^https?:\/\//i.test(href)) return;
        if (/addarticle|write|edit|draft|preview/i.test(href)) return;
        out.push({ href, text: ((a.innerText || a.textContent || '') + '').trim() });
      });
    } catch (e) { /* ignore */ }
    return out;
  }

  /** 经后台代取校验候选链接是否真实可访问且内容包含文章标题 */
  function verifyArticleUrl(url, title) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type: 'fetchUrl', url: url }, (r) => {
          if (!r || !r.ok) return resolve(false);
          const t = String(title || '').trim();
          if (!t) return resolve(true);
          const body = r.text || '';
          // 页面里标题可能被 HTML 转义/URL 编码：逐个尝试前 8 字的多种形态，任一命中即认可
          const raw = t.slice(0, 8);
          const needles = [raw, encodeURIComponent(raw), raw.replace(/&/g, '&amp;'), raw.replace(/"/g, '&quot;')];
          resolve(needles.some((n) => n && body.indexOf(n) >= 0));
        });
      } catch (e) { resolve(false); }
    });
  }

  // 发布成功后解析真实文章链接的平台钩子（避免把创作页/预览页 URL 当成结果链接回传）
  CRM.resultUrl = {
    // 搜狐：发布成功后常跳到「内容管理列表/预览页」。预览页 URL 形如
    // /news/articlepreview?id=<文章id>&accountId=<账号id>，并非真实文章页，需先排除；
    // 真实文章页为 https://www.sohu.com/a/<id>_<accountId>，由预览页参数推导并经后台校验后返回。
    sohu: async (job) => {
      const title = ((job && job.title) || '').trim();
      let preview = null;
      const start = Date.now();
      while (Date.now() - start < 12000) {
        for (const d of docList()) {
          // 已发布文章页优先：www.sohu.com/a/... 且标题匹配（列表行的「查看」等短链接无标题，跳过）
          const hit = collectArticleLinks(d).find((l) =>
            /sohu\.com\/a\//i.test(l.href)
            && (!title || (l.text && (l.text.indexOf(title) >= 0 || title.indexOf(l.text) >= 0))));
          if (hit) return hit.href;
          // 记录预览页链接，用于兜底推导真实文章地址
          if (!preview) {
            const pv = d.querySelector('a[href*="articlepreview"]');
            if (pv && pv.getAttribute('href')) preview = pv.getAttribute('href');
          }
        }
        await sleep(800);
      }
      // 只有预览页时：由 id/accountId 推导真实文章页并校验
      if (preview) {
        const full = preview.startsWith('http') ? preview : (location.origin + preview);
        const m = /id=(\d+)[\s\S]*?accountId=(\d+)/.exec(full);
        if (m) {
          const candidates = ['https://www.sohu.com/a/' + m[1] + '_' + m[2], 'https://www.sohu.com/a/' + m[1]];
          for (const c of candidates) {
            if (await verifyArticleUrl(c, title)) return c;
          }
        }
      }
      return '';
    },
    // CSDN：富文本创作页发布成功后停在 mp.csdn.net/mp_blog/creation/success/<文章id>
    //（「发布成功！正在审核中」），并非真实文章页。真实文章页为
    // https://blog.csdn.net/<用户名>/article/details/<id>：
    // 1) 成功页里若有「查看文章」等指向 blog.csdn.net 的链接，直接取用；
    // 2) 否则由文章 id + 用户名（cookie UserName / 页面博客链接）推导文章页，
    //    经后台校验后返回；文章处于审核中导致校验不通过时也返回推导链接
    //    （比回落到创作中心成功页更符合「发布后的文章链接」语义）。
    csdn: async (job) => {
      const title = ((job && job.title) || '').trim();
      const start = Date.now();
      while (Date.now() - start < 12000) {
        // 页面里直接给出文章详情链接（如「查看文章」按钮）：优先采用
        const hit = collectArticleLinks(document).find((l) =>
          /^https?:\/\/blog\.csdn\.net\/[^/]+\/article\/details\/\d+/i.test(l.href));
        if (hit) return hit.href;
        // 由成功页 URL 中的文章 id 推导
        const m = /mp_blog\/creation\/success\/(\d+)/.exec(location.href);
        if (m) {
          let user = '';
          try {
            const ck = document.cookie || '';
            const mm = /(?:^|;\s*)UserName=([^;]+)/.exec(ck);
            if (mm) user = decodeURIComponent(mm[1]).trim();
          } catch (e) { /* ignore */ }
          if (!user) {
            for (const l of collectArticleLinks(document)) {
              const mu = /^https?:\/\/blog\.csdn\.net\/([^/?#]+)/i.exec(l.href);
              if (mu && !/^(article|details)$/i.test(mu[1])) { user = mu[1]; break; }
            }
          }
          if (user) {
            const cand = 'https://blog.csdn.net/' + encodeURIComponent(user) + '/article/details/' + m[1];
            if (await verifyArticleUrl(cand, title)) return cand;
            console.warn('[CRM插件] CSDN 文章疑似审核中，返回推导的文章链接');
            return cand;
          }
          return ''; // 解析不出用户名：回落当前页地址
        }
        await sleep(800);
      }
      return '';
    },
    // 51CTO：发布成功跳 blogger/success/<文章id>（「发布成功 待审核」人工审核页），
    // 待审核期间成功页通常无文章详情链接，以成功页 URL 作为结果链接（含文章 id 可追溯）；
    // 页面若已出现指向 blog.51cto.com 的文章详情链接则优先采用
    cto51: async () => {
      try {
        const hit = collectArticleLinks(document).find((l) =>
          /^https?:\/\/blog\.51cto\.com\/(?!blogger\/success)[^/]+\/\d+/i.test(l.href));
        if (hit) return hit.href;
      } catch (e) { /* ignore */ }
      return /blogger\/success\/\d+/i.test(location.href) ? location.href : '';
    }
  };

  /** 统一取发布结果链接：平台钩子优先，解析不到时回落到当前页地址 */
  async function resolveResultUrl(code, job, fallback) {
    const resolver = CRM.resultUrl && CRM.resultUrl[code];
    if (typeof resolver === 'function') {
      try {
        const u = await resolver(job);
        if (u && /^https?:\/\//i.test(u)) return u;
        if (u === '') return '';
      } catch (e) { /* ignore */ }
    }
    return fallback || '';
  }

  /** 当前文档 + 所有同源 iframe 文档（富文本编辑器常嵌套在其中） */
  function docList() {
    const docs = [document];
    try {
      document.querySelectorAll('iframe').forEach((f) => {
        try {
          if (f.contentDocument) docs.push(f.contentDocument);
        } catch (e) { /* 跨域 iframe 忽略 */ }
      });
    } catch (e) { /* ignore */ }
    return docs;
  }

  /** 跨文档（含 iframe）查询单个选择器 */
  function queryDoc(selector) {
    // 支持 :has-text("…") 伪类：querySelector 原生不支持会抛错，导致配置里所有
    // has-text 选择器整条失效（此前全部靠宽泛兜底匹配，易误命中），这里显式实现
    const hm = /^(.*?):has-text\("([^"]*)"\)$/.exec(selector);
    if (hm) {
      const base = hm[1] || '*';
      const word = hm[2];
      for (const d of docList()) {
        try {
          for (const el of d.querySelectorAll(base)) {
            const t = ((el.innerText || el.textContent || '') + '').trim();
            if (t && t.indexOf(word) >= 0) return el;
          }
        } catch (e) { /* ignore */ }
      }
      return null;
    }
    for (const d of docList()) {
      try {
        const el = d.querySelector(selector);
        if (el) return el;
      } catch (e) { /* 选择器非法时忽略 */ }
    }
    return null;
  }

  /** 轮询等待候选选择器中的任一元素出现 */
  async function waitForSelector(selectors, timeout = 8000, interval = 250) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      for (const sel of selectors) {
        const el = queryDoc(sel);
        if (el) return el;
      }
      await sleep(interval);
    }
    return null;
  }

  /**
   * 写入：优先走「受控组件」路径（setter + input/change 事件），
   * contenteditable 则先尝试 execCommand 插入文本，失败再退化为直接赋值。
   */
  function nativeSet(el, value) {
    if (!el) return false;
    try {
      if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
        const proto = el.tagName === 'TEXTAREA'
          ? window.HTMLTextAreaElement.prototype
          : window.HTMLInputElement.prototype;
        Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, value);
      } else {
        el.focus();
        const doc = el.ownerDocument || document;
        const sel = doc.getSelection();
        const range = doc.createRange();
        range.selectNodeContents(el);
        range.collapse(false);
        sel.removeAllRanges();
        sel.addRange(range);

        let ok = false;
        // Slate 编辑器（data-slate-editor，如百家号）对 execCommand 兼容差，
        // 直接赋值又会被重渲染清空，需用其监听的 beforeinput 事件注入
        try {
          if (el.closest && el.closest('[data-slate-editor="true"]')) {
            const ev = new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertText', data: value });
            el.dispatchEvent(ev);
            ok = !ev.defaultPrevented && (el.innerText || '').trim().length > 0;
          }
        } catch (e) { ok = false; }
        if (!ok) {
          try {
            ok = doc.execCommand('insertText', false, value);
          } catch (e) {
            ok = false;
          }
        }
        if (!ok) {
          if ('innerText' in el) el.innerText = value;
          else el.textContent = value;
        }
      }
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    } catch (e) {
      return false;
    }
  }

  /**
   * 强制同步受控输入（Vue/React）：focus → nativeSet（input/change）→ blur。
   * 部分平台组件（如搜狐来源链接）仅靠 input/change 不更新内部模型，
   * 发布校验读模型导致「已显示值却报为空」，需补 blur 让组件提交。
   */
  function syncInputValue(el, value) {
    if (!el) return false;
    try {
      try { el.focus(); } catch (e) { /* ignore */ }
      nativeSet(el, value);
      try {
        el.dispatchEvent(new FocusEvent('blur'));
        if (el.blur) el.blur();
      } catch (e2) { /* ignore */ }
      return ((el.value || '') + '').trim() === String(value || '').trim();
    } catch (e) {
      return false;
    }
  }

  /**
   * 模拟真实打字写入：focus → 全选 → keydown → execCommand insertText（失败回退 setter+input）→ keyup → blur。
   * 部分编辑器（如 51CTO 标题）内部 model 不认 setter/事件合成的写入——显示有值但发布仍报「请填写标题」，
   * 必须走真实输入事件链才能同步内部状态。
   */
  function forceTypeValue(el, value) {
    if (!el) return false;
    try {
      try { el.focus(); } catch (e0) { /* ignore */ }
      const doc = el.ownerDocument || document;
      const isBox = el.tagName === 'INPUT' || el.tagName === 'TEXTAREA';
      if (isBox) {
        if (el.select) el.select();
      } else {
        const range = doc.createRange();
        range.selectNodeContents(el);
        const sel = doc.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
      }
      try { el.dispatchEvent(new KeyboardEvent('keydown', { key: 'a', bubbles: true, cancelable: true })); } catch (e1) { /* ignore */ }
      let ok = false;
      try { ok = doc.execCommand('insertText', false, value); } catch (e2) { ok = false; }
      if (!ok && isBox) {
        const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
        Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, value);
        el.dispatchEvent(new Event('input', { bubbles: true }));
      }
      try { el.dispatchEvent(new KeyboardEvent('keyup', { key: 'a', bubbles: true, cancelable: true })); } catch (e3) { /* ignore */ }
      try { el.dispatchEvent(new FocusEvent('blur')); if (el.blur) el.blur(); } catch (e4) { /* ignore */ }
      const got = (el.value != null ? el.value : el.innerText) || '';
      return got.trim().length >= Math.min(2, String(value || '').length);
    } catch (e) {
      return false;
    }
  }

  /** HTML → 段落纯文本（保留每段文本，图片占位符 [[CRM_IMG_n]] 会随之带出）。
   *  纯文本注入型编辑器（Slate/FeEditor）必须用这份文本，否则 contentText 里没有占位符，
   *  后续「占位符处粘贴图片」找不到锚点（实测：正文填了，但报「未找到图片占位符」） */
  function htmlToParagraphText(html) {
    try {
      const doc = new DOMParser().parseFromString(String(html || ''), 'text/html');
      const parts = [];
      Array.from(doc.body.children).forEach((el) => {
        const t = (el.textContent || '').replace(/\s+/g, ' ').trim();
        if (t) parts.push(t);
      });
      return parts.join('\n') || (doc.body.textContent || '').replace(/\s+/g, ' ').trim();
    } catch (e) { return String(html || '').replace(/<[^>]+>/g, '').trim(); }
  }

  /** 富文本写入：优先插入 HTML（保留段落/图片），失败退化为纯文本，最后才直接赋值 */
  function setRichText(el, html, text) {
    if (!el) return false;
    const tag = (el.tagName || '').toUpperCase();
    // 纯文本注入路径的文本：HTML 已把图片换成占位符时，从 HTML 派生（保住占位符锚点）
    const plain = (html && /(\[\[CRM_IMG_|CRMIMGPH)/.test(html)
      && !/(\[\[CRM_IMG_|CRMIMGPH)/.test(String(text || '')))
      ? htmlToParagraphText(html) : String(text || '');
    try {
      if (tag === 'TEXTAREA' || tag === 'INPUT') return nativeSet(el, plain || text || '');

      // Slate 编辑器：beforeinput 按段落逐段注入（insertParagraph 分段），
      // execCommand/直接赋值在 Slate 上会被重渲染清空
      try {
        if (el.closest && el.closest('[data-slate-editor="true"]')) {
          el.focus();
          const paras = String(plain || '').split(/\n+/).filter((s) => s.trim());
          let okAll = paras.length > 0;
          for (let i = 0; i < paras.length; i++) {
            if (i > 0) {
              const pe = new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertParagraph', data: null });
              el.dispatchEvent(pe);
              if (pe.defaultPrevented) { okAll = false; break; }
            }
            const ev = new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertText', data: paras[i] });
            el.dispatchEvent(ev);
            if (ev.defaultPrevented) { okAll = false; break; }
          }
          if (okAll && ((el.innerText || '').trim())) {
            el.dispatchEvent(new Event('input', { bubbles: true }));
            return true;
          }
        }
      } catch (e) { /* 退化到通用路径 */ }

      // DraftJS 编辑器（知乎专栏等）：直接赋值/execCommand 只改 DOM 不更新其 React 状态
      // （表现为「字数：0」，点发布无效后平台自动存草稿）。改用 paste 事件 + DataTransfer 注入，
      // DraftJS 的 onPaste 会把内容真正写入内部 EditorState。
      try {
        if (el.closest && el.closest('.public-DraftEditor-content, .DraftEditor-editorContainer, [class*="DraftEditor"]')) {
          el.focus();
          const d = el.ownerDocument || document;
          const s = d.getSelection();
          const r = d.createRange();
          r.selectNodeContents(el);
          s.removeAllRanges();
          s.addRange(r);
          const dt = new DataTransfer();
          dt.setData('text/plain', String(text || ''));
          if (html) dt.setData('text/html', html);
          const ev = new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dt });
          el.dispatchEvent(ev);
          if (((el.innerText || el.textContent || '') + '').trim().length > 0) {
            return true;
          }
        }
      } catch (e) { /* 退化到通用路径 */ }

      el.focus();
      const doc = el.ownerDocument || document;
      const sel = doc.getSelection();
      const range = doc.createRange();
      range.selectNodeContents(el);
      sel.removeAllRanges();
      sel.addRange(range);

      let ok = false;
      try { doc.execCommand('delete'); } catch (e) { /* ignore */ }
      if (html) {
        try { ok = doc.execCommand('insertHTML', false, html); } catch (e) { ok = false; }
      }
      if (!ok || !((el.innerHTML || '').trim())) {
        if (text) {
          try { ok = doc.execCommand('insertText', false, text); } catch (e) { ok = false; }
        }
        if (!ok || !((el.innerText || el.textContent || '').trim())) {
          if (html) el.innerHTML = html;
          else if ('innerText' in el) el.innerText = text || '';
          else el.textContent = text || '';
        }
      }
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Enter' }));
      return true;
    } catch (e) {
      return false;
    }
  }

  /** 写入后校验：SPA/UEditor 常在渲染完成后清空先前写入的内容，需确认真正落在编辑器里 */
  async function waitFilled(el, minLen, timeout = 2500) {
    const need = Math.max(1, minLen);
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const val = ((el.innerText != null ? el.innerText : el.textContent) || '') + '';
      if (val.trim().length >= need) return true;
      if ((el.innerHTML || '').trim().length >= need) return true;
      await sleep(300);
    }
    return false;
  }

  /** 读取元素真实值：input/textarea 用 value，contenteditable 用 innerText/textContent */
  function editableValue(el) {
    if (!el) return '';
    if (el.value != null && typeof el.value === 'string') return el.value;
    return ((el.innerText != null ? el.innerText : el.textContent) || '') + '';
  }

  /**
   * 稳定校验：写入成功后再延迟复核一次。
   * Slate/ProseMirror 等受控富文本会把「直接赋值」的内容在下一次重渲染时清空，
   * 立即校验会假成功（悬浮栏显示已填充、编辑器实际为空），必须延迟后再确认。
   */
  async function filledStable(el, minLen) {
    if (!el) return false;
    if (!(await waitFilled(el, minLen))) return false;
    await sleep(1500);
    const cur = editableValue(el).replace(/\s/g, '');
    return cur.length >= Math.max(1, minLen);
  }

  /**
   * 按 placeholder 文本查找 contenteditable 编辑框（含 CSS 伪元素实现，如百家号
   * 「请输入标题（2-64字）」写在 ::before 上，DOM 无 placeholder 属性可选）。
   */
  function findEditableByPlaceholder(keyword) {
    const list = deepQueryAll(document, '[contenteditable="true"]');
    for (const el of list) {
      let hint = (el.getAttribute('placeholder') || '')
        + (el.getAttribute('data-placeholder') || '')
        + (el.getAttribute('data-slate-placeholder') || '')
        + (el.getAttribute('aria-placeholder') || '');
      try { hint += getComputedStyle(el, '::before').content || ''; } catch (e) { /* ignore */ }
      if (hint && hint.indexOf(keyword) >= 0) return el;
    }
    return null;
  }

  /** UEditor / TinyMCE 等把正文放在 iframe 内，仅在 iframe 文档中查找，避免误改主页面 */
  const FRAME_CONTENT = ['.mce-content-body', '#tinymce', '.ueditor-body', 'body'];

  function queryFrameDoc(selector) {
    for (const d of docList()) {
      if (d === document) continue; // 跳过主文档
      try {
        const el = d.querySelector(selector);
        if (el) return el;
      } catch (e) { /* ignore */ }
    }
    return null;
  }

  async function waitForFrameContent(timeout = 5000, interval = 250) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      for (const sel of FRAME_CONTENT) {
        const el = queryFrameDoc(sel);
        if (el) return el;
      }
      await sleep(interval);
    }
    return null;
  }

  /** 把 iframe 元素换成其可编辑 body */
  function editableOf(el) {
    if (!el) return null;
    if ((el.tagName || '').toUpperCase() === 'IFRAME') {
      try {
        return (el.contentDocument && el.contentDocument.body) || null;
      } catch (e) {
        return null;
      }
    }
    return el;
  }

  /** 标题框特征识别：元素文本后紧跟「N/上限」计数器（如百家号标题旁的 256/64）即视为标题框。
   *  用于正文填充时排除与正文同构（同为 Slate contenteditable）的标题框：
   *  Slate 的 data-slate-placeholder 属性只在空框上存在，有字后 :not 排除失效 */
  function looksLikeCounterTitle(el, re) {
    try {
      const own = String(el.textContent || '').replace(/\s+/g, '');
      if (own.length < 4) return false; // 空框时旧排除规则本就生效，此处只防「有字后误命中」
      let n = el.parentElement;
      for (let up = 0; n && up < 4; up++, n = n.parentElement) {
        const t = String(n.textContent || '').replace(/\s+/g, '');
        if (!t.startsWith(own)) break; // 结构不符（父层把别的块也算进来了），不再向上看
        // 计数器后面通常还跟着别的文本（正文等），不能用 $ 锚定结尾
        if (re.test(t.slice(own.length, own.length + 16))) return true;
      }
    } catch (e) { /* ignore */ }
    return false;
  }

  /**
   * 填充正文：逐个候选选择器尝试写入 → 校验是否真的写进去 → 被清空则换下一个/重试。
   * 解决「编辑器渲染晚或 SPA 重渲染导致内容被清空、页面看起来正文为空」的问题。
   */
  async function fillContent(cfg, job) {
    const text = (job && job.contentText) || '';
    const html = (job && job.contentHtml) || '';
    if (!text && !html) return false;
    const need = Math.min(10, text.replace(/\s/g, '').length || 10);
    const sels = (cfg && cfg.content) || GENERIC_CFG.content;

    for (let attempt = 0; attempt < 3; attempt++) {
      const waitMs = attempt === 0 ? 8000 : 2000;
      // UEditor 类平台（如搜狐号）正文在 iframe 内，优先命中，避免写到主文档其它可编辑元素
      if (cfg && cfg.frameFirst) {
        const f = editableOf(await waitForFrameContent(waitMs));
        if (f) {
          setRichText(f, html, text);
          if (await filledStable(f, need)) return true;
        }
      }
      for (const sel of sels) {
        let el = null;
        if (cfg && cfg.titleCounterRe) {
          // 标题/正文同构的平台（如百家号）：同一选择器会同时命中两者且标题在前，
          // 必须枚举全部候选并按计数器特征排除标题框，取第一个非标题元素
          const t0 = Date.now();
          while (Date.now() - t0 < waitMs && !el) {
            const list = Array.from(document.querySelectorAll(sel)).map(editableOf);
            el = list.find((x) => x && elVisible(x) && !looksLikeCounterTitle(x, cfg.titleCounterRe)) || null;
            if (!el) await sleep(300);
          }
        } else {
          el = editableOf(await waitForSelector([sel], waitMs));
        }
        if (!el) continue;
        console.log('[CRM插件] 正文填充命中：' + sel + ' → <' + (el.tagName || '') + '> class=' + ((el.className || '') + '').slice(0, 60));
        setRichText(el, html, text);
        if (await filledStable(el, need)) return true;
      }
      const f2 = editableOf(await waitForFrameContent(2000));
      if (f2) {
        setRichText(f2, html, text);
        if (await filledStable(f2, need)) return true;
      }
      await sleep(800);
    }
    return false;
  }

  /** 按配置填充标题与正文 */
  async function fillByConfig(cfg, job, timeout) {
    const res = { titleFilled: false, contentFilled: false };
    const title = (job && job.title) || '';
    if (title) {
      // 选择器未命中时按伪元素/属性 placeholder 兜底查找（如百家号新编辑器 contenteditable 标题）
      let t = await waitForSelector(cfg.title, timeout) || findEditableByPlaceholder('标题');
      if (t) {
        nativeSet(t, title);
        await sleep(1000);
        // 写入后被框架重置（受控组件 initialValue）时补一次；contenteditable 用真实文本校验
        if (editableValue(t).trim().length < Math.min(4, title.length)) {
          const t2 = (await waitForSelector(cfg.title, 2000)) || findEditableByPlaceholder('标题') || t;
          nativeSet(t2, title);
          await sleep(800);
          t = t2;
        }
        res.titleFilled = editableValue(t).trim().length >= Math.min(4, title.length);
      }
    }
    res.contentFilled = await fillContent(cfg, job);
    return res;
  }

  /** 发布前按配置把必填关键词追加到标题/正文末尾 */
  function applyKeywordsToJob(job) {
    if (!job || !job.keywords) return;
    const kws = job.keywords.split(/[,，]/).map(s => s.trim()).filter(Boolean);
    if (!kws.length) return;
    const kwText = kws.join(' ');
    const mode = job.appendMode || 'none';
    if (mode === 'title' && job.title) {
      job.title = (job.title + ' ' + kwText).trim();
    } else if (mode === 'content') {
      if (job.contentText) job.contentText = (job.contentText + '\n' + kwText).trim();
      if (job.contentHtml) job.contentHtml = job.contentHtml + '<p>' + escapeHtml(kwText) + '</p>';
    }
  }

  function escapeHtml(s) {
    return (s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  /** 把必填关键词填入页面中的标签/话题输入框（尽力而为，按 Enter 尝试添加） */
  async function fillTagsGeneric(job, scope) {
    const kws = (job && job.keywords || '').split(/[,，]/).map(s => s.trim()).filter(Boolean);
    if (!kws.length) return;
    const root = scope || document;
    const inputs = deepQueryAll(root, 'input').filter(i => {
      const sig = ((i.placeholder || '') + (i.getAttribute('aria-label') || '') + (i.className || '')).toLowerCase();
      return /(标签|话题|关键字|tag)/.test(sig) && !i.value;
    });
    for (const inp of inputs) {
      for (const k of kws) {
        try {
          const setVal = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
          setVal.call(inp, k);
          inp.dispatchEvent(new Event('input', { bubbles: true }));
          inp.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
          inp.dispatchEvent(new KeyboardEvent('keypress', { key: 'Enter', keyCode: 13, bubbles: true }));
          inp.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', keyCode: 13, bubbles: true }));
        } catch (e) { /* ignore */ }
        await sleep(250);
      }
    }
  }

  /** 点击页面上第一个可见的短文案节点（去空格精确匹配，取最小面积目标） */
  function clickTextGlobal(txt) {
    const want = String(txt || '').replace(/\s+/g, '');
    if (!want) return false;
    let best = null;
    let bestArea = Infinity;
    for (const d of docList()) {
      for (const el of deepQueryAll(d, 'li, span, div, p, button, a, label')) {
        try {
          if (((el.textContent || '') + '').replace(/\s+/g, '') !== want) continue;
          const r = el.getBoundingClientRect();
          if (r.width < 5 || r.height < 5) continue;
          const area = r.width * r.height;
          if (area < bestArea) { bestArea = area; best = el; }
        } catch (e) { /* ignore */ }
      }
    }
    if (!best) return false;
    try {
      best.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
      best.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
    } catch (e) { /* ignore */ }
    try { best.click(); return true; } catch (e2) { return false; }
  }

  /** 通用可见性判定：rect 有尺寸 + 未隐藏。
   *  不要用 el.offsetParent——position:fixed/sticky 的元素 offsetParent 为 null，会被误判为不可见 */
  function isVisible(el) {
    if (!el) return false;
    try {
      const r = el.getBoundingClientRect();
      if (r.width < 5 || r.height < 5) return false;
      const st = window.getComputedStyle(el);
      return st.visibility !== 'hidden' && st.display !== 'none';
    } catch (e) { return false; }
  }

  /** 点击页面上包含目标文案的可见叶子节点（宽松包含匹配，取最小面积）。
   *  用于选项文案与配置值有细微差异（多空格/拆分节点）时的兜底。 */
  function clickTextLoose(txt) {
    const want = String(txt || '').replace(/\s+/g, '');
    if (!want) return false;
    let best = null;
    let bestArea = Infinity;
    for (const d of docList()) {
      for (const el of deepQueryAll(d, 'li, span, div, p, button, a, label')) {
        try {
          const t = ((el.textContent || '') + '').replace(/\s+/g, '');
          if (!t || t.indexOf(want) < 0) continue;
          if (el.querySelector('li, span, div, p, button, a, label')) continue; // 只点叶子，避免点中容器
          const r = el.getBoundingClientRect();
          if (r.width < 5 || r.height < 5) continue;
          const area = r.width * r.height;
          if (area < bestArea) { bestArea = area; best = el; }
        } catch (e) { /* ignore */ }
      }
    }
    if (!best) return false;
    try {
      best.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
      best.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
    } catch (e) { /* ignore */ }
    try { best.click(); return true; } catch (e2) { return false; }
  }

  /** 通用「分类」选择：先点同名选项（chip/下拉项），再尝试点开分类下拉后点选 */
  async function pickGenericCategory(name) {
    if (clickTextGlobal(name)) return true;
    const want = String(name || '').replace(/\s+/g, '');
    // 找到「分类」标签所在行，点开其下拉触发器
    const labels = Array.from(document.querySelectorAll('label, span, div'))
      .filter((el) => ((el.textContent || '') + '').trim() === '分类' && el.offsetParent);
    const scope = labels.length ? labels[labels.length - 1].parentElement : document;
    const trigger = scope && scope.querySelector('input, select, .el-select, [class*="select"], [class*="dropdown"]');
    if (trigger) {
      try { trigger.click(); } catch (e) { /* ignore */ }
      await sleep(500);
      return clickTextGlobal(name);
    }
    return false;
  }

  /**
   * 按用户在预览页设置的结构化配置填写平台表单（通用、尽力而为）：
   * tags/topic/topics → 标签/话题框；category → 分类下拉；digest/summary → 摘要框；original → 原创声明。
   * 搜狐已有平台特化逻辑（栏目/声明/属性等），由调用方跳过。
   */
  async function fillStructuredFields(job, skipTags) {
    const c = (job && job.platformConfig) || {};
    const splitWords = (v) => String(v || '').split(/[,，、;；\s]+/).map((s) => s.trim()).filter(Boolean);
    // 1) 标签 / 话题（CSDN 富文本页由 fillCsdnRichPanel 统一按配置填写，这里跳过避免重复）
    const words = [].concat(splitWords(c.tags), splitWords(c.topic), splitWords(c.topics));
    if (words.length && !skipTags) {
      try { await fillTagsGeneric({ keywords: words.join(',') }); } catch (e) { /* ignore */ }
    }
    // 2) 分类
    if (c.category) {
      try { await pickGenericCategory(c.category); } catch (e) { /* ignore */ }
    }
    // 3) 摘要 / 简介
    const summary = String(c.digest || c.summary || '').trim();
    if (summary) {
      try {
        const el = findEditableByPlaceholder('摘要') || findEditableByPlaceholder('简介')
          || document.querySelector('textarea[placeholder*="摘要"], input[placeholder*="摘要"], textarea[placeholder*="简介"], textarea[placeholder*="摘要"]');
        if (el) syncInputValue(el, summary);
      } catch (e) { /* ignore */ }
    }
    // 3b) 可见范围（CSDN 创作页单选组：全部可见/仅粉丝可见/VIP可见/仅我可见，默认全部可见）
    if (c.visibility && c.visibility !== '全部可见') {
      try { await clickTextGlobal(c.visibility); } catch (e) { /* ignore */ }
    }
    // 4) 原创声明
    if (c.original) clickTextGlobal('原创');
  }

  /** 点开表单 label 旁的下拉/选择器：从 label 向上最多 6 层祖先逐层找控件；
   *  原生 select 直接设值，自定义下拉点开后轮询点选目标项 */
  async function openLabelSelectAndPick(labelText, optionText) {
    const want = String(optionText || '').replace(/\s+/g, '');
    const wantLabel = String(labelText || '').replace(/\s+/g, '');
    // 找 label 文本节点（可见的最小面积目标，避免命中整块表单容器）；
    // 用包含匹配：label 旁常带 ⓘ 提示图标等兄弟文本节点
    let label = null;
    let bestArea = Infinity;
    for (const el of document.querySelectorAll('label, span, div')) {
      const txt = ((el.textContent || '') + '').replace(/\s+/g, '');
      if (!txt || txt.indexOf(wantLabel) < 0 || !isVisible(el)) continue;
      try {
        const r = el.getBoundingClientRect();
        if (r.width < 5 || r.height < 5) continue;
        const a = r.width * r.height;
        if (a < bestArea) { bestArea = a; label = el; }
      } catch (e) { /* ignore */ }
    }
    if (!label) { console.warn('[CRM插件] 未找到「' + labelText + '」标签'); return false; }
    // option 匹配：去空白全等优先，互相包含兜底（平台选项文案与配置值常有细微差异）
    const matchOpt = (t) => {
      const c = String(t || '').replace(/\s+/g, '');
      return !!c && (c === want || c.indexOf(want) >= 0 || want.indexOf(c) >= 0);
    };
    // 向上最多 10 层祖先，逐层找控件
    let node = label.parentElement;
    for (let i = 0; i < 10 && node && node !== document.body; i++) {
      // 原生 <select>：程序化点击不会展开下拉，直接匹配 option 设置值并派发 change
      const sel = node.tagName === 'SELECT' ? node : (node.querySelector ? node.querySelector('select') : null);
      if (sel) {
        const hit = Array.from(sel.options).find((o) => matchOpt(o.textContent));
        if (hit) {
          try {
            Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, 'value').set.call(sel, hit.value);
            sel.dispatchEvent(new Event('input', { bubbles: true }));
            sel.dispatchEvent(new Event('change', { bubbles: true }));
            console.log('[CRM插件] ' + labelText + '（原生下拉）已设为「' + (hit.textContent || '').trim() + '」');
            return true;
          } catch (e) { /* fallthrough */ }
        } else {
          console.warn('[CRM插件] ' + labelText + '：下拉已找到但无匹配项「' + optionText
            + '」，可选项：' + Array.from(sel.options).map((o) => (o.textContent || '').trim()).join(' | '));
        }
      }
      // 自定义下拉触发器：点开后轮询点选（精确 + 宽松匹配）
      const trigger = node.querySelector ? node.querySelector('[role="combobox"], [class*="select" i], input') : null;
      if (trigger) {
        try { trigger.click(); } catch (e) { /* ignore */ }
        const st = Date.now();
        let picked = false;
        while (Date.now() - st < 6000) {
          if (clickTextGlobal(optionText) || clickTextLoose(optionText)) { picked = true; break; }
          await sleep(300);
        }
        if (picked) {
          console.log('[CRM插件] ' + labelText + '已选「' + optionText + '」');
          return true;
        }
        // 未点中：收起下拉并直接失败返回——不能继续向上层祖先循环，
        // 否则每层都会重复点 trigger，把下拉反复点开/点关，选中动作永远被打断
        try {
          document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true, cancelable: true }));
        } catch (e2) { /* ignore */ }
        // 诊断：收集页面上可见的短文本候选项，便于比对实际选项文案
        const cands = Array.from(new Set(Array.from(document.querySelectorAll('li, [class*="option" i], [class*="Menu-item" i], [class*="Popover" i] *'))
          .filter((el) => isVisible(el) && el.children.length === 0)
          .map((el) => ((el.textContent || '') + '').trim())
          .filter((t) => t && t.length <= 30)));
        console.warn('[CRM插件]「' + labelText + '」下拉已打开但未能点选「' + optionText + '」，浮层候选：'
          + (cands.length ? cands.join(' | ') : '（未收集到候选项）'));
        return false;
      }
      node = node.parentElement;
    }
    // 兜底：页面全局找可见的原生 select（编辑页设置面板通常只有一个），按 option 特征或目标值直接设值
    const allSel = Array.from(document.querySelectorAll('select')).filter((s) => isVisible(s));
    for (const sel of allSel) {
      const hit = Array.from(sel.options).find((o) => matchOpt(o.textContent));
      if (hit) {
        try {
          Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, 'value').set.call(sel, hit.value);
          sel.dispatchEvent(new Event('input', { bubbles: true }));
          sel.dispatchEvent(new Event('change', { bubbles: true }));
          console.log('[CRM插件] ' + labelText + '（全局原生下拉兜底）已设为「' + (hit.textContent || '').trim() + '」');
          return true;
        } catch (e) { /* continue */ }
      }
    }
    console.warn('[CRM插件]「' + labelText + '」控件未找到或选项缺失，页面可见 select：'
      + (allSel.length ? allSel.map((s) => 'options[' + s.options.length + ']: ' + Array.from(s.options).slice(0, 8).map((o) => (o.textContent || '').trim()).join('/')).join('；') : '无'));
    return false;
  }

  /** 知乎封面：点「添加文章封面」入口，hook 拦截其 file input 的系统文件选择框（避免阻塞页面），
   *  直接把封面文件写入该 input → 等裁剪/确认弹窗 → 点确认 → 等入口消失。
   *  不能全局随便找 input[type=file]：编辑器旁常驻「正文图片上传」input，塞进去会把封面传进正文。 */
  async function fillZhihuCover(job) {
    try {
      // 封面添加入口：不同版本编辑器文案不同（添加文章封面/添加封面/设置封面/上传封面），包含匹配+最小面积
      const addEntry = () => {
        let found = null;
        let bestArea = Infinity;
        for (const el of document.querySelectorAll('span, div, button')) {
          const t = ((el.textContent || '') + '').replace(/\s+/g, '');
          if (!t || t.length > 20) continue;
          if (!/添加文章封面|添加封面|设置封面|上传封面/.test(t) || !isVisible(el)) continue;
          try {
            const r = el.getBoundingClientRect();
            if (r.width < 5 || r.height < 5) continue;
            const a = r.width * r.height;
            if (a < bestArea) { bestArea = a; found = el; }
          } catch (e) { /* ignore */ }
        }
        return found;
      };
      if (!addEntry()) {
        // 找不到添加入口：区分「封面已设置」（有更换/重新裁剪字样）与「入口文案未识别」
        const pageText = (document.body.innerText || '').replace(/\s+/g, '');
        if (/更换封面|重新裁剪|替换封面|修改封面/.test(pageText)) {
          console.log('[CRM插件] 知乎封面已存在（检测到更换封面入口），跳过');
          return true;
        }
        // 诊断：收集页面上含「封面」的可见文本，便于比对实际入口文案
        const hits = Array.from(new Set(Array.from(document.querySelectorAll('span, div, button, p'))
          .filter((el) => isVisible(el) && ((el.textContent || '') + '').indexOf('封面') >= 0)
          .map((el) => ((el.textContent || '') + '').replace(/\s+/g, '').slice(0, 30))));
        console.warn('[CRM插件] 知乎未找到封面添加入口，页面含「封面」的文本：'
          + (hits.length ? hits.join(' | ') : '（无）'));
        return false;
      }
      if (!job || !job.coverUrl) { console.warn('[CRM插件] 知乎封面未设置：任务未携带封面图'); return false; }
      const dataUrl = await fetchImageDataUrl(job.coverUrl);
      const file = dataUrl ? await dataUrlToUploadFile(dataUrl, 'cover.jpg') : null;
      if (!file) { console.warn('[CRM插件] 知乎封面下载失败：' + job.coverUrl); return false; }
      // main-world hook 捕获（v1.7.4）：content script 与页面 JS 隔离，content 世界
      // hook 不到知乎页面的 input.click() 调用（v1.7.3 及之前捕获恒空）。注入 main-world
      // 脚本：file input 被页面点击时打 data-crm-captured 时间戳标记，轮询读取。
      // 同时 hook showOpenFilePicker（新版可能用 File System Access API）：返回空数组避免阻塞
      let captured = null;
      const hookT0 = Date.now();
      try {
        const s = document.createElement('script');
        s.textContent = '(function(){if(window.__crmInputHook)return;window.__crmInputHook=1;var p=HTMLInputElement.prototype,o=p.click;p.click=function(){if(this&&this.type==="file"){try{this.setAttribute("data-crm-captured",String(Date.now()))}catch(e){}}return o.apply(this,arguments)};if(typeof window.showOpenFilePicker==="function"){var f=window.showOpenFilePicker;window.showOpenFilePicker=function(){try{document.documentElement.setAttribute("data-crm-picker",String(Date.now()))}catch(e){}return f.apply(this,arguments)}}})();';
        (document.head || document.documentElement).appendChild(s);
        s.remove();
      } catch (e) { /* ignore */ }
      let usedPicker = false;
      const origPicker = window.showOpenFilePicker;
      if (typeof origPicker === 'function') {
        window.showOpenFilePicker = function () { usedPicker = true; return Promise.resolve([]); };
      }
      try { addEntry().click(); } catch (e) { /* ignore */ }
      // 轮询 main-world 标记（最多 8 秒）；入口可能先弹「编辑封面」弹窗，辅助点弹窗内上传按钮
      const st0 = Date.now();
      while (Date.now() - st0 < 8000) {
        captured = Array.from(document.querySelectorAll('input[type="file"][data-crm-captured]'))
          .filter((el) => parseInt(el.getAttribute('data-crm-captured'), 10) > hookT0)[0] || null;
        if (captured) break;
        await sleep(300);
        captured = Array.from(document.querySelectorAll('input[type="file"][data-crm-captured]'))
          .filter((el) => parseInt(el.getAttribute('data-crm-captured'), 10) > hookT0)[0] || null;
        if (captured) break;
        // 「上传」按钮只在可见弹窗/模态内找，避免点到页面其他「上传」入口
        const modal = Array.from(document.querySelectorAll('[role="dialog"], [class*="modal" i], [class*="dialog" i]'))
          .find((m) => { try { const r = m.getBoundingClientRect(); return r.width > 200 && r.height > 120; } catch (e3) { return false; } });
        const up = findBtnInScope(modal || document.body, ['本地上传', '点击上传', '上传图片', '上传封面', '上传']);
        if (up) { try { up.click(); } catch (e2) { /* ignore */ } }
      }
      if (typeof origPicker === 'function') window.showOpenFilePicker = origPicker;
      if (usedPicker) console.warn('[CRM插件] 知乎封面使用了系统文件选择 API，暂无法自动写入，请手动添加封面');
      if (!captured) { console.warn('[CRM插件] 知乎未捕获封面文件选择框，请手动添加封面'); return false; }
      const acc = (captured.accept || '').toLowerCase();
      if (acc && acc.indexOf('image') < 0 && !/\.(jpe?g|png|webp)/.test(acc)) {
        console.warn('[CRM插件] 捕获的 file input 非图片类型，放弃写入'); return false;
      }
      putFileToInput(captured, file);
      console.log('[CRM插件] 知乎封面文件已写入，等待上传回显');
      // 等「添加文章封面」入口消失；若弹出裁剪/确认弹窗则点确认
      const st = Date.now();
      while (Date.now() - st < 15000) {
        if (!addEntry()) return true;
        const cb = findBtnInScope(document.body, ['确认', '确定', '完成']);
        if (cb) { try { cb.click(); } catch (e) { /* ignore */ } }
        await sleep(500);
      }
      console.warn('[CRM插件] 知乎封面 15 秒内未回显，请手动添加');
      return false;
    } catch (e) { return false; }
  }

  /**
   * 知乎发布设置：封面（自动上传文章封面）、创作声明（原生 select 下拉）、专栏收录（单选）。
   */
   async function fillZhihuSettings(job) {
     const c = (job && job.platformConfig) || {};
     console.log('[CRM插件] 知乎发布设置：开始填写（封面/声明/专栏）', JSON.stringify({ cover: !!(job && job.coverUrl), declaration: c.declaration, column: c.column }));
     // 1) 封面：文章封面图自动上传到「添加文章封面」
     if (job && job.coverUrl) {
       const okCover = await fillZhihuCover(job);
       if (!okCover) console.warn('[CRM插件] 知乎封面自动上传未完成，请手动添加');
     }
     // 2) 创作声明（下拉选择，默认「无声明」不需要操作）
     if (c.declaration && c.declaration !== '无声明' && c.declaration !== '无') {
       const okDecl = await openLabelSelectAndPick('创作声明', c.declaration).catch(() => false);
       if (!okDecl) console.warn('[CRM插件] 知乎创作声明「' + c.declaration + '」未能自动选择，请手动选择');
     }
     // 3) 专栏收录（单选）
     if (c.column) {
       try { if (!clickTextGlobal(c.column)) console.warn('[CRM插件] 知乎专栏收录「' + c.column + '」未找到，请手动选择'); } catch (e) { /* ignore */ }
     }
   }

  /** 知乎发布后补设置：创作页点「发布」直接发布且无设置弹窗（日志证实），
   *  封面/声明只在发布后的编辑页（/p/xxx/edit）可设——跳转到编辑页后由补传流程调用，
   *  在此设置封面/声明/专栏并保存，改动直接作用于已发布文章。 */
  CRM.fillZhihuPostPublish = async function (cfg) {
    cfg = cfg || {};
    // 发布成功后知乎常直接落在文章阅读页（zhuanlan.zhihu.com/p/数字），
    // 而封面/声明面板只存在于编辑页（/p/数字/edit）：阅读页直接转跳编辑页，
    // 返回 'navigating' 让调用方暂不回传，由新页面的内容脚本接手补设置
    if (/zhuanlan\.zhihu\.com\/p\/\d+\/?(\?.*)?$/i.test(location.href)) {
      console.log('[CRM插件] 知乎发布后落在阅读页，自动转编辑页补设置封面/声明');
      try { location.href = location.href.replace(/(\/p\/\d+)(\/?)(\?.*)?$/i, '$1/edit$3'); } catch (e) { /* ignore */ }
      return 'navigating';
    }
    // 防循环：点「更新」后知乎跳转可能再次触发补传流程，导致重复进入编辑页反复编辑。
    // 同一标签页内给该文章打「已补设置」标记（sessionStorage 按标签页隔离，不影响手动编辑），命中即跳过
    const articleId = (location.pathname.match(/p\/(\d+)/) || [])[1] || '';
    const doneKey = 'crm_zhihu_set_' + articleId;
    try {
      if (articleId && sessionStorage.getItem(doneKey)) {
        console.log('[CRM插件] 该文章已补设置过，跳过重复编辑');
        return true;
      }
    } catch (e) { /* ignore */ }
    // 等编辑页发布设置面板出现（含「创作声明」），最多 20 秒（封面已去掉，不再以封面入口判断）。
    // 用包含匹配+最小面积：label 常带 ⓘ 提示图标，textContent 是「创作声明?」之类，全等永远不成立
    const hasPanel = () => {
      let found = null;
      let bestArea = Infinity;
      for (const el of document.querySelectorAll('span, div, label')) {
        const t = ((el.textContent || '') + '').replace(/\s+/g, '');
        if (t.indexOf('创作声明') < 0 || !isVisible(el)) continue;
        try {
          const r = el.getBoundingClientRect();
          if (r.width < 5 || r.height < 5) continue;
          const a = r.width * r.height;
          if (a < bestArea) { bestArea = a; found = el; }
        } catch (e) { /* ignore */ }
      }
      return found;
    };
    const st = Date.now();
    while (Date.now() - st < 20000) {
      if (hasPanel()) break;
      await sleep(500);
    }
    if (!hasPanel()) {
      console.warn('[CRM插件] 知乎编辑页未见发布设置面板，声明/专栏需手动设置');
      return false;
    }
    console.log('[CRM插件] 知乎编辑页发布设置面板已出现，开始补设置（封面/声明/专栏）');
    if (cfg.coverUrl) {
      try { await fillZhihuCover({ coverUrl: cfg.coverUrl }); } catch (e) { /* ignore */ }
    }
    if (cfg.declaration && cfg.declaration !== '无声明' && cfg.declaration !== '无') {
      try { await openLabelSelectAndPick('创作声明', cfg.declaration); } catch (e) { /* ignore */ }
    }
    if (cfg.column) {
      try { clickTextGlobal(cfg.column); } catch (e) { /* ignore */ }
    }
    // 尝试保存改动（编辑已发布文章需点保存提交，知乎编辑页按钮为「更新」；「保存草稿」不会被误中）。
    // 优先 button/[role=button] 精确匹配（findBtnInScope），再文本匹配兜底
    await sleep(1500);
    const SAVE_WORDS = ['保存并发布', '保存并更新', '更新文章', '保存修改', '更新', '保存'];
    let saved = false;
    for (const t of SAVE_WORDS) {
      const b = findBtnInScope(document.body, [t]);
      if (b) {
        try { b.click(); saved = true; console.log('[CRM插件] 已点击「' + t + '」按钮提交改动'); break; } catch (e) { /* ignore */ }
      }
    }
    if (!saved) {
      for (const t of SAVE_WORDS) {
        if (clickTextGlobal(t)) { saved = true; console.log('[CRM插件] 已点击「' + t + '」（文本匹配）提交改动'); break; }
      }
    }
    if (!saved) console.warn('[CRM插件] 未找到保存按钮，改动可能未提交，请在编辑页手动点「更新」');
    // 「更新」后知乎可能弹确认弹窗：出现「确认/确定」则补点
    if (saved) {
      // 打「已补设置」标记：点「更新」后的跳转会再次触发补传流程，凭此标记跳过重复编辑
      try { sessionStorage.setItem(doneKey, String(Date.now())); } catch (e) { /* ignore */ }
      await sleep(1200);
      const cb = findBtnInScope(document.body, ['确认', '确定']);
      if (cb) {
        try { cb.click(); console.log('[CRM插件] 已点击「确认」完成提交'); } catch (e) { /* ignore */ }
      }
    }
    return true;
  };

  /** 平台特化优先，未填充成功的部分再用通用选择器兜底 */
  async function fillWithFallback(cfg, job) {
    applyKeywordsToJob(job);
    const res = await fillByConfig(cfg, job, 8000);
    if (!res.titleFilled && (job && job.title)) {
      const t = await waitForSelector(GENERIC_CFG.title, 4000) || findEditableByPlaceholder('标题');
      if (t) {
        nativeSet(t, job.title);
        await sleep(800);
        res.titleFilled = editableValue(t).trim().length >= Math.min(4, job.title.length);
      }
    }
    if (!res.contentFilled) {
      res.contentFilled = await fillContent(GENERIC_CFG, job);
    }
    return res;
  }

  // ==================== 填充入口 ====================

  /** 通用填充（兜底）：不依赖任何平台特化配置 */
  CRM.genericFill = function (job) {
    return fillByConfig(GENERIC_CFG, job, 10000);
  };

  /** 各平台特化：命中自身选择器，失败自动回落通用 */
  CRM.fillers = Object.keys(SELECTORS).reduce((acc, code) => {
    acc[code] = function (job) {
      return fillWithFallback(SELECTORS[code], job);
    };
    return acc;
  }, {});

  // ==================== 图片上传辅助 ====================

  /** data URL 转 File */
  function dataUrlToFile(dataUrl, filename) {
    try {
      const m = /^data:([^;]+);base64,(.*)$/.exec(dataUrl);
      if (!m) return null;
      const bin = atob(m[2]);
      const arr = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
      return new File([arr], filename || 'image', { type: m[1] || 'image/jpeg' });
    } catch (e) { return null; }
  }

  /** 经后台代取图片转 data URL（https 页面拦截 http://localhost 图片，后台不受限） */
  function fetchImageDataUrl(url) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type: 'fetchImage', url: url }, (r) => resolve(r && r.ok ? r.dataUrl : null));
      } catch (e) { resolve(null); }
    });
  }

  /** data URL 转 File；SVG 平台（如小红书）不收，先经 canvas 转成 JPEG */
  async function dataUrlToUploadFile(dataUrl, filename) {
    if (!/^data:image\/svg/i.test(dataUrl)) return dataUrlToFile(dataUrl, filename);
    try {
      const img = new Image();
      await new Promise((res, rej) => { img.onload = res; img.onerror = rej; img.src = dataUrl; });
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth || 800;
      canvas.height = img.naturalHeight || 600;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      return dataUrlToFile(canvas.toDataURL('image/jpeg', 0.92), 'cover.jpg');
    } catch (e) { return dataUrlToFile(dataUrl, filename); }
  }

  /** 把 File 塞进文件选择框并触发 change（模拟用户选图） */
  function putFileToInput(input, file) {
    try {
      const dt = new DataTransfer();
      dt.items.add(file);
      input.files = dt.files;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    } catch (e) { return false; }
  }

  /** 图文类平台通用准备：切到指定内容类型标签 → 自动上传封面图 → 等编辑器挂载（标题框出现） */
  async function prepareImagePlatform(job, tabText) {
    const titleSel = 'textarea[placeholder*="标题"], input[placeholder*="标题"], [class*="TitleInput"] input, [class*="title-input"] input';
    // SPA 渲染慢时 tab 可能延迟出现：轮询重试切换（最多约 12 秒），抖音等平台在此处易超时
    for (let i = 0; i < 10; i++) {
      if (document.querySelector(titleSel)) break;
      const tabs = deepQueryAll(document, 'div, span, a, [role="tab"], [class*="tab"]');
      let clicked = false;
      for (const el of tabs) {
        const t = ((el.innerText || '') + '').trim();
        if (t !== tabText) continue;
        try {
          const r = el.getBoundingClientRect();
          if (r.width < 5 || r.height < 5) continue;
        } catch (e) { /* ignore */ }
        el.click();
        clicked = true;
        await sleep(1500);
        break;
      }
      if (!clicked) await sleep(1000);
      if (clicked && (document.querySelector(titleSel) || document.querySelector('input[type="file"]'))) break;
    }
    // 自动上传封面图：找图片类文件输入框（跳过视频上传框）
    const hasImage = document.querySelector('[class*="img-preview"], [class*="preview"], img[src^="blob:"]');
    const isImageInput = (el) => {
      const acc = (el.accept || '').toLowerCase();
      // accept 可能是扩展名列表（如小红书 ".jpg,.jpeg,.png,.webp"），不含 "image" 字样
      return !acc || acc.indexOf('image') >= 0 || /\.(jpe?g|png|webp|gif|bmp|svg)/.test(acc);
    };
    const fileInput = deepQueryAll(document, 'input[type="file"]').find((el) => {
      try { return isImageInput(el); } catch (e) { return false; }
    });
    if (job && job.coverUrl && !hasImage && fileInput) {
      const dataUrl = await fetchImageDataUrl(job.coverUrl);
      const file = dataUrl ? await dataUrlToUploadFile(dataUrl, 'cover.jpg') : null;
      if (file && putFileToInput(fileInput, file)) {
        // 等编辑器挂载（标题框出现说明上传完成进入编辑态）
        const start = Date.now();
        while (Date.now() - start < 15000) {
          if (document.querySelector(titleSel)) break;
          await sleep(500);
        }
      }
    }
    return true;
  }

  /** 在 root 内查找包含指定文本的文本节点 */
  function findTextNode(root, token) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = walker.nextNode())) {
      if (n.textContent && n.textContent.indexOf(token) >= 0) return n;
    }
    return null;
  }

  // ==================== 图片占位符方案（通用） ====================
  // 多数平台编辑器（wangEditor/DraftJS/TinyMCE/CodeMirror 等）不接受 Base64 图片，
  // 或粘进去后不会真正上传导致发布报错。统一方案：
  // 1) prepare 阶段把 data URL 图片替换为 [[CRM_IMG_n]] 占位符随 HTML 粘贴；
  // 2) afterFill 阶段在占位符位置逐个「文件粘贴」，走编辑器自带上传流程。

  /** 把正文 HTML 中的 data URL 图片替换为占位符，图片 data URL 存入 job._crmImages。
   *  tokenFn(n)：自定义占位符格式（CSDN 的 Markdown 编辑器会把 [[xx]] 解析成引用式链接，
   *  正文会残留 ![xx][n] / [n]: url 片段，因此 CSDN 必须用不含方括号的占位符） */
  function preparePlaceholderImages(job, tokenFn) {
    try {
      if (!job || !job.contentHtml || job.contentHtml.indexOf('<img') < 0) return;
      const doc = new DOMParser().parseFromString(job.contentHtml, 'text/html');
      const imgs = Array.from(doc.querySelectorAll('img'));
      if (!imgs.length) return;
      const tokenOf = tokenFn || ((n) => '[[CRM_IMG_' + n + ']]');
      job._crmTokenFn = tokenOf;
      job._crmImages = [];
      imgs.forEach((img, i) => {
        const src = (img.getAttribute('src') || '').trim();
        if (/^data:image\//i.test(src)) {
          job._crmImages.push(src);
          const p = doc.createElement('p');
          p.textContent = tokenOf(i + 1);
          img.replaceWith(p);
        } else {
          img.remove(); // 未内联成功的图直接移除，避免裂图
        }
      });
      job.contentHtml = doc.body.innerHTML;
    } catch (e) { /* 不阻塞填充 */ }
  }

  /** 定位 CodeMirror 6 的 EditorView（掘金 bytemd / CSDN Markdown 等基于 CM6 的编辑器）。
   *  CM6 内部 state 与 DOM 分离：合成粘贴/DOM 选区常不生效，须用 cmView 事务直接改内部 state。
   *  cmView 挂载位置因版本而异（.cm-editor 或 .cm-content 上），逐层探测。 */
  function findCmView(el) {
    try {
      const root = (el && el.closest && el.closest('.cm-editor')) || document.querySelector('.cm-editor');
      if (!root) return null;
      const probeList = [root, root.querySelector('.cm-content')];
      for (const start of probeList) {
        let o = start && start.cmView;
        for (let d = 0; o && d < 4; d++) {
          if (o.state && o.state.doc && o.dispatch) return o;
          if (o.view && o.view.state && o.view.state.doc && o.view.dispatch) return o.view;
          o = o.view || o.parent;
        }
      }
    } catch (e) { /* ignore */ }
    return null;
  }

  /** 用 CM6 事务在内部 state 里删除第一个匹配 tokRe 的片段，并把光标定位到原位置。
   *  返回 true 表示已删除（state 已更新），false 表示未找到/不可用。 */
  function cm6DeleteToken(cmv, probe, tokRe) {
    try {
      if (!cmv || !cmv.state || !cmv.dispatch) return false;
      const docStr = cmv.state.doc.toString();
      const idx = docStr.indexOf(probe);
      if (idx < 0) return false;
      let len = probe.length;
      if (tokRe) {
        const m = new RegExp(tokRe.source, tokRe.flags.replace('g', '')).exec(docStr.slice(idx, idx + 300));
        if (m && m.index === 0) len = m[0].length;
      }
      cmv.dispatch({ changes: { from: idx, to: idx + len }, selection: { anchor: idx }, scrollIntoView: true });
      try { cmv.focus(); } catch (e) { /* ignore */ }
      return true;
    } catch (e) { return false; }
  }

  /** 定位 CodeMirror 5 实例（掘金编辑器实测为 CM5：wrapper 元素上挂有 .CodeMirror 属性，
   *  与 CM6 的 cmView 不同，且正文不暴露 contenteditable，DOM 操作全部无效）。
   *  兜底：部分打包版本实例可能挂在其他 expando 属性/隐藏 textarea 上，逐层扫描。 */
  function findCm5(el) {
    try {
      const root = (el && el.closest && el.closest('.CodeMirror')) || document.querySelector('.CodeMirror');
      if (!root) return null;
      if (root.CodeMirror && root.CodeMirror.getValue && root.CodeMirror.getValue) return root.CodeMirror;
      const isCm = (v) => v && typeof v === 'object' && typeof v.getValue === 'function' && v.display && v.display.wrapper;
      if (root.querySelector) {
        const ta = root.querySelector('textarea');
        if (ta && isCm(ta.CodeMirror)) return ta.CodeMirror;
      }
      // 扫描 wrapper 自身与子元素的 expando 属性（实例挂载键名可能不同）
      const scan = (node) => {
        if (!node || node.nodeType !== 1) return null;
        try {
          for (const k of Object.keys(node)) { if (isCm(node[k])) return node[k]; }
        } catch (e) { /* ignore */ }
        return null;
      };
      let hit = scan(root);
      if (hit) return hit;
      for (const c of root.querySelectorAll('*')) { hit = scan(c); if (hit) return hit; }
      return null;
    } catch (e) { return null; }
  }

  /** 循环删除编辑器内残留的图片占位符。
   *  受控编辑器（CodeMirror 等）内部 state 与 DOM 选区可能不同步，合成删除每次可能只删掉
   *  一个字符，因此这里循环「重新定位 → 选中 → 删除」，直到占位符完全消失（或达最大次数）。
   *  probe：占位符公共前缀；tokRe：宽松正则（可匹配被部分删除后的残片）。 */
  async function deleteResidualTokens(probe, tokRe, maxTries) {
    CRM.deleteResidualTokens = deleteResidualTokens; // 供 content.js 接管/跳过流程复用
    const bodyHas = () => ((document.body.innerText || '').indexOf(probe) >= 0);
    for (let k = 0; k < (maxTries || 30) && bodyHas(); k++) {
      const eds = Array.from(document.querySelectorAll('[contenteditable="true"]'));
      const ed = eds.find((e) => (e.innerText || '').indexOf(probe) >= 0) || document.body;
      // CM6（掘金 bytemd / CSDN Markdown 等）：DOM 选区/合成删除不进内部 state，
      // 优先用 cmView 事务直接删，删完重新走循环条件检查
      if (cm6DeleteToken(findCmView(ed), probe, tokRe)) { await sleep(300); continue; }
      // CM5（掘金编辑器实测为 CM5）：用实例 API 直接改文档
      try {
        const cm5 = findCm5(ed);
        const s5 = cm5 ? cm5.getValue() : '';
        const i5 = s5.indexOf(probe);
        if (i5 >= 0) {
          let len5 = probe.length;
          const m5 = tokRe ? new RegExp(tokRe.source, tokRe.flags.replace('g', '')).exec(s5.slice(i5, i5 + 300)) : null;
          if (m5 && m5.index === 0) len5 = m5[0].length;
          cm5.replaceRange('', cm5.posFromIndex(i5), cm5.posFromIndex(i5 + len5));
          await sleep(300);
          continue;
        }
        // state 不含占位符但 DOM 仍残留（state 与 DOM 分裂）：state 是发布数据源，
        // 直接对 DOM 文本节点做确定性切除，让守卫检查通过（CM5 非 contenteditable
        // 时 execCommand 合成删除必失效，之前就是卡在这里空转 40 轮）
        const idoc5 = ed.ownerDocument || document;
        const w5 = idoc5.createTreeWalker(ed, NodeFilter.SHOW_TEXT);
        let tn5 = null, cut5 = false;
        while ((tn5 = w5.nextNode())) {
          if (tn5.nodeValue && tn5.nodeValue.indexOf(probe) >= 0) {
            const m6 = tokRe ? new RegExp(tokRe.source, tokRe.flags.replace('g', '')).exec(tn5.nodeValue) : null;
            if (m6) { tn5.nodeValue = tn5.nodeValue.replace(m6[0], ''); cut5 = true; }
          }
        }
        if (cut5) {
          console.warn('[CRM插件] CM5 state 与 DOM 分裂，已直接切除 DOM 残留占位符（请发布后核对正文图片）');
          await sleep(300);
          continue;
        }
      } catch (e) { /* 回退 DOM 清理 */ }
      const idoc = ed.ownerDocument || document;
      const win = idoc.defaultView || window;
      const walker = idoc.createTreeWalker(ed, NodeFilter.SHOW_TEXT);
      let tn = null, n;
      while ((n = walker.nextNode())) {
        if (n.textContent && n.textContent.indexOf(probe) >= 0) { tn = n; break; }
      }
      if (!tn) break;
      const m = tn.textContent.match(tokRe);
      if (!m) break;
      const tok = m[0];
      const idx = tn.textContent.indexOf(tok);
      try { ed.focus(); } catch (e) { /* ignore */ }
      await sleep(200);
      const r = idoc.createRange();
      r.setStart(tn, idx);
      r.setEnd(tn, idx + tok.length);
      const sel = win.getSelection() || idoc.getSelection();
      sel.removeAllRanges();
      sel.addRange(r);
      try { idoc.dispatchEvent(new Event('selectionchange')); } catch (e) { /* ignore */ }
      await sleep(300);
      try { ed.dispatchEvent(new InputEvent('beforeinput', { inputType: 'deleteContentBackward', bubbles: true, cancelable: true })); } catch (e) { /* ignore */ }
      await sleep(250);
      if (bodyHas()) { try { idoc.execCommand('delete'); } catch (e) { /* ignore */ } await sleep(200); }
      if (bodyHas()) {
        try { ed.dispatchEvent(new KeyboardEvent('keydown', { key: 'Backspace', code: 'Backspace', bubbles: true, cancelable: true })); } catch (e) { /* ignore */ }
        await sleep(250);
      }
    }
    return !bodyHas();
  }

  /** 在指定编辑器内把占位符逐个替换为真实图片。
   *  关键：DraftJS 等受控编辑器的内部 state 与 DOM 分离，外部 DOM 改动不进内部 state（发布仍带占位符）。
   *  主路径：聚焦 → 选中占位符整体 → 直接文件粘贴（粘贴语义=替换选区，位置与删除一步到位，走内部 state）。
   *  若 12 秒后占位符仍在（部分编辑器文件粘贴不替换选区），再补「空格替换选区」删除占位符文本。 */
  async function pasteImagesAtPlaceholders(job, editor, tokenFn, useInsertHtml) {
    const imgs = (job && job._crmImages) || [];
    if (!imgs.length || !editor) return;
    const idoc = editor.ownerDocument;
    const win = idoc.defaultView;
    const isvg = /^data:image\/svg/i;
    const tokenOf = tokenFn || (job && job._crmTokenFn) || ((n) => '[[CRM_IMG_' + n + ']]');
    const findTokenNode = (token, root) => {
      const walker = idoc.createTreeWalker(root || editor, NodeFilter.SHOW_TEXT);
      let n;
      while ((n = walker.nextNode())) {
        if (n.textContent && n.textContent.indexOf(token) >= 0) return n;
      }
      return null;
    };
    // 编辑器选错兜底（如百家号新版编辑器标题框也是 contenteditable 且排在正文前）：
    // 占位符不在当前编辑器内时，遍历全部可见 contenteditable 找到真正含占位符的那个再继续
    if (!findTokenNode(tokenOf(1))) {
      const alt = deepQueryAll(idoc, '[contenteditable="true"]').find((ed) => ed !== editor && findTokenNode(tokenOf(1), ed));
      if (alt) {
        console.log('[CRM插件] 图片占位符不在原编辑器内（可能命中了标题框），已切换到实际含占位符的编辑器：class=' + ((alt.className || '') + '').slice(0, 60));
        editor = alt;
      }
    }
    const dispatchPaste = (dt) => {
      try { editor.dispatchEvent(new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dt })); } catch (e) { /* ignore */ }
    };
    /** 清理占位符残留碎片：受控编辑器分段删除常留下 ] 或 [[CRM_IMG_ 残迹（实测百家号每图残留一个 ]）。
     *  删两类：a) [[CRM_IMG_x]] 碎片；b) 整个文本节点就只有孤立 ]/]] 的（正文里正常的括号不会单独成节点） */
    const cleanupResidual = async () => {
      const re = /\[\[CRM_IMG_\d*\]?\]*/g;
      for (let k = 0; k < 6; k++) {
        let cut = false;
        for (let round = 0; round < 2 && !cut; round++) {
          const walker = idoc.createTreeWalker(editor, NodeFilter.SHOW_TEXT);
          const targets = [];
          let tn;
          while ((tn = walker.nextNode())) {
            const v = tn.nodeValue || '';
            re.lastIndex = 0;
            const m = re.exec(v);
            if (m) { targets.push({ node: tn, idx: v.indexOf(m[0]), len: m[0].length }); continue; }
            const tv = v.trim();
            if (tv === ']' || tv === ']]') targets.push({ node: tn, idx: v.indexOf(tv), len: tv.length });
          }
          if (!targets.length) break;
          for (const t of targets) {
            try {
              const sel = win.getSelection();
              const r = idoc.createRange();
              r.setStart(t.node, t.idx);
              r.setEnd(t.node, t.idx + t.len);
              editor.focus();
              sel.removeAllRanges();
              sel.addRange(r);
              idoc.execCommand('delete');
              cut = true;
              await sleep(150);
            } catch (e) { /* ignore */ }
          }
          await sleep(300);
        }
        if (!cut) break;
      }
    };
    // 选中占位符整体（先聚焦再设选区，等待编辑器同步进内部 state）
    const selectToken = async (token) => {
      const n2 = findTokenNode(token);
      if (!n2) return null;
      try { editor.focus(); } catch (e) { /* ignore */ }
      await sleep(250);
      const idx = n2.textContent.indexOf(token);
      const r = idoc.createRange();
      r.setStart(n2, idx);
      r.setEnd(n2, idx + token.length);
      win.getSelection().removeAllRanges();
      win.getSelection().addRange(r);
      // CodeMirror 等受控编辑器需要 selectionchange 事件才会把 DOM 选区同步进内部 state
      try { idoc.dispatchEvent(new Event('selectionchange')); } catch (e) { /* ignore */ }
      await sleep(400);
      return n2;
    };
    for (let i = 0; i < imgs.length; i++) {
      const token = tokenOf(i + 1);
      const node = findTokenNode(token);
      if (!node) { console.warn('[CRM插件] 未找到图片占位符：' + token); continue; }
      try {
        // 0) insertHTML 模式：51CTO 编辑器忽略合成的文件粘贴（img 数不增、占位符白删），
        //    改为选中占位符后 execCommand insertHTML 直接插入 data URL 图（一步替换），
        //    编辑器上传链路会自动转存为平台图床地址；未生效再退回文件粘贴
        if (useInsertHtml) {
          await selectToken(token);
          const imgBefore = editor.querySelectorAll('img').length;
          let okIns = false;
          try { okIns = idoc.execCommand('insertHTML', false, '<img src="' + imgs[i] + '">'); } catch (e) { okIns = false; }
          await sleep(1200);
          if (okIns && editor.querySelectorAll('img').length > imgBefore) {
            console.log('[CRM插件] 图片 ' + (i + 1) + ' 已通过 insertHTML 插入，等待编辑器转存上传');
            await sleep(800);
            continue;
          }
          console.warn('[CRM插件] 图片 ' + (i + 1) + ' insertHTML 未生效，改用文件粘贴');
        }
        const blob = await (await fetch(imgs[i])).blob();
        const file = new File([blob], 'crm-image-' + (i + 1) + (isvg.test(imgs[i]) ? '.png' : '.jpg'), { type: blob.type || 'image/png' });
        // 0b2) CodeMirror 5（掘金编辑器实测为 CM5）：用实例 API 把占位符设为选区，
        //      再在输入框上派发文件粘贴（走掘金自身上传链路）；粘贴未生效则删占位符保发布
        try {
          const cm5 = findCm5(editor);
          if (!cm5) console.warn('[CRM插件] 未定位到 CM5 实例（wrapper.CodeMirror 属性缺失），改走通用粘贴');
          const s5 = cm5 ? cm5.getValue() : '';
          const p5 = s5.indexOf(token);
          if (cm5 && p5 < 0) console.warn('[CRM插件] CM5 实例 state 不含 ' + token + '（state 是发布数据源，正文可能未被编辑器真正收录）');
          if (cm5 && p5 >= 0) {
            cm5.focus();
            const from = cm5.posFromIndex(p5);
            const to = cm5.posFromIndex(p5 + token.length);
            cm5.setSelection(from, to);
            const dt5 = new DataTransfer();
            dt5.items.add(file);
            const inp5 = cm5.getInputField ? cm5.getInputField() : null;
            (inp5 || cm5.display.wrapper).dispatchEvent(new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dt5 }));
            await sleep(2500);
            if (cm5.getValue().indexOf(token) < 0) {
              console.log('[CRM插件] 图片 ' + (i + 1) + ' 已通过 CodeMirror 实例选区+文件粘贴插入（掘金）');
              await sleep(800);
              continue;
            }
            // 粘贴未被编辑器处理：删占位符保证发布不残留（不因单图卡死整篇）
            try { cm5.replaceRange('', from, to); } catch (e5) { /* ignore */ }
            if (cm5.getValue().indexOf(token) >= 0) cm5.setValue(cm5.getValue().split(token).join(''));
            console.warn('[CRM插件] 图片 ' + (i + 1) + ' CodeMirror 粘贴未生效，已删除占位符（发布后请手动补图）');
            continue;
          }
        } catch (eCM5) { /* 回退通用流程 */ }
        // 0a) textarea 编辑器（bytemd 无 CM 插件时的兜底形态）：光标定位到占位符删除后，
        //     在原位置派发文件粘贴（编辑器 paste 处理器负责上传）；未生效则还原占位符
        if ((editor.tagName || '') === 'TEXTAREA') {
          try {
            const pos = (editor.value || '').indexOf(token);
            if (pos >= 0) {
              editor.focus();
              editor.setSelectionRange(pos, pos + token.length);
              try { editor.setRangeText('', pos, pos + token.length, 'end'); } catch (e2) { /* ignore */ }
              editor.dispatchEvent(new Event('input', { bubbles: true }));
              await sleep(400);
              const dtT = new DataTransfer();
              dtT.items.add(file);
              editor.dispatchEvent(new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dtT }));
              await sleep(2500);
              if ((editor.value || '').indexOf(token) < 0) {
                console.log('[CRM插件] 图片 ' + (i + 1) + ' 已在 textarea 编辑器内粘贴替换');
                await sleep(800);
                continue;
              }
              try { editor.setRangeText(token, Math.min(editor.selectionStart || pos, (editor.value || '').length), Math.min(editor.selectionStart || pos, (editor.value || '').length), 'end'); editor.dispatchEvent(new Event('input', { bubbles: true })); } catch (e3) { /* ignore */ }
              console.warn('[CRM插件] 图片 ' + (i + 1) + ' textarea 粘贴未生效，回退通用流程');
            }
          } catch (eTA) { /* 回退通用流程 */ }
        }
        // 0b) CM6（掘金 bytemd 等）：合成选区对内部 state 常年不生效 →
        //     用 cmView 事务删占位符并把光标定位到原位置，再派发文件粘贴让编辑器自行上传
        try {
          const cmv = findCmView(editor);
          if (cmv && cm6DeleteToken(cmv, token, null)) {
            await sleep(500);
            const dt0 = new DataTransfer();
            dt0.items.add(file);
            dispatchPaste(dt0);
            await sleep(2500);
            if (!findTokenNode(token)) {
              console.log('[CRM插件] 图片 ' + (i + 1) + ' 已通过 CM6 内部事务+文件粘贴插入（CodeMirror 编辑器）');
              await sleep(800);
              continue;
            }
            console.warn('[CRM插件] 图片 ' + (i + 1) + ' CM6 事务后粘贴未生效，回退通用粘贴流程');
          }
        } catch (eCM) { /* 回退通用流程 */ }
        // 1) 选中占位符整体 → 粘贴空格替换选区（已验证有效：占位符删除，光标留在原占位符位置）
        await selectToken(token);
        const dt2 = new DataTransfer();
        dt2.setData('text/plain', ' ');
        dispatchPaste(dt2);
        await sleep(800);
        // 1b) 受控编辑器（如 CSDN 的 CodeMirror）可能忽略合成 paste：
        //     先派发 beforeinput deleteContentBackward（CM6 监听 beforeinput 按内部选区删除）
        if (findTokenNode(token)) {
          try { editor.dispatchEvent(new InputEvent('beforeinput', { inputType: 'deleteContentBackward', bubbles: true, cancelable: true })); } catch (e2) { /* ignore */ }
          await sleep(400);
        }
        // 1c) 仍残留时改用 execCommand 删除选区
        if (findTokenNode(token)) {
          try { idoc.execCommand('delete'); } catch (e2) { /* ignore */ }
          await sleep(300);
        }
        // 1d) 最后派发 Backspace 键（部分编辑器 keymap 监听 keydown 删除选区）
        if (findTokenNode(token)) {
          try { editor.dispatchEvent(new KeyboardEvent('keydown', { key: 'Backspace', code: 'Backspace', bubbles: true, cancelable: true })); } catch (e2) { /* ignore */ }
          await sleep(300);
        }
        // 2) 光标此时在原占位符位置 → 粘贴图片文件（编辑器在光标处插入并上传）
        const dt = new DataTransfer();
        dt.items.add(file);
        dispatchPaste(dt);
        await sleep(2000);
        if (findTokenNode(token)) {
          console.warn('[CRM插件] 占位符「' + token + '」未能删除，启动循环清理');
          // 宽松正则兜底：受控编辑器可能每次只删部分字符，循环删到彻底消失
          const probe = token.replace(/\d+.*$/, '') || token;
          const tokRe = new RegExp(token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\d+.*$/, '') + '[A-Za-z0-9]*');
          await deleteResidualTokens(probe, tokRe, 40);
        }
        // 无论成功与否都清一遍残留碎片（[[CRM_IMG_ 碎片 / 孤立 ]），消除正文里的多余括号
        await cleanupResidual();
        if (findTokenNode(token)) console.warn('[CRM插件] 占位符「' + token + '」仍未能删除，发布前请手动处理');
        else console.log('[CRM插件] 图片 ' + (i + 1) + ' 已粘贴（先删占位符再在原位置插入图片）');
      } catch (e) {
        console.warn('[CRM插件] 图片文件粘贴失败：', e && e.message);
      }
      await sleep(800);
    }
  }

  /** 可见可编辑区域粗判（深度查询兜底时过滤隐藏元素/标题框） */
  function visibleEditableBox(el) {
    if (!el) return false;
    try {
      const r = el.getBoundingClientRect();
      return r.width > 40 && r.height > 20;
    } catch (e) { return false; }
  }

  /** 定位当前平台的富文本编辑器（含 iframe），按候选选择器轮询等待。
   *  timeout 可调：掘金等 SPA 编辑器水合慢，填充时可能还没有任何 contenteditable。
   *  常规 querySelector 落空时用 deepQueryAll 穿透 Shadow DOM 再找一轮。 */
  async function findEditorForImages(sels, timeout) {
    // 支持传入自定义定位函数（如百家号 bjhContentEl：正文锚点排除法 + 跨 iframe）
    if (typeof sels === 'function') {
      const start = Date.now();
      while (Date.now() - start < (timeout || 6000)) {
        try { const el = await sels(); if (el) return el; } catch (e) { /* ignore */ }
        await sleep(300);
      }
      return null;
    }
    const candidates = (sels || []).concat(['[contenteditable="true"]']);
    const start = Date.now();
    while (Date.now() - start < (timeout || 6000)) {
      for (const s of candidates) {
        const el = editableOf(queryDoc(s));
        if (el) return el;
      }
      // Shadow DOM 兜底：编辑器若在 web components 内，常规 querySelector 永远查不到
      for (const s of candidates) {
        const el = deepQueryAll(document, s).find(visibleEditableBox);
        if (el) return el;
      }
      await sleep(300);
    }
    return null;
  }

  /** 生成各平台通用的 afterFill：等编辑器就绪后在占位符位置粘贴图片 */
  function makeImagePasteAfterFill(sels, tokenFn, useInsertHtml, waitMs) {
    return async (job) => {
      const imgs = (job && job._crmImages) || [];
      if (!imgs.length) return;
      try {
        await sleep(800);
        const editor = await findEditorForImages(sels, waitMs);
        if (!editor) {
          // DOM 诊断：下次排查不再靠猜（常规/深度计数 + 关键结构存在性）
          try {
            const cnt = (sel) => deepQueryAll(document, sel).length;
            const census = [
              '常规[contenteditable]=' + document.querySelectorAll('[contenteditable="true"]').length,
              '深度[contenteditable]=' + cnt('[contenteditable="true"]'),
              'cm-editor=' + cnt('.cm-editor'),
              'cm-content=' + cnt('.cm-content'),
              'textarea=' + cnt('textarea')
            ].join(' | ');
            console.warn('[CRM插件] 未找到编辑器，图片占位符未替换（DOM 诊断：' + census + '）');
          } catch (e) {
            console.warn('[CRM插件] 未找到编辑器，图片占位符未替换');
          }
          return;
        }
        await pasteImagesAtPlaceholders(job, editor, tokenFn, useInsertHtml);
      } catch (e) { /* 不阻塞后续发布 */ }
    };
  }

  /** 51CTO 三步直传（页面同源请求版）：在内容脚本里直接发 getUploadSign → getUploadConfig →
   *  COS multipart POST。内容脚本 fetch 与页面同源，Origin/Referer/Cookie 与真实上传完全一致，
   *  避免 background（Origin 为 chrome-extension://）被服务端以「参数错误」拒绝。
   *  返回图床 https 地址。 */
  async function cto51UploadViaPage(dataUrl, nameHint) {
    const mimeM = /^data:([^;,]+)/i.exec(dataUrl || '');
    const mime = ((mimeM && mimeM[1]) || 'image/jpeg').toLowerCase();
    const extMap = { 'image/jpeg': 'jpg', 'image/jpg': 'jpg', 'image/png': 'png', 'image/gif': 'gif', 'image/webp': 'webp', 'image/svg+xml': 'svg' };
    const ext = extMap[mime] || 'jpg';
    const fname = ((nameHint || ('crm-img-' + Date.now())).replace(/\.[a-z0-9]+$/i, '')) + '.' + ext;
    const blob = await (await fetch(dataUrl)).blob();
    if (blob.size > 10485760) throw new Error('图片超过 51CTO 10M 上限');
    const postJson = async (url, params) => {
      const r = await fetch(url, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest' },
        body: new URLSearchParams(params).toString()
      });
      return r.json().catch(() => null);
    };
    // ① 签名
    const j1 = await postJson('https://blog.51cto.com/getUploadSign', { upload_type: 'image' });
    if (!j1 || j1.code !== 0 || !j1.data || !j1.data.sign) {
      throw new Error('getUploadSign 失败：' + JSON.stringify(j1 || {}).slice(0, 200));
    }
    // ② 上传配置（url + fields{key/policy/x-amz-*}，凭证在 data.fields 下）
    const j2 = await postJson('https://blog.51cto.com/getUploadConfig', { upload_type: 'image', upload_sign: j1.data.sign, ext: mime, name: fname });
    const d2 = j2 && j2.data;
    const f2 = d2 && (d2.fields || d2);
    if (!d2 || !d2.url || !f2 || !f2.key || !f2.policy) {
      throw new Error('getUploadConfig 失败：' + JSON.stringify(j2 || {}).slice(0, 300));
    }
    // ③ COS 表单直传（按服务端返回的 fields 原样提交，file 必须最后一个字段）
    const fd3 = new FormData();
    Object.keys(f2).forEach((k) => { if (k !== 'file' && f2[k] != null) fd3.append(k, String(f2[k])); });
    if (!Object.keys(f2).some((k) => k.toLowerCase() === 'content-type')) fd3.append('content-type', mime);
    fd3.append('file', blob, fname);
    const r3 = await fetch(d2.url, { method: 'POST', body: fd3 });
    if (r3.status !== 200 && r3.status !== 204) throw new Error('COS 上传失败：HTTP ' + r3.status);
    return d2.url.replace(/\/+$/, '') + '/' + f2.key;
  }

  /** 51CTO API 直传（主路径）：复刻页面三步上传链路
   *  （getUploadSign → getUploadConfig → COS multipart POST），
   *  拿到图床 https 地址后在编辑器内选中占位符 insertHTML 替换为正式图。
   *  不依赖文件选择框/CDP/用户手动操作。返回成功替换的图片数。 */
  async function cto51ApiUploadAndReplace(job, imgs) {
    const tokenOf = (job && job._crmTokenFn) || ((n) => '[[CRM_IMG_' + n + ']]');
    const editor = await findEditorForImages(['[contenteditable="true"]']);
    if (!editor) { console.warn('[CRM插件] 51CTO API 直传未找到编辑器'); return 0; }
    const idoc = editor.ownerDocument;
    const win = idoc.defaultView || window;
    const findTokenNode = (token) => {
      const walker = idoc.createTreeWalker(editor, NodeFilter.SHOW_TEXT);
      let n;
      while ((n = walker.nextNode())) {
        if (n.textContent && n.textContent.indexOf(token) >= 0) return n;
      }
      return null;
    };
    let ok = 0;
    for (let i = 0; i < imgs.length; i++) {
      const token = tokenOf(i + 1);
      const node = findTokenNode(token);
      if (!node) { ok++; continue; } // 占位符已被其他路径处理
      try {
        console.log('[CRM插件] 51CTO 图片 ' + (i + 1) + '/' + imgs.length + ' 走 API 直传…');
        // 主：页面同源请求（与真实上传的 Origin/Referer 完全一致）；备：background 请求
        let url = null, err1 = null;
        try { url = await cto51UploadViaPage(imgs[i], 'crm-img-' + (i + 1) + '-' + Date.now()); } catch (e) { err1 = e; }
        if (!url) {
          const r = await new Promise((res) => {
            try {
              const p = chrome.runtime.sendMessage({ type: 'crmCto51Upload', dataUrl: imgs[i], name: 'crm-img-' + (i + 1) + '-' + Date.now() });
              if (p && p.then) p.then(res).catch(() => res(null)); else res(null);
            } catch (e) { res(null); }
          });
          if (r && r.ok && r.url) url = r.url;
          else console.warn('[CRM插件] 51CTO 图片 ' + (i + 1) + ' 页面同源直传失败：' + ((err1 && err1.message) || '')
            + '；后台直传失败：' + ((r && r.message) || '无响应') + '，回退编辑器上传通道');
        }
        if (!url) break;
        const r = { ok: true, url };
        // 选中占位符 → insertHTML 替换为正式图（编辑器认可的写入路径，与原生上传完成后的状态一致）
        try { editor.focus(); } catch (e) { /* ignore */ }
        const idx = node.textContent.indexOf(token);
        const rng = idoc.createRange();
        rng.setStart(node, idx);
        rng.setEnd(node, idx + token.length);
        const sel = win.getSelection();
        sel.removeAllRanges();
        sel.addRange(rng);
        try { idoc.dispatchEvent(new Event('selectionchange')); } catch (e) { /* ignore */ }
        await sleep(250);
        const before = editor.querySelectorAll('img').length;
        let ins = false;
        try { ins = idoc.execCommand('insertHTML', false, '<img src="' + r.url + '">'); } catch (e) { ins = false; }
        await sleep(500);
        if (!ins || editor.querySelectorAll('img').length <= before) {
          // execCommand 未生效时 DOM 直接替换兜底（富文本编辑器以 DOM 为序列化来源）
          const img = idoc.createElement('img');
          img.setAttribute('src', r.url);
          try { rng.deleteContents(); rng.insertNode(img); } catch (e2) { /* ignore */ }
          await sleep(300);
        }
        if (findTokenNode(token)) console.warn('[CRM插件] 51CTO 占位符 ' + token + ' 替换后仍残留');
        ok++;
        console.log('[CRM插件] 51CTO 图片 ' + (i + 1) + ' 已 API 直传并回填：' + r.url);
      } catch (e) {
        console.warn('[CRM插件] 51CTO API 直传异常：', e && e.message);
        break;
      }
    }
    return ok;
  }

  /** 51CTO：把正文图片经编辑器原生上传通道提交。
   *  背景（v1.6.99~v1.7.1 实测）：编辑器忽略合成文件粘贴、不转存 DOM 插入的 data: 图；
   *  盲塞常驻 file input 也可能绑的不是编辑器上传回调（塞了无反应）。
   *  v1.7.2 改为验证式：① hook 工具栏「插入图片」按钮捕获其 file input（最可靠）；
   *  ② 无捕获则逐个候选 input 塞文件验证（编辑器出现新 img 才算有效，锁定后续用）；
   *  ③ 全部失败再试 drop 拖放兜底。返回成功插入的图片数。 */
  async function uploadCto51ImagesViaFileInput(job, imgs) {
    const tokenOf = (job && job._crmTokenFn) || ((n) => '[[CRM_IMG_' + n + ']]');
    const isImgInput = (el) => {
      const acc = (el.accept || '').toLowerCase();
      return !acc || acc.indexOf('image') >= 0 || /\.(jpe?g|png|webp|gif)/.test(acc);
    };
    const describe = (el) => {
      const path = [];
      let p = el.parentElement;
      for (let i = 0; i < 3 && p; i++) { path.push(((p.className || '') + '').slice(0, 40)); p = p.parentElement; }
      return 'accept=' + (el.accept || '空') + ' class=' + ((el.className || '') + '').slice(0, 40) + ' 父级=' + (path.join(' > ') || '无');
    };
    const editor = await findEditorForImages(['[contenteditable="true"]']);
    if (!editor) { console.warn('[CRM插件] 51CTO 未找到正文编辑器'); return 0; }
    const idoc = editor.ownerDocument;
    const win = idoc.defaultView || window;
    // 光标定位到占位符（编辑器把上传/拖放的图插在光标处）
    const placeCursorAtToken = async (token) => {
      let node = null;
      const walker = idoc.createTreeWalker(editor, NodeFilter.SHOW_TEXT);
      let n;
      while ((n = walker.nextNode())) { if (n.textContent && n.textContent.indexOf(token) >= 0) { node = n; break; } }
      if (!node) return false;
      try {
        try { editor.focus(); } catch (e) { /* ignore */ }
        await sleep(250);
        const idx = node.textContent.indexOf(token);
        const r = idoc.createRange();
        r.setStart(node, idx);
        r.setEnd(node, idx + token.length);
        const sel = win.getSelection();
        sel.removeAllRanges();
        sel.addRange(r);
        try { idoc.dispatchEvent(new Event('selectionchange')); } catch (e2) { /* ignore */ }
        await sleep(300);
        return true;
      } catch (e) { return false; }
    };
    const waitImgInsert = async (before, ms) => {
      const st = Date.now();
      while (Date.now() - st < ms) {
        await sleep(500);
        if (editor.querySelectorAll('img').length > before) return true;
      }
      return false;
    };
    const cleanupToken = async (token) => {
      if (((editor.innerText || '') + '').indexOf(token) < 0) return;
      const probe = token.replace(/\d+.*$/, '') || token;
      const tokRe = new RegExp(token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\d+.*$/, '') + '[A-Za-z0-9]*');
      try { await deleteResidualTokens(probe, tokRe, 20); } catch (e) { /* ignore */ }
    };
    // 候选 file input（排除封面/头像容器内的）
    const candidates = deepQueryAll(document, 'input[type="file"]').filter((el) => {
      if (!isImgInput(el)) return false;
      let p = el;
      for (let i = 0; i < 8 && p && p !== document.body; i++) {
        // cover/avatar/upload-img 等均为封面/头像/图片选择区，非正文编辑器上传通道
        if (/cover|avatar|upload-img|select-img/i.test((p.className || '') + '')) return false;
        p = p.parentElement;
      }
      return true;
    });
    // ① main-world hook 捕获：content script 与页面 JS 隔离（isolated world），
    //    直接 hook content 世界的 HTMLInputElement.prototype 拦不到页面编辑器代码。
    //    注入 main-world 脚本：页面代码调用 file input.click() 时打 data-crm-captured 标记
    //    （带毫秒时间戳，读标记时校验晚于 hookT0，避免读到历史标记的旧 input）
    let captured = null;
    const hookT0 = Date.now();
    try {
      const s = document.createElement('script');
      s.textContent = '(function(){if(window.__crmInputHook)return;window.__crmInputHook=1;var p=HTMLInputElement.prototype,o=p.click;p.click=function(){if(this&&this.type==="file"){try{this.setAttribute("data-crm-captured",String(Date.now()))}catch(e){}}return o.apply(this,arguments)};if(typeof window.showOpenFilePicker==="function"){var f=window.showOpenFilePicker;window.showOpenFilePicker=function(){try{document.documentElement.setAttribute("data-crm-picker",String(Date.now()))}catch(e){}return f.apply(this,arguments)}}})();';
      (document.head || document.documentElement).appendChild(s);
      s.remove();
    } catch (e) { /* CSP 拦截注入则退回候选验证 */ }
    // 读新标记（时间戳晚于 hookT0，且可按 except 排除已试过的 input）
    const readMarked = (except) => Array.from(document.querySelectorAll('input[type="file"][data-crm-captured]'))
      .filter((el) => parseInt(el.getAttribute('data-crm-captured'), 10) > hookT0 && (!except || except.indexOf(el) < 0))[0] || null;
    // 等待标记出现（含「插入图片」面板二次点击「本地上传」入口；面板文案做宽匹配）
    const UP_RE = /(本地上传|点击上传|上传图片|上传封面|选择图片|选择文件|从本地上传|上传)/;
    const awaitCapture = async (ms) => {
      const st = Date.now();
      while (Date.now() - st < ms) {
        captured = readMarked();
        if (captured) return;
        const up = Array.from(document.querySelectorAll('button, div, span, a, li, label'))
          .find((el) => {
            const t = ((el.textContent || '') + '').replace(/\s+/g, '');
            return t && t.length <= 8 && UP_RE.test(t) && elVisible(el);
          });
        if (up) { try { up.click(); } catch (e) { /* ignore */ } await sleep(500); continue; }
        await sleep(250);
      }
    };
    const escClear = () => { try { document.body.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true })); } catch (e) { /* ignore */ } };
    // ①a 特征查找：Quill/wangEditor 及常见自研编辑器图片按钮
    const btnSel = [
      'button.ql-image', '[class*="ql-image"]',
      '[class*="w-e-menu"] [title*="图"]',
      '[title*="图片"]', '[title*="图像"]', '[aria-label*="图片" i]',
      '[class*="toolbar" i] [class*="image" i]', '[class*="toolbar" i] [title*="图"]'
    ].join(',');
    const btn = Array.from(document.querySelectorAll(btnSel)).reverse().find((el) => {
      try { const r = el.getBoundingClientRect(); return r.width > 8 && r.width < 80 && r.height > 8 && r.height < 80 && elVisible(el); } catch (e) { return false; }
    });
    if (btn) {
      console.log('[CRM插件] 51CTO 已点工具栏图片按钮（' + ((btn.title || btn.getAttribute('aria-label') || btn.className || '') + '').slice(0, 30) + '）');
      try { btn.click(); } catch (e) { /* ignore */ }
      await awaitCapture(4000);
      escClear();
    }
    // ①b 工具栏候选（合成试探与 CDP 真实点击共用）：51CTO 工具栏按钮无任何 title/aria/class 特征
    let cand = [];
    if (!captured) {
      let scope = editor.parentElement;
      for (let i = 0; i < 4 && scope; i++) {
        try { if (scope.getBoundingClientRect().height < 600) break; } catch (e) { /* ignore */ }
        scope = scope.parentElement;
      }
      cand = Array.from((scope || document).querySelectorAll('button, span, i, svg, div, em, b, a, li')).filter((el) => {
        if (editor.contains(el)) return false;
        const t = ((el.innerText || el.textContent || '') + '').replace(/\s+/g, '');
        if (/发布|保存|草稿|定时|预览|帮助|设置/.test(t)) return false;
        try {
          const r = el.getBoundingClientRect();
          return r.width >= 12 && r.width <= 60 && r.height >= 12 && r.height <= 60 && elVisible(el);
        } catch (e) { return false; }
      });
      // 排序（v1.9.4）：图片/上传入口优先试，减少无效误点——
      // 0: title/aria 含「图/上传/image」；1: 纯图标（无文字，多为 svg）；
      // 2: 有文字的功能按钮；3: 纯字母格式按钮（B/I/U/S 等，几乎不可能是图片入口，
      //    且误点会改格式/弹下拉，放最后）
      const prio = (el) => {
        const t = ((el.innerText || el.textContent || '') + '').replace(/\s+/g, '');
        const tag = ((el.title || el.getAttribute('aria-label') || '') + '');
        if (/图|上传|image|upload|pic/i.test(tag)) return 0;
        if (!t) return 1;
        if (t.length <= 2 && /^[a-zA-Z]+$/.test(t)) return 3;
        return 2;
      };
      cand.sort((a, b) => prio(a) - prio(b));
      // v1.9.10：全工具栏试探（合成点击 + CDP 逐坐标点击，一次上百次点击、耗时数分钟、
      // 误点格式按钮还会往正文插空表格/弹公式面板）从未成功命中 51CTO 的图片上传入口，
      // 且严重影响使用体验——停用全量扫描，只保留排序最前（最可能是图片/上传入口）的 3 个
      cand = cand.slice(0, 3);
    }
    if (!captured) {
      // 合成试探：逐个点击候选图标，main-world hook 会让「图片上传入口」一被点击
      // 就在其 file input 上打标记。试探可能误点插入类按钮：先快照，结束未命中则恢复
      const snap = editor.innerHTML;
      const tried = new Set();
      console.log('[CRM插件] 51CTO 合成试探（仅限疑似图片入口 ' + cand.length + ' 个，已停用全工具栏扫描）');
      for (const el of cand) {
        tried.add(el);
        try { el.click(); } catch (e) { continue; }
        await awaitCapture(1200);
        if (captured) { console.log('[CRM插件] 51CTO 试探第 ' + tried.size + ' 个图标即命中图片上传入口'); break; }
        escClear();
        await sleep(150);
      }
      if (!captured) {
        escClear();
        // 恢复试探前正文（清掉误插入的空表格/空块等；v1.7.4 实测试探会插入空表格）
        try {
          if (editor.innerHTML !== snap) { editor.innerHTML = snap; console.log('[CRM插件] 51CTO 已恢复试探前正文'); }
        } catch (e) { /* ignore */ }
      }
    }
    // ①c CDP 真实点击 + 文件选择框拦截（v1.8.0 终局方案）：content script 合成点击没有
    // user activation，页面永远弹不出文件选择框。改由 background 经 chrome.debugger：
    // Input.dispatchMouseEvent 发浏览器级真实点击（trusted），点中图片入口时文件框被
    // Page.setInterceptFileChooserDialog 拦截并回报目标 input → DOM.setFileInputFiles
    // 直接写入图片文件 → 页面 change 监听器自动上传（Puppeteer uploadFile 同款机制）。
    const coords = [];
    const pushCoord = (el) => {
      try {
        const r = el.getBoundingClientRect();
        if (r.width > 0 && r.height > 0) coords.push([Math.round(r.left + r.width / 2), Math.round(r.top + r.height / 2)]);
      } catch (e) { /* ignore */ }
    };
    // CDP 坐标同样受限（cand 已截到 3 个）：不再扫描整个工具栏（v1.9.10）
    if (btn) pushCoord(btn);
    for (const el of cand) pushCoord(el);
    const cdpSend = (m) => ((chrome.runtime && chrome.runtime.sendMessage) ? chrome.runtime.sendMessage(m).catch(() => null) : Promise.resolve(null));
    const findUploadEntry = () => Array.from(document.querySelectorAll('button, div, span, a, li, label')).find((el) => {
      const t = ((el.textContent || '') + '').replace(/\s+/g, '');
      return t && t.length <= 8 && UP_RE.test(t) && elVisible(el);
    });
    let cdpFailed = false;
    // PNG → JPEG 转码（白底）：51CTO 的 showOpenFilePicker 带 accept 过滤，
    // 系统文件框中 png 文件呈灰色禁选（v1.9.1 实测），JPEG 内容 + .jpg 名必可通过
    const toJpegDataUrl = (d) => new Promise((res) => {
      try {
        const im = new Image();
        im.onload = () => {
          try {
            const cv = document.createElement('canvas');
            cv.width = im.naturalWidth || 800;
            cv.height = im.naturalHeight || 600;
            const cx = cv.getContext('2d');
            cx.fillStyle = '#ffffff';
            cx.fillRect(0, 0, cv.width, cv.height);
            cx.drawImage(im, 0, 0);
            res(cv.toDataURL('image/jpeg', 0.92));
          } catch (e) { res(null); }
        };
        im.onerror = () => res(null);
        im.src = d;
      } catch (e) { res(null); }
    });
    const cdpUploadOne = async (dataUrl, idx) => {
      if (cdpFailed || !coords.length) return false;
      const before = editor.querySelectorAll('img').length;
      const snap = editor.innerHTML; // CDP 点击可能误点插入类按钮，失败后据此恢复正文
      const key = 'img' + (idx + 1);
      // 先转 JPEG（后续拦截写入与手动选择用的是同一份文件）
      const jpeg = await toJpegDataUrl(dataUrl);
      if (jpeg) dataUrl = jpeg;
      // 预下载图片到「下载」目录：51CTO 图片按钮走 showOpenFilePicker（系统文件选择框），
      // CDP 无法自动填充——弹出后提示用户选中该文件，后续上传全自动
      const dl = await cdpSend({ type: 'crmCdpDownload', dataUrl, fileKey: key });
      const t0 = Date.now();
      const pickerOpened = () => {
        const p = parseInt(document.documentElement.getAttribute('data-crm-picker') || '0', 10);
        return p > t0; // main-world hook 给 showOpenFilePicker 打的时间戳标记
      };
      const tryCoord = async (x, y) => {
        const r = await cdpSend({ type: 'crmCdpClickAndSet', x, y, dataUrl, fileKey: key });
        if (r && r.reqs && r.reqs.length) console.log('[CRM插件] 51CTO CDP 点击后上传相关请求：' + r.reqs.join(' | '));
        if (r && r.ok && r.intercepted) {
          if (r.nodeAttrs) console.log('[CRM插件] 51CTO 拦截到的 file input 节点：' + r.nodeAttrs);
          return 'intercepted';
        }
        if (pickerOpened()) return 'picker';
        // 未命中：立即恢复正文（误点加粗/表格/公式等按钮会插入格式或空表格）
        await sleep(300);
        try {
          if (editor.innerHTML !== snap) { editor.innerHTML = snap; console.log('[CRM插件] 51CTO 已恢复试探点击污染的正文'); }
        } catch (e) { /* ignore */ }
        // 「插入图片」面板可能已被点开（51CTO 图片按钮先弹面板而非直接文件框）：
        // 有上传入口时保留面板，交由后续 findUploadEntry 点击；仅无面板时才 Escape 清场。
        // （v1.9.3 盲目 Escape 把面板提前关掉，v1.9.2 的半自动成功路径因此回归全失败）
        if (!findUploadEntry()) {
          try { document.body.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true })); } catch (e2) { /* ignore */ }
        }
        return false;
      };
      let ok = false, semiAuto = false;
      // 插入图片面板若已开着，直接点面板上传入口
      const up = findUploadEntry();
      if (up) {
        const r = up.getBoundingClientRect();
        const res = await tryCoord(Math.round(r.left + r.width / 2), Math.round(r.top + r.height / 2));
        if (res === 'intercepted') ok = true;
        else if (res === 'picker') semiAuto = true;
      }
      if (!ok && !semiAuto) {
        // 嵌套元素（span>svg 等）中心点相同：按坐标去重，减少无效点击轮次
        const seen = new Set();
        for (const [x, y] of coords) {
          const k = x + ',' + y;
          if (seen.has(k)) continue;
          seen.add(k);
          const res = await tryCoord(x, y);
          if (res === 'intercepted') { ok = true; break; }
          if (res === 'picker') { semiAuto = true; break; }
          const up2 = findUploadEntry();
          if (up2) {
            const r2 = up2.getBoundingClientRect();
            const res2 = await tryCoord(Math.round(r2.left + r2.width / 2), Math.round(r2.top + r2.height / 2));
            if (res2 === 'intercepted') { ok = true; break; }
            if (res2 === 'picker') { semiAuto = true; break; }
          }
          await sleep(100);
        }
      }
      // 半自动：系统文件选择框已弹出（无法自动填充），提示用户选中预下载的图片文件
      const hint = (window.__crmPanelHint) || ((h) => { if (h) console.log('[CRM插件] ' + h.replace(/<[^>]+>/g, '')); });
      if (semiAuto) {
        const fname = (dl && dl.name) || ('crm-tmp-' + key);
        console.warn('[CRM插件] 51CTO 图片上传使用系统文件选择框（浏览器安全限制，无法自动填充）。'
          + '请在弹出的窗口「下载」目录中选中「' + fname + '」，选中后插件自动接管上传（90 秒内）');
        hint('⚠ 请在弹出的文件窗口「下载」目录中选中 <b>' + fname + '</b>，选中后插件自动继续');
        if (await waitImgInsert(before, 90000)) { hint(''); return true; }
        hint('');
        console.warn('[CRM插件] 51CTO 等待手动选择文件超时（90 秒）');
        // 恢复试探点击可能残留的正文污染（空表格/格式痕迹）
        try {
          if (editor.innerHTML !== snap) { editor.innerHTML = snap; console.log('[CRM插件] 51CTO 已恢复试探点击污染的正文'); }
        } catch (e) { /* ignore */ }
        cdpFailed = true;
        await cdpSend({ type: 'crmCdpDetach' });
        return false;
      }
      if (!ok) {
        // 恢复 CDP 循环前正文（误点表格/代码块等插入类按钮的残留；v1.8.0 实测会插入多个空表格）
        try {
          if (editor.innerHTML !== snap) { editor.innerHTML = snap; console.log('[CRM插件] 51CTO 已恢复 CDP 点击前正文'); }
        } catch (e) { /* ignore */ }
        console.warn('[CRM插件] 51CTO CDP 真实点击未拦截到文件选择框（候选坐标已试完）');
        cdpFailed = true;
        await cdpSend({ type: 'crmCdpDetach' });
        return false;
      }
      if (await waitImgInsert(before, 15000)) return true;
      console.warn('[CRM插件] 51CTO CDP 已写入文件并派发 change，但编辑器未插入 img');
      // 诊断：编辑器内 img src 状态 + 页面错误/提示信息
      try {
        const srcs = Array.from(editor.querySelectorAll('img')).map((im) => ((im.getAttribute('src') || '').slice(0, 70))).join(' | ');
        console.log('[CRM插件] 51CTO 编辑器 img src：' + (srcs || '（无）'));
        const tips = Array.from(new Set(Array.from(document.querySelectorAll('[class*="message" i], [class*="toast" i], [class*="notice" i]'))
          .map((el) => ((el.innerText || '') + '').trim()).filter((t) => t && t.length > 0 && t.length < 60)));
        if (tips.length) console.log('[CRM插件] 51CTO 页面提示：' + tips.join(' | '));
      } catch (e) { /* ignore */ }
      cdpFailed = true;
      await cdpSend({ type: 'crmCdpDetach' });
      return false;
    };
    let chain = [];
    if (captured) { console.log('[CRM插件] 51CTO 已捕获(main-world hook)编辑器图片上传 input（' + describe(captured) + '）'); chain = [captured]; }
    if (!chain.length && candidates.length) {
      console.log('[CRM插件] 51CTO 候选图片上传 input ' + candidates.length + ' 个：' + candidates.map(describe).join('；'));
      chain = candidates;
    }
    // ③ drop 拖放兜底：优先编辑器正文，其次页面上可见的上传拖放区（插入图片面板内常有）
    const tryDrop = async (file, token) => {
      const targets = [];
      if (await placeCursorAtToken(token)) targets.push(editor);
      const zone = Array.from(document.querySelectorAll('[class*="upload" i], [class*="drag" i]')).find((el) => {
        try {
          const r = el.getBoundingClientRect();
          if (r.width < 80 || r.height < 40) return false;
          return elVisible(el) && !el.contains(editor) && !editor.contains(el);
        } catch (e) { return false; }
      });
      if (zone) targets.push(zone);
      for (const target of targets) {
        const before = editor.querySelectorAll('img').length;
        try {
          const dt = new DataTransfer();
          dt.items.add(file);
          target.dispatchEvent(new DragEvent('drop', { bubbles: true, cancelable: true, dataTransfer: dt }));
        } catch (e) { continue; }
        if (await waitImgInsert(before, 10000)) return true;
      }
      return false;
    };
    let okCnt = 0;
    let boundInput = null; // 已验证有效的 input（编辑器出现新 img）
    let manualHinted = false;
    for (let i = 0; i < imgs.length; i++) {
      const token = tokenOf(i + 1);
      const file = await dataUrlToUploadFile(imgs[i], 'crm-image-' + (i + 1) + '.jpg');
      if (!file) { console.warn('[CRM插件] 51CTO 图片 ' + (i + 1) + ' 转 File 失败'); continue; }
      let done = false;
      // ①c CDP 真实点击 + 文件框拦截（最优先；第 1 张图不通则整体降级不再尝试）
      if (!done && !cdpFailed) {
        done = await cdpUploadOne(imgs[i], i);
        if (done) {
          okCnt++;
          console.log('[CRM插件] 51CTO 图片 ' + (i + 1) + ' 已由 CDP 通道插入（等待图床地址回填）');
          await sleep(1200);
          await cleanupToken(token);
          continue;
        }
      }
      // ② 依次尝试：已验证 input → 其余候选 input
      const tryList = boundInput ? [boundInput] : [];
      for (const c of chain) if (c !== boundInput) tryList.push(c);
      for (const input of tryList) {
        if (!(await placeCursorAtToken(token))) break;
        const before = editor.querySelectorAll('img').length;
        if (!putFileToInput(input, file)) continue;
        if (await waitImgInsert(before, 8000)) {
          done = true;
          boundInput = input;
          console.log('[CRM插件] 51CTO 编辑器上传 input 已验证锁定：' + describe(input));
          break;
        }
      }
      if (!done) done = await tryDrop(file, token);
      // ④ 手动接管（v1.7.5）：自动通道全失败时——main-world hook 常驻（window.__crmInputHook），
      //    请用户手动点一下工具栏图片图标：用户点击带真实 user activation，页面调用
      //    file input.click() 会被 hook 打标记（系统文件框若弹出按 Esc 关闭即可），
      //    插件轮询读到标记后自动塞文件完成上传，用户无需选文件
      if (!done && i === 0) {
        if (!manualHinted) {
          manualHinted = true;
          if (document.documentElement.getAttribute('data-crm-picker')) {
            console.warn('[CRM插件] 51CTO 图片上传走的是系统文件选择 API（showOpenFilePicker），请在弹出的选择窗口中直接选中第 1 张图片，插件将自动继续后续图片');
          } else {
            console.warn('[CRM插件] 51CTO 自动上传通道全部未生效，请手动点击 51CTO 工具栏的「图片」图标（30 秒内；若弹出文件选择框按 Esc 关闭即可，或直接选中图片文件），插件将自动接管后续上传');
          }
        }
        const before0 = editor.querySelectorAll('img').length;
        const mst = Date.now();
        while (Date.now() - mst < 30000 && !done) {
          if (editor.querySelectorAll('img').length > before0) { done = true; break; } // 用户手动传成
          const m = readMarked();
          if (m) {
            await sleep(600);
            if (!(await placeCursorAtToken(token))) break;
            const before = editor.querySelectorAll('img').length;
            if (putFileToInput(m, file) && await waitImgInsert(before, 8000)) {
              done = true;
              boundInput = m;
              console.log('[CRM插件] 51CTO 手动点击的图片上传 input 已接管并锁定：' + describe(m));
            }
            break;
          }
          await sleep(400);
        }
      }
      if (done) {
        okCnt++;
        console.log('[CRM插件] 51CTO 图片 ' + (i + 1) + ' 已插入（等待图床地址回填）');
        await sleep(1200);
        await cleanupToken(token);
      } else {
        console.warn('[CRM插件] 51CTO 图片 ' + (i + 1) + ' 原生上传通道未生效（input 塞文件与拖放均未插入 img），请手动处理');
      }
    }
    // 结束：解除 CDP 拦截（恢复用户正常文件选择）并清理临时文件（重复调用安全）
    await cdpSend({ type: 'crmCdpDetach' });
    return okCnt;
  }

  // 填充前准备：部分平台创作页有多种内容类型标签，需先切到正确标签再填充
  CRM.prepare = {
    xiaohongshu: (job) => prepareImagePlatform(job, '上传图文'),
    douyin_image: (job) => prepareImagePlatform(job, '发布图文'),
    douyin_article: (job) => prepareImagePlatform(job, '发布文章'),
    // 知乎：编辑器粘贴 data URL 图片会报「图片导入失败」，图床 API 又带签名（403）。
    // 与通用方案一致：先替换占位符随 HTML 粘贴，填充完成后再逐个「文件粘贴」上传
    zhihu: preparePlaceholderImages,
    // 搜狐：与知乎同理——data URL 图片粘进编辑器后不会真正上传，发布会报
    // 「正文中含有未上传的图片」。先把图片替换成占位符随 HTML 粘贴，
    // 填充完成后再在占位符位置逐个「文件粘贴」，走搜狐编辑器自带上传流程。
    sohu: async (job) => {
      try {
        if (!job || !job.contentHtml || job.contentHtml.indexOf('<img') < 0) return;
        const doc = new DOMParser().parseFromString(job.contentHtml, 'text/html');
        const imgs = Array.from(doc.querySelectorAll('img'));
        if (!imgs.length) return;
        job._sohuImages = [];
        imgs.forEach((img, i) => {
          const src = (img.getAttribute('src') || '').trim();
          if (/^data:image\//i.test(src)) {
            job._sohuImages.push(src);
            const p = doc.createElement('p');
            p.textContent = '[[CRM_IMG_' + (i + 1) + ']]';
            img.replaceWith(p);
          } else {
            img.remove(); // 未内联成功的图直接移除，避免裂图
          }
        });
        job.contentHtml = doc.body.innerHTML;
      } catch (e) { /* 不阻塞填充 */ }
    },
    // 开源中国（wangEditor）/ 博客园（TinyMCE）/ CSDN / 掘金 / 百家号 / 51CTO：
    // 编辑器不接受 Base64 图片或不会自动上传，与知乎/搜狐同理——
    // 先替换占位符随 HTML 粘贴，填充完成后再逐个文件粘贴走编辑器自带上传。
    // 51CTO：base64 图片直接写入后编辑器转存慢/卡住，发布一直提示「请等待文章中图片上传完成」。
    // CSDN 是 Markdown 编辑器，[[xx]] 会被解析成引用式链接（正文残留 ![xx][n]），
    // 因此用不含方括号的占位符
    oschina: preparePlaceholderImages,
    cnblogs: preparePlaceholderImages,
    csdn: (job) => preparePlaceholderImages(job, (n) => 'CRMIMGPH' + n + 'END'),
    juejin: preparePlaceholderImages,
    baijiahao: preparePlaceholderImages,
    cto51: preparePlaceholderImages
  };

  /** CDP 消息发送（带超时保护）。百家号新版编辑器（FeEditorApp）只认可信事件：
   *  合成 beforeinput/execCommand 写入的 DOM 会被重渲染清空（表现为面板显示未填写、字数 0），
   *  标题/正文补填与图片上传统一走 CDP 可信通道（掘金同款方案） */
  async function crmCdpMsg(m, ms) {
    if (!(typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage)) return null;
    let timer = null;
    try {
      return await Promise.race([
        chrome.runtime.sendMessage(m).catch(() => null),
        new Promise((r) => { timer = setTimeout(() => r(null), ms || 8000); })
      ]);
    } finally { clearTimeout(timer); }
  }

  // 百家号正文编辑器选择器：标题框与正文都是 contenteditable 且标题在 DOM 前面，必须排除标题
  const BJH_CONTENT_SELS = [
    '[data-slate-placeholder*="正文"]', // 正文空框 Slate 会挂该属性，最可靠
    '[data-slate-editor="true"]:not([data-slate-placeholder*="标题"]):not([data-slate-placeholder])',
    '[contenteditable="true"]:not([placeholder*="标题"]):not([data-placeholder*="标题"]):not([data-slate-placeholder])',
    '[class*="FeEditorApp"][contenteditable="true"]',
    '.ueditor-body'
  ];
  /** 标题框锚点定位：标题行右侧固定有「智能标题」按钮（无论标题是否有字/被污染都在），
   *  从它向上找同时包含编辑框的祖先，该编辑框即标题框。彻底摆脱对占位符/计数器的依赖
   *  （Slate 有字后 placeholder 属性消失、计数器不一定在祖先文本里，两种启发式都漏过） */
  function bjhTitleEl() {
    try {
      const bar = document.getElementById('crm-plugin-bar');
      const btn = deepQueryAll(document, 'button, span, div, a').find((el) => {
        if (bar && bar.contains(el)) return false;
        if (!elVisible(el)) return false;
        const t = ((el.innerText || '') + '').replace(/\s+/g, '');
        if (t !== '智能标题') return false;
        return !Array.from(el.children).some((c) => elVisible(c) && ((c.innerText || '') + '').replace(/\s+/g, '') === t);
      });
      if (!btn) return null;
      for (let n = btn.parentElement, up = 0; n && up < 8; up++, n = n.parentElement) {
        const ed = n.querySelector('[contenteditable="true"], input[type="text"], textarea');
        if (ed && elVisible(ed)) return ed;
      }
    } catch (e) { /* ignore */ }
    return null;
  }
  function bjhContentEl() {
    // 首选锚点法：锚出标题框后，其余同族编辑框即正文。
    // 关键：必须跨文档收集候选——UEditor/TinyMCE 类正文位于同源 iframe 内，而主文档的
    // query 不穿透 iframe（这正是本轮「正文=未找到（0 字）」的根因）
    const tEl = bjhTitleEl();
    const bar = (() => { try { return document.getElementById('crm-plugin-bar'); } catch (e) { return null; } })();
    const diag = [];
    const key = (el, inFrame) => (inFrame ? 'frame:' : 'main:') + el.tagName
      + '.' + String(el.className || '').split(' ')[0].slice(0, 16);
    const rejectable = (el) => {
      if (!elVisible(el)) return '不可见';
      if (bar && bar.contains(el)) return '插件面板';
      if (tEl && (el === tEl || tEl.contains(el) || el.contains(tEl))) return '标题锚点框';
      if (looksLikeCounterTitle(el, /\d+\s*\/\s*64(?!\d)/)) return '疑似标题(计数器)';
      return null;
    };
    let frameHit = null;
    try {
      for (const d of docList()) {
        const inFrame = d !== document;
        const cands = deepQueryAll(d, '[contenteditable="true"], .ueditor-body, .mce-content-body, #tinymce');
        for (const el of cands) {
          const why = rejectable(el);
          if (why) { diag.push(key(el, inFrame) + '✗' + why); continue; }
          if (inFrame) {
            // iframe 内的可编辑体就是正文；先记住，主文档有更合适的 Slate 正文则优先用主文档
            if (!frameHit) { frameHit = el; diag.push(key(el, inFrame) + '✓候选'); }
            continue;
          }
          const cls = String(el.className || '');
          if (cls.indexOf('FeEditorApp') < 0 && !el.getAttribute('data-slate-editor')) {
            diag.push(key(el, inFrame) + '✗类不匹配');
            continue;
          }
          diag.push(key(el, inFrame) + '✓命中');
          console.log('[CRM插件] 百家号候选编辑框：' + diag.join(' | ').slice(0, 300));
          return el;
        }
      }
    } catch (e) { /* ignore */ }
    console.log('[CRM插件] 百家号候选编辑框：' + (diag.join(' | ') || '无任何候选')
      + '；同源 iframe ' + (docList().length - 1) + ' 个');
    if (frameHit) { console.log('[CRM插件] 百家号：正文取 iframe 内可编辑体'); return frameHit; }
    for (const s of BJH_CONTENT_SELS) {
      try {
        // 标题框与正文同构且在 DOM 前面（Slate 有字后 placeholder 属性消失，:not 失效），
        // 逐个候选按「N/64 计数器」特征排除标题框
        const list = Array.from(document.querySelectorAll(s));
        const hit = list.find((el) => el && elVisible(el) && !looksLikeCounterTitle(el, /\d+\s*\/\s*64(?!\d)/));
        if (hit) return hit;
      } catch (e) { /* ignore */ }
    }
    return null;
  }
  const bjhCdpClick = async (el) => {
    try {
      try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch (e) { /* ignore */ }
      await sleep(150);
      const r = el.getBoundingClientRect();
      let x = r.left + r.width / 2;
      let y = r.top + r.height / 2;
      const d = el.ownerDocument;
      if (d && d !== document) {
        // 元素在 iframe 内：rect 相对 iframe 视口，必须叠加 iframe 自身偏移才是页面坐标
        let host = null;
        try {
          Array.from(document.querySelectorAll('iframe')).forEach((f) => {
            if (host) return;
            try { if (f.contentDocument === d) host = f; } catch (e) { /* 跨域忽略 */ }
          });
        } catch (e) { /* ignore */ }
        if (!host) { console.warn('[CRM插件] 百家号：iframe 内元素找不到宿主 iframe，跳过 CDP 点击'); return null; }
        const hr = host.getBoundingClientRect();
        x += hr.left;
        y += hr.top;
      }
      if (x < 0 || y < 0 || x > window.innerWidth || y > window.innerHeight) return null;
      return await crmCdpMsg({ type: 'crmCdpClick', x: Math.round(x), y: Math.round(y) });
    } catch (e) { return null; }
  };

  /** 让目标编辑框成为「键入落点」：真实点击 → focus → 用 DOM Range 明确指定选区。
   *  百家号正文容器对 CDP 点击可能不响应，此时焦点仍在标题框，而 crmCdpType 的
   *  selectAll 是「Ctrl+A + Delete + insertText」→ 会把正文清进标题（实测事故）。
   *  故这里必须同时校验「焦点在框内」+「选区锚点在框内」，任一不满足则调用方不得键入。 */
  const bjhFocusEl = async (el, selectAll) => {
    if (!el) return false;
    // Shadow DOM 内 activeElement/selection 取自所属 root（document.* 只会返回宿主）
    const rootOf = () => { try { return el.getRootNode() || document; } catch (e) { return document; } };
    const activeEl = () => { try { const r = rootOf(); return (r && r.activeElement) || document.activeElement; } catch (e) { return document.activeElement; } };
    const selOf = () => { try { const r = rootOf(); return (r && r.getSelection) ? r.getSelection() : document.getSelection(); } catch (e) { return document.getSelection(); } };
    const state = () => {
      const a = activeEl();
      const s = selOf();
      const inside = !!(a && (el.contains(a) || a === el));
      const selIn = !!(s && s.rangeCount && el.contains(s.anchorNode));
      return { inside, selIn, dbg: (a ? a.tagName + '.' + String(a.className || '').split(' ')[0] : 'null').slice(0, 48) };
    };
    const placeCaret = () => {
      try {
        el.focus();
        const s = selOf();
        if (!s) return;
        // 元素可能在 iframe 内：Range 必须由所属文档创建，否则跨文档无效
        const rg = (el.ownerDocument || document).createRange();
        rg.selectNodeContents(el);
        if (!selectAll) rg.collapse(false);
        s.removeAllRanges();
        s.addRange(rg);
      } catch (e) { /* ignore */ }
    };
    await bjhCdpClick(el);
    await sleep(250);
    placeCaret();
    await sleep(150);
    let st = state();
    if (!st.inside || !st.selIn) {
      const inner = Array.from(el.querySelectorAll('p, div, span')).find((n) => elVisible(n)) || el;
      await bjhCdpClick(inner);
      await sleep(250);
      placeCaret();
      await sleep(150);
      st = state();
    }
    if (!st.inside || !st.selIn) {
      // 关键：键入被跳过时必须拆掉刚设的全选选区——残留的「选中整个正文」
      // 会让后续图片插入把整篇正文替换成一张图（v1.9.56 实测事故）
      try { const s = selOf(); if (s) s.removeAllRanges(); } catch (e) { /* ignore */ }
      console.warn('[CRM插件] 百家号：键入落点未就绪（焦点=' + st.dbg + '，选区落框=' + (st.selIn ? '是' : '否') + '），跳过键入');
    }
    return st.inside && st.selIn;
  };

  /** 百家号：合成填充被编辑器重渲染清空时（fresh 查询字数不足），CDP 可信键入补填标题/正文。
   *  全程 fresh 查询校验，避免对已分离旧节点校验造成"假成功" */
  async function cdpFillBaijiahao(job) {
    const title = (job && job.title) || '';
    const imgs = (job && job._crmImages) || [];
    const token = (job && job._crmTokenFn ? job._crmTokenFn(1) : '[[CRM_IMG_1]]');
    // 纯文本通道必须带图片占位符，否则图片粘贴没有锚点
    const bjhText = (job && job.contentHtml && imgs.length)
      ? htmlToParagraphText(job.contentHtml) : ((job && job.contentText) || '');
    const needTxt = bjhText.replace(/\s/g, '');
    // 诊断：打印本次识别到的标题/正文框（用于区分「框选错了」还是「键入落错了」）
    try {
      const dbgId = (el) => {
        if (!el) return '未找到';
        const r = el.getBoundingClientRect();
        return (el.tagName + '.' + String(el.className || '').split(' ')[0]).slice(0, 40)
          + '@top' + Math.round(r.top) + 'h' + Math.round(r.height);
      };
      const tDbg = bjhTitleEl();
      const cDbg = bjhContentEl();
      console.log('[CRM插件] 百家号框识别：标题=' + dbgId(tDbg) + '（' + ((editableValue(tDbg) || '').trim().length) + ' 字）'
        + '，正文=' + dbgId(cDbg) + '（' + ((editableValue(cDbg) || '').replace(/\s/g, '').length) + ' 字）');
      // 结构诊断同步投到悬浮面板（用户截图即可回传，不依赖控制台日志）
      const barEl = document.getElementById('crm-plugin-bar');
      const boxEl = barEl && barEl.querySelector('#crm-plugin-status');
      if (boxEl) {
        let diag = boxEl.querySelector('#crm-bjh-diag');
        if (!diag) {
          diag = document.createElement('div');
          diag.id = 'crm-bjh-diag';
          diag.style.cssText = 'color:#909399;font-size:11px;margin-top:4px;word-break:break-all;line-height:1.4';
          boxEl.appendChild(diag);
        }
        const list = deepQueryAll(document, '[contenteditable="true"]')
          .filter((el) => elVisible(el)).slice(0, 6)
          .map((el) => el.tagName + '.' + String(el.className || '').split(' ').slice(0, 2).join('.').slice(0, 28)
            + ':' + String(editableValue(el) || '').replace(/\s+/g, '').length + '字');
        diag.textContent = '编辑框: ' + (list.join(' | ') || '无');
      }
    } catch (e) { /* ignore */ }
    // 标题污染修复：被长文本误写入的标题框统一重置为 job.title。
    // 不依赖『标题』占位符（实测真正显示的标题框没有该属性，占位符定位永远漏掉它）：
    // 在编辑器邻近范围内（与正文框 8 层内有共同祖先），凡「可见、内容 ≠ 目标标题、
    // 且明显比标题长」的编辑框都视为被污染，直接 focus + execCommand/原生 setter 重置
    const fixPollutedTitle = async () => {
      if (!title) return;
      const nt = title.replace(/\s+/g, '');
      const cEl0 = bjhContentEl();
      const editables = [];
      try { editables.push(...deepQueryAll(document, '[contenteditable="true"]')); } catch (e) { /* ignore */ }
      try { editables.push(...document.querySelectorAll('textarea, input[type="text"]')); } catch (e) { /* ignore */ }
      for (const el of editables) {
        try {
          if (!el || el === cEl0 || (cEl0 && cEl0.contains(el))) continue;
          if (!elVisible(el)) continue;
          const indexOfPlaceholder = String(editableValue(el) || '').indexOf('[[CRM_IMG_');
          // 只处理编辑器邻近范围内的框，避免误伤 AI 助手面板等处的输入框
          let near = !cEl0;
          for (let n = cEl0 && cEl0.parentElement, up = 0; n && up < 8; up++, n = n.parentElement) {
            if (n.contains(el)) { near = true; break; }
          }
          if (!near) continue;
          const v = String(editableValue(el) || '').replace(/\s+/g, '');
          if (!v || v === nt || v.length <= nt.length + 4) continue;
          // 只认「锚点定位的标题框」或「带 N/64 计数器的框」；含正文占位符的一律跳过——
          // 否则会把刚填好的正文当成“被污染的标题”重置掉（v1.9.57 实测事故）
          if (indexOfPlaceholder >= 0) continue;
          const tAnchor = bjhTitleEl();
          const isTitle = (tAnchor && (el === tAnchor || tAnchor.contains(el)))
            || looksLikeCounterTitle(el, /\d+\s*\/\s*64(?!\d)/);
          if (!isTitle) continue;
          el.focus();
          if (/^(INPUT|TEXTAREA)$/.test(el.tagName)) {
            const proto = el.tagName === 'INPUT' ? HTMLInputElement.prototype : HTMLTextAreaElement.prototype;
            const desc = Object.getOwnPropertyDescriptor(proto, 'value');
            if (desc && desc.set) { desc.set.call(el, title); el.dispatchEvent(new Event('input', { bubbles: true })); }
          } else {
            document.execCommand('selectAll', false, null);
            document.execCommand('insertText', false, title);
          }
          const v2 = String(editableValue(el) || '').replace(/\s+/g, '');
          console.log('[CRM插件] 百家号：重置被污染的标题框（' + el.tagName + '.'
            + String(el.className || '').split(' ')[0].slice(0, 24) + '，原 ' + v.length + ' 字）→ '
            + (v2 === nt ? '成功' : '后为「' + String(editableValue(el) || '').trim().slice(0, 16) + '」'));
        } catch (e) { /* ignore */ }
      }
    };
    await fixPollutedTitle();
    // 标题：长度不足或与目标不一致（旧文案残留）都要重填；优先锚点定位
    if (title) {
      const tEl = bjhTitleEl()
        || findEditableByPlaceholder('标题')
        || document.querySelector('input[placeholder*="标题"], [data-slate-placeholder*="标题"]');
      if (tEl) {
        const norm = (s) => String(s || '').replace(/\s+/g, '');
        const cur = (editableValue(tEl) || '').trim();
        const need = Math.min(4, title.length);
        if (cur.length < need || norm(cur) !== norm(title)) {
          console.log('[CRM插件] 百家号：标题需重填（当前「' + (cur.slice(0, 12) || '空') + '」），CDP 可信键入');
          const okF = await bjhFocusEl(tEl, true);
          if (!okF) {
            console.warn('[CRM插件] 百家号：标题框键入落点未就绪，跳过键入（避免误写正文）');
          } else {
            await crmCdpMsg({ type: 'crmCdpType', text: title, selectAll: false });
            await sleep(600);
            const cur2 = (editableValue(bjhTitleEl() || findEditableByPlaceholder('标题') || tEl) || '').trim();
            console.log('[CRM插件] 百家号：CDP 补填标题' + (norm(cur2) === norm(title) ? '成功' : '后仍为「' + cur2.slice(0, 12) + '」'));
          }
        }
      }
    }
    // 正文：字数不足（未落框）或缺少图片占位符（纯文本通道丢锚点）都要 CDP 重填
    if (needTxt.length) {
      const cEl = bjhContentEl();
      if (cEl) {
        const need = Math.max(1, Math.floor(needTxt.length * 0.9));
        const curC = (editableValue(cEl) || '').replace(/\s/g, '');
        const lackToken = imgs.length > 0 && (editableValue(cEl) || '').indexOf(token) < 0;
        if (curC.length < need || lackToken) {
          console.log('[CRM插件] 百家号：正文' + (lackToken ? '缺图片占位符' : '未落框')
            + '（当前 ' + curC.length + '/' + needTxt.length + ' 字），CDP 可信键入');
          const okF = await bjhFocusEl(cEl, true);
          if (!okF) {
            console.warn('[CRM插件] 百家号：正文框键入落点未就绪，跳过键入（避免误写入标题）');
          } else {
            await crmCdpMsg({ type: 'crmCdpType', text: bjhText, selectAll: false }, 20000);
          }
          await sleep(800);
          const cEl2 = bjhContentEl() || cEl;
          const v2 = editableValue(cEl2) || '';
          const curC2 = v2.replace(/\s/g, '');
          const okT2 = imgs.length === 0 || v2.indexOf(token) >= 0;
          console.log('[CRM插件] 百家号：CDP 补填正文' + (curC2.length >= need && okT2
            ? '成功（' + curC2.length + ' 字' + (imgs.length ? '，含占位符' : '') + '）'
            : '后仍 ' + curC2.length + '/' + needTxt.length + ' 字' + (okT2 ? '' : '、占位符缺失')));
        }
      }
    }
    // 最后再扫一次污染（防止正文 CDP 键入或页面异步回填把标题又写花）
    await fixPollutedTitle();
  }

  /** 百家号：合成文件粘贴被编辑器忽略时（正式 img 不增），走 CDP 工具栏图片入口上传
   *  （trusted 点击 → 拦截文件选择框 → DOM.setFileInputFiles，掘金兜底同款） */
  async function baijiahaoCdpUpload(job) {
    const imgs = (job && job._crmImages) || [];
    const ed = bjhContentEl();
    if (!ed || !imgs.length) return;
    const httpCnt = () => Array.from(ed.querySelectorAll('img')).filter((im) => /^https?:/i.test(im.getAttribute('src') || '')).length;
    if (httpCnt() >= imgs.length) return;
    // 合成粘贴插入但从未转存的占位图先清掉（发布时会被平台丢弃）——
    // 但编辑器可能正在转存（blob → http）：仅当图片总数明显多于目标数时才清理，避免误删在途图
    const allImgs0 = Array.from(ed.querySelectorAll('img'));
    if (allImgs0.length > imgs.length) {
      allImgs0.forEach((im) => {
        if (/^(data:|blob:)/i.test(im.getAttribute('src') || '')) { try { im.remove(); } catch (e) { /* ignore */ } }
      });
    }
    const UP_RE = /(上传图片|本地上传|点击上传|上传照片|插入图片|图库|上传)/;
    const IMG_ATTR = /image|pic|photo|图片|图库/i;
    const panelEl0 = (() => { try { return document.getElementById('crm-plugin-bar'); } catch (e) { return null; } })();
    // 工具栏图片按钮的类名是哈希（无 图片/image 字样），只有 aria-label/data-*/xlink:href 带线索，
    // 且图标常是 svg/use → 改为扫描任意属性值
    const findEntries = () => {
      const list = [];
      Array.from(document.querySelectorAll('button, [role="button"], li, span, div, svg, use, path')).forEach((el) => {
        if (!elVisible(el) || ed.contains(el)) return;
        if (panelEl0 && panelEl0.contains(el)) return;
        let hit = false;
        try {
          for (const a of Array.from(el.attributes || [])) {
            if (IMG_ATTR.test(String(a.name) + '=' + String(a.value))) { hit = true; break; }
          }
        } catch (e) { /* ignore */ }
        if (hit) { list.push(el); return; }
        const t = ((el.innerText || el.textContent || '') + '').replace(/\s+/g, '');
        if (t && t.length <= 8 && UP_RE.test(t)) list.push(el);
      });
      return list;
    };
    // 入口诊断：把实际点击的元素信息打进日志，便于下轮精确定位「哪个才是真入口」
    const elDigest = (el) => {
      const attrs = Array.from(el.attributes || []).slice(0, 6)
        .map((a) => a.name + '=' + String(a.value || '').slice(0, 24)).join(' ');
      return '<' + el.tagName + '> class=' + String(el.className || '').slice(0, 30) + ' ' + attrs.slice(0, 120)
        + ' 文本=' + ((el.innerText || el.textContent || '') + '').replace(/\s+/g, '').slice(0, 8);
    };
    // 上传弹窗处理：百家号点图片入口会开「本地图片」弹窗，文件写入 input 后缩略图
    // 出现在弹窗内（编辑器里没有！），必须点「确认」才插入编辑器。
    // 注意：弹窗类名是哈希（无 modal/dialog 字样）→ 不能靠类名识别，改为按按钮文字成对定位
    const panelEl = (() => { try { return document.getElementById('crm-plugin-bar'); } catch (e) { return null; } })();
    // deepQueryAll：兼容弹窗渲染在 shadow root 里的情况；UEditor 弹窗在编辑器 iframe 内 → 跨文档收集
    const leafBtns = (re) => docList().flatMap((d) => deepQueryAll(d, 'button, [role="button"], a, span, div'))
      .filter((el) => {
        if (!elVisible(el) || ed.contains(el)) return false;
        if (panelEl && panelEl.contains(el)) return false; // 排除插件面板自己的按钮
        const t = ((el.innerText || '') + '').replace(/\s+/g, '');
        if (!t || t.length > 4 || !re.test(t)) return false;
        return !Array.from(el.children).some((c) => elVisible(c) && ((c.innerText || '') + '').replace(/\s+/g, '') === t);
      });
    /** 找与另一按钮同祖先的「成对」按钮（弹窗底部 取消/确认 一对），避免误点别处同名按钮 */
    const pairedBtn = (re, pairRe) => {
      for (const el of leafBtns(re)) {
        let n = el;
        for (let up = 0; up < 6 && n; up++, n = n.parentElement) {
          if (!n.querySelectorAll) break;
          if (Array.from(n.querySelectorAll('button, [role="button"], a, span, div'))
            .some((x) => x !== el && elVisible(x) && pairRe.test(((x.innerText || '') + '').replace(/\s+/g, '')))) return el;
        }
      }
      return null;
    };
    const clickEl = async (el) => {
      if (!el) return false;
      await bjhCdpClick(el);
      await sleep(250);
      try { el.click(); } catch (e) { /* ignore */ }
      return true;
    };
    const confirmDialog = async () => {
      const okBtn = pairedBtn(/^(确认|确定|插入|完成|添加)$/, /^(取消|关闭)$/);
      if (!okBtn) return false;
      await clickEl(okBtn);
      console.log('[CRM插件] 百家号兜底：已点击上传弹窗「' + ((okBtn.innerText || '').trim().slice(0, 4)) + '」');
      return true;
    };
    const closeDialog = async () => {
      const cBtn = pairedBtn(/^(取消|关闭)$/, /^(确认|确定|插入|完成|添加)$/);
      if (cBtn) await clickEl(cBtn);
    };
    /** 关掉「格式不正确/失败/提示」类错误弹窗（只剩一个 确认/知道了 按钮）：不关会挡住后续上传入口 */
    const dismissErrorDialog = async () => {
      try {
        const hit = leafBtns(/^(确认|确定|知道了|我知道了|知道)$/).find((el) => {
          let n = el;
          for (let up = 0; n && up < 8; up++, n = n.parentElement) {
            if (!n.innerText) break;
            if (/格式不正确|上传失败|失败|错误|提示/.test(n.innerText)) return true;
          }
          return false;
        });
        if (hit) {
          try { hit.click(); } catch (e) { /* ignore */ }
          console.log('[CRM插件] 百家号：已关闭错误提示弹窗');
          await sleep(500);
          return true;
        }
      } catch (e) { /* ignore */ }
      return false;
    };
    /** 插图前拆除危险选区：上传弹窗「确认」把图片插到当前选区，若残留着
     *  「选中整个正文」的选区（CDP 键入被跳过时遗留），整篇正文会被一张图替换。
     *  有占位符则改为精确选中占位符（插图正好替换它），否则把选区收拢到末尾 */
    const defuseSelection = () => {
      try {
        // 正文在 iframe 内：选区/TreeWalker 必须用所属文档（主文档 selection 看不到 iframe 内节点）
        const edoc = ed.ownerDocument || document;
        const s = edoc.getSelection ? edoc.getSelection() : document.getSelection();
        if (s && s.rangeCount && ed.contains(s.anchorNode)) {
          const r = s.getRangeAt(0);
          if (!r.collapsed) {
            const walker = edoc.createTreeWalker(ed, NodeFilter.SHOW_TEXT);
            let n2, tok = null;
            while ((n2 = walker.nextNode())) {
              const m = /\[\[CRM_IMG_\d+\]\]/.exec(n2.textContent || '');
              if (m) { tok = { node: n2, idx: m.index, len: m[0].length }; break; }
            }
            s.removeAllRanges();
            const rr = document.createRange();
            if (tok) {
              rr.setStart(tok.node, tok.idx);
              rr.setEnd(tok.node, tok.idx + tok.len);
            } else {
              rr.setStart(r.endContainer, r.endOffset);
              rr.collapse(true);
            }
            s.addRange(rr);
          }
        }
      } catch (e) { /* ignore */ }
    };
    for (let n = 0; n < imgs.length; n++) {
      if (httpCnt() > n) continue;
      const before = httpCnt();
      let done = false;
      const tried = new Set();
      await dismissErrorDialog(); // 上一轮遗留的错误弹窗（如格式不正确）先关掉
      /** 直写通道：UEditor 的上传弹窗/file input 挂在编辑器 iframe 文档里（主文档永远“无 input”），
       *  改为跨文档查找 input[type=file]，同源 iframe 内容脚本可直接写，无需 CDP */
      const isImgAcc = (el) => {
        // 必须按 accept 过滤：页面里还有视频上传通道（accept 含 video），把图片写进去
        // 会弹「视频格式不正确」错误弹窗（v1.9.65 实测事故）
        const acc = (el.accept || '').toLowerCase();
        return !acc || acc.indexOf('image') >= 0 || /\.(jpe?g|png|webp|gif|bmp)/.test(acc);
      };
      const allFileInputs = () => {
        const out = [];
        for (const d of docList()) {
          try { out.push(...Array.from(d.querySelectorAll('input[type="file"]')).filter(isImgAcc)); } catch (e) { /* ignore */ }
        }
        return out;
      };
      const tryDirectSet = async () => {
        const file = await dataUrlToUploadFile(imgs[n], 'bjh' + (n + 1) + '.jpg');
        if (!file) { console.warn('[CRM插件] 百家号兜底：图片数据转 File 失败'); return false; }
        const beforeInputs = allFileInputs();
        let input = beforeInputs.length ? beforeInputs[beforeInputs.length - 1] : null;
        if (!input) { // 弹窗未挂载：最多等 4 秒新 input 出现（点入口后弹窗挂载即命中）
          const st0 = Date.now();
          while (Date.now() - st0 < 4000) {
            const now = allFileInputs();
            const fresh = now.filter((x) => beforeInputs.indexOf(x) < 0);
            if (fresh.length) { input = fresh[fresh.length - 1]; break; }
            await sleep(300);
          }
        }
        if (!input) { console.log('[CRM插件] 百家号兜底：跨文档未找到 input[type=file]（弹窗未挂载）'); return false; }
        if (!putFileToInput(input, file)) { console.warn('[CRM插件] 百家号兜底：文件写入 input 失败'); return false; }
        console.log('[CRM插件] 百家号兜底：图片 ' + (n + 1) + ' 已直写 input（' + (input.ownerDocument === document ? '主文档' : 'iframe 内') + '），等待回显');
        await sleep(2500);
        defuseSelection();
        await confirmDialog();
        for (let w = 0; w < 60 && !done; w++) { await sleep(250); if (httpCnt() > before) done = true; }
        if (!done) { await sleep(800); await confirmDialog(); for (let w = 0; w < 40 && !done; w++) { await sleep(250); if (httpCnt() > before) done = true; } }
        if (done) console.log('[CRM插件] 百家号兜底：图片 ' + (n + 1) + '/' + imgs.length + ' 已直写 input 并插入编辑器');
        return done;
      };
      // ① 页面/弹窗若已挂载 file input，直写一步到位
      if (await tryDirectSet()) continue;
      for (let att = 0; att < 6 && !done; att++) {
        const entries = findEntries().filter((el) => !tried.has(el));
        if (!entries.length) break;
        const el = entries[0];
        tried.add(el);
        let r;
        try { r = el.getBoundingClientRect(); } catch (e) { continue; }
        console.log('[CRM插件] 百家号兜底：尝试入口 ' + elDigest(el));
        const res = await crmCdpMsg({
          type: 'crmCdpClickAndSet',
          x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2),
          dataUrl: imgs[n], fileKey: 'bjhimg' + (n + 1)
        }, 25000);
        await sleep(800);
        if (res && res.ok && res.intercepted) {
          // 文件已写入弹窗内 input：缩略图在弹窗里，点「确认」才会插入编辑器
          defuseSelection();
          await confirmDialog();
          for (let w = 0; w < 60 && !done; w++) { await sleep(250); if (httpCnt() > before) done = true; }
          if (!done) { // 缩略图还在生成时确认按钮可能未生效，再补一次
            await sleep(800);
            defuseSelection();
            await confirmDialog();
            for (let w = 0; w < 40 && !done; w++) { await sleep(250); if (httpCnt() > before) done = true; }
          }
          if (done) console.log('[CRM插件] 百家号兜底：图片 ' + (n + 1) + '/' + imgs.length + ' 已插入编辑器');
          else console.warn('[CRM插件] 百家号兜底：图片 ' + (n + 1) + ' 文件已写入 input 但编辑器未见回显（弹窗可能未确认）');
        } else {
          console.log('[CRM插件] 百家号兜底：CDP 未拦截到选择框（' + ((res && (res.message || (res.reqs && res.reqs.join('|')))) || '无响应') + '），换下一入口');
          // 入口点击可能已把上传弹窗打开（选择框被组件吞掉）：等其挂载后直接写入，不行再关弹窗
          await sleep(1200);
          await dismissErrorDialog(); // 格式不正确等错误弹窗会挡住后续入口，先关掉
          if (await tryDirectSet()) break;
          await closeDialog();
        }
      }
      // 上一入口已把图传好、弹窗还开着（如重跑场景）：先尝试确认插入
      if (!done) {
        defuseSelection();
        const cf = await confirmDialog();
        if (cf) {
          for (let w = 0; w < 40 && !done; w++) { await sleep(250); if (httpCnt() > 0) done = true; }
          if (done) console.log('[CRM插件] 百家号兜底：遗留弹窗确认后图片已插入编辑器');
        }
      }
      if (!done) console.warn('[CRM插件] 百家号兜底：图片 ' + (n + 1) + ' 未能上传（入口试尽/CDP 不可用）');
    }
  }

  /** 百家号封面：编辑页下方「基础信息 → 设置封面」默认取正文第一张图（用户要求）。
   *  流程：找「选择封面」入口（叶子最小面积）→ CDP 点击打开选图弹窗 → 点第一张候选图
   *  （img 或 background-image 格子）→ 点「确认/完成」→ 校验入口消失或封面区出现真图。
   *  失败不阻塞发布，由用户手动补选 */
  async function fillBaijiahaoCover() {
    try {
      const bar = document.getElementById('crm-plugin-bar');
      const leaf = (txt) => {
        let hit = null, best = Infinity;
        for (const el of deepQueryAll(document, 'div, span, button, a, p')) {
          if (bar && bar.contains(el)) continue;
          const t = ((el.innerText || '') + '').replace(/\s+/g, '');
          if (t !== txt) continue;
          if (!elVisible(el)) continue;
          const r = el.getBoundingClientRect();
          if (r.width < 5 || r.height < 5) continue;
          const a = r.width * r.height;
          if (a < best) { best = a; hit = el; }
        }
        return hit;
      };
      const realImgIn = (rootEl) => {
        if (!rootEl || !rootEl.querySelector) return null;
        return Array.from(rootEl.querySelectorAll('img')).find((im) => {
          if (!elVisible(im)) return false;
          if (!/^(https?:|blob:|data:)/i.test(im.getAttribute('src') || '')) return false;
          const r = im.getBoundingClientRect();
          return r.width >= 60 && r.height >= 40;
        }) || null;
      };
      const coverSet = () => {
        const e = leaf('选择封面');
        if (!e) return true; // 入口消失 = 已设置
        let n = e;
        for (let up = 0; n && up < 6; up++, n = n.parentElement) {
          if (realImgIn(n)) return true;
        }
        return false;
      };
      if (coverSet()) { console.log('[CRM插件] 百家号：封面已设置，跳过'); return true; }
      const entry = leaf('选择封面');
      if (!entry) { console.warn('[CRM插件] 百家号：未找到「选择封面」入口，请手动选择封面'); return false; }
      const clickEl = async (el) => {
        await bjhCdpClick(el);
        await sleep(300);
        try { el.click(); } catch (e) { /* ignore */ }
      };
      await clickEl(entry);
      // 等选图弹窗：含候选图（img 或背景图格子）的可见面板，取面积最小者（弹窗而非整页容器）
      const findPicker = () => {
        let hit = null, best = Infinity;
        for (const el of deepQueryAll(document, 'div')) {
          if (!elVisible(el)) continue;
          const r = el.getBoundingClientRect();
          if (r.width < 400 || r.height < 250) continue;
          let cells = Array.from(el.querySelectorAll('img')).filter((im) => {
            if (!elVisible(im)) return false;
            const ir = im.getBoundingClientRect();
            return ir.width >= 60 && ir.height >= 40;
          });
          if (!cells.length) {
            cells = Array.from(el.querySelectorAll('div, li')).filter((c) => {
              if (!elVisible(c)) return false;
              const cr = c.getBoundingClientRect();
              return cr.width >= 60 && cr.height >= 40 && /url\(/i.test(c.style.backgroundImage || '');
            });
          }
          if (!cells.length) continue;
          if (!/正文图片|选择封面|封面/.test((el.innerText || '') + '')) continue;
          const a = r.width * r.height;
          if (a < best) { best = a; hit = { el, cells }; }
        }
        return hit;
      };
      let picker = null;
      const st = Date.now();
      while (Date.now() - st < 10000) {
        picker = findPicker();
        if (picker) break;
        await sleep(400);
      }
      if (!picker) { console.warn('[CRM插件] 百家号：封面选择弹窗未出现或无候选图，请手动选择封面'); return false; }
      console.log('[CRM插件] 百家号：封面弹窗已打开（' + picker.cells.length + ' 张候选），默认选第 1 张');
      await clickEl(picker.cells[0]);
      // 点弹窗内「确认/完成/确定」（叶子最小面积），最多 3 层（可能叠加裁剪确认层）。
      // 关键：选图后裁剪层/按钮是异步渲染的，必须轮询等待（原来不等 → 按钮还没出现就 break，
      // 弹窗留在页面上挡住发布按钮，v1.9.67 实测事故）
      const findOkBtn = () => {
        let okBtn = null, bestA = Infinity;
        for (const el of deepQueryAll(document, 'button, [role="button"], span, div, a')) {
          if (bar && bar.contains(el)) continue;
          const t = ((el.innerText || '') + '').replace(/\s+/g, '');
          // 按钮可能带选中计数后缀，如「确定 (1)」→ 去空格后「确定(1)」，须允许
          if (!/^(确认|确定|完成|提交|使用)(\(\d+\)|（\d+）)?$/.test(t)) continue;
          if (!elVisible(el)) continue;
          const r = el.getBoundingClientRect();
          if (r.width < 5 || r.height < 5) continue;
          const a = r.width * r.height;
          if (a < bestA) { bestA = a; okBtn = el; }
        }
        return okBtn;
      };
      for (let i = 0; i < 3; i++) {
        let okBtn = findOkBtn();
        const stOk = Date.now();
        while (!okBtn && Date.now() - stOk < 6000) { await sleep(400); okBtn = findOkBtn(); }
        if (!okBtn) {
          console.warn('[CRM插件] 百家号：封面弹窗未找到确认按钮（' + (i === 0 ? '选图后裁剪层未出现' : '第 ' + (i + 1) + ' 层') + '）');
          break;
        }
        await clickEl(okBtn);
        console.log('[CRM插件] 百家号：已点击封面弹窗「' + ((okBtn.innerText || '').trim()) + '」');
        await sleep(1200);
        const stCs = Date.now();
        while (!coverSet() && Date.now() - stCs < 4000) await sleep(400);
        if (coverSet()) break;
      }
      // 弹窗仍开着说明没确认成功：关闭它，否则会挡住发布按钮（封面失败不阻塞发布）
      let ok = coverSet();
      if (!ok) {
        const cp = findPicker();
        if (cp) {
          const closeBtn = (() => {
            let hit = null, ba = Infinity;
            for (const el of deepQueryAll(document, 'button, [role="button"], span, div, a, i')) {
              if (bar && bar.contains(el)) continue;
              const t = ((el.innerText || '') + '').replace(/\s+/g, '');
              const isX = !t && /(close|cancel|icon-close|X)/i.test(String(el.className || ''));
              if (!isX && !/^(取消|关闭|×|x)$/.test(t)) continue;
              if (!elVisible(el)) continue;
              const r = el.getBoundingClientRect();
              if (r.width < 5 || r.height < 5 || r.width > 60 || r.height > 60) continue;
              const a = r.width * r.height;
              if (a < ba) { ba = a; hit = el; }
            }
            return hit;
          })();
          if (closeBtn) { await clickEl(closeBtn); await sleep(800); console.log('[CRM插件] 百家号：封面弹窗已关闭（未确认成功，避免挡住发布按钮）'); }
        }
        ok = coverSet();
      }
      console.log('[CRM插件] 百家号：封面' + (ok ? '设置成功（取正文第 1 张图）' : '设置结果未确认，请手动检查'));
      return ok;
    } catch (e) { return false; }
  }

  /** 百家号发布设置：同步 智能创作（自动生成视频/播客）、创作声明（AI 生成内容/来源说明）、
   *  拓展设置（支持用户打赏）复选框与预设一致。platformConfig 有对应键用键值，缺省一律不勾
   *  （平台默认会勾上视频/播客/打赏，实测与预设不符）。勾选框是自绘样式：状态取
   *  input.checked / aria-checked / class 含 checked 系，任一命中即认为已勾 */
  async function fillBaijiahaoSettings(job) {
    try {
      const c = (job && job.platformConfig) || {};
      const val = (...keys) => {
        for (const k of keys) {
          if (c[k] !== undefined && c[k] !== null && c[k] !== '') return !!c[k] && c[k] !== 'false' && c[k] !== '0';
        }
        return false; // 未配置 → 不勾
      };
      const options = [
        { label: '自动生成视频', want: val('autoVideo', 'autoGenerateVideo', 'bjhAutoVideo') },
        { label: '自动生成播客', want: val('autoPodcast', 'autoGeneratePodcast', 'bjhAutoPodcast') },
        { label: '采用AI生成内容', want: val('aiGenerated', 'aiContent', 'bjhAiContent') },
        { label: '来源说明', want: val('sourceNote', 'sourceStatement', 'bjhSourceNote') },
        { label: '支持用户打赏', want: val('tip', 'reward', 'enableTip', 'bjhTip') }
      ];
      const bar = document.getElementById('crm-plugin-bar');
      const checkedOf = (box) => {
        try {
          if (box.tagName === 'INPUT') return !!box.checked;
          const a = box.getAttribute('aria-checked');
          if (a === 'true' || a === 'false') return a === 'true';
          const cls = String(box.className || '');
          return /(^|\s|-)(is-)?checked(\s|$|-)/i.test(cls) || /(^|\s)active(\s|$)/i.test(cls);
        } catch (e) { return false; }
      };
      const findBox = (labelText) => {
        // 找选项文字的叶子节点 → 向上找同时包含勾选框的行容器 → 容器内找框
        let leaf = null, best = Infinity;
        for (const el of deepQueryAll(document, 'div, span, label, p')) {
          if (bar && bar.contains(el)) continue;
          const t = ((el.innerText || '') + '').replace(/\s+/g, '');
          if (t !== labelText) continue;
          if (!elVisible(el)) continue;
          const r = el.getBoundingClientRect();
          if (r.width < 5 || r.height < 5) continue;
          const a = r.width * r.height;
          if (a < best) { best = a; leaf = el; }
        }
        if (!leaf) return null;
        for (let n = leaf.parentElement, up = 0; n && up < 5; up++, n = n.parentElement) {
          const box = n.querySelector('input[type="checkbox"], [role="checkbox"], [class*="checkbox" i], [class*="Checkbox" i]');
          if (box) return { box, row: n };
        }
        return null;
      };
      for (const opt of options) {
        try {
          const f = findBox(opt.label);
          if (!f) { console.warn('[CRM插件] 百家号：未找到「' + opt.label + '」勾选项，请手动核对'); continue; }
          const cur = checkedOf(f.box);
          if (cur === opt.want) continue;
          await bjhCdpClick(f.box);
          await sleep(250);
          try { f.box.click(); } catch (e) { /* ignore */ }
          await sleep(400);
          const cur2 = checkedOf(f.box);
          if (cur2 !== opt.want) { // 点击框可能没反应，改点行内文字
            try { f.row.click(); } catch (e) { /* ignore */ }
            await sleep(400);
          }
          const cur3 = (() => { const g = findBox(opt.label); return g ? checkedOf(g.box) : cur2; })();
          console.log('[CRM插件] 百家号：「' + opt.label + '」' + (cur ? '已勾' : '未勾') + ' → ' + (opt.want ? '勾选' : '取消')
            + (cur3 === opt.want ? '，成功' : '，未生效请手动核对'));
        } catch (e) { /* ignore */ }
      }
    } catch (e) { /* ignore */ }
  }

  // 填充后处理：知乎逐个把占位符替换为真实图片（文件粘贴 → 编辑器自传）
  CRM.afterFill = {
    // 知乎：通用占位符粘贴；编辑器按候选轮询定位（旧版 DraftJS / 新版编辑器结构都可能变化）
    zhihu: makeImagePasteAfterFill([
      '.public-DraftEditor-content[contenteditable="true"]',
      '.DraftEditor-editorContainer [contenteditable="true"]',
      '[data-contents="true"] [contenteditable="true"]',
      '.PostEditor-contentContainer [contenteditable="true"]',
      '.EditPage-content [contenteditable="true"]'
    ]),
    // 小红书：上传图片后会弹出「图片编辑」裁剪弹窗，挡住发布按钮。
    // 填充完成后循环点「完成」确认，直到弹窗全部关闭，再交给自动发布
    xiaohongshu: async () => {
      try {
        let escSent = 0;
        for (let i = 0; i < 8; i++) {
          await sleep(1200);
          // 「图片编辑」弹窗检测：注意编辑页有常驻内嵌面板标题也叫「图片编辑」（旁挂 1/18 页码），
          // 单看文字会永久误报。模态的可靠特征是全屏蒙层（fixed + 大面积覆盖），两者同时成立才算弹窗在
          const hasOverlay = Array.from(document.querySelectorAll('div')).some((ov) => {
            try {
              const cs = (ov.ownerDocument.defaultView || window).getComputedStyle(ov);
              if (cs.position !== 'fixed') return false;
              const r = ov.getBoundingClientRect();
              if (!(r.width >= window.innerWidth * 0.9 && r.height >= window.innerHeight * 0.9)) return false;
              // 必须真的是「遮罩」：只统计固定全屏会命中透明容器（pointer-events:none /
              // 背景全透明），把常驻「图片编辑」面板误判成弹窗，导致 8 轮空转 + 狂发 ESC
              // （v1.9.78 实测事故）。要求：可接收指针 且（有半透明/实色背景 或 有背景图/毛玻璃）
              if (cs.pointerEvents === 'none') return false;
              const alpha = (function (bg) {
                const m = /rgba?\(([^)]+)\)/.exec(bg || '');
                if (!m) return 1;
                const ps = m[1].split(',').map((s) => parseFloat(s));
                return ps.length >= 4 ? ps[3] : 1;
              })(cs.backgroundColor);
              const hasBackdrop = cs.backdropFilter && cs.backdropFilter !== 'none';
              const hasImg = cs.backgroundImage && cs.backgroundImage !== 'none';
              return (alpha > 0.03 || hasImg || hasBackdrop);
            } catch (e) { return false; }
          });
          const hasCropModal = hasOverlay && Array.from(document.querySelectorAll('div,span')).some(
            (d) => {
              const t2 = ((d.textContent || '') + '').trim();
              if (t2 !== '图片编辑' || !d.offsetParent) return false;
              const r = d.getBoundingClientRect();
              return r.width > 0 && r.width < 300 && r.height > 0 && r.height < 80;
            }
          );
          if (!hasCropModal) {
            // 弹窗关闭后再确认一次（多图会逐张弹），无弹窗即结束
            if (i >= 2) break;
            continue;
          }
          // 「完成」按钮是自定义标签实现、且可能在 Shadow DOM 内（v1.9.70 实测 8 轮都找不到）：
          // 穿透 Shadow DOM 全元素扫描，文案按「完成」前缀匹配，取最小面积（最内层可点击元素）
          let doneBtn = null, bestA = Infinity;
          for (const el of deepQueryAll(document, '*')) {
            const t3 = ((el.innerText || el.textContent || '') + '').replace(/\s+/g, '');
            if (!t3 || t3.length > 8) continue;
            if (!(t3 === '完成' || t3.indexOf('完成') === 0)) continue;
            let r;
            try { r = el.getBoundingClientRect(); } catch (e) { continue; }
            if (r.width < 10 || r.height < 10 || r.width > 400 || r.height > 120) continue;
            try {
              const cs = (el.ownerDocument.defaultView || window).getComputedStyle(el);
              if (cs.display === 'none' || cs.visibility === 'hidden' || cs.pointerEvents === 'none') continue;
            } catch (e) { /* ignore */ }
            const a = r.width * r.height;
            if (a < bestA) { bestA = a; doneBtn = el; }
          }
          if (doneBtn) {
            try { doneBtn.click(); } catch (e) { /* ignore */ }
            console.log('[CRM插件] 小红书：已点击图片编辑「完成」（第 ' + (i + 1) + ' 轮）');
            await sleep(800);
          } else {
            // 诊断：列出弹窗内全部可见短文案，定位「完成」的真实文案/结构
            const seen = [];
            for (const el of deepQueryAll(document, 'button, div, span, a')) {
              const t4 = ((el.innerText || el.textContent || '') + '').replace(/\s+/g, '');
              if (!t4 || t4.length > 6 || seen.indexOf(t4) >= 0) continue;
              try {
                const r2 = el.getBoundingClientRect();
                if (r2.width < 20 || r2.height < 12) continue;
              } catch (e) { continue; }
              seen.push(t4);
              if (seen.length >= 30) break;
            }
            console.warn('[CRM插件] 小红书：图片编辑弹窗未找到「完成」按钮（页面可见短文案：' + (seen.join('、') || '无') + '）');
            // 「完成」可能叫别的名字：依次试 下一步/保存/确定/跳过/使用（v1.9.78：实测弹窗无「完成」字样）
            let alt = null, altA = Infinity;
            for (const el of deepQueryAll(document, 'button, div, span, a')) {
              const t5 = normBtnText(el.innerText || el.textContent || '');
              if (!t5 || !/^(完成|下一步|保存|确定|跳过|使用|插入)$/.test(t5)) continue;
              let r3;
              try { r3 = el.getBoundingClientRect(); } catch (e) { continue; }
              if (r3.width < 30 || r3.height < 20 || r3.width > 400) continue;
              try {
                const cs3 = (el.ownerDocument.defaultView || window).getComputedStyle(el);
                if (cs3.display === 'none' || cs3.visibility === 'hidden' || cs3.pointerEvents === 'none') continue;
              } catch (e) { /* ignore */ }
              const a3 = r3.width * r3.height;
              if (a3 < altA) { altA = a3; alt = el; }
            }
            if (alt) {
              try { alt.click(); } catch (e) { /* ignore */ }
              console.log('[CRM插件] 小红书：已点击图片编辑替代按钮「' + normBtnText(alt.innerText || '') + '」（第 ' + (i + 1) + ' 轮）');
              await sleep(800);
            } else if (escSent < 2) {
              // 最后兜底：ESC 取消当前弹层——图片已上传完毕，编辑是可选项。
              // 注意：ESC 可能中断上传，故整轮最多只发 2 次（v1.9.78 连发 8 次有风险）
              escSent++;
              try {
                const tgt = document.activeElement || document.body;
                ['keydown', 'keyup'].forEach((typ) => {
                  tgt.dispatchEvent(new KeyboardEvent(typ, { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true, cancelable: true }));
                });
                console.log('[CRM插件] 小红书：图片编辑弹窗无确认按钮，已发 ESC 尝试关闭（第 ' + escSent + ' 次）');
              } catch (e) { /* ignore */ }
              await sleep(800);
            }
          }
        }
      } catch (e) { /* 不阻塞自动发布 */ }
    },
    // 搜狐号：1) 按 CRM 结构化配置等待并点选 创作声明/补充声明/可见范围/栏目/属性/摘要；
    // 2) 自动上传封面；3) 图片占位符逐个替换为真实图片（文件粘贴 → 编辑器自带上传）。
    // 注意：页面为 SPA，右侧表单（摘要/属性/栏目/声明）渲染晚于正文编辑器，
    // 且按钮文案可能带空格（如“关 闭”），因此统一「轮询重试 + 文案去空格匹配」。
    sohu: async (job) => {
      const cfg = (job && job.platformConfig) || {};
      // 轮询执行 fn 直到返回真值或超时（默认 10 秒）
      const until = async (fn, timeout, interval) => {
        const start = Date.now();
        while (Date.now() - start < (timeout || 10000)) {
          try { if (await fn()) return true; } catch (e) { /* ignore */ }
          await sleep(interval || 600);
        }
        return false;
      };
      // 点击页面上可见的短文案节点（label/span/div/button/a/p），文案去空格比对；
      // 多层嵌套时取最小面积（最深层）元素，确保点到真正绑定事件的目标（如「关联栏目」按钮）
      const clickText = (txt) => {
        const want = String(txt || '').replace(/\s+/g, '');
        const els = Array.from(document.querySelectorAll('label, span, div, button, a, p'))
          .filter((e) => (e.textContent || '').replace(/\s+/g, '') === want && e.offsetParent);
        if (!els.length) return false;
        let best = null;
        let bestArea = Infinity;
        for (const el of els) {
          try {
            const r = el.getBoundingClientRect();
            const area = r.width * r.height;
            if (area < bestArea) { bestArea = area; best = el; }
          } catch (e) { /* ignore */ }
        }
        try { best.click(); return true; } catch (e) { return false; }
      };
      const clickTextWait = (txt, timeout) => until(() => clickText(txt), timeout || 8000);

      // —— 1. 声明 / 可见范围 / 栏目 / 属性 / 摘要 ——
      try {
        // 必选声明：等声明区渲染出 radio 后，仅当尚未勾选时按配置点选（默认无需声明）
        const declPicked = () => Array.from(document.querySelectorAll('input[type="radio"]')).some((i) => i.checked);
        if (!(await until(declPicked, 12000))) {
          console.warn('[CRM插件] 搜狐声明区未出现，跳过声明选择');
        }
        if (!declPicked()) {
          const decl = cfg.declaration || '无需声明';
          if (!(await clickTextWait(decl))) console.warn('[CRM插件] 搜狐创作声明未找到选项：' + decl);
        }
        // 补充声明：引用声明
        if (cfg.refDeclaration && !(await clickTextWait('引用声明', 5000))) {
          console.warn('[CRM插件] 搜狐「引用声明」未找到，请手动勾选');
        }
        // 来源链接：勾选「引用声明」后页面才出现该输入框（placeholder 含「链接地址」）；
        // 用强制同步（含 blur）写入，确保平台内部模型更新，否则发布会报「来源链接不能为空」
        if (cfg.refDeclaration && cfg.sourceUrl) {
          const fillSourceUrl = async () => {
            const el = document.querySelector('input[placeholder*="链接地址"], input[placeholder*="链接"], textarea[placeholder*="链接"]');
            if (el) return syncInputValue(el, cfg.sourceUrl);
            return false;
          };
          if (!(await until(fillSourceUrl, 8000))) console.warn('[CRM插件] 未找到搜狐来源链接输入框，请手动填写');
        }
        // 可见范围：必须登录才能查看全文
        if (cfg.loginOnly && !(await clickTextWait('必须登录才能查看全文', 6000))) {
          console.warn('[CRM插件] 搜狐「可见范围」未找到，请手动勾选');
        }
        // 栏目：弹窗选择——弹窗须「可见且尺寸达标」才算打开（避免隐藏 dialog 容器误判导致跳过）；
        // 点选栏目用鼠标事件序列；点「确定」后必须验证弹窗关闭，否则整轮重试
        if (cfg.category) {
          // 可见弹窗：排除隐藏/零尺寸的 dialog 容器（页面常驻隐藏弹窗骨架）
          const visibleModal = () => {
            const ms = document.querySelectorAll('[role="dialog"], [class*="dialog"], [class*="modal"], [class*="popup"]');
            for (const m of ms) {
              try {
                const r = m.getBoundingClientRect();
                if (r.width > 200 && r.height > 120) return m;
              } catch (e) { /* ignore */ }
            }
            return null;
          };
          // 弹窗容器内点击短文案：mousedown/mouseup/click 全套 + 叶子节点取最小面积
          const clickInModal = (modal, txt) => {
            if (!modal) return null;
            const want = String(txt || '').replace(/\s+/g, '');
            const els = Array.from(modal.querySelectorAll('button, span, div, a, label, li'))
              .filter((e) => (e.textContent || '').replace(/\s+/g, '') === want
                && !e.querySelector('button, span, div, a, label, li'));
            let best = null;
            let bestArea = Infinity;
            for (const el of els) {
              try {
                const r = el.getBoundingClientRect();
                if (r.width < 5 || r.height < 5) continue;
                const area = r.width * r.height;
                if (area < bestArea) { bestArea = area; best = el; }
              } catch (e) { /* ignore */ }
            }
            if (!best) return null;
            try {
              best.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
              best.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
            } catch (e) { /* ignore */ }
            try { best.click(); } catch (e2) { /* ignore */ }
            return best;
          };
          const pickCategory = async () => {
            const modal = visibleModal();
            // 弹窗已开：点选栏目 → 确定 → 验证弹窗关闭；找不到该栏目则取消本次弹窗
            if (modal) {
              const opt = clickInModal(modal, cfg.category);
              if (opt) {
                await sleep(500);
                const confirmed = clickInModal(modal, '确定') || clickInModal(modal, '确认') || clickInModal(modal, '保存');
                if (!confirmed) {
                  clickInModal(modal, '取消') || clickInModal(modal, '关闭');
                  return false;
                }
                // 等弹窗关闭（最多 3 秒）：未关闭说明未生效，重试
                const st = Date.now();
                while (Date.now() - st < 3000) {
                  if (!visibleModal()) return true;
                  await sleep(300);
                }
                return false;
              }
              clickInModal(modal, '取消') || clickInModal(modal, '关闭');
              return false;
            }
            // 弹窗未开：点「关联栏目」，弹窗渲染后由下一轮处理
            clickText('关联栏目');
            return false;
          };
          if (!(await until(pickCategory, 15000))) {
            console.warn('[CRM插件] 搜狐栏目「' + cfg.category + '」未能自动关联，请手动选择');
            const m = visibleModal();
            if (m) clickInModal(m, '取消') || clickInModal(m, '关闭');
          }
        }
        // 属性：Element 风格下拉——在下拉浮层里轮询点选目标项；
        // 选项渲染慢 + 组件只响应鼠标事件序列，普通 click() 一次点不中，需 mousedown/mouseup/click 全套
        if (cfg.attribute) {
          const attrWant = String(cfg.attribute).replace(/\s+/g, '');
          // 带鼠标事件序列的点击（部分组件监听 mousedown 而非 click）
          const clickEl = (el) => {
            try {
              el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
              el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
            } catch (e) { /* ignore */ }
            try { el.click(); } catch (e2) { /* ignore */ }
          };
          // 找可见的短文案节点（去空格精确匹配），取最小面积（最深层）目标
          const findVisibleText = (want, needFloat) => {
            const els = Array.from(document.querySelectorAll('li, span, div, p, button, a, label'))
              .filter((e) => (e.textContent || '').replace(/\s+/g, '') === want && e.offsetParent);
            let best = null;
            let bestArea = Infinity;
            for (const el of els) {
              try {
                if (needFloat && !inFloatLayer(el)) continue;
                const r = el.getBoundingClientRect();
                if (r.width < 5 || r.height < 5) continue;
                const area = r.width * r.height;
                if (area < bestArea) { bestArea = area; best = el; }
              } catch (e) { /* ignore */ }
            }
            return best;
          };
          // 是否处于下拉浮层（class 含 dropdown/popper 等，或定位脱离文档流）
          const inFloatLayer = (el) => {
            let n = el;
            while (n && n !== document.body) {
              if (/(dropdown|popper|popover|select|option|menu|layer)/i.test((n.className || '') + '')) return true;
              const pos = (n.style && n.style.position) || '';
              if (pos === 'absolute' || pos === 'fixed') return true;
              n = n.parentElement;
            }
            return false;
          };
          const pickAttr = async () => {
            // 下拉已开：目标选项可见 → 直接点选（不动触发器，避免把已开的下拉点关）
            const opt = findVisibleText(attrWant, true);
            if (opt) { clickEl(opt); return true; }
            // 未开：点「未选择」展开；找不到「未选择」说明已选中（触发器显示选中项）
            const trigger = findVisibleText('未选择', false);
            if (!trigger) return true;
            clickEl(trigger);
            return false;
          };
          if (!(await until(pickAttr, 12000))) {
            console.warn('[CRM插件] 搜狐属性「' + cfg.attribute + '」未能自动选择');
          }
        }
        // 摘要：填写 placeholder 含「摘要」的输入框（contenteditable 伪元素兜底）
        if (cfg.summary) {
          const fillSummary = async () => {
            const sumEl = document.querySelector('textarea[placeholder*="摘要"], input[placeholder*="摘要"]');
            if (sumEl) { nativeSet(sumEl, cfg.summary); return editableValue(sumEl).trim().length > 0; }
            const ed = findEditableByPlaceholder('摘要');
            if (ed) { nativeSet(ed, cfg.summary); return true; }
            return false;
          };
          if (!(await until(fillSummary, 6000))) console.warn('[CRM插件] 未找到搜狐摘要输入框');
        }
        // 话题：搜索式交互，暂不自动填写，提示手动
        if (cfg.topic) {
          console.warn('[CRM插件] 搜狐话题「' + cfg.topic + '」为搜索式选择，请在页面手动添加');
        }
      } catch (e) { /* 不阻塞后续步骤 */ }

      // —— 2. 封面：把 CRM 封面图塞进封面上传框（等同手动上传） ——
      try {
        if (job && job.coverUrl) {
          const hasCover = () => !!document.querySelector(
            '[class*="cover"] img[src]:not([src=""]):not([src*="placeholder"]), [class*="img-preview"] img, img[src^="blob:"]');
          if (!(await until(hasCover, 1200, 400))) {
            const dataUrl = await fetchImageDataUrl(job.coverUrl);
            const file = dataUrl ? await dataUrlToUploadFile(dataUrl, 'cover.jpg') : null;
            const input = deepQueryAll(document, 'input[type="file"]').find((el) => {
              const acc = (el.accept || '').toLowerCase();
              return !acc || acc.indexOf('image') >= 0 || /\.(jpe?g|png|webp|gif|bmp|svg)/.test(acc);
            });
            if (file && input) {
              putFileToInput(input, file);
              // 若弹出裁剪/确认弹窗则点确认；等封面缩略图出现
              await until(async () => {
                const ok = hasCover();
                if (!ok) {
                  const confirmBtn = Array.from(document.querySelectorAll('button, div, span'))
                    .find((b) => ['确定', '确 定', '完成', '裁剪'].indexOf((b.textContent || '').replace(/\s+/g, '').slice(0, 4)) >= 0
                      && !b.firstElementChild && b.offsetParent
                      && /(裁剪|dialog|modal)/i.test((b.closest('[class*="dialog"],[class*="modal"],[class*="popup"]') || {}).className || ''));
                  if (confirmBtn) { confirmBtn.click(); await sleep(500); }
                }
                return ok;
              }, 12000);
            }
          }
        }
      } catch (e) { /* 封面失败不阻塞发布 */ }

      // —— 3. 图片占位符 → 文件粘贴（编辑器自传，规避「正文中含有未上传的图片」） ——
      try {
        const imgs = (job && job._sohuImages) || [];
        if (imgs.length) {
          await sleep(800);
          // 搜狐编辑器为 UEditor：正文在 id=ueditor_0 的同源 iframe 内
          const iframe = queryFrameDoc('#ueditor_0') || queryFrameDoc('iframe[id^="ueditor"]');
          let editor = editableOf(iframe);
          if (!editor) editor = queryFrameDoc('.ueditor-body') || document.querySelector('[contenteditable="true"]');
          if (!editor) { console.warn('[CRM插件] 未找到搜狐编辑器'); return; }
          const idoc = editor.ownerDocument;
          const isvg = /^data:image\/svg/i;
          for (let i = 0; i < imgs.length; i++) {
            const token = '[[CRM_IMG_' + (i + 1) + ']]';
            const walker = idoc.createTreeWalker(editor, NodeFilter.SHOW_TEXT);
            let node = null;
            let n;
            while ((n = walker.nextNode())) {
              if (n.textContent && n.textContent.indexOf(token) >= 0) { node = n; break; }
            }
            if (!node) { console.warn('[CRM插件] 搜狐未找到图片占位符：' + token); continue; }
            const idx = node.textContent.indexOf(token);
            const sel = idoc.defaultView.getSelection();
            const range = idoc.createRange();
            range.setStart(node, idx);
            range.setEnd(node, idx + token.length);
            sel.removeAllRanges();
            sel.addRange(range);
            idoc.execCommand('delete');
            await sleep(200);
            // 以「文件粘贴」插入图片，触发搜狐编辑器自带上传
            try {
              const blob = await (await fetch(imgs[i])).blob();
              const file = new File([blob], 'crm-image-' + (i + 1) + (isvg.test(imgs[i]) ? '.png' : '.jpg'), { type: blob.type || 'image/png' });
              const dt = new DataTransfer();
              dt.items.add(file);
              try { editor.focus(); } catch (e2) { /* ignore */ }
              editor.dispatchEvent(new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dt }));
            } catch (e) {
              console.warn('[CRM插件] 搜狐图片文件粘贴失败：', e && e.message);
            }
            await sleep(2500); // 等编辑器完成上传与回填
          }
        }
      } catch (e) { /* 不阻塞后续发布 */ }
    },
    // 开源中国 / 博客园 / CSDN / 掘金 / 百家号 / 51CTO：占位符 → 文件粘贴（编辑器自传）
    oschina: makeImagePasteAfterFill(['.w-e-text[contenteditable="true"]', '.w-e-text']),
    cnblogs: makeImagePasteAfterFill(['.mce-content-body', '#tinymce']),
    csdn: makeImagePasteAfterFill([
      '.w-e-text-container [contenteditable="true"]',
      '[data-slate-editor="true"]',
      '[class*="editor-content"] [contenteditable="true"]',
      '.cm-content[contenteditable="true"]',
      '[contenteditable="true"]'
    ], (n) => 'CRMIMGPH' + n + 'END'),
    // 掘金：新版编辑器为富文本 coreditor（editor-content），旧版/残留的 .CodeMirror 只作兜底；
    // SPA 慢水合，等待放宽到 30 秒
    juejin: makeImagePasteAfterFill(['.editor-content', '[contenteditable="true"]', '.CodeMirror'], null, false, 30000),
    // 百家号三段式：① 标题/正文被编辑器重渲染清空时 CDP 可信补填；
    // ② 占位符处图片合成粘贴（编辑器接受则自传）；③ 粘贴被忽略时 CDP 工具栏上传兜底
    baijiahao: async (job) => {
      try { await cdpFillBaijiahao(job); } catch (e) { console.warn('[CRM插件] 百家号 CDP 补填异常：' + ((e && e.message) || e)); }
      // 正文在编辑器 iframe 内（BODY.view）：用 bjhContentEl 定位，别用主文档选择器（会命中标题框）
      try { await makeImagePasteAfterFill(() => bjhContentEl(), null, false, 30000)(job); } catch (e) { /* ignore */ }
      try { await baijiahaoCdpUpload(job); } catch (e) { /* ignore */ }
    },
    // 51CTO：编辑器既忽略合成文件粘贴、也不转存 DOM 插入的 data: 图（v1.7.0 实测发布被
    // 「请等待文章中图片上传完成」拦截），主路径改走编辑器原生上传 input；
    // 走不通的图退回 insertHTML（至少保证占位符不残留）。粘贴可能触发「Markdown 转投」询问，前后各清一次
    cto51: async (job) => {
      try { await closeCto51MarkdownPrompt(); } catch (e) { /* ignore */ }
      try {
        const imgs = (job && job._crmImages) || [];
        if (imgs.length) {
          // 主路径：API 直传（抓包 getUploadSign/getUploadConfig/COS，无需文件选择框）
          let okCnt = 0;
          try { okCnt = await cto51ApiUploadAndReplace(job, imgs); } catch (e) { /* ignore */ }
          if (okCnt < imgs.length) {
            const cnt2 = await uploadCto51ImagesViaFileInput(job, imgs);
            if (cnt2 + okCnt < imgs.length) {
              try { await makeImagePasteAfterFill(['[contenteditable="true"]'], null, true)(job); } catch (e) { /* ignore */ }
            }
          }
        }
      } catch (e) { /* ignore */ }
      try { await closeCto51MarkdownPrompt(); } catch (e) { /* ignore */ }
    }
  };

  // ==================== 自动发布 ====================
  // 各平台「发布」按钮与「二次确认」按钮候选选择器（按命中概率排序），
  // 找不到时返回失败，由 content.js 回退为手动模式，绝不误点。
  // published：发布成功后的文章页 URL 特征（命中才允许判成功）
  // draft：草稿/未真正发布的 URL 或页面特征，命中一律判失败，避免把「保存草稿」误报为成功
  const PUBLISH_CFG = {
    xiaohongshu: {
      // 创作页发布按钮文案是「发布笔记」（div 实现，非 button），靠文案兜底匹配
      words: ['发布笔记', '发笔记', '发布'],
      // 注意：创作页 URL/容器 class 全带 publish（/publish/publish），
      // `[class*="publish"] div/button` 会命中容器里文档序第一个元素（实测误点话题区「编辑」，
      // v1.9.69 事故），一律不能用 class 通配，只靠精确文案匹配
      publish: [
        'button:has-text("发布")',
        '.publish-btn',
        'button.el-button--primary'
      ],
      confirm: ['button:has-text("确认发布")', 'button:has-text("确定")', '.el-message-box__btns button.el-button--primary'],
      published: [/xiaohongshu\.com\/(explore|discovery\/item|user\/profile)/i, /\/publish\/success/i],
      draft: [/draft/i]
    },
    zhihu: {
      publish: ['button:has-text("发布")', 'button:has-text("发布文章")', '.PublishPanel button', 'button.Button--primary'],
      confirm: ['button:has-text("确认")', 'button:has-text("发布")', '[class*="Modal"] button.Button--primary'],
      // 知乎发布成功后从 /write 跳转到 /p/数字（阅读页）或 /p/数字/edit（新编辑器会停在编辑页），
      // 两者都算发布成功；创作页本身是 /write，仍是草稿特征
      published: [/zhuanlan\.zhihu\.com\/p\/\d+\/?(edit)?\/?(\?.*)?$/i, /zhihu\.com\/question\/\d+\/answer\/\d+\/?$/i],
      draft: [/draft/i, /\/write/i]
    },
    juejin: {
      publish: ['button:has-text("发布")', 'button:has-text("发布文章")', '.publish-btn', 'button.btn-primary'],
      confirm: ['button:has-text("确定并发布")', 'button:has-text("确认")', '.el-button--primary'],
      published: [/juejin\.cn\/post\//i],
      draft: [/juejin\.cn\/(editor|draft)/i]
    },
    baijiahao: {
      publish: ['button:has-text("发布")', 'button:has-text("发表")', '[class*="publish"] button', '.ant-btn-primary'],
      confirm: ['button:has-text("确定")', 'button:has-text("确认发布")', '.ant-btn-primary'],
      published: [/baijiahao\.baidu\.com\/s\?id=/i, /builder\/article\/status/i, /builder\/rc\/\?type=success/i,
        /baijiahao\.baidu\.com\/builder\/rc\/(home|article|content|list)/i],
      draft: [/draft/i, /builder\/author\/prepare\/write/i]
    },
    sohu: {
      publish: ['button:has-text("发布")', 'button:has-text("发表")', '#publishBtn', '.publish-btn'],
      confirm: ['button:has-text("确定")', 'button:has-text("确认")'],
      // 发布成功后跳内容管理列表页；注意编辑页 addarticle 本身含 "article"，需排除避免误判
      published: [/mp\.sohu\.com\/(?!.*addarticle).*(article|contentManagement|status|detail)/i, /sohu\.com\/a\//i],
      draft: [/draft/i, /mp\.sohu\.com\/.*(write|edit)/i]
    },
    oschina: {
      publish: ['button:has-text("发布")', 'button:has-text("发表")', '#btn-publish', '.btn-publish'],
      confirm: ['button:has-text("确定")', 'button:has-text("确认")'],
      published: [/my\.oschina\.net\/.*\/blog\/\d+/i],
      draft: [/my\.oschina\.net\/.*\/blog\/write/i, /draft/i]
    },
    cnblogs: {
      publish: ['button:has-text("发布")', '#btnPublish', 'input[value*="发布"]'],
      confirm: ['button:has-text("确定")', 'button:has-text("是")'],
      published: [/cnblogs\.com\/[\w-]+\/p\/\d+/i, /cnblogs\.com\/[\w-]+\/articles\//i],
      draft: [/i\.cnblogs\.com/i, /draft/i]
    },
    csdn: {
      // 富文本页底部是「保存草稿 / 定时发布 / 发布博客」：宽泛的 has-text("发布")
      // 会按文档序先命中「定时发布」，必须用精确文案匹配
      publish: ['button:has-text("发布博客")', 'button:has-text("发布文章")'],
      confirm: ['button:has-text("确定")', 'button:has-text("确认发布")', '.el-button--primary'],
      published: [/blog\.csdn\.net\/[\w]+\/article\/details\//i],
      // 停在创作页（Markdown 编辑器或新版富文本编辑器）都算未发布
      draft: [/editor\.csdn\.net/i, /mp_blog\/creation\/editor/i, /draft/i]
    },
    cto51: {
      publish: ['button:has-text("发布")', 'button:has-text("发布文章")', '[class*="publish"] button'],
      confirm: ['button:has-text("确认发布")', 'button:has-text("确定")'],
      // 发布成功整页跳转到 blogger/success/<文章id>（「发布成功 待审核」页）；
      // 此前无 cto51 条目回落 generic（published 为空），跳转后补传永远判不中导致结果不回写
      published: [/blog\.51cto\.com\/blogger\/success\/\d+/i],
      draft: [/draft/i]
    },
    douyin_image: {
      publish: ['button:has-text("发布")', 'button:has-text("投稿")', '[class*="publish"] button'],
      confirm: ['button:has-text("确定")', 'button:has-text("确认发布")'],
      published: [/creator\.douyin\.com\/.*(manage|works|success)/i],
      draft: [/creator\.douyin\.com\/.*(publish|image)/i, /draft/i]
    },
    douyin_article: {
      publish: ['button:has-text("发布")', 'button:has-text("投稿")', '[class*="publish"] button'],
      confirm: ['button:has-text("确定")', 'button:has-text("确认发布")'],
      published: [/creator\.douyin\.com\/.*(manage|works|success)/i],
      draft: [/creator\.douyin\.com\/.*(publish|article)/i, /draft/i]
    },
    generic: {
      publish: ['button:has-text("发布")', 'button:has-text("发表")', 'button:has-text("投稿")', 'button:has-text("提交")'],
      confirm: ['button:has-text("确认发布")', 'button:has-text("确定")', 'button:has-text("确认")'],
      published: [],
      draft: [/draft/i, /editor/i, /\/write/i]
    }
  };

  const SUCCESS_WORDS = ['发布成功', '发表成功', '发布完成', '已发布', '投稿成功'];

  /** 判断 URL 是否命中平台「已发布文章页」特征（供跳转后补传判定） */
  CRM.checkPublished = function (code, url) {
    const cfg = PUBLISH_CFG[code] || PUBLISH_CFG.generic;
    return (cfg.published || []).some((re) => re.test(url));
  };
  /** 小红书：发布成功页（/publish/success）没有笔记直链，同源抓「笔记管理」页
   *  解析最新一篇的笔记链接（尽力而为）：
   *  1) 页面 DOM/HTML 里的 explore / xhslink 直链；2) 内嵌 JSON 的 noteId（24 位 hex）。
   *  笔记管理页若为纯客户端渲染则拿不到，返回空串由调用方标注降级 */
  CRM.resolveXhsNoteUrl = async function () {
    const pages = [
      'https://creator.xiaohongshu.com/publish/note?source=official',
      'https://creator.xiaohongshu.com/manage/note?source=official'
    ];
    for (const u of pages) {
      try {
        const res = await fetch(u, { credentials: 'include' });
        if (!res.ok) continue;
        const html = await res.text();
        // 1) 直链：explore 详情 / 用户主页笔记 / xhslink 短链
        const m = html.match(/https?:\/\/www\.xiaohongshu\.com\/(?:explore|discovery\/item|user\/profile)\/[0-9a-f]{24}/i)
          || html.match(/https?:\/\/xhslink\.com\/[A-Za-z0-9]+/);
        if (m) return m[0];
        // 2) 内嵌 JSON 的 noteId（__INITIAL_STATE__ 等）
        const id = html.match(/"note_id"\s*:\s*"?([0-9a-f]{24})"?/i) || html.match(/explore\/([0-9a-f]{24})/i);
        if (id) return 'https://www.xiaohongshu.com/explore/' + id[1];
      } catch (e) { /* 换下一个入口 */ }
    }
    return '';
  };
  const DRAFT_WORDS = ['保存草稿', '已保存', '存入草稿', '草稿箱', '保存成功'];

  /** 穿透 Shadow DOM 的深度选择器查询（搜狐新版编辑器可能使用 web components） */
  function deepQueryAll(rootDoc, selector) {
    const out = [];
    const seenRoots = typeof WeakSet === 'function' ? new WeakSet() : null;
    const walk = (root) => {
      if (!root) return;
      if (seenRoots) {
        if (seenRoots.has(root)) return;
        seenRoots.add(root);
      }
      // 必须遍历所有元素（而非仅匹配选择器的）：小红书发布栏/图片编辑弹窗是自定义元素
      // （宿主标签不是 div/span/button），只递归命中元素的 shadowRoot 会整块漏掉其内部
      // 的「发布/完成」按钮（v1.9.77 实测：底部发布按钮连候选明细都不出现）
      let els = [];
      try { els = Array.from(root.querySelectorAll('*')); } catch (e) { els = []; }
      for (const el of els) {
        let hit = false;
        try { hit = el.matches(selector); } catch (e) { /* ignore */ }
        if (hit) out.push(el);
        try { if (el.shadowRoot) walk(el.shadowRoot); } catch (e) { /* ignore */ }
      }
    };
    walk(rootDoc);
    return out;
  }

  /** 文案是否像「发布」按钮：与候选词精确相同或以其开头（如「发布笔记」），
   *  且不含草稿/保存/预览/定时等负面词，避免误点保存草稿、定时发布 */
  /** 文案归一化（核弹级）：只保留 中文/字母/数字——零宽字符、软连字符(U+00AD)、
   *  变体选择符(U+FE0F)、emoji 修饰符等一切隐形/装饰字符全部剔除。
   *  小红书等平台会在按钮文字里插隐形字符（防爬/排版），\s 与 indexOf('发布') 都匹配不上，
   *  导致「发布」按钮在所有文案匹配里凭空消失（v1.9.72/73 实测事故，v1.9.74 升级为白名单清洗） */
  function normBtnText(s) {
    return ((s || '') + '').replace(/[^\u4e00-\u9fa5a-zA-Z0-9]/g, '');
  }
  function isPublishText(txt, words) {
    const t = normBtnText(txt);
    if (!t) return false;
    if (/草稿|保存|存|预览|定时|排版|返回|取消|一键/.test(t)) return false;
    return (words || []).some((w) => t === w || t.indexOf(w) === 0);
  }

  /** 按可见文本匹配按钮（各平台 class 混乱，文案更稳定） */
  function findByText(selectors, words) {
    for (const sel of selectors) {
      let el = null;
      try {
        el = queryDoc(sel);
      } catch (e) {
        el = null; // :has-text 在部分环境不被支持，忽略并走下一候选
      }
      if (el) return el;
    }
    // 兜底：遍历按钮按文案匹配（含 Shadow DOM）
    for (const d of docList()) {
      const btns = deepQueryAll(d, 'button, a[role="button"], input[type="button"], [role="button"]');
      for (const b of btns) {
        const txt = ((b.innerText || b.textContent || b.value || '') + '').trim();
        if (!txt) continue;
        if (!isPublishText(txt, words)) continue;
        return b;
      }
      // 部分平台（如搜狐）的「发布」按钮是 div/span 而非 button：按文案匹配可见可点击元素。
      // 用「前缀匹配」而非精确相等：小红书等平台按钮文案是「发布笔记」这类组合词
      const els = deepQueryAll(d, 'div, span, a');
      for (const el of els) {
        const txt = ((el.innerText || '') + '').trim();
        if (!txt || txt.length > 8) continue; // 只接受短文案，避免命中正文段落
        if (!isPublishText(txt, words)) continue;
        try {
          const cs = (el.ownerDocument.defaultView || window).getComputedStyle(el);
          if (cs.display === 'none' || cs.visibility === 'hidden' || cs.pointerEvents === 'none') continue;
        } catch (e) { /* ignore */ }
        const r = el.getBoundingClientRect();
        if (r.width < 10 || r.height < 10) continue;
        return el;
      }
    }
    return null;
  }

  /**
   * 自动发布：点击「发布」→ 如有二次确认弹窗则点「确认」→ 等待发布成功信号（URL 跳转 / 成功提示）。
   * 任一步未命中即返回失败，交给上层回退为手动模式，不做无依据的猜测点击。
   */
  function hasText(words) {
    for (const d of docList()) {
      let txt = '';
      try {
        txt = (d.body && d.body.innerText) || '';
      } catch (e) {
        txt = '';
      }
      if (!txt) continue;
      if (words.some((w) => txt.includes(w))) return true;
    }
    return false;
  }

  /**
   * 搜狐「发布」按钮专用查找：
   * 按钮文案可能带空格（如“发 布”），且不一定是标准 <button>，
   * 按去空格后的文案在 button/div/span/a/p/label 中精确匹配，轮询等待工具栏渲染。
   */
  async function findSohuPublishBtn(timeout) {
    const norm = (s) => ((s || '') + '').replace(/\s+/g, '');
    const start = Date.now();
    while (Date.now() - start < (timeout || 8000)) {
      const cands = [];
      for (const d of docList()) {
        // 搜狐可能用非标准标签渲染按钮：全元素扫描，按去空格文案精确匹配
        for (const el of deepQueryAll(d, '*')) {
          const t = norm(el.innerText || el.textContent || '');
          if (t !== '发布' && t !== '发布文章' && t !== '发表') continue;
          if (!elVisible(el)) continue;
          try {
            const r = el.getBoundingClientRect();
            if (r.width > 400 || r.height > 120) continue; // 排除误命中的大容器
            cands.push({ el, area: r.width * r.height });
          } catch (e) { /* ignore */ }
        }
      }
      // 多层嵌套时取最小面积（最深层的实际可点击元素），避免点到不响应的外层容器
      if (cands.length) {
        cands.sort((a, b) => a.area - b.area);
        return cands[0].el;
      }
      await sleep(600);
    }
    return null;
  }

  /** 小红书笔记发布前设置（发布页「内容设置」区，消费 job.platformConfig）：
   *  original=true → 打开「原创声明」开关；allowCopy=false → 关「允许正文复制」；
   *  visibility → 可见权限下拉（公开可见/仅自己可见/仅互关好友可见）。
   *  这些控件在 shadow DOM 里（v1.9.83 起 main-world 补丁已强制 open，可正常扫描）。
   *  开关状态判定：aria-checked 优先，红色背景兜底；已达目标状态不重复点击。 */
  async function applyXhsNoteSettings(c) {
    c = c || {};
    // 入口诊断：配置原样打印 + 版本号，一次测试就能分辨「没收到配置」还是「控件没找到」
    try {
      const ver = (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getManifest) ? chrome.runtime.getManifest().version : '?';
      console.log('[CRM插件] 小红书：笔记设置开始 v' + ver + '，platformConfig=' + JSON.stringify(c));
    } catch (e) { /* ignore */ }
    if (!c.original && !c.allowCopy && !c.visibility && !c.contentType) {
      console.warn('[CRM插件] 小红书：platformConfig 无笔记设置项（original/allowCopy/visibility/contentType 全空）——请检查预览适配里是否已填写并点「保存」');
      return;
    }
    // 轮询助手（模块级无 until，sohu 里的那份是函数局部，不在本作用域）
    const until = async (fn, timeout, interval) => {
      const start = Date.now();
      while (Date.now() - start < (timeout || 10000)) {
        try { if (await fn()) return true; } catch (e) { /* ignore */ }
        await sleep(interval || 600);
      }
      return false;
    };
    // 派发完整指针事件序列（小红书 React 组件部分只认 pointer/mousedown，裸 .click() 可能无效）
    const fireClick = (el) => {
      if (!el) return;
      try {
        const r = el.getBoundingClientRect();
        const opts = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
        el.dispatchEvent(new PointerEvent('pointerdown', opts));
        el.dispatchEvent(new MouseEvent('mousedown', opts));
        el.dispatchEvent(new PointerEvent('pointerup', opts));
        el.dispatchEvent(new MouseEvent('mouseup', opts));
        el.dispatchEvent(new MouseEvent('click', opts));
      } catch (e) { try { el.click(); } catch (e2) { /* ignore */ } }
    };
    // 浏览器级可信点击（chrome.debugger Input.dispatchMouseEvent）。
    // v1.9.87 实测：小红书设置区（开关/下拉）对合成事件完全无反应，发布按钮当初也是靠这条路点成功的
    const cdpClickEl = async (el) => {
      if (!el) return false;
      try { el.scrollIntoView({ block: 'center' }); } catch (e) { /* ignore */ }
      await sleep(350);
      let r;
      try { r = el.getBoundingClientRect(); } catch (e) { return false; }
      const x = Math.round(r.left + r.width / 2), y = Math.round(r.top + r.height / 2);
      // 遮挡探测：看这个坐标真实命中谁。点不动却毫无报错，多半点在预览副本/透明蒙层上
      try {
        const top = document.elementFromPoint(x, y);
        if (top && top !== el && !el.contains(top) && !top.contains(el)) {
          console.warn('[CRM插件] 小红书：点击位 @' + x + ',' + y + ' 实际命中 '
            + top.tagName + '.' + ((top.className && top.className.toString ? top.className.toString() : '') || '').slice(0, 30)
            + '「' + (((top.textContent || '') + '').trim()).slice(0, 12) + '」，与目标元素不符（被遮挡/副本）');
        }
      } catch (e) { /* ignore */ }
      if (x < 1 || y < 1 || x > window.innerWidth - 1 || y > window.innerHeight - 1) {
        console.warn('[CRM插件] 小红书：目标不在视口内（@' + x + ',' + y + '，视口 ' + window.innerWidth + 'x' + window.innerHeight + '），跳过 CDP 点击');
        return false;
      }
      try {
        const res = await chrome.runtime.sendMessage({ type: 'crmCdpClick', x, y });
        if (res && res.ok) { console.log('[CRM插件] 小红书：CDP 可信点击 @' + x + ',' + y); return true; }
        console.warn('[CRM插件] 小红书：CDP 点击失败：' + ((res && res.message) || '后台无响应'));
      } catch (e) { console.warn('[CRM插件] 小红书：CDP 点击异常：' + ((e && e.message) || e)); }
      return false;
    };
    // 最后兜底：CDP 按文本穿透查找并点击（能穿透 closed shadow root，minY=0 关闭底部过滤）
    const cdpTextClick = async (text) => {
      try {
        const r = await chrome.runtime.sendMessage({ type: 'crmCdpFindTextClick', text: String(text), minY: 0 });
        if (r && r.clicked) { console.log('[CRM插件] 小红书：CDP 文本穿透点击「' + text + '」@' + r.clicked.x + ',' + r.clicked.y); return true; }
      } catch (e) { /* ignore */ }
      return false;
    };
    // 排除右侧「手机预览」里的镜像副本：创作页右侧常驻等比缩放的预览，里面同样有
    // 「原创声明 / 公开可见 / 添加内容类型声明」等文案（v1.9.80 曾误点预览区模板），点了毫无反应
    const inPreviewCopy = (el) => {
      let node = el;
      for (let i = 0; i < 8 && node; i++) {
        try {
          const cn = (node.className && node.className.toString ? node.className.toString() : '');
          const sig = (cn + ' ' + (node.id || '') + ' ' + ((node.getAttribute && node.getAttribute('data-testid')) || '')).toLowerCase();
          if (/preview|mock|phone|mobile|simulator|miniprogram|预览|缩略|thumbnail/.test(sig)) return true;
          // 预览区通常整体缩放：祖先存在非 1 缩放的 transform 也可疑
          const cs = (node.ownerDocument.defaultView || window).getComputedStyle(node);
          if (cs && cs.transform && /matrix\(([\d.]+)/.test(cs.transform)) {
            const sc = parseFloat(/matrix\(([\d.]+)/.exec(cs.transform)[1]);
            if (sc > 0 && Math.abs(sc - 1) > 0.02) return true;
          }
        } catch (e) { /* ignore */ }
        const root = node.getRootNode && node.getRootNode();
        node = node.parentElement || (root && root.host) || null;
      }
      return false;
    };
    // 精确文本找菜单选项（取最小面积，防止命中容器而非选项本身）
    const findOptText = (want) => {
      let opt = null, bestArea = Infinity;
      for (const el of deepQueryAll(document, 'div, li, span')) {
        const t = ((el.textContent || '') + '').replace(/\s+/g, '');
        if (t !== want) continue; // 精确匹配，防止「仅自己可见」匹配到「仅互关好友可见」
        if (inPreviewCopy(el)) continue; // 跳过右侧手机预览里的镜像文案
        let r;
        try { r = el.getBoundingClientRect(); } catch (e) { continue; }
        if (r.width < 30 || r.height < 20) continue;
        try {
          const cs = (el.ownerDocument.defaultView || window).getComputedStyle(el);
          if (cs.display === 'none' || cs.visibility === 'hidden') continue;
        } catch (e) { /* ignore */ }
        const a = r.width * r.height;
        if (a < bestArea) { bestArea = a; opt = el; }
      }
      return opt;
    };
    // 点选菜单选项：合成点击 → CDP 可信点击 → CDP 文本穿透点击，三级兜底
    const pickOption = async (want, label) => {
      let ok = await until(() => { const o = findOptText(want); if (!o) return false; fireClick(o); return true; }, 3000, 300);
      if (!ok) {
        const o = findOptText(want);
        if (o) ok = await cdpClickEl(o);
      }
      if (!ok) ok = await cdpTextClick(want);
      console.log(ok ? '[CRM插件] 小红书：已点选「' + want + '」' + (label ? '（' + label + '）' : '')
        : '[CRM插件] 小红书：未出现「' + want + '」选项' + (label ? '（' + label + '）' : ''));
      await sleep(500);
      return ok;
    };
    // 点开下拉再选：合成点击展开 → 失败改 CDP 可信点击展开
    const openAndPick = async (rowEl, want, label) => {
      fireClick(rowEl);
      let ok = await pickOption(want, label);
      if (!ok) {
        console.warn('[CRM插件] 小红书：「' + label + '」合成点击未打开菜单，改 CDP 可信点击展开');
        await cdpClickEl(rowEl);
        await sleep(700);
        ok = await pickOption(want, label);
      }
      return ok;
    };
    // 向上爬（跨 shadow host 边界），返回第一个通过 test 的祖先
    const climbFor = (el, test) => {
      let node = el;
      for (let i = 0; i < 8 && node && node !== document.body; i++) {
        if (test(node)) return node;
        const root = node.getRootNode && node.getRootNode();
        node = node.parentElement || (root && root.host) || null;
      }
      return null;
    };
    // 向上爬到「文本内容相同的最高层祖先」（通常即整行容器，含行尾开关/箭头）
    const climbSameText = (el) => {
      let node = el, top = el;
      for (let i = 0; i < 8 && node && node !== document.body; i++) {
        const root = node.getRootNode && node.getRootNode();
        const p = node.parentElement || (root && root.host) || null;
        if (!p || p === document.body) break;
        let r;
        try { r = p.getBoundingClientRect(); } catch (e) { break; }
        if (r.width > window.innerWidth * 0.7) break; // 爬出整行范围即停
        const tp = ((p.textContent || '') + '').replace(/\s+/g, '');
        const tc = ((node.textContent || '') + '').replace(/\s+/g, '');
        if (tp !== tc) break;
        top = p; node = p;
      }
      return top;
    };
    // 开关控件特征：role=switch / aria-checked 优先，几何胶囊（宽28-70 高16-36，取最靠行尾的）兜底
    const findToggleIn = (root) => {
      if (!root || !root.querySelector) return null;
      const aria = root.querySelector('[role="switch"], [aria-checked]');
      if (aria) return aria;
      let best = null, bestRight = -1;
      for (const el of root.querySelectorAll('*')) {
        let r;
        try { r = el.getBoundingClientRect(); } catch (e) { continue; }
        if (r.width < 28 || r.width > 70 || r.height < 16 || r.height > 36) continue;
        const right = r.left + r.width;
        if (right > bestRight) { bestRight = right; best = el; }
      }
      return best;
    };
    // 找「label 开头的最小可见行」及其开关控件：从文本元素向上爬到含开关的行容器，
    // 避免最小命中是文字 span 本身（点文字不动开关）——v1.9.86 未生效的主因
    const findSwitchRow = (label) => {
      const want = String(label).replace(/\s+/g, '');
      const vis = (el) => {
        try {
          const r = el.getBoundingClientRect();
          if (r.width < 40 || r.height < 20 || r.width > window.innerWidth * 0.9) return false;
          const cs = (el.ownerDocument.defaultView || window).getComputedStyle(el);
          return cs.display !== 'none' && cs.visibility !== 'hidden';
        } catch (e) { return false; }
      };
      const cands = [];
      for (const el of deepQueryAll(document, 'div, span, section')) {
        const t = ((el.textContent || '') + '').replace(/\s+/g, '');
        if (!t || t.indexOf(want) !== 0 || t.length > want.length + 12) continue;
        if (inPreviewCopy(el)) continue; // 跳过右侧手机预览里的镜像文案（点了没反应）
        if (vis(el)) cands.push(el);
      }
      if (!cands.length) return null;
      cands.sort((a, b) => {
        const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
        return ra.width * ra.height - rb.width * rb.height;
      });
      for (const el of cands.slice(0, 3)) {
        const row = climbFor(el, (n) => !!findToggleIn(n));
        if (row) return { row, toggle: findToggleIn(row) };
      }
      // 没有任何祖先含开关：点「同文本最高层祖先」整行（行点击通常也可切换）
      return { row: climbSameText(cands[0]), toggle: null };
    };
    // 开关是否处于「开」：aria-checked 优先，红底（小红书 #ff2444 系）兜底
    const isSwitchOn = (el) => {
      try {
        if (el.getAttribute) {
          const ac = el.getAttribute('aria-checked');
          if (ac === 'true') return true;
          if (ac === 'false') return false;
        }
        const cs = (el.ownerDocument.defaultView || window).getComputedStyle(el);
        const bg = (cs.backgroundColor || '') + ';' + (cs.backgroundImage || '');
        const ms = bg.match(/rgba?\(\s*\d+\s*,\s*\d+\s*,\s*\d+/g) || [];
        return ms.some((m) => {
          const x = /rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/.exec(m);
          if (!x) return false;
          const R = +x[1], G = +x[2], B = +x[3];
          return R >= 180 && G <= 120 && B <= 140;
        });
      } catch (e) { return false; }
    };
    const setSwitch = async (label, wantOn, tag) => {
      let hit = findSwitchRow(label);
      if (!hit) {
        // 可能折叠在「更多设置」里：点开展开头再找一次
        let exp = null, bestArea = Infinity;
        for (const el of deepQueryAll(document, 'div, span')) {
          const t = ((el.textContent || '') + '').replace(/\s+/g, '');
          if (t !== '更多设置' && t !== '展开' && t !== '展开设置') continue;
          let r;
          try { r = el.getBoundingClientRect(); } catch (e) { continue; }
          if (r.width < 40 || r.height < 20) continue;
          const a = r.width * r.height;
          if (a < bestArea) { bestArea = a; exp = el; }
        }
        if (exp) {
          fireClick(climbSameText(exp));
          await sleep(900);
          hit = findSwitchRow(label);
          console.log('[CRM插件] 小红书：已展开「更多设置」后' + (hit ? '重新找到' : '仍未找到') + '「' + label + '」');
        }
      }
      if (!hit) { console.warn('[CRM插件] 小红书：未找到「' + label + '」设置项'); return; }
      try {
        const rr = (hit.toggle || hit.row).getBoundingClientRect();
        console.log('[CRM插件] 小红书：「' + label + '」命中控件 @' + Math.round(rr.left + rr.width / 2) + ',' + Math.round(rr.top + rr.height / 2)
          + ' ' + Math.round(rr.width) + 'x' + Math.round(rr.height) + '（开关' + (hit.toggle ? '已定位' : '未定位，将点整行') + '）');
      } catch (e) { /* ignore */ }
      const state = () => isSwitchOn(hit.toggle || findToggleIn(hit.row) || hit.row);
      if (state() === wantOn) { console.log('[CRM插件] 小红书：「' + label + '」已是目标状态（' + (wantOn ? '开' : '关') + '）'); return; }
      fireClick(hit.toggle || hit.row);
      await sleep(700);
      if (state() !== wantOn) {
        // 合成事件被平台的 React 事件系统忽略 → 浏览器级可信点击
        console.warn('[CRM插件] 小红书：「' + label + '」合成点击未生效，改 CDP 可信点击');
        await cdpClickEl(hit.toggle || hit.row);
        await sleep(800);
      }
      if (state() !== wantOn && hit.toggle && hit.row !== hit.toggle) {
        console.warn('[CRM插件] 小红书：「' + label + '」CDP 点开关仍未生效，改点整行');
        await cdpClickEl(hit.row);
        await sleep(800);
      }
      if (state() === wantOn) {
        console.log('[CRM插件] 小红书：已' + (wantOn ? '打开' : '关闭') + '「' + label + '」' + (tag || ''));
      } else {
        console.warn('[CRM插件] 小红书：「' + label + '」未能切到目标状态（当前' + (state() ? '开' : '关') + '，目标' + (wantOn ? '开' : '关') + '）');
      }
    };
    if (c.original === true || c.original === 'true') {
      await setSwitch('原创声明', true, '（原创声明）');
    }
    if (c.allowCopy === true || c.allowCopy === 'true') {
      await setSwitch('允许正文复制', true, '（允许正文复制）');
    } else if (c.allowCopy === false || c.allowCopy === 'false') {
      await setSwitch('允许正文复制', false, '（关闭正文复制）');
    }
    if (c.visibility) {
      // 可见权限：点当前值行展开下拉 → 轮询菜单出现 → 点目标选项（精确匹配防误点）
      const want = String(c.visibility).replace(/\s+/g, '');
      if (want === '公开可见') { console.log('[CRM插件] 小红书：可见权限默认公开，无需设置'); }
      else {
        // 设置行特征：含「可见」的中等宽度行（排除菜单选项本身——选项短且以 公开/仅 开头）
        let row = null, bestArea = Infinity;
        for (const el of deepQueryAll(document, 'div, span')) {
          const t = ((el.textContent || '') + '').replace(/\s+/g, '');
          if (!t || t.indexOf('可见') < 0 || t.length > 14 || /^(公开|仅)/.test(t)) continue;
          if (inPreviewCopy(el)) continue;
          let r;
          try { r = el.getBoundingClientRect(); } catch (e) { continue; }
          if (r.width < 60 || r.height < 24 || r.width > window.innerWidth * 0.9) continue;
          try {
            const cs = (el.ownerDocument.defaultView || window).getComputedStyle(el);
            if (cs.display === 'none' || cs.visibility === 'hidden') continue;
          } catch (e) { /* ignore */ }
          const a = r.width * r.height;
          if (a < bestArea) { bestArea = a; row = el; }
        }
        if (!row) { console.warn('[CRM插件] 小红书：未找到可见权限设置行'); return; }
        const rowEl = climbSameText(row);
        try {
          const rr = rowEl.getBoundingClientRect();
          console.log('[CRM插件] 小红书：可见权限行 @' + Math.round(rr.left + rr.width / 2) + ',' + Math.round(rr.top + rr.height / 2)
            + ' ' + Math.round(rr.width) + 'x' + Math.round(rr.height));
        } catch (e) { /* ignore */ }
        const ok = await openAndPick(rowEl, want, '可见权限');
        console.log(ok ? '[CRM插件] 小红书：可见权限已设为「' + want + '」'
          : '[CRM插件] 小红书：可见权限未设置成功（下拉未展开或无「' + want + '」选项）');
        await sleep(500);
        if (ok && (want === '只给谁看' || want === '不给谁看')) {
          // 选人面板：按 visibilityUsers 逐个搜索并点选，最后点确定。
          // 未配置用户列表时无法自动收尾（发布会被拦），大声提示
          const users = String(c.visibilityUsers || '').split(/[,，、;；\s]+/).map((s) => s.trim()).filter(Boolean);
          if (!users.length) {
            console.warn('[CRM插件] 小红书：已点开「' + want + '」，但预览配置未填「可见用户」，请在页面手动选择后发布');
          } else {
            // 搜索框：可见 input，placeholder 含 搜索/昵称/用户；兜底取面板里唯一可见输入框
            let input = null;
            {
              const cands = deepQueryAll(document, 'input').filter((i) => {
                let r;
                try { r = i.getBoundingClientRect(); } catch (e) { return false; }
                return r.width >= 80 && r.height >= 20;
              });
              input = cands.find((i) => /搜索|昵称|用户|名字/.test(i.placeholder || '')) || (cands.length === 1 ? cands[0] : null);
            }
            if (!input) {
              console.warn('[CRM插件] 小红书：未找到「' + want + '」选人面板搜索框，请手动选择');
            } else {
              let picked = 0;
              for (const u of users) {
                // 输入昵称：合成事件对受控组件可能不生效，并行启用 CDP 真实键入兜底
                try {
                  Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set.call(input, u);
                  input.dispatchEvent(new Event('input', { bubbles: true }));
                } catch (e) { /* ignore */ }
                try {
                  await chrome.runtime.sendMessage({ type: 'crmCdpType', text: u, mode: 'keys', selectAll: true });
                } catch (e) { /* ignore */ }
                await sleep(900);
                // 点结果里含该昵称的最小可见元素（输入框 value 不算 textContent，不会误中）
                let hit = await until(() => {
                  let el = null, bestArea = Infinity;
                  for (const cand of deepQueryAll(document, 'div, span, p')) {
                    const t = ((cand.textContent || '') + '').replace(/\s+/g, '');
                    if (!t || t.indexOf(u) < 0 || t.length > u.length + 20) continue;
                    let r;
                    try { r = cand.getBoundingClientRect(); } catch (e) { continue; }
                    if (r.width < 30 || r.height < 20) continue;
                    try {
                      const cs = (cand.ownerDocument.defaultView || window).getComputedStyle(cand);
                      if (cs.display === 'none' || cs.visibility === 'hidden') continue;
                    } catch (e) { /* ignore */ }
                    const a = r.width * r.height;
                    if (a < bestArea) { bestArea = a; el = cand; }
                  }
                  if (!el) return false;
                  fireClick(el); return true;
                }, 2500, 250);
                if (!hit) hit = await cdpTextClick(u); // 兜底：CDP 文本穿透点击结果
                if (hit) picked++; else console.warn('[CRM插件] 小红书：「' + u + '」搜索无结果');
                await sleep(500);
              }
              console.log('[CRM插件] 小红书：「' + want + '」已选 ' + picked + '/' + users.length + ' 个用户');
              await sleep(400);
              // 点确定/完成收尾
              let confirmed = false;
              for (const b of deepQueryAll(document, 'button, div, span')) {
                const t = ((b.textContent || '') + '').replace(/\s+/g, '');
                if (t !== '确定' && t !== '完成' && t !== '确认') continue;
                let r;
                try { r = b.getBoundingClientRect(); } catch (e) { continue; }
                if (r.width < 40 || r.height < 20) continue;
                // 选人面板确定按钮走 CDP 可信点击（合成事件小红书不响应）
                await cdpClickEl(b);
                confirmed = true; break;
              }
              console.log(confirmed ? '[CRM插件] 小红书：已点击选人面板确认按钮'
                : '[CRM插件] 小红书：未找到选人面板确认按钮（若平台选完自动生效可忽略）');
              await sleep(500);
            }
          }
        }
      }
    }
    if (c.contentType) {
      // 内容类型声明：点开「添加内容类型声明」下拉 → 点选项；
      // 「内容来源声明-自主拍摄」为二级：先点「内容来源声明」再点子菜单「自主拍摄」
      //（子菜单里「来源转载」在平台置灰不可选，不提供该配置）
      const want = String(c.contentType).replace(/\s+/g, '');
      if (want && want !== '不添加') {
        // 展开声明下拉：找含「内容类型声明」的最小可见行
        let row = null, bestArea = Infinity;
        for (const el of deepQueryAll(document, 'div, span')) {
          const t = ((el.textContent || '') + '').replace(/\s+/g, '');
          if (!t || t.indexOf('内容类型声明') < 0 || t.length > 18) continue;
          if (inPreviewCopy(el)) continue;
          let r;
          try { r = el.getBoundingClientRect(); } catch (e) { continue; }
          if (r.width < 60 || r.height < 24 || r.width > window.innerWidth * 0.9) continue;
          try {
            const cs = (el.ownerDocument.defaultView || window).getComputedStyle(el);
            if (cs.display === 'none' || cs.visibility === 'hidden') continue;
          } catch (e) { /* ignore */ }
          const a = r.width * r.height;
          if (a < bestArea) { bestArea = a; row = el; }
        }
        if (!row) { console.warn('[CRM插件] 小红书：未找到「添加内容类型声明」入口'); return; }
        const rowEl = climbSameText(row); // 爬到整行容器再点（含箭头），避免只点文字无效
        try {
          const rr = rowEl.getBoundingClientRect();
          console.log('[CRM插件] 小红书：内容类型声明行 @' + Math.round(rr.left + rr.width / 2) + ',' + Math.round(rr.top + rr.height / 2)
            + ' ' + Math.round(rr.width) + 'x' + Math.round(rr.height));
        } catch (e) { /* ignore */ }
        let ok = false;
        if (want === '内容来源声明-自主拍摄') {
          // 二级菜单：先点「内容来源声明」再点子菜单「自主拍摄」
          ok = await openAndPick(rowEl, '内容来源声明', '内容类型声明');
          if (ok) { await sleep(500); ok = await pickOption('自主拍摄', '内容类型声明'); }
        } else {
          ok = await openAndPick(rowEl, want, '内容类型声明');
        }
        console.log(ok ? '[CRM插件] 小红书：内容类型声明已设为「' + want + '」'
          : '[CRM插件] 小红书：内容类型声明未设置成功（菜单未展开或无「' + want + '」选项）');
        await sleep(500);
      }
    }
  }

  /** 小红书发布按钮专属查找：底部红色「发布」按钮。
   *  不能用宽泛选择器——左上角有「发布笔记」下拉（点开会打开菜单而非发布），
   *  容器 class 又全带 publish（误点过话题区「编辑」）。两通道：
   *  A) 文案全等「发布/发布笔记」+ top>=120（排除顶部导航）+ 最小面积；
   *  B) 备用：红色背景（小红书 #ff2444 系）+ 文案含「发布」——主通道全灭时兜底
   *  找不到时输出全部「发布」候选的几何/可见性明细，一次日志定位真凶 */
  async function findXhsPublishBtn(timeout) {
    const isRed = (el) => {
      try {
        const cs = (el.ownerDocument.defaultView || window).getComputedStyle(el);
        // 背景色和背景图（渐变）都查：小红书按钮可能用 linear-gradient，backgroundColor 为透明
        const bg = (cs.backgroundColor || '') + ';' + (cs.backgroundImage || '');
        const ms = bg.match(/rgba?\(\s*\d+\s*,\s*\d+\s*,\s*\d+/g) || [];
        return ms.some((m) => {
          const x = /rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/.exec(m);
          return x && +x[1] > 190 && +x[2] < 110 && +x[3] < 110;
        });
      } catch (e) { return false; }
    };
    const start = Date.now();
    let lastDiag = 0;
    while (Date.now() - start < (timeout || 8000)) {
      let hit = null, bestA = Infinity, redHit = null, redA = Infinity;
      const diag = [];
      for (const d of docList()) {
        for (const el of deepQueryAll(d, 'button, div, span')) {
          const t = normBtnText(el.innerText || el.textContent);
          if (!t || t.indexOf('发布') < 0 || t.length > 8) continue;
          const vis = elVisible(el);
          let r;
          try { r = el.getBoundingClientRect(); } catch (e) { continue; }
          diag.push(t + '|' + el.tagName + '@top' + Math.round(r.top) + 'w' + Math.round(r.width) + (vis ? '' : ':隐'));
          if (!vis) continue;
          if (r.top < 120) continue; // 排除顶部导航的「发布笔记」下拉
          if (r.width > 400 || r.height > 120) continue;
          const a = r.width * r.height;
          if ((t === '发布' || t === '发布笔记') && a < bestA) { bestA = a; hit = el; }
          if (isRed(el) && a < redA) { redA = a; redHit = el; }
        }
      }
      if (hit) return hit;
      // 「暂存离开」锚点通道：footer 里「暂存离开」与红色「发布」并排，从它向上找容器里的红元素。
      // 不依赖「发布」二字本身（隐形字符防不胜防），「暂存离开」是普通文案更干净
      try {
        const anchor = deepQueryAll(document, 'button, div, span').find((el) => {
          const t5 = normBtnText(el.innerText || el.textContent || '');
          // 模糊匹配：容器文本可能带额外字（如「暂存离开发布」），只要以「暂存」开头即可
          return t5.indexOf('暂存') === 0 && elVisible(el);
        });
        if (anchor) {
          for (let n = anchor.parentElement, up = 0; n && up < 6; up++, n = n.parentElement) {
            let best = null, ba = Infinity;
            for (const x of n.querySelectorAll('*')) {
              if (!isRed(x) || !elVisible(x)) continue;
              const rx = x.getBoundingClientRect();
              if (rx.width < 40 || rx.height < 24 || rx.width > 300) continue;
              const ax = rx.width * rx.height;
              if (ax < ba) { ba = ax; best = x; }
            }
            if (best) {
              console.log('[CRM插件] 小红书：经「暂存离开」锚点命中红色发布按钮（第 ' + (up + 1) + ' 层）');
              return best;
            }
          }
        }
      } catch (e) { /* ignore */ }
      if (redHit) { console.log('[CRM插件] 小红书：主通道未命中，用红色背景备用通道命中发布按钮'); return redHit; }
      // 终极兜底：纯几何红钮（文本可能仍带未见过的隐形字符）——红色背景 + 按钮尺寸 +
      // 主体区位置（top>=300 且中心 x<视口宽 72%，排除右栏笔记预览里的红色「关注」钮）
      for (const el of deepQueryAll(document, 'button, div, span')) {
        if (!isRed(el)) continue;
        let r;
        try { r = el.getBoundingClientRect(); } catch (e) { continue; }
        if (r.top < 300 || r.width < 50 || r.width > 220 || r.height < 28 || r.height > 64) continue;
        if (r.left + r.width / 2 > window.innerWidth * 0.72) continue;
        if (!elVisible(el)) continue;
        console.log('[CRM插件] 小红书：用纯几何红钮兜底命中发布按钮@top' + Math.round(r.top));
        return el;
      }
      if (Date.now() - lastDiag > 3000) {
        lastDiag = Date.now();
        console.warn('[CRM插件] 小红书：未找到主体区发布按钮（「发布」候选明细：' + (diag.join('；') || '无') + '）');
      }
      await sleep(500);
    }
    return null;
  }

  /** 小红书 CDP 终极兜底：发布按钮位于 closed shadow root（el.shadowRoot 为 null，content script
   *  任何 DOM 扫描都不可见，v1.9.79 实测：页脚「定时发布」能扫到而红色「发布」在 DOM 里不存在）。
   *  走 CDP DOM.performSearch（穿透 closed shadow root）找「发布」文本坐标 → Input 可信点击。
   *  成功返回点击坐标；失败返回 null（外层继续走原有失败路径）。 */
  async function cdpFindAndClickXhsPublish() {
    const send = (m) => {
      try { return chrome.runtime.sendMessage(m).catch(() => null); } catch (e) { return Promise.resolve(null); }
    };
    try {
      // 单条消息内完成 搜索→视口过滤→点击（v1.9.80 的 find/click 分两条消息，中途 debugger
      // 掉线导致点击失败；且未过滤 x 坐标，命中过视口外右侧预览区的隐藏模板）
      const r = await send({ type: 'crmCdpFindTextClick', text: '发布', minY: 250 });
      if (!r) { console.warn('[CRM插件] 小红书 CDP 兜底：后台无响应（扩展上下文可能失效）'); return null; }
      if (!r.ok) { console.warn('[CRM插件] 小红书 CDP 兜底失败：' + (r.message || '未知错误')); return null; }
      if (r.clicked) {
        console.log('[CRM插件] 小红书：CDP 可信点击发布按钮 @' + r.clicked.x + ',' + r.clicked.y
          + '（视口 ' + r.vw + 'x' + r.vh + '，候选 ' + ((r.candidates || []).length) + ' 个：'
          + (r.candidates || []).map((h) => '@' + h.x + ',' + h.y + ' ' + h.w + 'x' + h.h).join('；') + '）');
        return { ok: true, x: r.clicked.x, y: r.clicked.y, w: r.clicked.w, h: r.clicked.h };
      }
      console.warn('[CRM插件] 小红书 CDP 兜底：' + (r.message || '未找到可点击的发布按钮')
        + '（视口 ' + r.vw + 'x' + r.vh + '，全部命中 ' + ((r.hits && r.hits.length) || 0) + ' 处）');
    } catch (e) { console.warn('[CRM插件] 小红书 CDP 兜底异常：' + ((e && e.message) || e)); }
    return null;
  }

  CRM.autoSubmit = async function (job, timeoutMs) {
    const code = (job && job.platformCode) || '';
    const cfg = PUBLISH_CFG[code] || PUBLISH_CFG.generic;
    const before = location.href;
    window.__crmXhsCdpClicked = false; // 同页重跑时清掉上一轮的 CDP 点击标记

    // 需要封面但任务未带封面：平台通常无法自动发布，直接判失败避免误报
    if (job && job.requireCover && !job.coverUrl) {
      return { ok: false, msg: '该平台要求封面图，无法自动发布' };
    }

    // 编辑器 SPA 渲染慢时底部工具栏可能延迟出现：共尝试 3 轮。
    // 小红书多图（8-18 张）时平台要等全部图片上传完才渲染底部红色「发布」按钮，
    // 8 秒判负太快（v1.9.78 实测：扫描时 DOM 里根本没有发布钮）→ 首轮等 45 秒
    let pubBtn = null;
    for (let attempt = 0; attempt < 3 && !pubBtn; attempt++) {
      if (attempt > 0) {
        await sleep(3000);
        // 重试前滚到页面底部：底部操作栏可能在视口外，CDP/坐标点击需要它进入视口
        try { window.scrollTo(0, document.body.scrollHeight); } catch (e) { /* ignore */ }
        await sleep(600);
      }
      pubBtn = (code === 'xiaohongshu' ? await findXhsPublishBtn(45000) : null)
        || await waitForSelectorSafely(cfg.publish, 8000).catch(() => null)
        || findByText(cfg.publish, ['发布文章', '发布', '发表', '投稿'].concat(cfg.words || []))
        || (code === 'sohu' ? await findSohuPublishBtn(6000) : null);
    }
    // 误命中「定时发布」类按钮时改找真正的发布按钮（定时发布=延迟发布，不是立即发布）
    if (pubBtn && /定时/.test(((pubBtn.innerText || pubBtn.textContent || '') + ''))) {
      console.warn('[CRM插件] 匹配到「定时发布」按钮，改找立即发布按钮');
      pubBtn = findByText(['button:has-text("发布博客")', 'button:has-text("发布文章")', 'button:has-text("发布")'], ['发布博客', '发布文章']);
    }
    if (!pubBtn) {
      // 小红书终极兜底：发布按钮疑似位于 closed shadow root（任何 DOM 扫描不可见），
      // 走 CDP 穿透查找 + 可信点击；点中后用假 pubBtn 走统一成功等待路径
      if (code === 'xiaohongshu') {
        const cdpHit = await cdpFindAndClickXhsPublish();
        if (cdpHit && cdpHit.ok) {
          window.__crmXhsCdpClicked = true;
          pubBtn = {
            innerText: '发布', textContent: '发布', value: '',
            click: function () { /* CDP 已可信点击，这里不再重复 */ },
            scrollIntoView: function () { /* 已在视口内 */ }
          };
        }
      }
    }
    if (!pubBtn) {
      // 诊断：列出页面（含 Shadow DOM）可见的短文案候选，便于定位发布按钮的真实文案/结构
      const seen = [];
      for (const d of docList()) {
        for (const el of deepQueryAll(d, '*')) {
          const t = ((el.innerText || el.textContent || '') + '').trim();
          if (!t || t.length > 6 || seen.indexOf(t) >= 0) continue;
          try {
            const r = el.getBoundingClientRect();
            if (r.width < 10 || r.height < 10) continue;
          } catch (e) { /* ignore */ }
          seen.push(t);
          if (seen.length >= 40) break;
        }
        if (seen.length >= 40) break;
      }
      return { ok: false, msg: '未找到“发布”按钮（页面可见候选：' + (seen.join('、') || '无') + '）' };
    }

    // 明确排除「保存草稿」类按钮，避免误点
    const btnText = ((pubBtn.innerText || pubBtn.textContent || pubBtn.value || '') + '').trim();
    if (/草稿|保存/.test(btnText)) {
      return { ok: false, msg: '仅匹配到“保存草稿”按钮，未执行发布' };
    }
    // 误命中「编辑/设置」类非发布按钮：改按文案重找，绝不点击
    if (/^(编辑|修改|设置|管理|收起|展开)$/.test(btnText.replace(/\s+/g, ''))) {
      console.warn('[CRM插件] 误命中「' + btnText + '」按钮，重找发布按钮');
      pubBtn = findByText([], ['发布'].concat(cfg.words || []));
      if (!pubBtn) return { ok: false, msg: '仅匹配到「' + btnText + '」按钮，未执行发布' };
    }
    // 小红书：顶部导航的「发布笔记」是下拉入口（点了只展开菜单，不会发布），
    // 必须换成页面主体区的发布按钮；找不到就判失败，避免反复点下拉
    if (code === 'xiaohongshu' && btnText.replace(/\s+/g, '') === '发布笔记') {
      const pr = pubBtn.getBoundingClientRect ? pubBtn.getBoundingClientRect() : null;
      if (!pr || pr.top < 120) {
        console.warn('[CRM插件] 小红书误命中顶部「发布笔记」下拉，改找主体区发布按钮');
        pubBtn = await findXhsPublishBtn(8000);
        // 主体区扫不到（发布钮在 closed shadow root，DOM 扫描不可见）→ CDP 穿透兜底。
        // v1.9.81 实测：CDP 兜底只挂在 pubBtn 全空的分支，而通用查找先命中「发布笔记」，
        // 走到这里就 return 了，兜底从未执行——这里必须同样接入
        if (!pubBtn) {
          const cdpHit = await cdpFindAndClickXhsPublish();
          if (cdpHit && cdpHit.ok) {
            window.__crmXhsCdpClicked = true;
            pubBtn = {
              innerText: '发布', textContent: '发布', value: '',
              click: function () { /* CDP 已可信点击，这里不再重复 */ },
              scrollIntoView: function () { /* 已在视口内 */ }
            };
          }
        }
        if (!pubBtn) return { ok: false, msg: '仅匹配到顶部「发布笔记」下拉，未执行发布' };
      }
    }

    try {
      pubBtn.scrollIntoView({ block: 'center' });
    } catch (e) { /* ignore */ }

    // 发布前把必填关键词自动填入平台标签/话题输入框（创作页可见的标签框，尽力而为）。
    // CSDN 富文本创作页（mp.csdn.net）除外：job.keywords 含 AI 检测提取的标签，
    // 再填会与预览配置的标签（fillCsdnRichPanel 按 c.tags 填写）叠加超出配置，故跳过
    if (job && job.fillTag && !(code === 'csdn' && /mp\.csdn\.net/.test(location.host)) && code !== 'xiaohongshu') {
      try { await fillTagsGeneric(job); } catch (e) { /* ignore */ }
    }

    // 发布前填写用户在预览页设置的结构化字段（标签/话题/分类/摘要/原创等）；
    // 搜狐已有平台特化逻辑，跳过避免重复操作
    if (code === 'xiaohongshu' && job && job.platformConfig) {
      // 小红书平台专用：原创声明/允许正文复制/可见权限（内容设置区）。
      // 不能走通用 fillStructuredFields——它的 original→clickTextGlobal('原创') 会误触
      // 「添加内容类型声明」菜单，visibility 通用文本点击也会点错
      try { await applyXhsNoteSettings(job.platformConfig); } catch (e) { /* ignore */ }
    } else if (code !== 'sohu' && job && job.platformConfig) {
      // 51CTO 的标签/话题由 handleCto51Modal 专填（其话题框 placeholder 含「标签」特征，
      // 通用 fillTagsGeneric 会把标签误写进话题框），这里跳过标签写入
      try { await fillStructuredFields(job, code === 'csdn' || code === 'cto51'); } catch (e) { /* ignore */ }
    }

    // 发布前兜底：搜狐勾选「引用声明」后来源链接必填，即使输入框已显示值，
    // 平台内部模型也可能未同步（发布报「来源链接不能为空」）——发布前强制重写一次
    if (code === 'sohu' && job && job.platformConfig && job.platformConfig.sourceUrl) {
      try {
        const srcInput = document.querySelector('input[placeholder*="链接"], textarea[placeholder*="链接"]');
        if (srcInput) syncInputValue(srcInput, job.platformConfig.sourceUrl);
      } catch (e) { /* ignore */ }
    }

    // 发布前守卫 1：正文若仍残留图片占位符，循环删除（受控编辑器每次可能只删部分字符，
    // 需反复「重新定位 → 选中 → 删除」直到彻底消失）；删不掉才放弃自动发布。
    // CSDN 的 Markdown 编辑器会把 [[xx]] 解析成引用式链接，占位符为不含方括号的 CRMIMGPHnEND
    try {
      const probe = code === 'csdn' ? 'CRMIMGPH' : '[[CRM_IMG_';
      // 宽松正则：兼容被部分删除后的残片（如 CRMIMGPHEND2、[[CRM_IMG_）
      const tokRe = code === 'csdn' ? /CRMIMGPH[A-Za-z0-9]*/ : /\[\[CRM_IMG_\d*\]*\]*/;
      if (!window.__crmSkipImgGuard && (document.body.innerText || '').indexOf(probe) >= 0) {
        console.warn('[CRM插件] 正文残留图片占位符，自动循环删除');
        // 兜底补跑（51CTO 有独立接管流程，排除）：afterFill 阶段编辑器可能尚未水合
        // （掘金等 SPA 慢挂载），当时「未找到编辑器」空跑过——发布前编辑器已就绪，重试一次
        if (job && job._crmImages && job._crmImages.length && code !== 'cto51') {
          try {
            const ed2 = await findEditorForImages(['.editor-content', '[contenteditable="true"]', '.CodeMirror'], 10000);
            if (ed2) {
              console.log('[CRM插件] 编辑器已就绪，守卫阶段补跑一次图片粘贴');
              await pasteImagesAtPlaceholders(job, ed2, null, false);
            }
          } catch (e) { /* 忽略，继续走清理 */ }
        }
        const cleaned = await deleteResidualTokens(probe, tokRe, 40);
        if (!cleaned) {
          console.warn('[CRM插件] 重试后正文仍残留图片占位符，已停止自动发布');
          return { ok: false, msg: '正文图片未插入完成（仍残留占位符，已自动重试），请手动删除占位符/检查图片后发布' };
        }
        console.log('[CRM插件] 占位符已通过重试清理，继续发布');
      }
    } catch (e) { /* ignore */ }

    // 51CTO 手动接管监听（v1.9.6/v1.9.8）：CDP/半自动均失败后，引导用户手点工具栏图片按钮上传。
    // 启动时先经 background chrome.downloads 预下载全部图片到「下载」目录（本轮未走 semiAuto
    // 预下载时文件并不存在，v1.9.7 实测文件框里找不到 crm-tmp-img1.jpg）；PNG 转 JPEG（51CTO
    // 文件框 accept 过滤下 png 灰选）。文件框弹出（main-world picker 标记）→ 提示选第 N 张；
    // 图片全部转存为正式 http 后自动清理 data: 残图与占位符，发布由 content.js 层接管完成
    const startCto51Takeover = async (imgs) => {
      try {
        if (window.__crm51Takeover) return;
        window.__crm51Takeover = 1;
        imgs = imgs || [];
        const need = imgs.length;
        if (!need) return;
        const hint = window.__crmPanelHint || ((h) => { if (h) console.log('[CRM插件] ' + h.replace(/<[^>]+>/g, '')); });
        // main-world hook（幂等）：file input 被点击 → data-crm-captured；showOpenFilePicker 调用 → data-crm-picker
        const s = document.createElement('script');
        s.textContent = '(function(){if(window.__crmInputHook)return;window.__crmInputHook=1;var p=HTMLInputElement.prototype,o=p.click;p.click=function(){if(this&&this.type==="file"){try{this.setAttribute("data-crm-captured",String(Date.now()))}catch(e){}}return o.apply(this,arguments)};var ofp=window.showOpenFilePicker;window.showOpenFilePicker=function(){try{document.documentElement.setAttribute("data-crm-picker",String(Date.now()))}catch(e){}return ofp?ofp.apply(this,arguments):Promise.resolve([])}};})();';
        (document.head || document.documentElement).appendChild(s);
        s.remove();
        // PNG → JPEG 转码（白底）：51CTO 文件框 accept 过滤下 png 灰选，JPEG 必可选
        const toJpeg = (d) => new Promise((res) => {
          try {
            const im = new Image();
            im.onload = () => {
              try {
                const cv = document.createElement('canvas');
                cv.width = im.naturalWidth || 800;
                cv.height = im.naturalHeight || 600;
                const cx = cv.getContext('2d');
                cx.fillStyle = '#ffffff';
                cx.fillRect(0, 0, cv.width, cv.height);
                cx.drawImage(im, 0, 0);
                res(cv.toDataURL('image/jpeg', 0.92));
              } catch (e) { res(d); }
            };
            im.onerror = () => res(d);
            im.src = d;
          } catch (e) { res(d); }
        });
        // 预下载全部图片到「下载」目录（crmCdpDownload 走 chrome.downloads，与 debugger 无关）
        const dlNames = [];
        for (let i = 0; i < imgs.length; i++) {
          const fallback = 'crm-tmp-img' + (i + 1) + '.jpg';
          try {
            const jpeg = await toJpeg(imgs[i]);
            const r = await new Promise((res) => {
              try {
                // crmKeepDownload：下载后保留文件（crmCdpDownload 的文件会被 detach 清理，
                // v1.9.10 实测接管预下载的图片刚下完就被删，文件框里找不到）
                const p = chrome.runtime.sendMessage({ type: 'crmKeepDownload', dataUrl: jpeg, fileKey: 'img' + (i + 1) });
                if (p && p.then) p.then(res).catch(() => res(null)); else res(null);
              } catch (e) { res(null); }
            });
            // uniquify 重名时会带 " (1)" 后缀，用真实文件名提示
            dlNames.push((r && r.ok && r.name) || fallback);
            console.log('[CRM插件] 51CTO 接管模式已预下载图片 ' + (i + 1) + '/' + need + '：' + dlNames[i]);
          } catch (e) { dlNames.push(fallback); }
        }
        const ed = () => document.querySelector('[contenteditable="true"]') || document.body;
        const httpCnt = () => Array.from(ed().querySelectorAll('img')).filter((im) => {
          const x = (im.getAttribute('src') || '').toLowerCase();
          return x.indexOf('http') === 0 && x.indexOf('blob:') < 0;
        }).length;
        let lastPicker = 0, done = false;
        hint('⚠ 自动上传未成功，已进入<b>手动接管模式</b>：请点工具栏图片按钮 → 本地上传 → 选中「下载」目录 <b>' + dlNames[0] + '</b>（可搜索 crm），上传后插件自动继续');
        console.warn('[CRM插件] 51CTO 手动接管模式已启动：请手动点工具栏图片按钮上传（' + dlNames.join(' / ') + '），插件将自动接管后续');
        const iv = setInterval(async () => {
          try {
            if (done) { clearInterval(iv); return; }
            const pk = parseInt(document.documentElement.getAttribute('data-crm-picker') || '0', 10);
            if (pk > lastPicker) {
              lastPicker = pk;
              const n = Math.min(need - 1, httpCnt());
              hint('⚠ 请在弹出的文件窗口选中 <b>' + dlNames[n] + '</b>（下载目录，可搜索 crm）');
            }
            if (httpCnt() >= need) {
              done = true;
              clearInterval(iv);
              console.log('[CRM插件] 51CTO 手动上传的图片已全部转存为正式地址，清理 data: 残图与占位符');
              const edEl = ed();
              // 删除 data:/blob: 残图（insertHTML 兜底插入的，发布会被丢弃）并清理占位符
              Array.from(edEl.querySelectorAll('img')).forEach((im) => {
                const x = (im.getAttribute('src') || '').toLowerCase();
                if (x.indexOf('http') !== 0 || x.indexOf('blob:') === 0) { try { im.remove(); } catch (e) { /* ignore */ } }
              });
              if (((edEl.innerText || '') + '').indexOf('[[CRM_IMG_') >= 0) {
                try { await deleteResidualTokens('[[CRM_IMG_', /\[\[CRM_IMG_\d*\]*\]*/, 40); } catch (e) { /* ignore */ }
              }
              // 提示与发布由 content.js 层接管监听完成（重走 autoSubmit → 守卫通过 → 点发布 → 回传）
              hint('✓ 图片已全部转存并清理残图，正在自动发布…');
              console.log('[CRM插件] 51CTO 图片全部转存完成，等待发布接管流程执行');
            }
          } catch (e) { /* ignore */ }
        }, 1500);
      } catch (e) { /* ignore */ }
    };

    // 掘金兜底：富文本 coreditor 对合成文件粘贴只插入 data: 占位图、不触发真实上传时，
    // 清掉占位图，走 CDP（chrome.debugger）上传：trusted 点击工具栏「图片」按钮 →
    // 拦截文件选择框 → DOM.setFileInputFiles 直填图片（51CTO 同款终局方案）。
    // 掘金 CSP 拦 main-world hook 注入，CDP 是唯一不受限通道。
    // 兜底图插在光标位置（文末），发布后可在编辑器里手动挪位
    const juejinFallbackUpload = async () => {
      try {
        const ed = document.querySelector('.editor-content')
          || document.querySelector('.coreditor-content-medium-editor-container [contenteditable="true"]')
          || document.querySelector('[contenteditable="true"]');
        if (!ed) return false;
        const cdpSend = (m) => ((chrome.runtime && chrome.runtime.sendMessage) ? chrome.runtime.sendMessage(m).catch(() => null) : Promise.resolve(null));
        // ① 清掉 data:/blob: 占位图（合成粘贴插入但从未转存的，发布时会被丢弃）
        Array.from(ed.querySelectorAll('img')).forEach((im) => {
          if (/^(data:|blob:)/i.test(im.getAttribute('src') || '')) { try { im.remove(); } catch (e) { /* ignore */ } }
        });
        const httpCnt = () => Array.from(ed.querySelectorAll('img')).filter((im) => /^https?:/i.test(im.getAttribute('src') || '')).length;
        const need = (job._crmImages || []).length;
        const UP_RE = /(上传图片|本地上传|点击上传|上传照片|插入图片|上传)/;
        // 上传入口候选：工具栏图片按钮（aria/title/class）+ 可见「上传图片」类文案入口
        const findEntries = () => {
          const list = [];
          const tbBtn = Array.from(document.querySelectorAll('button, [role="button"], li, span')).find((el) => {
            if (!elVisible(el)) return false;
            const a = el.getAttribute ? (el.getAttribute('aria-label') || el.getAttribute('title') || el.getAttribute('data-title') || '') : '';
            const c = ((el.className && el.className.baseVal !== undefined ? el.className.baseVal : el.className) || '') + '';
            return /image|图片|photo/i.test(a + ' ' + c);
          });
          if (tbBtn) list.push(tbBtn);
          Array.from(document.querySelectorAll('button, div, span, a, li, label')).forEach((el) => {
            const t = ((el.textContent || '') + '').replace(/\s+/g, '');
            if (elVisible(el) && t && t.length <= 8 && UP_RE.test(t)) list.push(el);
          });
          return list;
        };
        for (let n = 0; n < need; n++) {
          const before = httpCnt();
          ed.focus();
          // 光标定位到文末
          try {
            const sel = window.getSelection(); const rng = document.createRange();
            rng.selectNodeContents(ed); rng.collapse(false);
            sel.removeAllRanges(); sel.addRange(rng);
          } catch (e) { /* ignore */ }
          await sleep(300);
          let done = false;
          const tried = new Set();
          for (let att = 0; att < 6 && !done; att++) {
            const entries = findEntries().filter((el) => !tried.has(el));
            if (!entries.length) break;
            const el = entries[0];
            tried.add(el);
            let r;
            try { r = el.getBoundingClientRect(); } catch (e) { continue; }
            const res = await cdpSend({
              type: 'crmCdpClickAndSet',
              x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2),
              dataUrl: job._crmImages[n], fileKey: 'juejinimg' + (n + 1)
            });
            await sleep(800);
            if (!res) { console.warn('[CRM插件] 掘金兜底：CDP 通道不可用（background 未响应），换下一入口'); continue; }
            if (!(res.ok && res.intercepted)) {
              console.log('[CRM插件] 掘金兜底：CDP 未拦截到选择框（ok=' + res.ok
                + (res.reqs && res.reqs.length ? '，上传相关请求：' + res.reqs.join(' | ') : '')
                + (res.message ? '，' + res.message : '') + '），换下一入口');
            }
            if (res && res.ok && res.intercepted) {
              for (let w = 0; w < 40 && !done; w++) { await sleep(250); if (httpCnt() > before) done = true; }
              if (done) console.log('[CRM插件] 掘金兜底：图片 ' + (n + 1) + '/' + need + ' 已 CDP 上传'
                + (res.nodeAttrs ? '（input：' + res.nodeAttrs + '）' : ''));
              else console.warn('[CRM插件] 掘金兜底：图片 ' + (n + 1) + ' 文件已写入 input 但未见回显');
            }
            // 未拦截到选择框：可能是点开了「插入图片」面板（第一层按钮），
            // 循环继续点面板里的「上传图片」入口（findEntries 每轮重新收集）
          }
          if (!done) {
            console.warn('[CRM插件] 掘金兜底(CDP)：图片 ' + (n + 1) + ' 未能上传（候选入口已试完/CDP 不可用），请手动上传');
            return false;
          }
          await sleep(600);
        }
        await cdpSend({ type: 'crmCdpDetach' });
        return httpCnt() >= need;
      } catch (e) { return false; }
    };

    // 发布前守卫 2（知乎/CSDN）：文件粘贴只是插入图片块，上传是异步的——
    // 不等上传完成就点发布，文章会没图（上传中的 img 是 blob:/data: src，发布时被丢弃）。
    // 等编辑器内 img 的 src 变为正式 http 地址（最多 40 秒）
    // 覆盖所有占位符平台（含 51CTO）：此前 51CTO 不等图片上传完成就点发布，文章发出没图
    if (job && job._crmImages && job._crmImages.length && !window.__crmSkipImgGuard) {
      const need = job._crmImages.length;
      // 编辑器可能在同源 iframe 内（百家号 UEditor 正文是 BODY.view）→ 跨文档收集根节点，
      // 去重并剔除嵌套（外层 contenteditable 包住内层时旧逻辑会把同一张图数两遍/数零遍）
      const editorRoots = () => {
        const roots = [];
        for (const d of docList()) {
          try { roots.push(...Array.from(d.querySelectorAll('[contenteditable="true"], .ueditor-body'))); } catch (e) { /* ignore */ }
        }
        const uniq = [];
        for (const r of roots) { if (uniq.indexOf(r) < 0) uniq.push(r); }
        return uniq.filter((r) => !uniq.some((x) => x !== r && x.contains(r)));
      };
      const imgCount = () => editorRoots().reduce((acc, ed) => acc + Array.from(ed.querySelectorAll('img')).filter((im) => {
        const s = (im.getAttribute('src') || '').toLowerCase();
        return s.indexOf('http') === 0 && s.indexOf('blob:') < 0;
      }).length, 0);
      const imgTotal = () => editorRoots().reduce((acc, ed) => acc + ed.querySelectorAll('img').length, 0);
      const st = Date.now();
      // 上传失败的图片块会显示「重试」按钮：自动点击重传（最多 3 次，间隔 3 秒防抖）
      const clickRetry = (() => {
        let last = 0, count = 0;
        return async () => {
          if (Date.now() - last < 3000 || count >= 3) return;
          const btn = editorRoots().map((ed) => Array.from(ed.querySelectorAll('button, a, span, div')).find((el) =>
            el.children.length === 0 && ((el.textContent || '') + '').trim() === '重试' && elVisible(el))).find(Boolean);
          if (btn) {
            try { btn.click(); } catch (e) { /* ignore */ }
            count++; last = Date.now();
            console.log('[CRM插件] 检测到正文图片上传失败，已自动点击重试（' + count + '/3）');
            await sleep(1000);
          }
        };
      })();
      // 掘金合成粘贴实测从不触发真实上传（CP 编辑器只留 data: 占位图），等满 60s 纯属白等；
      // 缩短到 12s 观察，无进展立即切 CDP 兜底通道（兜底流程本身完整，早切不影响成功率）
      // 多图场景：每张图平台上传 3-7s + 编辑器 sleep ≈2.7s/张，4 张以上 60s 不够；随图片数放大
      // （v1.9.69 多图压测）：4 张=90s，每多 1 张 +10s，封顶 240s；不够就重试 + 兜底兜住
      const imgWaitMs = (code === 'juejin') ? 12000
        : Math.min(90000 + 10000 * Math.max(0, need - 4), 240000);
      let lastProgLog = 0;
      while (Date.now() - st < imgWaitMs && imgCount() < need) {
        await sleep(500);
        await clickRetry();
        if (Date.now() - lastProgLog > 10000) {
          lastProgLog = Date.now();
          console.log('[CRM插件] 图片守卫进度：正式 img ' + imgCount() + '/' + need + '（剩余 ' + Math.max(0, Math.ceil((imgWaitMs - (Date.now() - st)) / 1000)) + 's）');
        }
      }
      const cnt = imgCount();
      if (cnt < need) {
        // 掘金兜底：合成粘贴只留 data: 占位图不触发上传时，改走工具栏 file input 直填
        if (code === 'juejin') {
          let okJj = false;
          try { okJj = await juejinFallbackUpload(); } catch (e) { /* ignore */ }
          const cnt2 = imgCount();
          if (okJj && cnt2 >= need) {
            console.log('[CRM插件] 掘金兜底上传完成（正式 img ' + cnt2 + '/' + need + '）');
          } else {
            console.warn('[CRM插件] 掘金兜底后图片仍未上传完成（正式 img ' + cnt2 + '/' + need
              + '，编辑器内共 ' + imgTotal() + ' 张），已停止自动发布');
            return { ok: false, msg: '掘金正文图片未上传完成（' + cnt2 + '/' + need + '），请手动上传图片后发布' };
          }
        } else {
          console.warn('[CRM插件] 正文图片未上传完成（正式 img ' + cnt + '/' + need
            + '，编辑器内共 ' + imgTotal() + ' 张，含重试后），已停止自动发布');
          if (code === 'cto51') startCto51Takeover(job._crmImages);
          return { ok: false, msg: '正文图片未上传完成（正式 img ' + cnt + '/' + need + '，已自动重试 3 次仍失败），请手动点击图片上的「重试」后发布' };
        }
      }
      console.log('[CRM插件] 正文图片已上传完成（正式 img ' + cnt + '/' + need + '）');
    }

    // 点击发布前同步日志快照（发布成功瞬间可能整页跳转，日志由补传路径回传）
    try { if (typeof window.__crmSyncPendingLogs === 'function') await window.__crmSyncPendingLogs(); } catch (e) { /* ignore */ }

    // CSDN 富文本创作页（mp.csdn.net）：发布设置（标签/分类）是常驻面板，
    // 点「发布博客」前先通过面板按钮填好（Markdown 编辑器页仍走发布后的 el-dialog 弹窗）
    if (code === 'csdn' && /mp\.csdn\.net/.test(location.host)) {
      try { await fillCsdnRichPanel(job); } catch (e) { /* ignore */ }
      try { if (typeof window.__crmSyncPendingLogs === 'function') await window.__crmSyncPendingLogs(); } catch (e) { /* ignore */ }
    }

    // 开源中国：等编辑器内粘贴的图片上传完成（src 由 blob:/data: 占位换成远程地址），
    // 否则平台可能因「图片上传中」拦截发布弹窗
    if (code === 'oschina') {
      const stUp = Date.now();
      while (Date.now() - stUp < 15000) {
        const pending = deepQueryAll(document, '.w-e-text img, [contenteditable="true"] img')
          .some((im) => /^(blob:|data:)/i.test(im.src || ''));
        if (!pending) break;
        await sleep(800);
      }
    }

    // 51CTO：点发布前清除可能仍在的「Markdown 转投」询问弹窗（挡住发布按钮）
    if (code === 'cto51') {
      try { await closeCto51MarkdownPrompt(); } catch (e) { /* ignore */ }
    }

    // 发布前标题守卫：标题未填就点「发布」，51CTO 等强校验平台会反复弹「请输入标题」。
    // 标题框为空先用平台/通用选择器补填；51CTO 补填仍失败则直接判失败、绝不点发布（否则死循环弹窗）。
    const titleBox = () => document.querySelector('input[placeholder*="标题"], textarea[placeholder*="标题"], input[name="title"], #title, [contenteditable="true"][class*="title" i]');
    const titleVal = (el) => ((el && el.value != null ? el.value : (el && el.innerText)) || '').trim();
    if (job && job.title) {
      const tb = titleBox();
      if (tb && !titleVal(tb)) {
        try { syncInputValue(tb, job.title); await sleep(600); } catch (e) { /* ignore */ }
      }
      if (code === 'cto51') {
        // 51CTO 编辑器内部 model 不认合成写入：即使显示有值，发布仍报「请填写标题」。
        // 点发布前无条件用「模拟真实打字」重写一遍，确保内部状态同步
        const tb1 = titleBox();
        if (tb1) {
          try { forceTypeValue(tb1, job.title); await sleep(600); } catch (e) { /* ignore */ }
          console.log('[CRM插件] 51CTO 标题已通过模拟输入重写同步');
        }
        const tb2 = titleBox();
        if (!tb2 || !titleVal(tb2)) {
          return { ok: false, msg: '51CTO 标题未填写成功（编辑器标题框未匹配或写入未同步），请手动填写标题后点「重新发布」' };
        }
      }
    }

    // 百家号：发布前把封面默认设为正文第一张图（「基础信息 → 设置封面」与编辑器同页），
    // 并同步 智能创作/创作声明/拓展设置 勾选与预设一致（平台默认勾了视频/播客/打赏）
    if (code === 'baijiahao') {
      try { await fillBaijiahaoCover(); } catch (e) { /* ignore */ }
      try { await fillBaijiahaoSettings(job); } catch (e) { /* ignore */ }
    }

    // 掘金：重试时设置面板可能已打开，再点顶部「发布」会 toggle 关闭面板，
    // 导致 handleJuejinModal 等不到面板而误报「未检测到掘金发布设置面板」
    let skipPubClick = false;
    if (code === 'juejin') {
      const panelOpen = document.querySelector('.add-article-form')
        || Array.from(document.querySelectorAll('div, aside')).some((d) => {
          const txt = d.innerText || '';
          return /发布文章/.test(txt) && /分类/.test(txt) && d.offsetWidth > 200 && d.offsetWidth < 700 && d.offsetHeight > 250;
        });
      if (panelOpen) { skipPubClick = true; console.log('[CRM插件] 掘金设置面板已打开，跳过顶部「发布」点击'); }
    }
    if (!skipPubClick && !window.__crmXhsCdpClicked) {
      // 百家号：发布前检查是否仍有封面弹窗残留——它会整块遮住发布按钮导致点击无效
      if (code === 'baijiahao') {
        const blocker = deepQueryAll(document, 'div').some((el) => {
          if (!elVisible(el)) return false;
          const r = el.getBoundingClientRect();
          return r.width >= 400 && r.height >= 250 && /选择封面/.test((el.innerText || '') + '');
        });
        if (blocker) console.warn('[CRM插件] 百家号：发布前仍有封面弹窗残留，可能挡住发布按钮');
      }
      pubBtn.click();
      console.log('[CRM插件] 已点击发布按钮「' + (((pubBtn.innerText || pubBtn.textContent || '') + '').trim().slice(0, 12)) + '」');
    }

    // 知乎发布设置弹窗：点击「发布」后弹出（含 添加文章封面/创作声明/文章话题/内容来源），
    // 在弹窗内完成设置后，再点弹窗内的「发布」确认
    if (code === 'zhihu' && job && job.platformConfig) {
      try {
        const settingsModal = () => {
          const ms = document.querySelectorAll('[role="dialog"], [class*="modal" i], [class*="dialog" i]');
          for (const m of ms) {
            try {
              const r = m.getBoundingClientRect();
              if (r.width > 300 && r.height > 200 && (((m.textContent || '').indexOf('添加文章封面') >= 0)
                || ((m.textContent || '').indexOf('创作声明') >= 0))) return m;
            } catch (e) { /* ignore */ }
          }
          return null;
        };
        let modal = null;
        const st = Date.now();
        while (Date.now() - st < 8000) {
          modal = settingsModal();
          if (modal) break;
          await sleep(400);
        }
        if (modal) {
          console.log('[CRM插件] 知乎发布设置弹窗已出现，开始填写声明/专栏');
          try { await fillZhihuSettings(job); } catch (e) { /* ignore */ }
          // 设置完成后再次同步日志快照（点确认后页面可能跳转）
          try { if (typeof window.__crmSyncPendingLogs === 'function') await window.__crmSyncPendingLogs(); } catch (e) { /* ignore */ }
          // 弹窗内点「发布」确认（叶子节点取最小面积，避免点到弹窗外同名按钮）
          let confirmBtn = null;
          let bestArea = Infinity;
          for (const el of modal.querySelectorAll('button, [role="button"], span, div')) {
            if (((el.textContent || '') + '').replace(/\s+/g, '') !== '发布') continue;
            try {
              const r = el.getBoundingClientRect();
              if (r.width < 5 || r.height < 5) continue;
              const a = r.width * r.height;
              if (a < bestArea) { bestArea = a; confirmBtn = el; }
            } catch (e) { /* ignore */ }
          }
          if (confirmBtn) {
            try { confirmBtn.click(); } catch (e) { /* ignore */ }
            console.log('[CRM插件] 已点击弹窗内「发布」确认');
          } else {
            console.warn('[CRM插件] 发布设置弹窗内未找到「发布」确认按钮');
          }
        } else {
          console.warn('[CRM插件] 点击发布后未出现设置弹窗（该版本可能直接发布）');
        }
      } catch (e) { /* ignore */ }
    }

    // CSDN / 掘金 / 开源中国 / 51CTO 发布弹窗：需先填设置再点弹窗内发布按钮，单独处理
    if (code === 'csdn' || code === 'juejin' || code === 'oschina' || code === 'cto51') {
      const modalRes = await (code === 'csdn' ? handleCsdnModal(job)
        : code === 'juejin' ? handleJuejinModal(job)
          : code === 'cto51' ? handleCto51Modal(job)
            : handleOschinaModal(job));
      if (modalRes && modalRes.ok === false && modalRes.msg) {
        return modalRes;
      }
      // modal 已点发布，直接进入成功信号轮询
      const timeout = timeoutMs || 20000;
      const start = Date.now();
      while (Date.now() - start < timeout) {
        const now = location.href;
        // 成功提示优先于草稿 URL 判定：知乎发布成功后跳 /p/xxx/edit，与草稿 URL 特征相同
        if (hasText(SUCCESS_WORDS)) {
          // 开源中国：提示出现时通常还没跳文章页，等 URL 稳定到文章详情（/blog/数字 结尾）再回传，最多 6s
          if (code === 'oschina') {
            const stOk = Date.now();
            while (Date.now() - stOk < 6000 && !/\/blog\/\d+\/?$/.test(location.pathname)) await sleep(400);
          }
          return { ok: true, url: location.href, msg: '页面提示发布成功' };
        }
        // 仅当 URL 发生变化且命中草稿特征才判草稿（编辑器本身的 /edit URL 不算，避免发布完成前被误杀）
        const isDraft = now !== before && (cfg.draft || []).some((re) => re.test(now));
        if (isDraft) {
          return { ok: false, msg: '平台将其保存为草稿，未真正发布' };
        }
        if (now !== before && (cfg.published || []).some((re) => re.test(now))) {
          return { ok: true, url: now, msg: '已跳转到已发布的文章页' };
        }
        await sleep(500);
      }
      return { ok: false, msg: '未检测到发布成功信号，请在弹窗中手动点发布' };
    }

    // 严格判定轮询：命中「已发布文章页 URL」或明确的发布成功提示才算成功；
    // 期间持续补点二次确认弹窗（开源中国等平台弹窗渲染慢，需在轮询中反复尝试）
    const timeout = timeoutMs || 20000;
    const start = Date.now();
    let confirmed = false;
    while (Date.now() - start < timeout) {
      const now = location.href;
      // 成功提示优先于草稿 URL 判定：知乎发布成功后跳 /p/xxx/edit，与草稿 URL 特征相同
      if (hasText(SUCCESS_WORDS)) {
        const url = await resolveResultUrl(code, job, now);
        // 搜狐创作页含「已发布」等干扰文案：仍在创作页且没解析出文章链接时不判成功，继续等待真正跳转
        if (!(code === 'sohu' && !url && /addarticle/i.test(now))) {
          return { ok: true, url: url || '', msg: url ? '页面提示发布成功' : '页面提示发布成功（未获取到文章链接）' };
        }
      }
      // 仅当 URL 变化且命中草稿特征才判草稿：编辑器自身的 /edit URL 与自动保存文案不算
      const isDraft = now !== before && (cfg.draft || []).some((re) => re.test(now));
      if (isDraft) {
        return { ok: false, msg: '平台将其保存为草稿，未真正发布' };
      }
      if (now !== before && (cfg.published || []).some((re) => re.test(now))) {
        return { ok: true, url: await resolveResultUrl(code, job, now), msg: '已跳转到已发布的文章页' };
      }
      // 补点二次确认弹窗（仅长词精确匹配，避免误点）
      if (!confirmed) {
        const cb = findBtnInScope(document.body, ['确定并发布', '确认发布', '确定发布', '发布文章并提交'])
          || findByText(cfg.confirm, ['确认发布', '确定并发布', '确定', '确认']);
        if (cb) {
          try { cb.click(); confirmed = true; } catch (e) { /* ignore */ }
        }
      }
      await sleep(500);
    }
    return { ok: false, msg: '未检测到发布成功信号，请手动确认' };
  };

  /** 富文本创作页（mp.csdn.net）：发布设置是编辑器下方「常驻面板」（无 el-dialog），
   *  标签/分类要点「+ 添加文章标签」「+ 新建分类专栏」按钮打开浮层选择。
   *  DOM 不可控，全部尽力而为：失败不阻塞发布，由用户在面板手动补填。 */
  async function fillCsdnRichPanel(job) {
    const c = (job && job.platformConfig) || {};
    const splitWords = (v) => String(v || '').split(/[,，、;；\s]+/).map((s) => s.trim()).filter(Boolean);
    const findLeafByText = (txt) => {
      let hit = null, best = Infinity;
      for (const d of docList()) {
        for (const el of deepQueryAll(d, 'div, span, button, a')) {
          const t = ((el.innerText || el.textContent || '') + '').replace(/\s+/g, '');
          if (t !== txt) continue;
          try {
            if (!elVisible(el)) continue;
            const r = el.getBoundingClientRect();
            if (r.width < 5 || r.height < 5) continue;
            const a = r.width * r.height;
            if (a < best) { best = a; hit = el; }
          } catch (e) { /* ignore */ }
        }
      }
      return hit;
    };
    // 跨文档 + 穿透 Shadow DOM 的查询：CSDN 编辑器/设置面板可能嵌在 iframe 或 web components 中，
    // 普通 querySelectorAll 不穿透 shadow root，会导致标签区域收集为空（findLeafByText 能成功而
    // querySelectorAll 系全失败，正对应 deepQueryAll 穿透、普通查询不穿透的差异）
    const qsaAll = (sel) => {
      const out = [];
      for (const d of docList()) {
        try { deepQueryAll(d, sel).forEach((el) => out.push(el)); } catch (e) { /* ignore */ }
      }
      return out;
    };
    // 包含式查找（最小面积优先）：入口文案常带前缀符号（如「+ 从本地上传」）；跨文档含 iframe
    const findContainsLeaf = (kw) => {
      let hit = null, best = Infinity;
      for (const d of docList()) {
        for (const el of deepQueryAll(d, 'div, span, button, a, p')) {
          const t = ((el.innerText || el.textContent || '') + '').replace(/\s+/g, '');
          if (!t || t.indexOf(kw) < 0 || t.length > 30) continue;
          try {
            if (!elVisible(el)) continue;
            const r = el.getBoundingClientRect();
            if (r.width < 5 || r.height < 5) continue;
            const a = r.width * r.height;
            if (a < best) { best = a; hit = el; }
          } catch (e) { /* ignore */ }
        }
      }
      return hit;
    };
    const tags = splitWords(c.tags);
    // 「文章标签」区域（label 文本常带 * 星号，用包含匹配；向上找到含「添加文章标签」的容器）
    const tagArea = () => {
      // 多锚点：label →「+添加文章标签」按钮 → 标签输入框（跨文档）
      const anchors = [findContainsLeaf('文章标签'), findLeafByText('+添加文章标签'), findLeafByText('添加文章标签')]
        .filter(Boolean);
      if (!anchors.length) {
        const inp = qsaAll('input').find((i) => elVisible(i) && /标签|关键词/.test(i.placeholder || ''));
        if (inp) anchors.push(inp);
      }
      if (!anchors.length) { console.warn('[CRM插件] CSDN 未定位到「文章标签」区域锚点'); return null; }
      for (const anchor of anchors) {
        let container = anchor.parentElement;
        for (let i = 0; i < 6 && container && container !== document.body; i++) {
          if (((container.innerText || '') + '').indexOf('添加文章标签') >= 0) return container;
          container = container.parentElement;
        }
      }
      console.warn('[CRM插件] CSDN「文章标签」锚点已定位但向上未找到含「添加文章标签」的容器');
      return null;
    };
    // 页面已存在的标签 chip 文本。
    // 注意：chip 内含 × 关闭图标（svg），文本元素不是叶子节点——按「叶子节点」过滤会收集为空
    //（上一版即栽在这里），改为取「最内层同名文本元素」的文本
    const chipTexts = () => {
      const box = tagArea();
      if (!box) return [];
      const stop = /添加文章标签|文章标签|从本地上传|文章摘要|添加封面|AI提取/;
      const texts = [];
      const seen = {};
      for (const el of deepQueryAll(box, 'span, div')) {
        if (!elVisible(el)) continue;
        const t = ((el.textContent || '') + '').replace(/\s+/g, '');
        if (!t || t.length > 20 || stop.test(t)) continue;
        if (seen[t]) continue;
        // 有更内层的同名文本元素时跳过外层（只统计最内层）
        const inner = el.querySelector('span, div');
        if (inner && ((inner.textContent || '') + '').replace(/\s+/g, '') === t) continue;
        seen[t] = 1;
        texts.push(t);
      }
      return texts;
    };
    // 清理非配置标签：CSDN 会按正文 AI 推荐自动打标签，导致页面标签与预览配置不一致
    const removeExtraTags = async (wanted) => {
      try {
        const box = tagArea();
        if (!box) return;
        if (!chipTexts().length) {
          console.warn('[CRM插件] CSDN「文章标签」区域已定位但未收集到任何标签 chip');
        }
        const want = wanted.map((t) => t.replace(/\s+/g, ''));
        // 完整鼠标事件序列（部分组件只监听 mousedown/mouseup，element.click() 无效）
        const fireClick = (el) => {
          try {
            const r = el.getBoundingClientRect();
            const opts = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
            el.dispatchEvent(new MouseEvent('mousedown', opts));
            el.dispatchEvent(new MouseEvent('mouseup', opts));
            el.dispatchEvent(new MouseEvent('click', opts));
          } catch (e) { try { el.click(); } catch (e2) { /* ignore */ } }
        };
        for (let round = 0; round < 8; round++) {
          const extra = chipTexts().find((t) => want.indexOf(t.replace(/\s+/g, '')) < 0);
          if (!extra) { if (round) console.log('[CRM插件] CSDN 已清理非配置标签'); return; }
          // 找该文案的最小元素 → 向上收集 chip 容器内所有疑似关闭控件（svg/icon/×文本及各层），
          // 逐个点击并校验 chip 是否真的消失（点击事件可能绑在任一层，盲点一次常无效）
          const leaf = deepQueryAll(box, 'span, div')
            .filter((el) => elVisible(el) && ((el.textContent || '') + '').trim() === extra)
            .sort((a, b) => (a.textContent || '').length - (b.textContent || '').length)[0];
          const cands = [];
          const lookLikeCloser = (x) => {
            const t = ((x.textContent || '') + '').trim();
            const cls = (x.className && typeof x.className === 'string') ? x.className
              : (x.className && x.className.baseVal !== undefined ? x.className.baseVal : '');
            return /^(×|✕|x|X)$/.test(t) || x.tagName === 'SVG' || x.tagName === 'I' || /close|icon|delete/i.test(cls || '');
          };
          let q = leaf;
          for (let up = 0; up < 5 && q; up++) {
            if (q.querySelectorAll) {
              Array.from(q.querySelectorAll('svg, i, span, b, button, [class*="close" i], [class*="icon" i], [class*="delete" i]'))
                .forEach((x) => { if (elVisible(x) && lookLikeCloser(x) && cands.indexOf(x) < 0) cands.push(x); });
            }
            q = q.parentElement;
          }
          let closed = false;
          for (const c of cands) {
            try { fireClick(c); } catch (e) { /* ignore */ }
            await sleep(500);
            if (!chipTexts().some((t) => t.replace(/\s+/g, '') === extra.replace(/\s+/g, ''))) { closed = true; break; }
          }
          if (!closed) { console.warn('[CRM插件] CSDN 非配置标签「' + extra + '」自动删除未成功，请手动删除'); return; }
          await sleep(400);
        }
      } catch (e) { /* ignore */ }
    };
    if (tags.length) {
      try {
        await removeExtraTags(tags);
        const addBtn = findLeafByText('+添加文章标签') || findLeafByText('添加文章标签');
        if (addBtn) {
          try { addBtn.click(); } catch (e) { /* ignore */ }
          await sleep(800);
          for (const tag of tags) {
            const want = tag.replace(/\s+/g, '');
            let added = false;
            // 两次尝试：输入 → 优先点联想项（CSDN 通常需从联想列表选中，Enter 不一定生效）→ 校验 chip
            for (let attempt = 0; attempt < 2 && !added; attempt++) {
              const st = Date.now();
              let target = null;
              while (Date.now() - st < 5000 && !target) {
                target = qsaAll('input')
                  .find((i) => elVisible(i) && !i.disabled && !i.readOnly && /标签|关键词/.test(i.placeholder || ''));
                if (!target) await sleep(400);
              }
              if (!target) { console.warn('[CRM插件] CSDN 未找到标签输入框，标签「' + tag + '」未填写'); break; }
              try { target.focus(); } catch (e) { /* ignore */ }
              syncInputValue(target, tag);
              await sleep(900);
              // 联想项：浮层中与标签全等的可见元素（排除标签区已有 chip，避免点到 chip 本身）
              const boxA = tagArea();
              const sugg = deepQueryAll(document, 'li, div, span, p')
                .filter((el) => elVisible(el)
                  && (!boxA || !boxA.contains(el))
                  && ((el.textContent || '') + '').trim().replace(/\s+/g, '') === want)
                .sort((a, b) => (a.textContent || '').length - (b.textContent || '').length);
              if (sugg.length) {
                try { sugg[0].click(); } catch (e) { /* ignore */ }
              } else {
                try {
                  target.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
                  target.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', keyCode: 13, bubbles: true }));
                } catch (e) { /* ignore */ }
              }
              await sleep(800);
              added = chipTexts().map((s) => s.replace(/\s+/g, '')).indexOf(want) >= 0;
            }
            if (!added) console.warn('[CRM插件] CSDN 标签「' + tag + '」两次尝试均未添加成功');
          }
          const ok = findLeafByText('确定') || findLeafByText('确认');
          if (ok) { try { ok.click(); } catch (e) { /* ignore */ } await sleep(500); }
          // 校验：页面 chip 与配置一致，不一致给出明细日志
          const have = chipTexts().map((t) => t.replace(/\s+/g, ''));
          const missing = tags.filter((t) => have.indexOf(t.replace(/\s+/g, '')) < 0);
          if (missing.length) console.warn('[CRM插件] CSDN 标签未全部添加：缺 ' + missing.join(',') + '，当前：' + have.join(','));
          else console.log('[CRM插件] CSDN 标签已填写（' + tags.join(',') + '）');
        } else {
          console.warn('[CRM插件] CSDN 未找到「添加文章标签」入口');
        }
      } catch (e) { /* ignore */ }
    }
    // 2) 分类专栏：点「+ 新建分类专栏」→ 浮层中优先选配置的分类，否则选第一个可见项
    try {
      const addCat = findLeafByText('+新建分类专栏') || findLeafByText('新建分类专栏');
      if (addCat) {
        try { addCat.click(); } catch (e) { /* ignore */ }
        await sleep(800);
        const want = String(c.category || '').trim();
        const cands = Array.from(document.querySelectorAll('li, [class*="item"], [class*="option"], [class*="option"] [class*="text"]'))
          .filter((el) => {
            if (!elVisible(el)) return false;
            const t = ((el.innerText || '') + '').trim();
            return t && t.length <= 20 && !/新建|取消|确定|关闭/.test(t);
          });
        let item = want ? cands.find((el) => ((el.innerText || '') + '').trim() === want) : null;
        if (!item) item = cands[0];
        if (item) {
          try { item.click(); } catch (e) { /* ignore */ }
          await sleep(500);
          const ok = findLeafByText('确定');
          if (ok) { try { ok.click(); } catch (e) { /* ignore */ } await sleep(400); }
          console.log('[CRM插件] CSDN 分类专栏已尝试选择');
        }
      }
    } catch (e) { /* ignore */ }
    // 2b) 可见范围：VIP可见/仅粉丝可见/仅我可见（radio，默认「全部可见」不点）。
    //     通用流程（fillStructuredFields）执行较早、面板可能未渲染完，这里发布前再兜一次
    const vis = String(c.visibility || '').trim();
    if (vis && vis !== '全部可见') {
      try {
        const el = findLeafByText(vis);
        if (el) {
          try { el.click(); } catch (e) { /* ignore */ }
          await sleep(400);
          console.log('[CRM插件] CSDN 可见范围已选「' + vis + '」');
        } else {
          console.warn('[CRM插件] CSDN 未找到可见范围选项「' + vis + '」，请手动选择');
        }
      } catch (e) { /* ignore */ }
    }
    // 3) 文章类型：原创/转载/翻译（radio 组，点选项文案；页面默认「原创」，非默认才点）
    const at = String(c.articleType || '').trim();
    if (at && at !== '原创') {
      try {
        const el = findLeafByText(at);
        if (el) {
          try { el.click(); } catch (e) { /* ignore */ }
          await sleep(400);
          console.log('[CRM插件] CSDN 文章类型已选「' + at + '」');
        } else {
          console.warn('[CRM插件] CSDN 未找到文章类型选项「' + at + '」');
        }
      } catch (e) { /* ignore */ }
    }
    // 3b) 转载：CSDN 选「转载」后出现「原文链接*」输入框与「原文允许转载…」授权复选框，均为发布必填
    if (at === '转载') {
      try {
        const srcUrl = String(c.sourceUrl || '').trim();
        // 原文链接：选转载后输入框异步渲染，轮询等待
        const st = Date.now();
        let urlInput = null;
        while (Date.now() - st < 8000 && !urlInput) {
          urlInput = qsaAll('input').find((i) =>
            elVisible(i) && /原文链接|请填写原文链接/.test(i.placeholder || ''));
          if (!urlInput) await sleep(400);
        }
        if (urlInput && srcUrl) {
          syncInputValue(urlInput, srcUrl);
          console.log('[CRM插件] CSDN 原文链接已填写');
        } else if (!srcUrl) {
          console.warn('[CRM插件] 文章类型为转载但未配置原文链接，请手动填写');
        }
        // 转载授权复选框：未勾选时勾上（不勾 CSDN 不允许发布转载文章）；
        // 用户显式取消授权（authAllowed === false）时尊重配置，仅提示
        const auth = findLeafByText('原文允许转载或者本次转载已经获得原作者授权') || findContainsLeaf('原文允许转载');
        if (auth) {
          let box = auth.closest('label') || auth.parentElement;
          let input = null;
          while (box && box !== document.body) {
            input = box.querySelector ? box.querySelector('input[type="checkbox"]') : null;
            if (input) break;
            box = box.parentElement;
          }
          if (!input) input = qsaAll('input[type="checkbox"]')[0];
          if (c.authAllowed === false) {
            console.warn('[CRM插件] 配置未勾选转载授权：CSDN 不允许发布未授权的转载文章，请注意');
          } else if (input && input.checked) {
            console.log('[CRM插件] CSDN 转载授权已勾选');
          } else if (input) {
            try { input.click(); } catch (e) { /* ignore */ try { auth.click(); } catch (e2) { /* ignore */ } }
            await sleep(300);
            console.log('[CRM插件] CSDN 转载授权已勾选');
          } else {
            // 找不到原生 checkbox（自定义样式）：直接点文案
            try { auth.click(); } catch (e) { /* ignore */ }
            await sleep(300);
            console.log('[CRM插件] CSDN 转载授权已尝试勾选（点选文案）');
          }
        } else {
          console.warn('[CRM插件] CSDN 未找到转载授权复选框（原文允许转载…），请手动勾选');
        }
      } catch (e) { /* ignore */ }
    }
    // 4) 封面：cover 配置优先；留空默认取正文第一张图（与前端「留空默认取正文第一张图」的约定一致）。
    //    入口是封面区的「从本地上传」，不能全局抓 input[type=file]（会命中正文图片上传框）：
    //    参考知乎做法 hook HTMLInputElement.click，点击入口瞬间捕获封面 input 再塞文件。
    try {
      const pageText0 = ((document.body.innerText || '') + '').replace(/\s+/g, '');
      if (/更换封面|删除封面/.test(pageText0)) {
        console.log('[CRM插件] CSDN 封面已存在，跳过上传');
      } else {
        let coverUrl = String(c.cover || '').trim();
        if (!coverUrl) {
          // 默认取正文第一张图：按区域分级取（正文编辑器内 → 编辑器容器 → 文章区 → 全页兜底）。
          // 注意 querySelectorAll 返回文档顺序，单条多选择器会先命中页头/侧栏图，故分级别取
          const clean = (im) => {
            const s = im.src || '';
            return /^(https?:|data:image)/i.test(s) && !/icon|logo|avatar|emoji|placeholder/i.test(s) ? s : '';
          };
          const pick = (sel) => {
            const im = qsaAll(sel)[0];
            return im ? clean(im) : '';
          };
          const groups = [
            '[contenteditable="true"] img',
            '.editor img',
            '[class*="editor"] img',
            'article img'
          ];
          for (const g of groups) {
            const list = qsaAll(g).map(clean).filter(Boolean);
            if (list.length) { coverUrl = list[0]; break; }
          }
          if (!coverUrl) {
            const all = qsaAll('img').map(clean).filter(Boolean);
            if (all.length) coverUrl = all[0];
          }
          if (!coverUrl) coverUrl = pick('img');
        }
        if (coverUrl) {
          // 优先：点击封面区已有的「推荐封面」缩略图（CSDN 按正文图自动推荐，即正文第一张图）。
          // file 上传在该页面不可靠（多版捕获不到 input），推荐图点击是页面原生路径
          let coverDone = false;
          try {
            const coverLabel = findContainsLeaf('添加封面');
            if (coverLabel) {
              let boxc = coverLabel.parentElement;
              for (let i = 0; i < 5 && boxc && boxc !== document.body; i++) {
                if (((boxc.innerText || '') + '').indexOf('从本地上传') >= 0) break;
                boxc = boxc.parentElement;
              }
              const rec = boxc ? Array.from(boxc.querySelectorAll('img')).find((im) => {
                try { const r = im.getBoundingClientRect(); return r.width >= 60 && r.height >= 40; } catch (e) { return false; }
              }) : null;
              if (rec) {
                try { rec.click(); } catch (e) { /* ignore */ }
                await sleep(1200);
                const okr = findLeafByText('确定') || findLeafByText('确认');
                if (okr) { try { okr.click(); } catch (e) { /* ignore */ } await sleep(600); }
                coverDone = await verifyCoverShown();
                if (coverDone) console.log('[CRM插件] CSDN 封面已通过推荐图选中');
                else console.warn('[CRM插件] CSDN 点击推荐封面后未见回显，改走本地上传');
              }
            }
          } catch (e) { /* ignore */ }
          if (!coverDone) {
          const entry = findLeafByText('从本地上传') || findLeafByText('添加封面') || findContainsLeaf('从本地上传');
          if (entry) {
            const dataUrl = await fetchImageDataUrl(coverUrl);
            const file = dataUrl ? await dataUrlToUploadFile(dataUrl, 'cover.jpg') : null;
            // 上传后校验：页面出现「更换封面/删除封面」入口才算成功
            const verifyCoverShown = async () => {
              const stc = Date.now();
              while (Date.now() - stc < 8000) {
                let pt = '';
                for (const d of docList()) {
                  try { pt += (d.body && d.body.innerText) || ''; } catch (e) { /* ignore */ }
                }
                if (/更换封面|删除封面/.test(pt.replace(/\s+/g, ''))) return true;
                await sleep(500);
              }
              return false;
            };
            if (!file) {
              console.warn('[CRM插件] CSDN 封面图下载失败：' + coverUrl + '，请手动上传或配置封面地址');
            } else {
              // 优先：封面容器内常驻的隐藏 input[type=file] 直接塞（上一版仅靠 hook input.click
              // 捕获失败——CSDN 上传控件可能用 dispatchEvent 触发，绕过了 proto.click hook）
              let p = entry, coverInput = null;
              for (let i = 0; i < 6 && p && p !== document.body && !coverInput; i++) {
                p = p.parentElement;
                try { coverInput = p && p.querySelector && p.querySelector('input[type="file"]'); } catch (e) { /* ignore */ }
              }
              if (coverInput && putFileToInput(coverInput, file)) {
                console.log('[CRM插件] CSDN 封面已提交上传（容器 input）');
                await sleep(1500);
                const okc = findLeafByText('确定');
                if (okc) { try { okc.click(); } catch (e) { /* ignore */ } await sleep(600); }
                if (await verifyCoverShown()) console.log('[CRM插件] CSDN 封面上传成功');
                else console.warn('[CRM插件] CSDN 封面上传后未见回显（更换/删除封面入口），请检查');
              } else {
              let captured = null;
              const proto = window.HTMLInputElement && window.HTMLInputElement.prototype;
              const origClick = proto && proto.click;
              if (proto && origClick) {
                proto.click = function () {
                  if (this && this.type === 'file') { captured = this; return undefined; }
                  return origClick.apply(this, arguments);
                };
              }
              const origPicker = window.showOpenFilePicker;
              if (typeof origPicker === 'function') {
                window.showOpenFilePicker = function () { return Promise.resolve([]); };
              }
              try { entry.click(); } catch (e) { /* ignore */ }
              const st = Date.now();
              while (Date.now() - st < 8000 && !captured) await sleep(300);
              if (proto && origClick) proto.click = origClick;
              if (typeof origPicker === 'function') window.showOpenFilePicker = origPicker;
              if (captured && putFileToInput(captured, file)) {
                console.log('[CRM插件] CSDN 封面已提交上传');
                await sleep(1500);
                // 部分版本弹裁剪/确认浮层：有「确定」按钮则点一次
                const ok = findLeafByText('确定');
                if (ok) { try { ok.click(); } catch (e) { /* ignore */ } await sleep(600); }
                if (await verifyCoverShown()) console.log('[CRM插件] CSDN 封面上传成功');
                else console.warn('[CRM插件] CSDN 封面上传后未见回显（更换/删除封面入口），请检查');
              } else {
                console.warn('[CRM插件] CSDN 封面未捕获到文件输入框，请手动上传');
              }
              }
            }
          } else {
            console.warn('[CRM插件] CSDN 未找到封面入口（从本地上传/添加封面）');
          }
          }
        }
      }
    } catch (e) { /* 封面失败不阻塞发布 */ }
    // 5) 创作声明：CSDN 自定义下拉（无声明/部分内容由AI辅助生成/内容来源网络，进行整合/再创作/个人观点，仅供参考）。
    //    默认「无声明」不操作。上一版通用逻辑点选失败（trigger 命中错误控件/浮层候选为空），
    //    改专用实现：点「创作声明」旁的下拉显示值打开浮层 → 点目标选项 → 校验显示值已变为目标
    const decl = String(c.declaration || '').trim();
    if (decl && decl !== '无声明' && decl !== '无') {
      const fillCsdnDeclaration = async (target) => {
        // 触发器：label「创作声明」所在 form-item 容器内的 select/input；兜底点当前显示值「无声明」
        let trigger = null;
        const label = findLeafByText('创作声明');
        if (label) {
          let node = label.parentElement;
          for (let i = 0; i < 6 && node && node !== document.body && !trigger; i++) {
            try { trigger = node.querySelector('[class*="select" i], [role="combobox"], input'); } catch (e) { /* ignore */ }
            node = node.parentElement;
          }
        }
        if (!trigger) trigger = findLeafByText('无声明');
        if (!trigger) return false;
        const shown = (el) => (((el && (el.innerText || el.value)) || '') + '').replace(/\s+/g, '');
        try { trigger.click(); } catch (e) { /* ignore */ }
        // 轮询浮层选项：去空格包含匹配目标文案，点最小面积元素
        const st = Date.now();
        while (Date.now() - st < 6000) {
          const opt = findContainsLeaf(target);
          if (opt && opt !== trigger) {
            try { opt.click(); } catch (e) { /* ignore */ }
            break;
          }
          await sleep(300);
        }
        await sleep(600);
        return shown(trigger).indexOf(target.replace(/\s+/g, '')) >= 0;
      };
      try {
        const okDecl = await fillCsdnDeclaration(decl);
        if (okDecl) console.log('[CRM插件] CSDN 创作声明已选「' + decl + '」');
        else console.warn('[CRM插件] CSDN 创作声明「' + decl + '」未能自动选择，请手动选择');
      } catch (e) { /* ignore */ }
    }
  }

  /**
   * CSDN 发布弹窗处理：自动为必填下拉（分类）选第一项，点击弹窗内「发布」主按钮，
   * 若校验报错（如仍有必填项为空）则再尝试一次。返回 { ok, msg }。
   */
  async function handleCsdnModal(job) {
    await sleep(700);
    // 误点「定时发布」会弹出定时对话框（请选择发布时间）：点「取消」关闭，
    // 再点真正的「发布博客/发布文章」，保证立即发布
    const d0 = document.querySelector('.el-dialog');
    if (d0 && /定时/.test((d0.innerText || ''))) {
      console.warn('[CRM插件] 检测到定时发布弹窗，点取消并改用立即发布');
      const cancel = Array.from(d0.querySelectorAll('button')).find((b) => /^取\s*消$/.test(((b.innerText || b.textContent || '') + '').trim()));
      if (cancel) { try { cancel.click(); } catch (e) { /* ignore */ } await sleep(600); }
      const real = findByText(['button:has-text("发布博客")', 'button:has-text("发布文章")'], ['发布博客', '发布文章']);
      if (real) { try { real.click(); } catch (e) { /* ignore */ } await sleep(800); }
    }
    const dialog = document.querySelector('.el-dialog');
    if (!dialog) {
      // 富文本创作页（mp.csdn.net）没有发布设置弹窗：设置为常驻面板，发布前已由
      // fillCsdnRichPanel 填好，点「发布博客」后直接进入成功判定轮询
      if (/mp\.csdn\.net/.test(location.host)) return { ok: true };
      return { ok: false, msg: '未检测到 CSDN 发布设置弹窗' };
    }
    // 把必填关键词补填到弹窗内的标签框
    if (job && job.fillTag) { try { await fillTagsGeneric(job, dialog); } catch (e) { /* ignore */ } }

    // 依次处理弹窗内仍为空的下拉（分类为必填，自动选第一项）
    const selectEmpty = () => {
      const selects = Array.from(dialog.querySelectorAll('.el-select'));
      for (const sel of selects) {
        const input = sel.querySelector('.el-input__inner');
        const val = ((input && input.value) || '').trim();
        const tags = sel.querySelectorAll('.el-tag');
        if (!val && !tags.length) return sel;
      }
      return null;
    };
    const pickFirstOption = async () => {
      const sel = selectEmpty();
      if (!sel) return false;
      try { sel.click(); } catch (e) { /* ignore */ }
      await sleep(400);
      // 取当前可见下拉中的第一项（CSDN 下拉挂在 body 下）
      let item = document.querySelector('.el-select-dropdown:not([style*="display: none"]) .el-select-dropdown__item');
      if (!item) item = document.querySelector('.el-select-dropdown .el-select-dropdown__item');
      if (item) { try { item.click(); } catch (e) { /* ignore */ } }
      await sleep(300);
      return true;
    };

    // 最多尝试 2 次：先填分类，点发布；若报错再补填一次
    for (let i = 0; i < 2; i++) {
      while (await pickFirstOption()) { /* 依次填充所有空下拉 */ }
      const publishBtn = dialog.querySelector('.el-button--primary')
        || findByText(['button:has-text("发布")'], ['发布']);
      if (!publishBtn) return { ok: false, msg: '未找到 CSDN 弹窗的发布按钮' };
      try { publishBtn.click(); } catch (e) { /* ignore */ }
      await sleep(900);
      // 已离开发布弹窗（弹窗关闭）即视为提交成功，交给上层轮询判定
      if (!document.querySelector('.el-dialog')) break;
      const errText = (document.querySelector('.el-message--error') || {}).innerText
        || (document.querySelector('.el-form-item__error') || {}).innerText || '';
      if (!errText) break; // 无错误提示，提交已发出
    }
    return { ok: true };
  }

  /** 元素当前是否可见可点 */
  function elVisible(el) {
    try {
      const r = el.getBoundingClientRect();
      const cs = (el.ownerDocument.defaultView || window).getComputedStyle(el);
      return r.width > 10 && r.height > 10 && cs.display !== 'none' && cs.visibility !== 'hidden' && cs.pointerEvents !== 'none';
    } catch (e) { return false; }
  }

  /** 在容器内按文案找按钮（精确匹配优先，排除草稿/定时/取消类） */
  function findBtnInScope(scope, words) {
    if (!scope) return null;
    const btns = scope.querySelectorAll('button, [role="button"], .btn, [class*="button"]');
    const clean = (b) => {
      const t = ((b.innerText || b.textContent || '') + '').trim();
      if (!t || /草稿|取消|返回|关闭|定时/.test(t)) return '';
      return t;
    };
    // 第一轮：精确匹配（如「发布」不会被「定时发布」抢占）
    for (const b of btns) {
      const t = clean(b);
      if (t && words.some((w) => t === w) && elVisible(b)) return b;
    }
    // 第二轮：包含匹配
    for (const b of btns) {
      const t = clean(b);
      if (t && words.some((w) => t.includes(w)) && elVisible(b)) return b;
    }
    return null;
  }

  /**
   * 51CTO：粘贴富文本后编辑器会弹「检测到粘贴内容符合 Markdown 语法，是否需要转投?」询问框，
   * 不处理会挡住后续图片粘贴与发布。保持富文本模式（图片粘贴流程基于富文本），点「取消」关闭。
   * 弹窗可能在每次粘贴后反复出现，调用方在关键节点多次调用。
   */
  async function closeCto51MarkdownPrompt(maxRounds) {
    for (let i = 0; i < (maxRounds || 6); i++) {
      let cancelBtn = null;
      for (const el of document.querySelectorAll('button, a, span, div')) {
        if (((el.textContent || '') + '').replace(/\s+/g, '') !== '取消' || !elVisible(el)) continue;
        // 确认是 Markdown 询问弹窗内的「取消」：祖先容器同时含「Markdown」与「转投/语法」文案
        let p = el, ok = false;
        for (let k = 0; k < 6 && p && p !== document.body; k++) {
          const pt = (p.innerText || '') + '';
          if (/Markdown/i.test(pt) && /转投|语法/.test(pt)) { ok = true; break; }
          p = p.parentElement;
        }
        if (ok) { cancelBtn = el; break; }
      }
      if (!cancelBtn) return;
      try { cancelBtn.click(); console.log('[CRM插件] 51CTO 已取消「Markdown 转投」询问，保持富文本'); } catch (e) { /* ignore */ }
      await sleep(600);
    }
  }

  /**
   * 51CTO 发布弹窗处理：点「发布」后弹出「基础信息」设置
   * （文章分类必填、标签必填、摘要/话题/封面可选、高级选项含「置顶」、可见性公开/私密）。
   * 按预览配置填写后点弹窗内「发布」。
   */
  async function handleCto51Modal(job) {
    // 轮询等待发布设置弹窗：含「文章分类/设置标签/基础信息/文章摘要」任一特征文案的
    // 最小可见容器（51CTO 弹窗版本较多，特征词放宽），期间补点「发布」
    const DIALOG_RE = /文章分类|设置标签|基础信息|发布设置|文章摘要|选择分类/;
    // 强特征词：整弹窗会同时命中多个，而弹窗的局部区块（如仅「分类+摘要」的中间层）
    // 命中数更少——据此优先选整弹窗，避免抓小导致「置顶/发布按钮」找不到
    const DIALOG_KWS = ['文章分类', '设置标签', '文章摘要', '个人分类', '封面设置', '其他设置', '高级选项', '文章类型', '可见性', '请选择二级分类'];
    const findDialog = () => {
      let hit = null, bestKw = 0, bestArea = Infinity;
      for (const el of deepQueryAll(document, 'div')) {
        const t = (el.innerText || '') + '';
        if (!elVisible(el) || !DIALOG_RE.test(t)) continue;
        const kws = DIALOG_KWS.filter((k) => t.indexOf(k) >= 0).length;
        if (kws < 2) continue;
        const r = el.getBoundingClientRect();
        if (r.width < 320 || r.height < 260) continue;
        const a = r.width * r.height;
        if (kws > bestKw || (kws === bestKw && a < bestArea)) { bestKw = kws; bestArea = a; hit = el; }
      }
      return hit;
    };
    let dialog = null;
    const wt0 = Date.now();
    handleCto51Modal._blobWarned = false;
    // 图片未上传完（blob 占位/平台「等待上传」提示）时点「发布」会被拦截、弹窗不出现：
    // 与开源中国同策略——等图片就绪后再补点
    const blobCount = () => Array.from(document.images || [])
      .filter((im) => /^blob:/i.test(im.src || '') && elVisible(im)).length;
    const uploadPending = () => blobCount() > 0
      || /等待.{0,6}图片.{0,6}上传|图片.{0,6}上传.{0,4}完成/.test(((document.querySelector('.el-message, [class*="message" i], [class*="toast" i]') || {}).innerText || ''));
    // 标题未填时点「发布」会让 51CTO 反复弹「请输入标题」；点击前确认标题已填，否则补填一次，仍无则不点
    const titleBox = () => document.querySelector('input[placeholder*="标题"], textarea[placeholder*="标题"], input[name="title"], #title, [contenteditable="true"][class*="title" i]');
    const titleFilled = () => {
      const tb = titleBox();
      const v = ((tb && tb.value != null ? tb.value : (tb && tb.innerText)) || '').trim();
      return !!tb && v.length >= 2;
    };
    while (Date.now() - wt0 < 60000 && !dialog) {
      dialog = findDialog();
      if (!dialog) {
        // Markdown 转投询问可能随时弹出挡住「发布」，每轮快速检查关闭
        try { await closeCto51MarkdownPrompt(1); } catch (e) { /* ignore */ }
        if (uploadPending()) {
          if (!handleCto51Modal._blobWarned) {
            handleCto51Modal._blobWarned = true;
            console.log('[CRM插件] 51CTO 检测到 ' + blobCount() + ' 张图片仍在上传，暂不点击「发布」，等待就绪');
          }
          await sleep(600);
          continue;
        }
        if (!titleFilled()) {
          const tb = titleBox();
          if (tb && job && job.title) {
            try { forceTypeValue(tb, job.title); await sleep(600); } catch (e) { /* ignore */ }
            if (titleFilled()) { console.log('[CRM插件] 51CTO 标题已补填（模拟输入），继续'); }
            else { console.warn('[CRM插件] 51CTO 标题补填后仍为空，暂缓点「发布」（避免反复弹「请输入标题」）'); await sleep(800); continue; }
          } else {
            console.warn('[CRM插件] 51CTO 未检测到已填标题，暂缓点「发布」（避免反复弹「请输入标题」）');
            await sleep(800);
            continue;
          }
        }
        const pubBtn = findByText(['button:has-text("发布")'], ['发布']);
        if (pubBtn && elVisible(pubBtn)) { try { pubBtn.click(); } catch (e) { /* ignore */ } }
        await sleep(800);
      }
    }
    if (!dialog) {
      const nb = blobCount();
      const noTitle = !titleFilled();
      // 诊断：列出页面可见弹窗容器及文案摘要（弹窗特征词不匹配时可据此精准修选择器）
      const dlgInfo = [];
      const seenT = new Set();
      for (const el of document.querySelectorAll('[role="dialog"], [class*="modal" i], [class*="dialog" i], .el-dialog, .el-drawer, [class*="drawer" i]')) {
        try {
          if (!elVisible(el)) continue;
          const r = el.getBoundingClientRect();
          if (r.width < 250 || r.height < 120) continue;
          const t = ((el.innerText || '') + '').replace(/\s+/g, ' ').trim().slice(0, 70);
          if (!t || seenT.has(t)) continue;
          seenT.add(t);
          dlgInfo.push(t);
          if (dlgInfo.length >= 4) break;
        } catch (e) { /* ignore */ }
      }
      console.warn('[CRM插件] 51CTO 弹窗未识别，页面弹窗容器文案：' + (dlgInfo.join(' | ') || '（未发现弹窗容器）'));
      return { ok: false, msg: (noTitle ? '标题未填写（51CTO 必填）' : (nb > 0 ? nb + ' 张图片未上传完成，未检测到 51CTO 发布设置弹窗' : '60 秒内未检测到 51CTO 发布设置弹窗'))
        + '，请手动发布后点「标记成功」' };
    }
    const c = (job && job.platformConfig) || {};
    const inDlg = (sel) => Array.from(dialog.querySelectorAll(sel));
    const leafInDlg = (txt) => {
      let hit = null, best = Infinity;
      for (const el of dialog.querySelectorAll('div, span, label, li, p, a')) {
        // 双文本源匹配（v1.9.14）：chip 内常有隐藏文本节点，innerText 与 textContent 不一致
        // （51CTO 实测诊断用 textContent 能列出「后端开发」而 innerText 匹配落空）
        const t1 = ((el.innerText || '') + '').replace(/\s+/g, '');
        const t2 = ((el.textContent || '') + '').replace(/\s+/g, '');
        if (t1 !== txt && t2 !== txt) continue;
        try {
          if (!elVisible(el)) continue;
          const r = el.getBoundingClientRect();
          if (r.width < 5 || r.height < 5) continue;
          const a = r.width * r.height;
          if (a < best) { best = a; hit = el; }
        } catch (e) { /* ignore */ }
      }
      return hit;
    };

    // 1) 文章分类（必填）：一级 chip；51CTO 一级选中后还必须选二级（红字「请选择二级分类」）。
    //    二级 chips 由接口异步渲染（点一级后可能 >1s 才出现），轮询等待红字与二级选项后点选
    const cat = String(c.category || '').trim();
    const needSub = () => inDlg('span, div, p, label').some((el) => elVisible(el)
      && el.children.length === 0 && /请选择二级分类/.test((el.textContent || '') + ''));
    // 一级分类红字（点击后仍在 = 未选中，需重试）
    const catMissing = () => inDlg('span, div, p, label').some((el) => elVisible(el)
      && el.children.length === 0 && /请选择一级分类|请选择分类/.test((el.textContent || '') + ''));
    if (cat) {
      // 分类 chips 由接口异步渲染，实测可能 >10 秒才出现（v1.9.12 轮询 10 秒仍扑空），
      // 轮询等待最多 25 秒；点击后以红字「请选择一级分类」是否消失验证，未生效则重点
      let catDone = false;
      const catSt = Date.now();
      while (Date.now() - catSt < 25000 && !catDone) {
        const chip = leafInDlg(cat);
        if (chip) {
          try { chip.click(); } catch (e) { /* ignore */ }
          await sleep(800);
          if (!catMissing()) {
            catDone = true;
            console.log('[CRM插件] 51CTO 文章分类一级已选「' + cat + '」');
            break;
          }
        }
        await sleep(500);
      }
      if (!catDone) {
        // 诊断：打印弹窗内可见的短文本叶子，便于比对配置的分类名与页面实际文案
        const chips = inDlg('div, span, label, li, p, a')
          .filter((el) => { try { return elVisible(el) && el.children.length === 0 && ((el.textContent || '') + '').replace(/\s+/g, '').length > 0 && ((el.textContent || '') + '').replace(/\s+/g, '').length <= 10; } catch (e) { return false; } })
          .slice(0, 24).map((el) => ((el.textContent || '') + '').replace(/\s+/g, ''));
        console.warn('[CRM插件] 51CTO 未找到/未选中文章分类「' + cat + '」（已轮询等待 25 秒），弹窗内文本：' + chips.join('、') + '，请手动选择');
      }
      const sub = String(c.subCategory || '').trim();
      // 无红字 = 该一级无需二级，直接跳过；有红字则最多等 8s 点选
      let subDone = !needSub();
      const subStart = Date.now();
      while (!subDone && Date.now() - subStart < 8000) {
        const subChip = sub ? leafInDlg(sub) : null;
        if (subChip) {
          try { subChip.click(); } catch (e) { /* ignore */ }
          await sleep(600);
          if (!needSub()) {
            console.log('[CRM插件] 51CTO 二级分类已选「' + sub + '」');
            subDone = true;
            break;
          }
        }
        await sleep(500);
      }
      if (!subDone && !sub) {
        // 诊断：打印弹窗内短文本候选（排除一级名），便于定位二级选项真实文案
        const cand = inDlg('span, div, li, label')
          .filter((el) => elVisible(el) && ((el.textContent || '') + '').replace(/\s+/g, '')
            && ((el.textContent || '') + '').length < 12
            && ((el.textContent || '') + '').replace(/\s+/g, '') !== cat)
          .slice(0, 12)
          .map((el) => ((el.textContent || '') + '').replace(/\s+/g, ''));
        console.warn('[CRM插件] 51CTO 需要二级分类但未配置 subCategory'
          + (cand.length ? '，弹窗内候选：' + cand.join('、') : '') + '，请手动选择');
      } else if (!subDone) {
        console.warn('[CRM插件] 51CTO 二级分类「' + sub + '」未生效（仍提示必选），请手动选择');
      }
      // 红字「请选择二级分类」仍在 = 必填未满足：硬拦截，不再点发布/保存
      // （此前只 warn 后继续发布，被平台校验拦下导致发布失败）
      if (!subDone) {
        return { ok: false, msg: '51CTO 一级分类「' + cat + '」需要选择二级分类'
          + (sub ? '（配置的「' + sub + '」未生效，平台选项可能已更名）' : '，请先在 CMS「预览适配」中为该一级分类配置二级分类')
          + '，也可在弹窗手动选择二级后手动发布' };
      }
    } else {
      console.warn('[CRM插件] 51CTO 未配置文章分类（平台必填），请手动选择');
    }

    // 2) 个人分类（选填文本）
    const pcat = String(c.personalCategory || '').trim();
    if (pcat) {
      const inp = inDlg('input').find((i) => elVisible(i) && !i.disabled && /个人分类/.test(i.placeholder || ''));
      if (inp) { syncInputValue(inp, pcat); console.log('[CRM插件] 51CTO 个人分类已填写'); }
    }

    // 2.5) 话题：仅配置了 topic 才填写；未配置时清空残留值（此前标签误写进话题框会残留）
    try {
      const topicV = String(c.topic || '').trim();
      const topicInp = inDlg('input').find((i) => elVisible(i) && !i.disabled && /话题/.test(i.placeholder || ''));
      if (topicInp) {
        if (topicV) {
          syncInputValue(topicInp, topicV);
          console.log('[CRM插件] 51CTO 话题已填写「' + topicV + '」（如为搜索式请手动确认）');
        } else if ((topicInp.value || '').trim()) {
          syncInputValue(topicInp, '');
          console.log('[CRM插件] 51CTO 未配置话题，已清空话题框残留值');
        }
      }
    } catch (e) { /* ignore */ }

    // 3) 标签（必填，最多 5 个）：逐个「模拟打字写入 → Escape 收起联想 → Enter 生成 chip → 校验」。
    //    联想推荐词高亮时 Enter 会误选「迭代/链路/复用」类推荐词而非生成自定义 chip，
    //    故 Enter 前先派发 Escape 收起联想；生成后清理不在配置内的误生成 chip。
    //    注意：51CTO 话题框 placeholder 可能含「标签」特征，必须排除，否则标签会误写进话题框
    const tags = String(c.tags || '').trim();
    if (tags) {
      const allInp = inDlg('input').filter((i) => elVisible(i) && !i.disabled && !i.readOnly);
      let inp = allInp.find((i) => /设置标签|添加标签/.test(i.placeholder || ''))
        || allInp.find((i) => /标签/.test(i.placeholder || '') && !/话题|个人分类|摘要|标题|转载/.test(i.placeholder || ''));
      if (!inp) {
        // 兜底：按「标签」label 向上找所在表单项内的输入框（placeholder 可能不含「标签」）
        const lbl = inDlg('label, span, div').find((el) => elVisible(el) && el.children.length === 0
          && /^标签$/.test(((el.textContent || '') + '').replace(/\s+/g, '')));
        if (lbl) {
          let p = lbl.closest('label') || lbl;
          for (let i = 0; i < 6 && p && !inp; i++) {
            p = p.parentElement;
            if (p) inp = Array.from(p.querySelectorAll('input')).find((x) => elVisible(x) && !x.disabled && !x.readOnly
              && !/话题|个人分类|摘要|标题|转载/.test(x.placeholder || ''));
          }
        }
      }
      if (inp) {
        console.log('[CRM插件] 51CTO 标签输入框已定位（placeholder=' + ((inp.placeholder || '').slice(0, 30) || '空') + '）');
        // chip 识别：取「文本以 × 结尾」的最内层元素（el-tag 内含文本节点+关闭图标两层子元素，
        // 此前 children.length<=1 的判断永远匹配不到，导致联想推荐词误加的 chip 清不掉）
        const chipEls = () => {
          const all = inDlg('span, div, li').filter((el) => {
            try { return elVisible(el) && /×$/.test(((el.textContent || '') + '').replace(/\s+/g, '')); } catch (e) { return false; }
          });
          return all.filter((el) => !all.some((o) => o !== el && el.contains(o)));
        };
        const chipName = (el) => (((el.textContent || '') + '').replace(/\s+/g, '').replace(/×+$/, ''));
        const closeChip = async (el) => {
          const closer = el.querySelector('[class*="close" i], .el-tag__close, i, svg');
          if (closer) {
            try { closer.click(); } catch (e) { /* ignore */ }
          } else {
            // × 为伪元素（无 DOM 节点）：点击 chip 右上角区域触发删除
            try {
              const r = el.getBoundingClientRect();
              el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, clientX: r.right - 6, clientY: r.top + r.height / 2 }));
            } catch (e) { /* ignore */ }
          }
          await sleep(300);
        };
        const removeChips = async (pred) => {
          for (const el of chipEls()) {
            const nm = chipName(el);
            if (!pred(nm)) continue;
            await closeChip(el);
            console.warn('[CRM插件] 51CTO 已移除标签 chip「' + nm + '」');
          }
        };
        const list = tags.split(/[,，、;；\s]+/).map((s) => s.trim()).filter(Boolean).slice(0, 5);
        // 预清理：平台会预填推荐/自动标签，先全部移除，再按配置逐个添加
        await removeChips(() => true);
        await sleep(400);
        let added = 0;
        for (const tag of list) {
          let okTag = chipEls().some((el) => chipName(el) === tag);
          for (let t = 0; t < 3 && !okTag; t++) {
            try { inp.focus(); } catch (e) { /* ignore */ }
            try { forceTypeValue(inp, tag); } catch (e) { syncInputValue(inp, tag); }
            await sleep(400);
            // 先收起联想下拉（cancelable=true 才会被 Vue 处理，否则 Enter 会选中高亮推荐词）
            for (let k = 0; k < 2; k++) {
              inp.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, which: 27, bubbles: true, cancelable: true }));
              await sleep(200);
            }
            inp.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
            inp.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
            await sleep(600);
            okTag = chipEls().some((el) => chipName(el) === tag);
          }
          if (okTag) added++;
          else console.warn('[CRM插件] 51CTO 标签「' + tag + '」未能确认添加，请手动补充');
          // 每加一个即清理：非配置 chip（联想词被 Enter 误选）与重复 chip
          await removeChips((nm) => !list.includes(nm));
          const seen = new Set();
          for (const el of chipEls()) {
            const nm = chipName(el);
            if (seen.has(nm)) await closeChip(el); else seen.add(nm);
          }
        }
        if (added) console.log('[CRM插件] 51CTO 标签已添加 ' + added + '/' + list.length + ' 个：' + chipEls().map(chipName).join('、'));
      } else {
        console.warn('[CRM插件] 51CTO 未找到标签输入框，请手动填写（平台必填）');
      }
    } else {
      console.warn('[CRM插件] 51CTO 未配置标签（平台必填），请手动填写');
    }

    // 4) 文章摘要（选填，最多 500 字）：未配置时自动取正文纯文本前 500 字兜底
    let summary = String(c.summary || '').trim();
    if (!summary && job && job.contentText) {
      summary = String(job.contentText).replace(/\s+/g, ' ').trim().slice(0, 500);
      if (summary) console.log('[CRM插件] 51CTO 未配置摘要，已自动取正文前 ' + summary.length + ' 字');
    }
    if (summary) {
      const ta = inDlg('textarea').find((i) => elVisible(i) && !i.disabled && /摘要/.test(i.placeholder || ''));
      if (ta) { syncInputValue(ta, summary.slice(0, 500)); console.log('[CRM插件] 51CTO 文章摘要已填写'); }
    }

    // 4.5) 文章类型（原创/转载/翻译，el-select 下拉，选项渲染在 body 级弹层）
    const atype = String(c.articleType || '').trim();
    if (atype && atype !== '原创') {
      try {
        const label = leafInDlg('文章类型');
        let box = null;
        let p = label;
        for (let i = 0; i < 6 && p && !box; i++) {
          box = p.querySelector ? p.querySelector('.el-select, [class*="select" i]') : null;
          p = p.parentElement;
        }
        if (box) {
          try { box.click(); } catch (e) { /* ignore */ }
          await sleep(600);
          // 优先在 body 级下拉弹层里找选项（不在 dialog 内，避免命中分类 chips）
          let opt = Array.from(document.querySelectorAll('.el-select-dropdown__item, [class*="dropdown" i] li'))
            .find((el) => elVisible(el) && ((el.textContent || '') + '').replace(/\s+/g, '') === atype);
          if (!opt) {
            opt = Array.from(document.querySelectorAll('li, span, div')).find((el) => elVisible(el)
              && el.children.length === 0 && !dialog.contains(el)
              && ((el.textContent || '') + '').replace(/\s+/g, '') === atype);
          }
          if (opt) {
            try { opt.click(); } catch (e) { /* ignore */ }
            await sleep(400);
            console.log('[CRM插件] 51CTO 文章类型已选「' + atype + '」');
          } else {
            console.warn('[CRM插件] 51CTO 未找到文章类型选项「' + atype + '」，请手动选择');
          }
        } else {
          console.warn('[CRM插件] 51CTO 未找到「文章类型」下拉，请手动选择');
        }
      } catch (e) { /* ignore */ }
    }

    // 5) 可见性：公开/私密 radio
    const vis = String(c.visibility || '公开').trim();
    try {
      const el = leafInDlg(vis);
      if (el) {
        let p = el.closest('label') || el.parentElement;
        let radio = null;
        for (let i = 0; i < 4 && p && !radio; i++) {
          radio = p.querySelector ? p.querySelector('input[type="radio"]') : null;
          p = p.parentElement;
        }
        const target = radio || el;
        if (radio && radio.checked) {
          console.log('[CRM插件] 51CTO 可见性已为「' + vis + '」');
        } else {
          try { (target || el).click(); } catch (e) { /* ignore */ }
          await sleep(300);
          console.log('[CRM插件] 51CTO 可见性已选「' + vis + '」');
        }
      } else {
        console.warn('[CRM插件] 51CTO 未找到可见性选项「' + vis + '」');
      }
    } catch (e) { /* ignore */ }

    // 6) 高级选项：置顶（勾选框）。Element 自绘勾选框的原生 input 多为隐藏（直接点不生效），
    //    优先点 .el-checkbox 容器，勾选后回读 input.checked 验证
    if (c.sticky === true) {
      try {
        const el = leafInDlg('置顶');
        let target = null;
        if (el) {
          let p = el;
          for (let i = 0; i < 8 && p && !target; i++) {
            const cbBox = p.querySelector ? p.querySelector('.el-checkbox, [class*="checkbox" i]:not(input)') : null;
            if (cbBox && elVisible(cbBox)) { target = cbBox; break; }
            p = p.parentElement;
          }
        }
        if (!target) {
          const boxes = inDlg('.el-checkbox, input[type="checkbox"]').filter((b) => elVisible(b));
          if (boxes.length === 1) target = boxes[0];
        }
        const cbState = () => {
          if (!target) return null;
          const cb = target.matches && target.matches('input[type="checkbox"]')
            ? target
            : (target.querySelector ? target.querySelector('input[type="checkbox"]') : null);
          return cb ? !!cb.checked : null;
        };
        if (target) {
          if (cbState() === false) {
            try { target.click(); } catch (e) { if (el) { try { el.click(); } catch (e2) { /* ignore */ } } }
            await sleep(500);
          }
          const after = cbState();
          console.log(after === true ? '[CRM插件] 51CTO 置顶已勾选'
            : after === false ? '[CRM插件] 51CTO 置顶勾选未生效，请手动勾选'
              : '[CRM插件] 51CTO 已点击「置顶」选项，请确认是否勾选');
        } else if (el) {
          const box = el.closest('label') || el.parentElement || el;
          try { box.click(); } catch (e) { /* ignore */ }
          await sleep(400);
          console.log('[CRM插件] 51CTO 已点击「置顶」选项容器，请确认是否勾选');
        } else {
          console.warn('[CRM插件] 51CTO 未找到「置顶」选项，请手动勾选');
        }
      } catch (e) { /* ignore */ }
    }

    // 7) 点弹窗内「发布」类按钮（确认发布/发布/发布文章）。51CTO 存在两种弹窗模式：
    //    发布模式（底部「确认发布/发布」）与保存模式（底部「重置/保存」，保存后回编辑器
    //    再点页面「发布文章」）。保存模式流程：点保存 → 等弹窗关 → 点页面级「发布文章」→
    //    若「基础信息」弹窗重现（发布模式）则重入完成确认发布
    handleCto51Modal._depth = (handleCto51Modal._depth || 0) + 1;
    const btnText = (b) => ((b.innerText || '') + '').replace(/\s+/g, '');
    const isPubBtn = (b) => /^(确认发布|发布文章|发布)$/.test(btnText(b));
    let pub = inDlg('button').find((b) => elVisible(b) && isPubBtn(b));
    if (!pub) {
      let p = dialog.parentElement;
      for (let i = 0; i < 8 && p && p !== document.body && !pub; i++) {
        if (/文章分类|设置标签|文章摘要/.test((p.innerText || '') + '')) {
          pub = Array.from(p.querySelectorAll('button')).find((b) => elVisible(b) && isPubBtn(b));
        }
        p = p.parentElement;
      }
    }
    if (pub) {
      try { pub.click(); } catch (e) { /* ignore */ }
      await sleep(900);
      const err = document.querySelector('.el-message--error, .el-form-item__error');
      if (err) {
        console.warn('[CRM插件] 51CTO 弹窗校验提示：' + ((err.innerText || '') + '').trim());
        try { pub.click(); } catch (e) { /* ignore */ }
        await sleep(900);
      }
      handleCto51Modal._depth = 0;
      return { ok: true };
    }
    if (handleCto51Modal._depth >= 2) {
      handleCto51Modal._depth = 0;
      return { ok: false, msg: '51CTO 发布弹窗内未找到「发布」按钮（重入已达上限）' };
    }
    // 保存模式：点「保存」（弹窗内或祖先容器）
    let save = inDlg('button').find((b) => elVisible(b) && /^(保存|确定)$/.test(btnText(b)));
    if (!save) {
      let p = dialog.parentElement;
      for (let i = 0; i < 8 && p && p !== document.body && !save; i++) {
        if (/文章分类|设置标签|文章摘要/.test((p.innerText || '') + '')) {
          save = Array.from(p.querySelectorAll('button')).find((b) => elVisible(b) && /^(保存|确定)$/.test(btnText(b)));
        }
        p = p.parentElement;
      }
    }
    if (!save) {
      handleCto51Modal._depth = 0;
      return { ok: false, msg: '51CTO 发布弹窗内未找到「发布/保存」按钮' };
    }
    try { save.click(); } catch (e) { /* ignore */ }
    console.log('[CRM插件] 51CTO 弹窗为保存模式，已点「保存」，继续找页面「发布文章」');
    // 等弹窗关闭（保存成功后消失）
    const sc0 = Date.now();
    while (Date.now() - sc0 < 10000) {
      await sleep(500);
      if (!findDialog()) break;
    }
    // 找页面级「发布文章/发布」按钮（排除弹窗内按钮）
    let pubPage = null;
    const sc1 = Date.now();
    while (Date.now() - sc1 < 15000 && !pubPage) {
      for (const b of document.querySelectorAll('button, [role="button"], a')) {
        if (/^(发布文章|发布)$/.test(btnText(b)) && elVisible(b) && !dialog.contains(b)) { pubPage = b; break; }
      }
      if (!pubPage) await sleep(600);
    }
    if (!pubPage) {
      handleCto51Modal._depth = 0;
      return { ok: true, msg: '51CTO 已保存基础信息，未找到页面「发布」按钮，请手动发布后点「标记成功」' };
    }
    try { pubPage.click(); } catch (e) { /* ignore */ }
    console.log('[CRM插件] 51CTO 已点击页面「' + btnText(pubPage) + '」');
    // 等待：基础信息弹窗重现（发布模式）→ 重入完成确认发布；已跳成功页/出现成功提示 → 直接成功
    const sc2 = Date.now();
    while (Date.now() - sc2 < 20000) {
      await sleep(800);
      if (/blogger\/success\/\d+/.test(location.href) || /发布成功/.test(((document.body || {}).innerText) || '')) {
        handleCto51Modal._depth = 0;
        return { ok: true, url: location.href };
      }
      if (findDialog()) {
        console.log('[CRM插件] 51CTO 发布弹窗重现（发布模式），继续确认发布');
        const re = await handleCto51Modal(job);
        handleCto51Modal._depth = 0;
        return re;
      }
    }
    handleCto51Modal._depth = 0;
    return { ok: true, url: location.href };
  }

  /**
   * 开源中国发布弹窗处理：「发布文章」弹窗含 文章来源（原创/转载 radio）、
   * 博客分类（多选 chips，可「+ 新建分类」）、选择专区（可搜索下拉，可选）、
   * 权限设置（是否公开/是否禁用评论）。按预览配置填写后点「确定并发布」。
   */
  async function handleOschinaModal(job) {
    // 弹窗可能渲染较慢：轮询等待。注意不能用 URL/「发布成功」文案判定「直接发布」——
    // 开源中国点「发布文章」会先保存文章（URL 立即变为 /blog/数字）再弹设置弹窗，
    // 任何此类兜底都会在弹窗出现前误判成功、跳过整个填表流程（v1.6.70/75 均栽于此）
    const findDialog = () => {
      let hit = null, bestArea = Infinity;
      for (const el of deepQueryAll(document, 'div')) {
        const t = (el.innerText || '') + '';
        // 须同时含 ≥2 个弹窗关键词：排除只含单个关键词的行级容器（如「博客分类」表单行）
        const kws = ['博客分类', '文章来源', '权限设置', '选择专区', '确定并发布'].filter((k) => t.indexOf(k) >= 0);
        if (kws.length < 2 || !elVisible(el)) continue;
        const r = el.getBoundingClientRect();
        if (r.width < 240 || r.height < 250) continue;
        const a = r.width * r.height;
        if (a < bestArea) { bestArea = a; hit = el; }
      }
      return hit;
    };
    let dialog = null;
    const wt0 = Date.now();
    handleOschinaModal._blobWarned = false;
    const blobCount = () => Array.from(document.images || [])
      .filter((im) => /^blob:/i.test(im.src || '') && elVisible(im)).length;
    while (Date.now() - wt0 < 30000 && !dialog) {
      dialog = findDialog();
      if (!dialog) {
        // 诊断：页面有 toast 提示（如图片上传中/上传失败）时打印，帮助定位弹窗未出现原因
        const toast = document.querySelector('.el-message, .el-notification');
        const toastTxt = toast ? ((toast.innerText || '') + '').replace(/\s+/g, ' ').slice(0, 80) : '';
        if (toastTxt && !handleOschinaModal._lastToast || (toastTxt && toastTxt !== handleOschinaModal._lastToast)) {
          handleOschinaModal._lastToast = toastTxt;
          console.log('[CRM插件] 开源中国 等待弹窗中，页面提示：' + toastTxt);
        }
        // 图片未上传完（blob 占位）时不补点：平台会拦截「发布」并提示上传中，等就绪后再点
        const nb = blobCount();
        if (nb > 0) {
          if (!handleOschinaModal._blobWarned) {
            handleOschinaModal._blobWarned = true;
            console.log('[CRM插件] 开源中国 检测到 ' + nb + ' 张图片仍在上传（blob 占位），暂不点击「发布文章」');
          }
          await sleep(600);
          continue;
        }
        const pubBtn = findByText(['button:has-text("发布文章")'], ['发布文章']);
        if (pubBtn && elVisible(pubBtn)) {
          // 完整鼠标事件点击（部分场景仅原生 click 不触发平台校验/弹窗逻辑）
          try {
            const r = pubBtn.getBoundingClientRect();
            const mo = { bubbles: true, cancelable: true, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
            pubBtn.dispatchEvent(new MouseEvent('mousedown', mo));
            pubBtn.dispatchEvent(new MouseEvent('mouseup', mo));
            pubBtn.click();
          } catch (e) { try { pubBtn.click(); } catch (e2) { /* ignore */ } }
        } else if (Date.now() - wt0 > 4000 && !handleOschinaModal._noBtnWarned) {
          handleOschinaModal._noBtnWarned = true;
          console.warn('[CRM插件] 开源中国 页面上未找到可见的「发布文章」按钮（可能当前是已发布文章的编辑页，或页面尚未加载完成）');
        }
        await sleep(800);
      }
    }
    handleOschinaModal._lastToast = '';
    handleOschinaModal._noBtnWarned = false;
    if (!dialog) {
      const leftBlob = blobCount();
      return { ok: false, msg: '30 秒内未检测到开源中国发布设置弹窗'
        + (leftBlob > 0 ? '（' + leftBlob + ' 张图片仍未上传完成）' : '（当前页面无「发布文章」按钮，或为已发布文章的编辑页）')
        + '，请手动点「发布文章」并填写设置发布，再点「标记成功」' };
    }
    try {
      const dr = dialog.getBoundingClientRect();
      console.log('[CRM插件] 开源中国 设置弹窗已定位（' + Math.round(dr.width) + 'x' + Math.round(dr.height) + '），开始填写');
    } catch (e) { /* ignore */ }
    const c = (job && job.platformConfig) || {};
    // 回传完整弹窗配置，便于排查「字段没填」类问题（预览配置是否真的下发到插件）
    try { console.log('[CRM插件] 开源中国 弹窗配置：' + JSON.stringify(c)); } catch (e) { /* ignore */ }
    const inDlg = (sel) => Array.from(dialog.querySelectorAll(sel));
    const leafInDlg = (txt) => {
      let hit = null, best = Infinity;
      for (const el of dialog.querySelectorAll('div, span, label, li, p, a')) {
        // 双文本源匹配（v1.9.14）：chip 内常有隐藏文本节点，innerText 与 textContent 不一致
        // （51CTO 实测诊断用 textContent 能列出「后端开发」而 innerText 匹配落空）
        const t1 = ((el.innerText || '') + '').replace(/\s+/g, '');
        const t2 = ((el.textContent || '') + '').replace(/\s+/g, '');
        if (t1 !== txt && t2 !== txt) continue;
        try {
          if (!elVisible(el)) continue;
          const r = el.getBoundingClientRect();
          if (r.width < 5 || r.height < 5) continue;
          const a = r.width * r.height;
          if (a < best) { best = a; hit = el; }
        } catch (e) { /* ignore */ }
      }
      return hit;
    };

    // 1) 文章来源：radio。开源中国弹窗默认不选中任何项，「原创」也必须点选。
    //    element-plus radio：点 .el-radio 根元素最可靠（hidden input 直点不触发），失败重试一次
    const st0 = String(c.sourceType || '原创').trim();
    const wantSrc = st0 === '转载' ? '转载' : '原创';
    try {
      const clickEl = (el) => {
        if (!el) return;
        const r = el.getBoundingClientRect();
        const mo = { bubbles: true, cancelable: true, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
        try {
          el.dispatchEvent(new MouseEvent('mousedown', mo));
          el.dispatchEvent(new MouseEvent('mouseup', mo));
          el.click();
        } catch (e) { /* ignore */ }
      };
      const pick = async () => {
        const leaf = leafInDlg(wantSrc);
        if (!leaf) return false;
        clickEl(leaf.closest('.el-radio') || leaf.closest('label') || leaf);
        await sleep(500);
        return inDlg('input[type="radio"]').some((i) => i.checked);
      };
      let srcOk = await pick();
      if (!srcOk) srcOk = await pick();
      if (srcOk) console.log('[CRM插件] 开源中国 文章来源已选「' + wantSrc + '」');
      else console.warn('[CRM插件] 开源中国 文章来源未能确认选中「' + wantSrc + '」，请手动选择');
    } catch (e) { /* ignore */ }
    // 1b) 转载：「转载链接」输入框（选转载后异步出现）。
    //     先按字段文案「转载链接/原文链接/来源链接」定位其表单项内的 input，
    //     再按 placeholder（转载/原文/来源/链接）兜底；不能宽松匹配空 input，
    //     否则会误填到其它输入框（如把分类值填进转载链接）
    if (st0 === '转载') {
      const srcUrl = String(c.sourceUrl || '').trim();
      const labTexts = ['转载链接', '原文链接', '来源链接'];
      const findByLab = () => {
        for (const lt of labTexts) {
          let lab = null, best = Infinity;
          for (const el of dialog.querySelectorAll('div, span, label, li, p, a')) {
            const t = ((el.innerText || el.textContent || '') + '').replace(/\s+/g, '');
            if (!t || t.indexOf(lt) < 0 || t.length > lt.length + 3) continue;
            try {
              if (!elVisible(el)) continue;
              const r = el.getBoundingClientRect();
              if (r.width < 5 || r.height < 5) continue;
              const a = r.width * r.height;
              if (a < best) { best = a; lab = el; }
            } catch (e) { /* ignore */ }
          }
          if (!lab) continue;
          let p = lab.parentElement;
          for (let i = 0; i < 5 && p; i++) {
            const inp = Array.from(p.querySelectorAll('input')).find((x) =>
              elVisible(x) && x.type !== 'radio' && x.type !== 'checkbox');
            if (inp) return inp;
            p = p.parentElement;
          }
        }
        return null;
      };
      const st = Date.now();
      let urlInput = null;
      while (Date.now() - st < 6000 && !urlInput) {
        urlInput = findByLab()
          || inDlg('input').find((i) => elVisible(i) && i.type !== 'radio' && i.type !== 'checkbox'
            && /转载|原文|来源|链接/.test(i.placeholder || ''));
        if (!urlInput) await sleep(400);
      }
      if (urlInput && srcUrl) {
        syncInputValue(urlInput, srcUrl);
        console.log('[CRM插件] 开源中国 转载链接已填写');
      } else if (urlInput && !srcUrl) {
        console.warn('[CRM插件] 开源中国 转载未配置原文链接，若平台必填请手动填写');
      } else {
        console.warn('[CRM插件] 开源中国 未找到转载链接输入框，请手动填写');
      }
    }

    // 2) 博客分类：多选。已有同名 chip 点选；否则点「+ 新建分类」输入创建
    //    （输入框异步渲染需轮询等待；创建成功即选中，不再重复点击避免取消选中）
    const cats = String(c.category || '').split(/[,，、;；]/).map((s) => s.trim()).filter(Boolean);
    for (const cat of cats) {
      try {
        const chip = leafInDlg(cat);
        if (chip) {
          try { chip.click(); } catch (e) { /* ignore */ }
          await sleep(400);
          console.log('[CRM插件] 开源中国 已点选已有分类「' + cat + '」');
          continue;
        }
        const addBtn = leafInDlg('+新建分类') || leafInDlg('新建分类');
        if (!addBtn) { console.warn('[CRM插件] 开源中国 未找到分类「' + cat + '」的选项或新建入口'); continue; }
        // 记录点击前已有的输入框：新建分类的输入框应是「新出现的」或 placeholder 明确含「分类」，
        // 避免兜底命中「转载链接」等其它输入框
        const beforeInputs = new Set(inDlg('input'));
        try { addBtn.click(); } catch (e) { /* ignore */ }
        let inp = null;
        const stIn = Date.now();
        // 新建分类的输入框可能在 teleport 到 body 的浮层里（.el-popper），查找范围含弹窗外
        const scopeInputs = () => Array.from(new Set(inDlg('input')
          .concat(Array.from(document.querySelectorAll('.el-popper input, .el-overlay input')))))
          .filter((i) => elVisible(i) && !i.disabled && !i.readOnly && i.type !== 'radio' && i.type !== 'checkbox');
        while (Date.now() - stIn < 5000 && !inp) {
          inp = scopeInputs().find((i) => /分类/.test(i.placeholder || '') || (!beforeInputs.has(i) && !i.value));
          if (!inp) await sleep(300);
        }
        if (!inp) { console.warn('[CRM插件] 开源中国 新建分类输入框未出现，请手动填写分类'); continue; }
        syncInputValue(inp, cat);
        inp.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
        inp.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', keyCode: 13, bubbles: true }));
        await sleep(600);
        // 部分实现弹确认小按钮（确定/添加）：出现则点一次
        const okBtn = leafInDlg('确定') || leafInDlg('添加');
        if (okBtn) { try { okBtn.click(); } catch (e) { /* ignore */ } await sleep(400); }
        try { inp.blur(); } catch (e) { /* ignore */ }
        const chip2 = leafInDlg(cat);
        if (chip2) console.log('[CRM插件] 开源中国 已创建分类「' + cat + '」');
        else console.warn('[CRM插件] 开源中国 分类「' + cat + '」创建结果未知，请检查弹窗');
      } catch (e) { /* ignore */ }
    }
    if (cats.length) console.log('[CRM插件] 开源中国 博客分类处理完成（' + cats.join(',') + '）');

    // 3) 选择专区：可搜索下拉。点开 → 输入关键词 → 点浮层匹配项（浮层可能 teleport 到 body）
    const zone = String(c.zone || '').trim();
    if (!zone) {
      console.log('[CRM插件] 开源中国 未配置专区，跳过');
    } else {
      try {
        // element-plus 新版 select 的 placeholder 渲染在内部 span（.el-select__placeholder），
        // input 自身 placeholder 为空——先按 placeholder 找，找不到再从「选择专区」label 行定位：
        // 向上爬行时只认「容器文案含专区」的行，避免误抓博客分类等其他输入框
        let zInput = inDlg('input').find((i) => elVisible(i) && /专区/.test(i.placeholder || ''));
        if (!zInput) {
          const zl = leafInDlg('选择专区');
          let p = zl ? zl.parentElement : null;
          for (let i = 0; i < 5 && p && p !== dialog.parentElement && !zInput; i++) {
            if (p.querySelector && /专区/.test((p.innerText || '') + '')) {
              zInput = Array.from(p.querySelectorAll('input'))
                .find((x) => elVisible(x) && x.type !== 'radio' && x.type !== 'checkbox' && x.type !== 'hidden') || null;
            }
            p = p.parentElement;
          }
        }
        if (!zInput) { console.warn('[CRM插件] 开源中国 未找到专区下拉输入框'); }
        else {
          console.log('[CRM插件] 开源中国 已找到专区下拉，尝试展开选择');
          const want = zone.replace(/\s+/g, '');
          // 精确匹配（忽略空格）→ 宽松匹配（按字母/中文分词，任一 token 命中，
          // 兼容「Llama中文社区」实际显示为「Llama 中文社区」等名称差异）
          const tokens = want.split(/[^A-Za-z0-9\u4e00-\u9fa5]+/).filter((s) => s.length >= 2);
          // 选项搜索范围：弹窗内部 + teleport 到 body 的下拉浮层。
          // 不再全文档扫（之前会命中页面其他区域同文案元素，点错且不报错）
          const scopeEls = () => {
            const list = [dialog];
            for (const sel of ['.el-select-dropdown', '.el-popper', '[class*="dropdown" i]', '[class*="popover" i]', '[class*="popper" i]']) {
              try { list.push(...dialog.parentElement.querySelectorAll(sel)); } catch (e) { /* ignore */ }
              try { list.push(...document.querySelectorAll(sel)); } catch (e) { /* ignore */ }
            }
            return list;
          };
          const clickEl = (el) => {
            const r = el.getBoundingClientRect();
            const mo = { bubbles: true, cancelable: true, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
            try {
              el.dispatchEvent(new MouseEvent('mousedown', mo));
              el.dispatchEvent(new MouseEvent('mouseup', mo));
              el.click();
            } catch (e) { /* ignore */ }
          };
          const pickZone = (fuzzy) => {
            let hit = null, best = Infinity;
            const seen = new Set();
            for (const scope of scopeEls()) {
              if (!scope || !scope.querySelectorAll) continue;
              for (const el of scope.querySelectorAll('.el-select-dropdown__item, li, div, span')) {
                if (seen.has(el)) continue;
                seen.add(el);
                if (!elVisible(el)) continue;
                const t = ((el.textContent || '') + '').replace(/\s+/g, '');
                if (!t || t.length > 40) continue;
                const matched = t === want || (!!fuzzy && t.indexOf(want) < 0 && tokens.length > 0 && tokens.some((k) => t.indexOf(k) >= 0));
                if (!matched) continue;
                const r = el.getBoundingClientRect();
                const a = r.width * r.height;
                if (a < best) { best = a; hit = el; }
              }
            }
            return hit ? (hit.closest('.el-select-dropdown__item') || hit) : null;
          };
          const expand = () => {
            // 对输入框及其下拉容器（自定义 select 的点击区通常是父级）都派发完整鼠标事件；
            // 再补 ArrowDown 键盘事件（select 组件聚焦后展开下拉的标准方式）
            const targets = [zInput, zInput.closest('[class*="select" i]') || zInput.parentElement];
            for (const t of targets) {
              if (!t) continue;
              try { clickEl(t); } catch (e) { /* ignore */ }
            }
            try {
              zInput.focus();
              zInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', keyCode: 40, bubbles: true }));
              zInput.dispatchEvent(new KeyboardEvent('keyup', { key: 'ArrowDown', keyCode: 40, bubbles: true }));
            } catch (e) { /* ignore */ }
          };
          // element-plus 新版 select 非 filterable 时 input.value 为空（选中值显示在内部 span），
          // 校验看输入框值或弹窗文本是否出现专区名
          const checked = () => ((zInput.value || '') + '').replace(/\s+/g, '').indexOf(want) >= 0
            || ((dialog.innerText || '') + '').replace(/\s+/g, '').indexOf(want) >= 0;
          const tryPick = async (fuzzy) => {
            // 展开 → 轮询等选项出现（最多 4s），中途未出现补点一次
            let opt = null;
            const stZ = Date.now();
            let reexpanded = false;
            while (Date.now() - stZ < 4000 && !opt) {
              opt = pickZone(fuzzy);
              if (opt) break;
              if (!reexpanded && Date.now() - stZ > 1500) { reexpanded = true; expand(); }
              await sleep(400);
            }
            if (!opt && !fuzzy) {
              // 精确未命中：输入关键词过滤后再匹配（宽松 → 精确）
              syncInputValue(zInput, zone);
              await sleep(1200);
              opt = pickZone(true) || pickZone(false);
            }
            if (!opt) return false;
            clickEl(opt);
            await sleep(700);
            // 校验真实选中：输入框值/弹窗内出现已选专区（带删除标记），否则视为未生效
            if (checked()) return true;
            console.log('[CRM插件] 开源中国 专区点击后未确认选中，重试');
            return false;
          };
          let zOk = await tryPick(false);
          if (!zOk) zOk = await tryPick(false);
          if (zOk) {
            console.log('[CRM插件] 开源中国 专区已选「' + zone + '」');
          } else {
            // 诊断：打印下拉浮层当前实际选项，便于定位（名称不符/浮层未展开等）
            const opts = deepQueryAll(document, '.el-select-dropdown__item, li')
              .filter((el) => elVisible(el) && ((el.textContent || '') + '').trim()
                && ((el.textContent || '') + '').replace(/\s+/g, '').length < 30)
              .slice(0, 8)
              .map((el) => ((el.textContent || '') + '').replace(/\s+/g, ''))
              .filter(Boolean);
            console.warn('[CRM插件] 开源中国 专区未能确认选中「' + zone + '」'
              + (opts.length ? '，下拉当前选项：' + opts.join('、') : '（下拉浮层未展开或为空）')
              + '，请手动选择');
          }
        }
      } catch (e) { /* ignore */ }
    }

    // 4) 权限设置：是否公开（默认勾选，配置 false 时取消）；是否禁用评论（配置 true 时勾选）
    const toggleCheck = async (labelTxt, want) => {
      try {
        const label = leafInDlg(labelTxt);
        if (!label) { console.warn('[CRM插件] 开源中国 未找到「' + labelTxt + '」'); return; }
        let p = label.closest('label') || label.parentElement;
        let input = null;
        for (let i = 0; i < 4 && p && !input; i++) {
          input = p.querySelector ? p.querySelector('input[type="checkbox"]') : null;
          p = p.parentElement;
        }
        if (input && input.checked !== !!want) {
          try { input.click(); } catch (e) { try { label.click(); } catch (e2) { /* ignore */ } }
          await sleep(300);
          console.log('[CRM插件] 开源中国 「' + labelTxt + '」已' + (want ? '勾选' : '取消勾选'));
        }
      } catch (e) { /* ignore */ }
    };
    await toggleCheck('是否公开', c.isPublic !== false);
    await toggleCheck('是否禁用评论', c.disableComment === true);

    // 5) 点「确定并发布」（文案可能是 确定并发布/确定发布/确定）。
    //    按钮在弹窗 footer，与表单区平级、不在定位到的最小容器内；
    //    先扩大到弹窗根节点/遮罩层找，找不到再全页面按可见按钮精确匹配兜底
    const btnScope = dialog.closest('.el-dialog, .el-overlay, [class*="dialog" i], [class*="modal" i]')
      || dialog.parentElement || dialog;
    const pub = (function () {
      const tryScope = (scope) => {
        if (!scope) return null;
        const btns = scope.querySelectorAll('button');
        for (const b of btns) {
          const t = ((b.innerText || '') + '').replace(/\s+/g, '');
          if (/^(确定并发布|确定发布|发布)$/.test(t) && elVisible(b)) return b;
        }
        for (const b of btns) {
          const t = ((b.innerText || '') + '').replace(/\s+/g, '');
          if (/确定/.test(t) && elVisible(b)) return b;
        }
        return null;
      };
      return tryScope(btnScope) || tryScope(document.body);
    })();
    if (!pub) return { ok: false, msg: '开源中国发布弹窗内未找到「确定并发布」按钮' };
    // 发布点击后页面可能整页跳转，先把弹窗阶段的日志快照进 pendingResult（否则这些日志全部丢失，
    // 任务详情「适配日志」只剩填充阶段的几条，无法排查弹窗环节问题）
    try { if (typeof window.__crmSyncPendingLogs === 'function') await window.__crmSyncPendingLogs(); } catch (e) { /* ignore */ }
    try { pub.click(); } catch (e) { /* ignore */ }
    await sleep(900);
    // 校验报错（必填为空等）再补点一次
    const err = document.querySelector('.el-message--error, .el-form-item__error');
    if (err) {
      console.warn('[CRM插件] 开源中国 弹窗校验提示：' + ((err.innerText || '') + '').trim());
      try { pub.click(); } catch (e) { /* ignore */ }
      await sleep(900);
    }
    return { ok: true };
  }

  /**
   * 掘金发布弹窗处理：点「发布文章」后弹出发布设置（分类必填），
   * 自动打开分类下拉选第一项，再点弹窗内「发布文章/确定并发布」按钮；失败自动重试一次。
   */
  async function handleJuejinModal(job) {
    // 探针：流程若在填标签时"无声消失"，多半是页面被导航/卸载（执行上下文被销毁）
    try {
      const unloadLog = () => { try { console.log('[CRM插件] 页面卸载！弹窗流程被导航中断（后续日志不会再产生）'); } catch (e) { /* ignore */ } };
      window.addEventListener('pagehide', unloadLog, { once: true });
      window.addEventListener('beforeunload', unloadLog, { once: true });
    } catch (e) { /* ignore */ }
    await sleep(800);
    // 掘金发布设置：新版为右侧内嵌「发布文章」面板，旧版为弹窗表单。
    // 图片 CDP 上传耗时较长，面板可能晚于本函数出现——轮询等待（最多 ~25s）而不是立刻判失败
    let form = null;
    for (let w = 0; w < 60 && !form; w++) {
      form = document.querySelector('.add-article-form')
        || Array.from(document.querySelectorAll('div, aside')).find((d) => {
          const txt = d.innerText || '';
          return /发布文章/.test(txt) && /分类/.test(txt) && d.offsetWidth > 200 && d.offsetWidth < 700 && d.offsetHeight > 250;
        });
      if (!form) await sleep(300);
    }
    if (!form) return { ok: false, msg: '未检测到掘金发布设置面板' };
    const cfg = (job && job.platformConfig) || {};
    const cfgTags = String(cfg.tags || '').trim();
    // 配置了标签时按配置逐个搜索选择；否则沿用关键词补填到弹窗内的标签框
    if (!cfgTags && job && job.fillTag) { try { await fillTagsGeneric(job, form); } catch (e) { /* ignore */ } }

    // 1) 分类：优先点配置的分类选项（chip 短文案按钮），无配置/未命中再点第一个，返回所选文案
    const clickFirstCategory = (want) => {
      const labels = Array.from(form.querySelectorAll('*')).filter((el) =>
        el.children.length === 0 && ((el.textContent || '') + '').trim() === '分类');
      for (const label of labels) {
        let box = label.parentElement;
        for (let up = 0; up < 4 && box && box !== document.body; up++) {
          const chips = Array.from(box.querySelectorAll('*')).filter((el) => {
            if (el === label || label.contains(el) || el.contains(label)) return false;
            const t = ((el.innerText || '') + '').trim();
            if (!t || t.length > 8 || /\s/.test(t)) return false;
            if (!elVisible(el)) return false;
            const r = el.getBoundingClientRect();
            return r.width < 150 && r.height < 60;
          });
          if (chips.length) {
            chips.sort((a, b) => ((a.innerText || '') + '').length - ((b.innerText || '') + '').length);
            let chip = null;
            if (want) chip = chips.find((c) => ((c.innerText || '') + '').trim() === want);
            if (!chip) chip = chips[0];
            const t = ((chip.innerText || '') + '').trim();
            try { chip.click(); return t; } catch (e) { /* continue */ }
          }
          box = box.parentElement;
        }
      }
      return '';
    };

    // 2) 标签（必填）：输入关键词，从联想列表选匹配项（精确 → 前缀 → 包含）。
    //    掘金联想组件对合成 input/鼠标事件完全不响应（实测联想列表始终为空），
    //    故首选 CDP 可信键入（Input.insertText）+ 可信点击；合成事件仅作 CDP 不可用时的兜底
    // 同步抛错（如扩展上下文失效）也要兜住，否则 await 直接把整个弹窗流程打断
    const cdpSendM = (m) => {
      try {
        if (!(chrome.runtime && chrome.runtime.sendMessage)) return Promise.resolve(null);
        return chrome.runtime.sendMessage(m).catch(() => null);
      } catch (e) { return Promise.resolve(null); }
    };
    // 带超时：后台 SW 中途重启可能让 sendMessage 永不 resolve（实测整个流程因此卡死到超时）
    const cdpSendT = async (m, ms) => {
      let timer = null;
      try {
        return await Promise.race([
          cdpSendM(m),
          new Promise((r) => { timer = setTimeout(() => r(null), ms || 8000); })
        ]);
      } finally { clearTimeout(timer); }
    };
    const cdpClickAt = async (el) => {
      try {
        const r = el.getBoundingClientRect();
        const res = await cdpSendM({ type: 'crmCdpClick', x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) });
        return res && res.ok ? { ok: true } : { ok: false, message: (res && res.message) || '无响应' };
      } catch (e) { return { ok: false, message: (e && e.message) || String(e) }; }
    };
    const fillFirstTag = async (word) => {
      // 只选可见、可用、placeholder 含「标签」的输入框；掘金部分控件占位符写在父容器
      // 伪元素上（DOM 无 placeholder），再按「请搜索添加标签」容器向上找 input 兜底
      const tagInputs = Array.from(form.querySelectorAll('input')).filter((i) => /标签/.test(i.placeholder || ''));
      let tagInput = tagInputs.find((i) => elVisible(i) && !i.disabled && !i.readOnly)
        || tagInputs.find((i) => elVisible(i)) || tagInputs[0] || null;
      if (!tagInput) {
        const holder = Array.from(form.querySelectorAll('*')).find((el) =>
          el.children.length === 0 && /请搜索添加标签/.test((el.textContent || '') + '') && elVisible(el));
        let box = holder ? holder.parentElement : null;
        for (let up = 0; up < 4 && box && !tagInput; up++) {
          tagInput = Array.from(box.querySelectorAll('input')).find((i) => elVisible(i) && !i.disabled && !i.readOnly) || box.querySelector('input') || null;
          box = box.parentElement;
        }
      }
      // 重跑/重试时标签可能已选中（chip 已存在且输入框 placeholder 已变化）：先查已有 chip
      const normW = ((word || '') + '').replace(/\s+/g, '');
      if (normW) {
        const hasChip = Array.from(form.querySelectorAll('*')).find((el) =>
          el.children.length <= 2 && elVisible(el)
          && (((el.innerText || '') + '').replace(/\s+/g, '') === normW)
          && !/option|menu|dropdown|popper|suggest|popover/i.test(((el.parentElement && el.parentElement.className) || '') + ''));
        if (hasChip) { console.log('[CRM插件] 掘金标签「' + word + '」已是选中状态（chip 已存在），跳过键入'); return true; }
      }
      if (!tagInput || !word) { console.warn('[CRM插件] 掘金标签：未定位到可用标签输入框（placeholder 匹配 ' + tagInputs.length + ' 个）'); return false; }
      const norm = (s) => ((s || '') + '').replace(/\s+/g, '');
      // 已选标记：标签区（输入框所在容器）内出现与关键词同文的短元素（chip）。
      // 必须排除联想浮层里的同名候选项——否则浮层一弹出就"计数+1"，点没点中都误判为已选中
      const isDropItem = (el) => {
        let n = el;
        for (let up = 0; up < 5 && n && n !== document.body; up++) {
          const cls = ((n.className || '') + '');
          if (/option|menu|dropdown|popper|suggest|popover|panel/i.test(cls)) return true;
          n = n.parentElement;
        }
        return false;
      };
      const tagChips = () => {
        const host = tagInput.parentElement || form;
        return Array.from(host.querySelectorAll('*')).filter((el) => el !== tagInput && !tagInput.contains(el)
          && elVisible(el) && el.children.length <= 2 && norm(el.innerText) === norm(word) && !isDropItem(el)).length;
      };
      const beforeChips = tagChips();
      // 候选容器：联想浮层渲染在输入框正下方（可能挂在 body 级 portal），按几何位置过滤，
      // 避免把表单里的分类 chip 等短文案元素误当候选（否则污染匹配也污染候选日志）
      const nearInput = (el) => {
        try {
          if (tagInput.contains(el)) return false;
          const ir = tagInput.getBoundingClientRect();
          const r = el.getBoundingClientRect();
          // 标签框在面板底部，联想浮层可能向上/向下弹出：上下都放宽 360px
          const vertNear = r.bottom >= ir.top - 360 && r.top <= ir.bottom + 360;
          const horzNear = r.right > ir.left - 80 && r.left < ir.right + 80;
          return r.width > 30 && r.height > 20 && vertNear && horzNear;
        } catch (e) { return false; }
      };
      const sugCands = () => Array.from(document.querySelectorAll(
        'li, [class*="option"], [class*="item"], [class*="menu"] *, [class*="popover"] *, [class*="dropdown"] *, [class*="suggestion"] *, [class*="complete"] *, [class*="popper"] *, [class*="portal"] *'
      )).filter((el) => elVisible(el) && el.children.length <= 2 && norm(el.innerText) && nearInput(el));
      const findSug = () => {
        const cands = sugCands();
        return cands.find((el) => norm(el.innerText) === norm(word))
          || cands.find((el) => norm(el.innerText).indexOf(norm(word)) === 0)
          || cands.find((el) => norm(el.innerText).indexOf(norm(word)) >= 0 && norm(el.innerText).length <= norm(word).length + 4);
      };
      for (let t = 0; t < 3; t++) {
        // 第 0/1 轮：合成聚焦 + CDP 可信点击双保险 → CDP 真实键入 → 校验落框；
        // 第 2 轮：纯合成事件兜底
        if (t < 2) {
          // 整段异常隔离：任何键入通道异常都不能中断弹窗流程（否则封面和点发布都不会执行）
          try {
            try { tagInput.focus(); if (tagInput.select) tagInput.select(); } catch (eF) { /* ignore */ }
            await sleep(250);
            const ae = document.activeElement;
            console.log('[CRM插件] 掘金标签输入框：' + ((tagInput.placeholder || '') + '').slice(0, 20)
              + ' / 可见=' + elVisible(tagInput) + ' / 禁用=' + !!tagInput.disabled + ' / 只读=' + !!tagInput.readOnly
              + ' / 焦点在框上=' + (ae === tagInput ? '是' : '否(' + (((ae && ae.tagName) || '无') + '.' + ((ae && ae.className) || '')).slice(0, 40) + ')'));
            // 键入多级降级，每级都校验落框值；CDP 全部带超时（后台 SW 重启可能让消息永不返回，
            // 之前正是因此整个流程卡死、封面和发布都没执行）
            // ① 页面级真实编辑命令：焦点已在框上时直写并触发 input，等效真人输入
            let curV = '';
            console.log('[CRM插件] 掘金标签轮次' + (t + 1) + '：开始键入');
            try {
              document.execCommand('insertText', false, word);
              tagInput.dispatchEvent(new Event('input', { bubbles: true }));
            } catch (eE1) { console.warn('[CRM插件] 掘金标签：execCommand 抛错（' + ((eE1 && eE1.message) || String(eE1)) + '）'); }
            await sleep(400);
            curV = ((tagInput.value || '') + '').trim();
            console.log('[CRM插件] 掘金标签轮次' + (t + 1) + '：execCommand 后输入框值「' + (curV || '空') + '」');
            // ② CDP insertText
            if (norm(curV) !== norm(word)) {
              console.warn('[CRM插件] 掘金标签：execCommand 未落框（当前值「' + (curV || '空') + '」），改 CDP insertText');
              const tr = await cdpSendT({ type: 'crmCdpType', text: word, selectAll: true });
              if (!tr || !tr.ok) console.warn('[CRM插件] 掘金标签：CDP insertText 失败（' + ((tr && tr.message) || '超时/无响应') + '）');
              await sleep(300);
              curV = ((tagInput.value || '') + '').trim();
            }
            // ③ CDP 逐字符真实按键
            if (norm(curV) !== norm(word)) {
              console.warn('[CRM插件] 掘金标签：insertText 未落框（当前值「' + (curV || '空') + '」），改逐字符真实按键');
              await cdpSendT({ type: 'crmCdpType', text: word, selectAll: true, mode: 'keys' });
              await sleep(400);
              curV = ((tagInput.value || '') + '').trim();
            }
            // ④ beforeinput + native set
            if (norm(curV) !== norm(word)) {
              try {
                tagInput.focus();
                tagInput.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertText', data: word }));
                const setVal = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
                setVal.call(tagInput, word);
                tagInput.dispatchEvent(new Event('input', { bubbles: true }));
                console.warn('[CRM插件] 掘金标签：CDP 键入未落框（当前值「' + (curV || '空') + '」），已用 beforeinput+input 重输');
                await sleep(300);
                curV = ((tagInput.value || '') + '').trim();
              } catch (eB) { /* ignore */ }
            }
          } catch (eRound) {
            console.warn('[CRM插件] 掘金标签键入异常：' + ((eRound && eRound.message) || String(eRound)));
          }
        } else {
          try {
            tagInput.focus();
            const setVal = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
            setVal.call(tagInput, word);
            tagInput.dispatchEvent(new Event('input', { bubbles: true }));
          } catch (e) { /* continue */ }
        }
        const stT = Date.now();
        let sug = null;
        while (Date.now() - stT < 3000 && !sug) { sug = findSug(); if (!sug) await sleep(200); }
        console.log('[CRM插件] 掘金标签轮次' + (t + 1) + '：等待联想结束，命中=' + (sug ? '是' : '否') + '，候选数=' + sugCands().length);
        if (!sug) {
          const seen = sugCands().slice(0, 10).map((el) => norm(el.innerText));
          console.warn('[CRM插件] 掘金标签联想（第' + (t + 1) + '次）未出现匹配项「' + word + '」（输入框值「' + (((tagInput.value || '') + '').trim() || '空') + '」）'
            + (seen.length ? '，当前候选(' + seen.length + ')：' + seen.join('、') : '，输入框附近无联想浮层（联想接口未触发）'));
          continue;
        }
        // 优先可信点击联想项（带超时）；失灵再补合成鼠标序列
        const sk = await (async () => {
          try {
            const r = sug.getBoundingClientRect();
            const res = await cdpSendT({ type: 'crmCdpClick', x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) });
            return !!(res && res.ok);
          } catch (e) { return false; }
        })();
        if (!sk) {
          try {
            sug.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
            sug.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
            sug.click();
          } catch (e) { /* ignore */ }
        }
        await sleep(800);
        // 选中判据：① 标签区出现 chip；② 输入框被清空（掘金选中后会清空筛选词）。
        // 只靠 ① 会被浮层候选项误判，只靠 ② 会被"清空但没选上"误判，两者同时满足才算选中
        let afterChips = tagChips();
        let cleared = !((tagInput.value || '') + '').trim();
        console.log('[CRM插件] 掘金标签轮次' + (t + 1) + '：点击后 chip ' + beforeChips + '→' + afterChips + '，输入框清空=' + (cleared ? '是' : '否'));
        // 点击未生效时补一次可信「回车」：联想组件普遍支持回车确认高亮项
        if (!(afterChips > beforeChips && cleared)) {
          try { tagInput.focus(); } catch (eF) { /* ignore */ }
          await cdpSendT({ type: 'crmCdpType', text: '\r', mode: 'keys' });
          await sleep(800);
          afterChips = tagChips();
          cleared = !((tagInput.value || '') + '').trim();
          console.log('[CRM插件] 掘金标签轮次' + (t + 1) + '：回车后 chip ' + beforeChips + '→' + afterChips + '，输入框清空=' + (cleared ? '是' : '否'));
        }
        if (afterChips > beforeChips && cleared) { console.log('[CRM插件] 掘金标签「' + word + '」已选中'); return true; }
        console.warn('[CRM插件] 掘金标签「' + word + '」点击联想后未见选中标记，重试');
      }
      return false;
    };
    // 2b) 搜索式下拉（专栏/话题）：按 placeholder 定位输入框 → 输入 → 点完全匹配联想项
    const fillSearchSelect = async (phRe, word) => {
      const inp = Array.from(form.querySelectorAll('input')).find((i) => elVisible(i) && !i.disabled && phRe.test(i.placeholder || ''));
      if (!inp || !word) return false;
      try {
        const setVal = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
        setVal.call(inp, word);
        inp.dispatchEvent(new Event('input', { bubbles: true }));
      } catch (e) { return false; }
      await sleep(900);
      const sug = Array.from(document.querySelectorAll('li, [class*="option"], [class*="item"], [class*="menu"] *')).find((el) => {
        const t = ((el.innerText || '') + '').trim();
        return t === word && elVisible(el) && el.children.length <= 2;
      });
      if (sug) { try { sug.click(); } catch (e) { /* ignore */ } await sleep(400); return true; }
      return false;
    };
    const tagList = cfgTags ? cfgTags.split(/[,，、;；\s]+/).map((s) => s.trim()).filter(Boolean).slice(0, 3) : [];
    const cfgSummary = String(cfg.summary || '').trim();

    for (let i = 0; i < 2; i++) {
      const categoryText = clickFirstCategory(String(cfg.category || '').trim());
      // 标签：优先按配置逐个搜索选择（掘金只允许选标签库已有标签）
      if (tagList.length) {
        for (const tg of tagList) {
          let okTg = false;
          // 单个标签失败不能中断整个弹窗流程（后面还有封面和点发布）
          try { okTg = await fillFirstTag(tg); } catch (eFT) {
            console.warn('[CRM插件] 掘金标签填充异常：' + ((eFT && eFT.message) || String(eFT)));
          }
          if (!okTg) console.warn('[CRM插件] 掘金标签「' + tg + '」联想未命中（须为掘金标签库已有标签），请手动补充');
        }
      } else {
        await fillFirstTag(categoryText);
      }
      // 3) 摘要（必填）：优先配置，未配置截取正文前 100 字
      const summaryTa = Array.from(form.querySelectorAll('textarea')).find((t) => /摘要/.test(t.placeholder || ''));
      if (summaryTa) {
        const txt = cfgSummary || (job && job.contentText ? String(job.contentText).replace(/\s+/g, ' ').trim().slice(0, 100) : '');
        if (txt) nativeSet(summaryTa, txt);
      }
      // 3b) 专栏/话题（选填，搜索式）
      const colV = String(cfg.column || '').trim();
      if (colV) {
        const okCol = await fillSearchSelect(/专栏/, colV);
        if (!okCol) console.warn('[CRM插件] 掘金专栏「' + colV + '」联想未命中，请手动选择');
      }
      const topV = String(cfg.topic || '').trim();
      if (topV) {
        const okTop = await fillSearchSelect(/话题/, topV);
        if (!okTop) console.warn('[CRM插件] 掘金话题「' + topV + '」联想未命中，请手动选择');
      }
      // 3c) 封面：默认取正文第一张图（重试轮次里封面已回显则跳过，避免重复上传）
      try {
        const imgs = (job && job._crmImages) || [];
        const uploadTxt = Array.from(form.querySelectorAll('*')).find((el) =>
          el.children.length === 0 && /上传封面/.test((el.textContent || '') + '') && elVisible(el));
        // 封面容器：从「上传封面」文案向上爬到同时含「封面」标签的容器
        let coverBox = null;
        if (uploadTxt) {
          let box = uploadTxt.parentElement;
          for (let up = 0; up < 5 && box && box !== document.body; up++) {
            if (/封面/.test((box.innerText || '') + '')) { coverBox = box; break; }
            box = box.parentElement;
          }
        }
        const hasCover = coverBox && coverBox.querySelector('img');
        if (imgs.length && !coverBox) {
          console.warn('[CRM插件] 掘金封面：未找到「上传封面」入口（uploadTxt=' + (uploadTxt ? '有' : '无') + '），请手动选择封面');
        }
        if (imgs.length && coverBox && !hasCover) {
          // 优先 CDP 可信点击（点「上传封面」→ 拦截文件选择框 → 设文件），
          // 掘金上传组件对合成 putFileToInput 不响应；失败再合成兜底
          let coverDone = false;
          const tgt = uploadTxt || coverBox.querySelector('input[type=file]');
          if (tgt) {
            try {
              const r = tgt.getBoundingClientRect();
              const resC = await cdpSendT({ type: 'crmCdpClickAndSet', x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2), dataUrl: imgs[0], fileKey: 'juejin-cover-' + Date.now() }, 25000);
              coverDone = !!(resC && resC.ok);
              console.log('[CRM插件] 掘金封面 CDP 上传' + (coverDone ? '已提交' : '失败（' + ((resC && (resC.message || JSON.stringify(resC).slice(0, 120))) || '无响应') + '）'));
            } catch (eCDP) { /* 走兜底 */ }
          }
          if (!coverDone) {
            // 封面容器内的 file input，找不到再退回表单内 accept 为 image 的
            const fin = coverBox.querySelector('input[type=file]')
              || Array.from(form.querySelectorAll('input[type=file]')).find((i) => /image/i.test(i.accept || ''));
            const f = fin ? dataUrlToFile(imgs[0], 'cover.jpg') : null;
            if (fin && f) {
              putFileToInput(fin, f);
              coverDone = true;
            } else {
              console.warn('[CRM插件] 掘金封面：未定位到封面上传 input，请手动选择封面');
            }
          }
          if (coverDone) {
            // 等封面回显（最多 ~6s），避免未上传完就点发布
            for (let w = 0; w < 20; w++) { await sleep(300); if (coverBox.querySelector('img')) break; }
            console.log('[CRM插件] 掘金封面已用正文第一张图' + (coverBox.querySelector('img') ? '上传成功' : '已提交上传（未见回显，请留意弹窗）'));
          }
        }
      } catch (e) { /* 封面失败不阻塞发布 */ }
      // 4) 点「发布」：面板打开时精确匹配「确定并发布」优先（顶部「发布」在面板已开时点了无效）。
      //    重跑时 form 引用可能已失联（DOM 重渲染），故确认按钮从 document 现查。
      //    用 CDP 可信点击（掘金对合成 click 偶尔不响应），失灵再合成 click 兜底
      const confirmBtn = findBtnInScope(document.body, ['确定并发布']);
      const publishBtn = confirmBtn || findBtnInScope(form, ['发布']) || findBtnInScope(document.body, ['发布']);
      if (!publishBtn) return { ok: false, msg: '未找到掘金的发布按钮' };
      console.log('[CRM插件] 掘金点击「' + (((publishBtn.innerText || '') + '').trim().slice(0, 12) || '?') + '」（' + (confirmBtn ? '面板确认按钮' : '顶部发布') + '）');
      const ckPub = await cdpClickAt(publishBtn);
      if (!ckPub.ok) {
        console.warn('[CRM插件] 掘金：CDP 点击发布失败（' + ckPub.message + '），改合成 click');
        try { publishBtn.click(); } catch (e) { /* ignore */ }
      }
      await sleep(1200);
      // 已跳离编辑器则提交成功；仍在编辑器且有校验报错则重试一次
      if (!/juejin\.cn\/(editor|draft)/i.test(location.href)) break;
      const errEl = document.querySelector('.byte-toast, [class*="message"], [class*="toast"]');
      const errText = ((errEl && errEl.innerText) || '').trim();
      // 账号级限制（禁言等）：立即中止，不再重试点击（反复重试会加重平台风控）
      if (/禁言|封禁|违规/.test(errText)) {
        console.warn('[CRM插件] 掘金拒绝发布：' + errText + '，停止重试');
        try { await cdpSendM({ type: 'crmCdpDetach' }); } catch (e) { /* ignore */ }
        return { ok: false, muted: true, msg: '掘金拒绝发布：' + errText + '（账号受限，请等待解禁或申诉后手动发布）' };
      }
      if (!errText) break;
    }
    // 解除 CDP 调试会话（顺带清掉文件选择框拦截，避免影响用户后续手动操作）
    try { await cdpSendM({ type: 'crmCdpDetach' }); } catch (e) { /* ignore */ }
    return { ok: true };
  }

  function waitForSelectorSafely(selectors, timeout) {
    // :has-text 等非标准选择器会抛错，先过滤出可解析的
    const safe = (selectors || []).filter((s) => {
      try {
        document.querySelector(s);
        return true;
      } catch (e) {
        return false;
      }
    });
    if (!safe.length) return Promise.resolve(null);
    return waitForSelector(safe, timeout);
  }

  // ==================== 剪贴板 ====================

  CRM.copyText = function (text) {
    if (!text) return Promise.resolve(false);
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text).then(() => true).catch(() => fallbackCopy(text));
    }
    return Promise.resolve(fallbackCopy(text));
  };

  function fallbackCopy(text) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try {
      ok = document.execCommand('copy');
    } catch (e) {
      ok = false;
    }
    document.body.removeChild(ta);
    return ok;
  }
})();
