@echo off
chcp 65001 >nul

REM ---- 检测部署路径是否含括号: cmd 会把括号当语法符号, 导致脚本错乱甚至一闪而过 ----
setlocal EnableDelayedExpansion
set "SELF_DIR=%~dp0"
set "PAREN="
echo !SELF_DIR!|findstr /C:"(" >nul && set "PAREN=1"
echo !SELF_DIR!|findstr /C:")" >nul && set "PAREN=1"
if not defined PAREN goto PAREN_OK
echo.
echo [错误] 部署目录的路径中包含括号, 请把文件夹重命名去掉括号后重试。
echo   当前路径: !SELF_DIR!
echo   例如:  crm-system-2.6.5-windows ^(4^)   改为   crm-system-2.6.5-windows
echo.
pause
exit /b 1
:PAREN_OK
endlocal

cd /d "%~dp0"

set "PID_FILE=crm.pid"

if exist "%PID_FILE%" (
    set /p PID=<"%PID_FILE%"
    taskkill /F /PID %PID% >nul 2>&1
    echo [停止] 已停止进程 %PID%
    del "%PID_FILE%" >nul 2>&1
) else (
    echo [停止] 未找到 PID 文件, 按命令行查找进程...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*crm-system.jar*' -and $_.Name -eq 'java.exe' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force; Write-Host ('[停止] 已停止 PID ' + $_.ProcessId) }"
)
