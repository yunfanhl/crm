// 注入到各平台创作页：自动填充 CRM 待发布内容，并提供悬浮栏回传发布结果。
(function () {
  const STORE = chrome.storage.local;
  // 版本自证打点：改版后必须「刷新扩展 + 重新加载页面」才会重新注入，
  // 日志首行确认实际运行的版本（多数“改了没效果”都是页面没重载、仍跑旧脚本）
  try {
    console.log('[CRM插件] 内容脚本已注入 v'
      + (chrome.runtime && chrome.runtime.getManifest ? chrome.runtime.getManifest().version : '?')
      + ' @ ' + location.hostname + new Date().toLocaleTimeString());
  } catch (e) { /* ignore */ }

  function getStore(key) {
    return new Promise((resolve) => STORE.get([key], (r) => resolve(r[key])));
  }

  /** 读取当前待发布任务（background.writeActiveJob 整键写入） */
  async function getActiveJob() {
    return await getStore('activeJob');
  }

  /** 平台可配多个创作页 host（如 CSDN 既有 Markdown 编辑器也有富文本编辑器） */
  function hostList(code) {
    const h = (window.CRM_PLUGIN && window.CRM_PLUGIN.hosts[code]) || '';
    return Array.isArray(h) ? h : [h];
  }

  function pageMatches(job) {
    const hosts = hostList(job.platformCode).filter(Boolean);
    if (!hosts.length) return true; // 未知平台不限制
    for (const host of hosts) {
      if (location.hostname.endsWith(host.replace(/^https?:\/\//, ''))) return true;
    }
    return !!(job.publishUrl && location.href.startsWith(job.publishUrl.split('?')[0]));
  }

  async function waitForJob() {
    for (let i = 0; i < 20; i++) {
      const job = await getActiveJob();
      if (job) return job;
      await new Promise((r) => setTimeout(r, 300));
    }
    return null;
  }

  /** 等待页面资源就绪（创作页多为 SPA，编辑器渲染晚于注入时机） */
  async function waitPageReady() {
    for (let i = 0; i < 40; i++) {
      if (document.readyState === 'complete') {
        // SPA 编辑器常在 load 之后才挂载，额外静置一段时间再填充，避免写入被重渲染清空
        await new Promise((r) => setTimeout(r, 1200));
        return;
      }
      await new Promise((r) => setTimeout(r, 250));
    }
  }

  /**
   * 将正文中不安全的 http:// 图片经后台代取并转为 data URL（base64）内联。
   * https 平台页会按混合内容策略拦截 http://localhost 图片导致裂图；
   * 转成 data URL 后不再受该限制。转换失败保留原 src。
   */
  /**
   * 全量内联正文图片并压缩后随 HTML 粘贴：
   * - http(s) 外链（含防盗链图床）一律经后台代取转 data URL，避免平台服务器拉取失败；
   * - data URL 大图经 canvas 压缩（最长边 1600、JPEG 0.9），知乎等平台对超大粘贴内容会报「图片导入失败」。
   */
  async function inlineInsecureImages(job) {
    const html = job && job.contentHtml;
    if (!html || html.indexOf('<img') < 0) return;
    let doc;
    try { doc = new DOMParser().parseFromString(html, 'text/html'); } catch (e) { return; }
    const imgs = Array.from(doc.querySelectorAll('img'));
    let changed = false;
    for (const img of imgs) {
      const src = (img.getAttribute('src') || '').trim();
      let dataUrl = null;
      if (/^data:image\//i.test(src)) {
        dataUrl = src;
      } else if (/^https?:\/\//i.test(src) || /^\/\//.test(src)) {
        dataUrl = await new Promise((resolve) => {
          try {
            chrome.runtime.sendMessage({ type: 'fetchImage', url: src }, (r) => resolve(r && r.ok ? r.dataUrl : null));
          } catch (e) { resolve(null); }
        });
      } else {
        continue;
      }
      if (!dataUrl) continue;
      const compressed = await compressImageDataUrl(dataUrl);
      if (compressed && compressed !== src) { img.setAttribute('src', compressed); changed = true; }
    }
    if (changed) job.contentHtml = doc.body.innerHTML;
  }

  /** data URL 图片规范化：SVG 一律转 PNG（知乎等平台图床不收 SVG）；位图超 1600 缩放并转 JPEG；小图/GIF 原样返回 */
  function compressImageDataUrl(dataUrl) {
    if (!/^data:image\//i.test(dataUrl)) return Promise.resolve(dataUrl);
    if (/^data:image\/gif/i.test(dataUrl)) return Promise.resolve(dataUrl);
    const isSvg = /^data:image\/svg/i.test(dataUrl);
    if (!isSvg && dataUrl.length < 200 * 1024 * 4 / 3) return Promise.resolve(dataUrl);
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        try {
          const MAX = 1600;
          let w = img.naturalWidth || img.width || 0;
          let h = img.naturalHeight || img.height || 0;
          if (!w || !h) return resolve(dataUrl);
          if (w > MAX || h > MAX) {
            const r = Math.min(MAX / w, MAX / h);
            w = Math.round(w * r); h = Math.round(h * r);
          }
          const canvas = document.createElement('canvas');
          canvas.width = w; canvas.height = h;
          const ctx = canvas.getContext('2d');
          if (!isSvg) {
            // 位图转 JPEG 时垫白底（JPEG 无透明通道）
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, w, h);
          }
          ctx.drawImage(img, 0, 0, w, h);
          resolve(canvas.toDataURL(isSvg ? 'image/png' : 'image/jpeg', 0.9));
        } catch (e) { resolve(dataUrl); }
      };
      img.onerror = () => resolve(dataUrl);
      img.src = dataUrl;
    });
  }

  /** 执行一次填充：先执行平台准备步骤（如切换内容类型标签），再走平台特化填充 */
  async function doFill(job) {
    try { await inlineInsecureImages(job); } catch (e) { /* 图片内联失败不阻塞填充 */ }
    try {
      const prepare = CRM_PLUGIN.prepare && CRM_PLUGIN.prepare[job.platformCode];
      if (typeof prepare === 'function') await prepare(job);
    } catch (e) { if (e && e.name === 'JobCancelledError') throw e; /* 准备失败继续尝试填充 */ }
    const filler =
      (CRM_PLUGIN.fillers && CRM_PLUGIN.fillers[job.platformCode]) || CRM_PLUGIN.genericFill;
    try {
      return (await filler(job)) || {};
    } catch (e) {
      if (e && e.name === 'JobCancelledError') throw e;
      return {};
    } finally {
      try {
        const after = CRM_PLUGIN.afterFill && CRM_PLUGIN.afterFill[job.platformCode];
        if (typeof after === 'function') await after(job);
      } catch (e) {
        if (e && e.name === 'JobCancelledError') throw e;
        /* 填充后处理失败不阻塞上报 */
      }
    }
  }

  /** 经后台代发查后端：该同步任务是否已被用户取消（status=5）。失败保守返回 false */
  function checkCancelHere(recordId) {
    if (!recordId) return Promise.resolve(false);
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type: 'checkCancel', recordId }, (r) => {
          if (chrome.runtime.lastError) { console.warn('[CRM插件] 取消检测失败：' + chrome.runtime.lastError.message); return resolve(false); }
          resolve(!!(r && r.cancelled));
        });
      } catch (e) { resolve(false); }
    });
  }

  /** 任务已被用户取消时的统一收尾：toast 提示、关平台标签、不回传成功（后端 status=5 会忽略任何回传） */
  async function handleJobCancelled(job, where) {
    console.warn('[CRM插件] 任务已取消（' + (where || '') + '），停止发布并关掉创作页');
    try { STORE.remove('activeJob'); } catch (e) { /* ignore */ }
    try { STORE.remove('pendingResult'); } catch (e) { /* ignore */ }
    try { toast('任务已取消，已停止发布', false); } catch (e) { /* ignore */ }
    try { notifyAutoDone(job, false, '任务已取消', true); } catch (e) { /* ignore */ }
  }

  function toast(msg, ok) {
    const el = document.createElement('div');
    el.textContent = msg;
    el.style.cssText =
      'position:fixed;top:16px;left:50%;transform:translateX(-50%);z-index:2147483647;' +
      'background:' + (ok ? '#67c23a' : '#f56c6c') + ';color:#fff;padding:8px 16px;border-radius:6px;' +
      'font-size:14px;box-shadow:0 2px 8px rgba(0,0,0,.2)';
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 2500);
  }

  async function report(job, status, url, msg) {
    // 知乎补设置（封面/声明/专栏）会停在编辑页 /p/数字/edit，回传给后台的应是文章浏览地址
    if (url && /^https?:\/\/zhuanlan\.zhihu\.com\/p\/\d+\/edit(\?.*)?$/i.test(url)) {
      url = url.replace(/\/edit(\?.*)?$/i, '$1');
    }
    // 附加插件运行日志（页面跳转后 Console 日志丢失，随结果回传到后台记录，便于排障）
    let fullMsg = msg || (status === 2 ? '插件发布成功' : '插件发布失败');
    try {
      const dbg = window.CRM_PLUGIN && window.CRM_PLUGIN.debugLog;
      if (dbg && dbg.length) {
        fullMsg += ' ｜适配日志: ' + dbg.slice(-40).join(' / ');
        // 超长时保留【最新】一段日志：弹窗/标签等最后环节的日志才最有排障价值，
        // 截头会把它们整个丢掉（此前正是因此看不到标签失败原因）
        if (fullMsg.length > 3500) fullMsg = '…(前略)' + fullMsg.slice(-3500);
      }
    } catch (e) { /* ignore */ }
    // 通过后台代发（平台页面上下文跨域 fetch 会被 CORS 拦截，后台 Service Worker 不受限）；
    // 发布成功后页面可能随即跳转打断消息发送，失败时自动重试一次
    const sendOnce = () => new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type: 'report', payload: {
          recordId: job.recordId,
          status: status,
          resultUrl: url || '',
          resultMsg: fullMsg
        } }, (r) => resolve(r || {}));
      } catch (e) { resolve({ ok: false, message: e.message }); }
    });
    let ok = false;
    let errMsg = '';
    for (let attempt = 0; attempt < 2 && !ok; attempt++) {
      if (attempt > 0) await new Promise((r) => setTimeout(r, 1000));
      try {
        const resp = await sendOnce();
        ok = !!resp.ok;
        if (!ok) errMsg = resp.message || '';
      } catch (e) {
        errMsg = e.message;
      }
    }
    if (ok) {
      toast(status === 2 ? '已回传：发布成功' : '已回传：发布失败', true);
    } else {
      toast('回传失败：' + errMsg, false);
    }
    // 清理 activeJob
    STORE.remove('activeJob');
    STORE.remove('pendingResult');
  }

  function escapeHtml(s) {
    return (s || '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  }

  /** 填充状态文案（可局部刷新）；pending=true 表示正在自动填充 */
  function statusInner(job, fillRes, pending) {
    const verTag = '<div style="color:#c0c4cc;font-size:11px">插件版本 v'
      + (chrome.runtime && chrome.runtime.getManifest ? chrome.runtime.getManifest().version : '?') + '</div>';
    if (pending) {
      return '<div style="color:#909399">正在检测编辑器并自动填充…（可直接使用下方复制按钮）</div>' + verTag;
    }
    const title = (job.title || '').slice(0, 24);
    return (
      '<div>标题：' + escapeHtml(title) +
      (fillRes && fillRes.titleFilled
        ? ' <span style="color:#67c23a">✓已填</span>'
        : ' <span style="color:#e6a23c">未填（请复制）</span>') + '</div>' +
      '<div>正文：' +
      (fillRes && fillRes.contentFilled
        ? '<span style="color:#67c23a">✓已填</span>'
        : '<span style="color:#e6a23c">请手动粘贴</span>') + '</div>' +
      (job.coverUrl ? '<div style="color:#909399;margin-top:4px;">封面：需手动上传（可复制链接）</div>' : '')
    );
  }

  function buildBar(job, fillRes, pending) {
    const bar = document.createElement('div');
    bar.id = 'crm-plugin-bar';
    bar.style.cssText =
      'position:fixed;right:16px;bottom:16px;z-index:2147483647;width:280px;background:#fff;' +
      'border:1px solid #409eff;border-radius:10px;box-shadow:0 4px 16px rgba(64,158,255,.25);' +
      'font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"PingFang SC",sans-serif;font-size:13px;color:#303133;';
    bar.innerHTML =
      '<div style="padding:10px 12px;border-bottom:1px solid #ebeef5;font-weight:600;color:#409eff;">' +
      'CRM 同步 · ' + escapeHtml(job.platformName || job.platformCode) + '</div>' +
      '<div id="crm-plugin-status" style="padding:10px 12px;line-height:1.6;">' + statusInner(job, fillRes, pending) + '</div>' +
      '<div style="padding:0 12px 12px;display:flex;flex-wrap:wrap;gap:6px;">' +
      '<button data-act="copyTitle" style="flex:1 0 45%">复制标题</button>' +
      '<button data-act="copyContent" style="flex:1 0 45%">复制正文</button>' +
      (job.coverUrl ? '<button data-act="copyCover" style="flex:1 0 45%">复制封面</button>' : '') +
      '<button data-act="refill" style="flex:1 0 45%">重新填充</button>' +
      '<button data-act="republish" style="flex:1 0 45%;background:#409eff;color:#fff;border:none">重新发布</button>' +
      (job.publishUrl ? '<button data-act="openUrl" style="flex:1 0 45%">打开创作页</button>' : '') +
      '<button data-act="success" style="flex:1 0 45%;background:#67c23a;color:#fff;border:none">标记成功</button>' +
      '<button data-act="fail" style="flex:1 0 45%;background:#f56c6c;color:#fff;border:none">标记失败</button>' +
      '</div>';
    document.body.appendChild(bar);

    // 实时提示：platforms.js 的自动发布流程（如「请在弹出的文件窗口选中图片」）可直接
    // 调 window.__crmPanelHint(html) 把关键操作提示打到面板顶部，无需开 Console
    window.__crmPanelHint = (html) => {
      const b = document.getElementById('crm-plugin-bar');
      if (!b) return;
      const box = b.querySelector('#crm-plugin-status');
      if (!box) return;
      let el = box.querySelector('#crm-plugin-live-hint');
      if (!html) { if (el) el.remove(); return; }
      if (!el) {
        el = document.createElement('div');
        el.id = 'crm-plugin-live-hint';
        el.style.cssText = 'color:#e6a23c;margin-top:4px;font-weight:600;line-height:1.5';
        box.prepend(el);
      }
      el.innerHTML = html;
    };

    bar.querySelectorAll('button').forEach((btn) => {
      btn.style.cssText +=
        'padding:6px 4px;border-radius:6px;border:1px solid #dcdfe6;cursor:pointer;font-size:12px;';
      btn.addEventListener('click', async () => {
        const act = btn.getAttribute('data-act');
        if (act === 'copyTitle') {
          CRM_PLUGIN.copyText(job.title || '');
          toast('已复制标题', true);
        } else if (act === 'copyContent') {
          CRM_PLUGIN.copyText(job.contentText || '');
          toast('已复制正文', true);
        } else if (act === 'copyCover') {
          CRM_PLUGIN.copyText(job.coverUrl || '');
          toast('已复制封面链接', true);
        } else if (act === 'openUrl') {
          // 被重定向到首页（未登录/登录态失效）时，登录后可一键回到创作页重试
          location.href = job.publishUrl;
        } else if (act === 'refill') {
          // 编辑器后于注入渲染时，手动重试一次自动填充
          const origin = btn.textContent;
          btn.textContent = '填充中…';
          btn.disabled = true;
          let res = null;
          try { res = await doFill(job); } catch (e) {
            if (e && e.name === 'JobCancelledError') {
              await handleJobCancelled(job, '重新填充');
              bar.remove();
              return;
            }
            throw e;
          }
          const box = bar.querySelector('#crm-plugin-status');
          if (box) box.innerHTML = statusInner(job, res);
          btn.textContent = origin;
          btn.disabled = false;
          if (res.titleFilled || res.contentFilled) toast('已重新尝试填充', true);
          else toast('未匹配到编辑器，请手动复制粘贴', false);
        } else if (act === 'republish') {
          // 编辑器加载慢导致首次自动发布失败时，一键重试发布
          btn.textContent = '发布中…';
          btn.disabled = true;
          let submit = null;
          try { submit = await CRM_PLUGIN.autoSubmit(job); }
          catch (e) {
            if (e && e.name === 'JobCancelledError') {
              await handleJobCancelled(job, '重新发布');
              bar.remove();
              return;
            }
            submit = { ok: false, msg: e.message };
          }
          btn.textContent = '重新发布';
          btn.disabled = false;
          if (submit && submit.ok) {
            await report(job, 2, submit.url || '', '插件自动发布成功（手动重试）');
            notifyAutoDone(job, true, submit.msg || '自动发布成功', true);
            bar.remove();
          } else {
            toast('自动发布未成功：' + ((submit && submit.msg) || '未知原因'), false);
          }
        } else if (act === 'success') {
          const url = prompt('发布成功！请粘贴该平台文章链接：', '');
          if (url === null) return;
          await report(job, 2, url.trim(), '插件发布成功');
          bar.remove();
        } else if (act === 'fail') {
          const msg = prompt('发布失败原因（可选）：', '') || '插件发布失败';
          await report(job, 3, '', msg);
          bar.remove();
        }
      });
    });

    return bar;
  }

  /** 通知后台自动发布队列：本任务已结束（成功/失败均通知，避免队列卡住）；closeTab 为 true 时由后台关闭本标签页 */
  function notifyAutoDone(job, ok, msg, closeTab) {
    try {
      chrome.runtime.sendMessage({ type: 'autoDone', recordId: job && job.recordId, ok: !!ok, msg: msg || '', closeTab: !!closeTab });
    } catch (e) { /* ignore */ }
  }

  (async function main() {
    // 跳转后补传：发布成功瞬间页面整页跳转会销毁旧内容脚本（旧脚本里的回传代码没机会执行）。
    // 新页面注入时检查上个脚本留下的「进行中发布任务」，当前 URL 已命中该平台已发布特征则补传成功
    try {
      const pending = await getStore('pendingResult');
      if (pending && pending.recordId) {
        const fresh = Date.now() - (pending.ts || 0) < 10 * 60 * 1000;
        const published = fresh
          && location.href !== pending.before
          && window.CRM_PLUGIN
          && typeof CRM_PLUGIN.checkPublished === 'function'
          && CRM_PLUGIN.checkPublished(pending.platformCode, location.href);
        if (published) {
          // 知乎特例：创作页点「发布」直接发布，封面/声明只在编辑页可设——先补设置再回传成功
          try {
            if (pending.platformCode === 'zhihu' && window.CRM_PLUGIN
              && typeof CRM_PLUGIN.fillZhihuPostPublish === 'function') {
              const zp = await CRM_PLUGIN.fillZhihuPostPublish(pending.zhihu);
              // 返回 'navigating'：正在从阅读页转跳编辑页，本页不回传不关 tab，
              // 保留 pendingResult 由编辑页的内容脚本接手补设置
              if (zp === 'navigating') return;
            }
          } catch (e) { /* ignore */ }
          let doneMsg = '发布成功（跳转后自动补传）';
          try {
            if (pending.logs && pending.logs.length) {
              doneMsg += ' ｜适配日志: ' + pending.logs.join(' / ');
              if (doneMsg.length > 3500) doneMsg = doneMsg.slice(0, 3500);
            }
          } catch (e) { /* ignore */ }
          // 小红书：/publish/success 是「发布成功」提示页，不是笔记页——
          // 同源抓笔记管理页解析最新一篇的真实链接（尽力而为），失败则明确标注
          let finalUrl = location.href;
          if (pending.platformCode === 'xiaohongshu' && /\/publish\/success/.test(location.href)
            && window.CRM_PLUGIN && typeof CRM_PLUGIN.resolveXhsNoteUrl === 'function') {
            try {
              const real = await CRM_PLUGIN.resolveXhsNoteUrl();
              if (real) { finalUrl = real; doneMsg += ' ｜笔记链接已解析'; }
              else doneMsg += ' ｜返回的是发布成功提示页，未能自动解析笔记直链';
            } catch (e) { /* ignore */ }
          }
          await report({ recordId: pending.recordId }, 2, finalUrl, doneMsg);
          notifyAutoDone({ recordId: pending.recordId }, true, '发布成功', true);
          STORE.remove('pendingResult');
          return;
        }
        if (!fresh) STORE.remove('pendingResult');
      }
    } catch (e) { /* 补传失败不影响正常流程 */ }

    const job = await waitForJob();
    if (!job) return;
    if (!pageMatches(job)) return;
    // 入口即查取消：任务可能在创作页还没加载完、甚至打开标签页之前就被用户取消了，
    // 这时再跑填充/发布就是往已取消的记录里写内容——直接停手并关掉这个创作页。
    if (await checkCancelHere(job.recordId)) {
      await handleJobCancelled(job, '创作页入口');
      return;
    }

    // 孤儿脚本检测：扩展刷新后未重载的页面里，旧内容脚本与扩展的连接已断
    // （console 表现为成串 chrome-extension://invalid + message channel closed），
    // 此时跑的全是旧代码且无法回传。检测到即自动刷新本页——刷新后新脚本接管，
    // 任务仍在 storage 里会自动继续；sessionStorage 防刷新死循环。
    try {
      if (!(chrome.runtime && chrome.runtime.id)) throw new Error('no runtime');
    } catch (e) {
      console.warn('[CRM插件] 检测到本页运行的是旧版脚本（扩展已刷新但页面未重载），自动刷新本页以接管任务');
      try {
        const k = '__crmOrphanReload';
        if (!sessionStorage.getItem(k)) { sessionStorage.setItem(k, '1'); location.reload(); return; }
        sessionStorage.removeItem(k);
      } catch (e2) { /* ignore */ }
      console.error('[CRM插件] 刷新后仍是旧脚本环境（可能扩展已卸载），停止执行，请手动重载扩展');
      return;
    }

    // 自动模式：静默执行（不弹悬浮栏）→ 填充 → 自动点击发布 → 自动回传结果；失败才弹出手动悬浮栏
    if (job.autoPublish) {
      // 包裹整个自动发布流程：用户在「多平台同步」页点「取消」时（后端 status=5），
      // platforms.js 的 checkCancelOrThrow 会抛 JobCancelledError，这里统一收尾——
      // toast 提示、关创作页标签、不回传结果（后端 status=5 本身就会忽略任何回传）
      try {
      // 记录进行中的发布任务：发布成功瞬间若发生整页跳转，由新页面的内容脚本补传结果；
      // 知乎需携带封面/声明配置（创作页点发布直接发布，这些设置只能在发布后的编辑页补做）
      try {
        const pc = job.platformConfig || {};
        STORE.set({ pendingResult: {
          recordId: job.recordId, platformCode: job.platformCode, before: location.href, ts: Date.now(),
          zhihu: { coverUrl: job.coverUrl || '', declaration: pc.declaration || '', column: pc.column || '' }
        } });
      } catch (e) { /* ignore */ }
      await waitPageReady();
      // 供平台适配层在点击发布前同步日志快照到 pendingResult：
      // 发布成功瞬间页面可能整页跳转，跳转后补传时把这份日志随结果回传（否则日志全丢）
      window.__crmSyncPendingLogs = async () => {
        try {
          const p = await getStore('pendingResult');
          if (p && p.recordId === job.recordId) {
            p.logs = ((window.CRM_PLUGIN && window.CRM_PLUGIN.debugLog) || []).slice(-40);
            STORE.set({ pendingResult: p });
          }
        } catch (e) { /* ignore */ }
      };
      const fillRes = await doFill(job);

      let submit = null;
      try {
        submit = await CRM_PLUGIN.autoSubmit(job);
      } catch (e) {
        submit = { ok: false, msg: e.message };
      }
      // 首次失败重试一次：图片上传等异步流程可能尚未就绪。
      // 账号受限（muted，如掘金禁言）不重试：重跑只会反复触发风控
      if (!(submit && submit.ok) && !(submit && submit.muted)) {
        await new Promise((r) => setTimeout(r, 1500));
        try {
          submit = await CRM_PLUGIN.autoSubmit(job);
        } catch (e) {
          submit = { ok: false, msg: e.message };
        }
      }

      // 51CTO 手动接管模式（v1.9.6）：自动上传通道全失败后进入常驻监听（最长 10 分钟）。
      // 用户手动点工具栏图片按钮 → 本地上传 → 选中「下载」目录 crm-tmp-imgN.jpg（可搜索 crm），
      // 图片全部转存为正式 http 地址后（platforms.js 接管器会清理 data: 残图与占位符），
      // 这里重走 autoSubmit：守卫通过 → 自动点发布 → 正常回传结果（不能用面板「重试」，
      // 重试会重填正文抹掉手动上传的图）
      if (!(submit && submit.ok) && job.platformCode === 'cto51' && (job._crmImages || []).length) {
        const needImgs = job._crmImages.length;
        const rawHint = window.__crmPanelHint || ((h) => { if (h) console.log('[CRM插件] ' + String(h).replace(/<[^>]+>/g, '')); });
        const httpImgs = () => Array.from((document.querySelector('[contenteditable="true"]') || document.body).querySelectorAll('img'))
          .filter((im) => { const x = (im.getAttribute('src') || '').toLowerCase(); return x.indexOf('http') === 0 && x.indexOf('blob:') < 0; }).length;
        let tkDone = false;
        let tkIv = null;
        // 保底出口（v1.9.9）：任何时候都能「忽略图片直接发布」，把文章先发出去，
        // 避免图片通道失败把整个发布卡死（图片通道的价值低于「能发布」本身）
        const skipPublishBtn = '<button id="crm-skip-img" style="margin-left:6px;background:#409eff;color:#fff;'
          + 'border:none;border-radius:3px;padding:2px 6px;cursor:pointer;font-weight:600">忽略图片直接发布</button>';
        const doSkip = async () => {
          if (tkDone) return;
          tkDone = true;
          if (tkIv) clearInterval(tkIv);
          window.__crmSkipImgGuard = true;
          setHint('正在「忽略图片」发布…');
          try {
            const ed = document.querySelector('[contenteditable="true"]') || document.body;
            Array.from(ed.querySelectorAll('img')).forEach((im) => {
              const x = (im.getAttribute('src') || '').toLowerCase();
              if (x.indexOf('http') !== 0 || x.indexOf('blob:') === 0) { try { im.remove(); } catch (e) { /* ignore */ } }
            });
            if (((ed.innerText || '') + '').indexOf('[[CRM_IMG_') >= 0) {
              try {
                if (window.CRM_PLUGIN && window.CRM_PLUGIN.deleteResidualTokens) {
                  await window.CRM_PLUGIN.deleteResidualTokens('[[CRM_IMG_', /\[\[CRM_IMG_\d*\]*\]*/, 40);
                }
              } catch (e) { /* ignore */ }
            }
          } catch (e) { /* ignore */ }
          await new Promise((r) => setTimeout(r, 1200));
          let sub2 = null;
          try { sub2 = await CRM_PLUGIN.autoSubmit(job); } catch (e) { sub2 = { ok: false, msg: e.message }; }
          if (sub2 && sub2.ok) {
            await report(job, 2, sub2.url || '', '插件自动发布成功（忽略图片直接发布）');
            notifyAutoDone(job, true, sub2.msg || '自动发布成功', true);
          } else {
            console.warn('[CRM插件] 51CTO 忽略图片后发布未成功：' + ((sub2 && sub2.msg) || '未知原因'));
            setHint('⚠ 发布未成功：' + ((sub2 && sub2.msg) || '') + '，可手动点「发布文章」后点「标记成功」');
          }
        };
        const setHint = (html) => {
          try {
            rawHint(html ? html + skipPublishBtn : '');
            const b = document.getElementById('crm-skip-img');
            if (b) b.onclick = doSkip;
          } catch (e) { /* ignore */ }
        };
        console.warn('[CRM插件] 51CTO 手动接管模式已启动：请手动点工具栏图片按钮 → 本地上传 → 选中「下载」目录 '
          + (needImgs > 1 ? 'crm-tmp-img1.jpg、crm-tmp-img2.jpg' : 'crm-tmp-img1.jpg') + '（可搜索 crm），上传后插件自动完成发布');
        setHint('⚠ 自动上传失败，已进入<b>手动接管</b>：请点工具栏图片按钮 → 本地上传 → 选中下载目录 <b>crm-tmp-img1.jpg</b>（可搜索 crm），全部上传后插件自动发布');
        const tkSt = Date.now();
        tkIv = setInterval(async () => {
          try {
            if (tkDone) { clearInterval(tkIv); return; }
            if (Date.now() - tkSt > 600000) { clearInterval(tkIv); setHint('⚠ 手动接管超时（10 分钟），可点「忽略图片直接发布」先把文章发出去'); return; }
            if (httpImgs() < needImgs) return;
            tkDone = true;
            clearInterval(tkIv);
            console.log('[CRM插件] 51CTO 手动上传图片已全部转存（正式 img ' + httpImgs() + '/' + needImgs + '），重走自动发布');
            // 等 platforms.js 接管器完成残图/占位符清理
            await new Promise((r) => setTimeout(r, 2500));
            let sub2 = null;
            try { sub2 = await CRM_PLUGIN.autoSubmit(job); } catch (e) { sub2 = { ok: false, msg: e.message }; }
            if (sub2 && sub2.ok) {
              await report(job, 2, sub2.url || '', '插件自动发布成功（图片手动上传后自动接管发布）');
              notifyAutoDone(job, true, sub2.msg || '自动发布成功', true);
            } else {
              console.warn('[CRM插件] 51CTO 手动接管后发布未成功：' + ((sub2 && sub2.msg) || '未知原因'));
              setHint('⚠ 图片已转存但自动发布未成功：' + ((sub2 && sub2.msg) || '') + '，可手动点「发布文章」后点「标记成功」');
            }
          } catch (e) { /* ignore */ }
        }, 2000);
      }

      if (submit && submit.ok) {
        // 静默回传成功结果，页面不弹任何悬浮栏；标签页由后台在收到 autoDone 后关闭
        // （页面脚本无法 window.close() 非自己打开的标签，会触发浏览器报错）
        await report(job, 2, submit.url || '', '插件自动发布成功');
        notifyAutoDone(job, true, submit.msg || '自动发布成功', true);
        return;
      }

      // 仅当被踢到不同域名（未登录/登录态失效被重定向）时才提示重新登录；
      // 同站路由跳转（如知乎 /write 自动跳到 /p/xxx/edit 草稿页）属正常行为
      let redirected = false;
      try {
        redirected = !!job.publishUrl && location.host !== new URL(job.publishUrl).host;
      } catch (e) { redirected = false; }
      const failMsg = redirected
        ? '创作页被重定向到首页：该平台未登录或登录态已失效，请先登录，再点「打开创作页」'
        : ((submit && submit.msg) || '未知原因');
      const bar = buildBar(job, fillRes, false);
      const statusBox = bar.querySelector('#crm-plugin-status');
      if (statusBox) {
        statusBox.innerHTML = statusInner(job, fillRes, false) +
          '<div style="color:#f56c6c;margin-top:4px">自动发布未完成：' +
          failMsg + (redirected ? '' : '，请手动发布后点「标记成功」') + '</div>' +
          '<div style="color:#c0c4cc;font-size:11px">插件版本 v'
          + (chrome.runtime && chrome.runtime.getManifest ? chrome.runtime.getManifest().version : '?') + '</div>';
      }
      // 失败也要回传，否则后端记录会一直停在「待插件」；用户手动发布成功后仍可点「标记成功」改判
      await report(job, 3, '', '自动发布未完成：' + failMsg);
      notifyAutoDone(job, false, failMsg);
      return;
      } catch (e) {
        if (e && e.name === 'JobCancelledError') {
          await handleJobCancelled(job, e.message || '发布流程');
          return;
        }
        throw e;
      }
    }

    // 手动模式：先展示悬浮栏（填充中），确保用户随时可手动复制；随后再自动填充并刷新状态
    const bar = buildBar(job, {}, true);
    const statusBox = bar.querySelector('#crm-plugin-status');
    await waitPageReady();
    const fillRes = await doFill(job);
    if (statusBox) statusBox.innerHTML = statusInner(job, fillRes, false);
  })();
})();
