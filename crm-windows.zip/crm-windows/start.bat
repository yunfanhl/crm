@echo off
chcp 65001 >nul
title 云帆智能客户管理系统

REM ---- 检测部署路径是否含括号: cmd 会把括号当语法符号, 导致脚本错乱甚至一闪而过 ----
REM 说明: 这里用延迟展开(!VAR!)读取路径, 避免路径中的括号在解析期被当成语法符号。
setlocal EnableDelayedExpansion
set "SELF_DIR=%~dp0"
set "PAREN="
echo !SELF_DIR!|findstr /C:"(" >nul && set "PAREN=1"
echo !SELF_DIR!|findstr /C:")" >nul && set "PAREN=1"
if not defined PAREN goto PAREN_OK
echo.
echo ============================================================
echo   [错误] 部署目录的路径中包含括号
echo.
echo    当前路径: !SELF_DIR!
echo.
echo   Windows 命令解释器会把路径里的括号当作语法符号, 导致脚本无法正常运行,
echo   可能一闪而过。请把整个部署文件夹【重命名】, 去掉名称中的括号,
echo   然后重新双击 start.bat, 即可正常启动。
echo.
echo    例如:   crm-system-2.6.5-windows ^(4^)
echo     改为:   crm-system-2.6.5-windows
echo ============================================================
echo.
pause
exit /b 1
:PAREN_OK
endlocal

cd /d "%~dp0"

set "ENV_FILE=.env"
set "PID_FILE=crm.pid"
set "LOG_DIR=logs"

REM ---- 递归查找 crm-system.jar (兼容任意嵌套解压, 绝不向上 cd 避免路径特殊字符问题) ----
set "JAR_PATH="
for /r "." %%F in (crm-system*.jar) do (
    if not defined JAR_PATH set "JAR_PATH=%%F"
)
if not defined JAR_PATH (
    echo [错误] 未找到 crm-system*.jar
    echo        请确认部署包解压完整, start.bat 与 crm-system.jar 应在一起
    echo        当前目录: %CD%
    pause
    exit /b 1
)
echo [启动] 找到 jar: %JAR_PATH%

REM ---- 定位 Java: 优先 PATH, 其次 JAVA_HOME, 再兜底常见安装目录 ----
set "JAVA_EXE="
for /f "delims=" %%J in ('where java 2^>nul') do (
    if not defined JAVA_EXE set "JAVA_EXE=%%J"
)
if not defined JAVA_EXE if defined JAVA_HOME if exist "%JAVA_HOME%\bin\java.exe" set "JAVA_EXE=%JAVA_HOME%\bin\java.exe"
if not defined JAVA_EXE (
    for %%P in ("C:\Program Files\Zulu" "C:\Program Files\Eclipse Adoptium" "C:\Program Files\Java" "C:\Program Files\Microsoft") do (
        if not defined JAVA_EXE (
            for /f "delims=" %%J in ('dir /b /s "%%~P\java.exe" 2^>nul') do (
                if not defined JAVA_EXE set "JAVA_EXE=%%J"
            )
        )
    )
)
if not defined JAVA_EXE (
    echo [错误] 未找到 Java, 请先安装 JDK 17+ 并配置 PATH 或 JAVA_HOME 环境变量
    echo        若已安装仍报此错, 通常是环境变量未刷新: 请重启电脑, 或先打开 cmd 执行 setx JAVA_HOME 后重试
    pause
    exit /b 1
)
echo [启动] 使用 Java: %JAVA_EXE%

REM ---- configure: 强制为 .env 现有主密钥重新生成配套密文(修复密钥不匹配) ----
if /i "%~1"=="configure" (
    echo [配置] 正在校正授权主密钥与配套密文...
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0configure.ps1" -Ensure
    if errorlevel 1 (
        echo [错误] 生成配置失败
        pause
        exit /b 1
    )
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0configure.ps1" -Reencrypt
    if errorlevel 1 (
        echo [错误] 重新生成配套密文失败
        pause
        exit /b 1
    )
    echo [配置] 完成, 请执行 restart.bat 重启服务
    pause
    exit /b 0
)

REM ---- 查看日志: start.bat logs (实时跟随 logs/app.log) ----
if /i "%~1"=="logs" (
    if not exist "%LOG_DIR%\app.log" (
        echo [提示] 暂无日志文件: %LOG_DIR%\app.log
        pause
        exit /b 0
    )
    echo [日志] 正在实时跟随 %LOG_DIR%\app.log, 按 Ctrl+C 退出
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-Content -Path '%LOG_DIR%\app.log' -Wait -Encoding UTF8"
    exit /b 0
)

REM ---- 每次启动校正 .env: 保证授权主密钥与配套密文配套(缺失则自动生成/补齐) ----
REM 场景: 旧版本升级后 .env 已存在但配套密文为空, 或主密钥被手工修改,
REM       会导致后端启动失败(授权主密钥与配套密文不匹配 / Tag mismatch)。
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0configure.ps1" -Ensure
if errorlevel 1 (
    echo [警告] .env 自动校正失败, 请查看上方提示; 仍将尝试启动...
)

REM ---- 加载 .env 到环境变量 ----
for /f "usebackq eol=# tokens=1,* delims==" %%a in ("%~dp0%ENV_FILE%") do (
    if not "%%a"=="" set "%%a=%%b"
)

REM ---- 已运行则退出 ----
if exist "%PID_FILE%" (
    set /p OLDPID=<"%PID_FILE%"
    tasklist /FI "PID eq %OLDPID%" 2>nul | findstr /i "%OLDPID%" >nul && (
        echo [提示] 服务已在运行, PID %OLDPID%
        pause
        exit /b 0
    )
    REM 进程已不在, 清理失效的 pid 文件, 继续启动
    del "%PID_FILE%" >nul 2>&1
)

if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"

if "%JVM_XMS%"=="" set "JVM_XMS=512m"
if "%JVM_XMX%"=="" set "JVM_XMX=1024m"

REM 关键: Windows 下 JVM 默认编码为 GBK, 必须显式指定 UTF-8, 否则中文配置/日志/接口响应会乱码
set "JVM_OPTS=-Dfile.encoding=UTF-8 -Dsun.jnu.encoding=UTF-8 -Duser.language=zh -Duser.country=CN -Xms%JVM_XMS% -Xmx%JVM_XMX%"
set "LOG_PATH=%LOG_DIR%\app.log"
echo [启动] 日志将写入: %CD%\%LOG_PATH%
start "crm-system" /b "%JAVA_EXE%" %JVM_OPTS% -jar "%JAR_PATH%" > "%LOG_PATH%" 2>&1

REM 需要实时看日志时, 另开一个 cmd 执行: start.bat logs

REM ---- 记录 PID ----
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*crm-system.jar*' -and $_.Name -eq 'java.exe' } | Select-Object -First 1; if ($p) { $p.ProcessId | Set-Content -Path '%~dp0crm.pid' }"

REM ---- 等待服务就绪 ----
echo [启动] 服务启动中, 首次约需 30-60 秒, 请稍候...
set /a TRIES=0
:WAIT
set /a TRIES+=1
if %TRIES% gtr 90 (
    echo [警告] 等待超时, 请查看日志: %LOG_DIR%\app.log
    pause
    exit /b 1
)
powershell -NoProfile -Command "try { $r = Invoke-WebRequest -Uri 'http://127.0.0.1:8080/auth/captcha' -UseBasicParsing -TimeoutSec 2; if ($r.StatusCode -eq 200) { 'OK' } } catch { }" 2>nul | findstr "OK" >nul && goto READY
ping -n 2 127.0.0.1 >nul
<nul set /p=.
goto WAIT

:READY
echo [启动] 服务已就绪: http://127.0.0.1:8080
echo [启动] 日志: %CD%\%LOG_DIR%\app.log
echo.
echo ------ 实时日志(先回放启动过程, 之后持续跟随, 按 Ctrl+C 退出) ------
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-Content -Path '%LOG_DIR%\app.log' -Wait -Encoding UTF8"
pause
