﻿# ==========================================================
#  云帆智能客户管理系统 - 生成 / 校正 .env(授权主密钥与配套密文)
#  用法:
#    configure.ps1             # 首次运行: 生成 .env(随机主密钥 + 配套密文)
#    configure.ps1 -Ensure     # 每次启动调用: 保证 .env 存在且主密钥与配套密文配套
#    configure.ps1 -Reencrypt  # 为 .env 现有主密钥强制重新生成配套密文(修复不匹配)
# ----------------------------------------------------------
#  背景: 代码内置密文由"演示主密钥"加密; 一旦 .env 使用自定义主密钥却没有配套密文,
#        后端启动即失败: 授权主密钥与配套密文不匹配 / AEADBadTagException: Tag mismatch!
#  本脚本保证"主密钥 <-> 密文"始终配套:
#    - 自定义主密钥: 调用 jar 内 MasterKeySetupTool 重新加密, 生成配套密文
#    - 演示主密钥  : 清空 .env 中的密文, 直接使用代码内置密文
#    - 生成失败时  : 回退为演示主密钥, 保证服务一定能启动
#  明文(License 签名密钥等)始终不变, 重新加密不影响已签发的 License。
#  注意: 本文件需保存为 UTF-8 BOM + CRLF(PowerShell 5.1 正确显示中文所需)
# ==========================================================
param(
    [switch]$Ensure,
    [switch]$Reencrypt
)
$ErrorActionPreference = "Stop"

# 脚本与 jar 同级(部署包根目录), .env / .env.example 均在此
$root = $PSScriptRoot
$envFile = Join-Path $root ".env"
$template = Join-Path $root ".env.example"
# 代码内置密文由该演示主密钥加密, 二者配套
$demoKey = "Crm2026@MasterKey!X8zQwL9p"

# ---- .env 读写辅助: 兼容 CRLF / LF 行尾, 兼容手工编辑后的行尾空格 ----
# 说明: 早期版本用 (?m)^KEY=(\S+)$ 取值, .NET 的 $ 不匹配 \r\n 里的 \r,
#       而 .env 由 CRLF 模板生成, 导致 start.bat configure 必然报"未设置主密钥"。
function Get-EnvValue {
    param([string]$Path, [string]$Name)
    if (-not (Test-Path $Path)) { return "" }
    $raw = [System.IO.File]::ReadAllText($Path)
    $m = [regex]::Match($raw, "(?m)^" + [regex]::Escape($Name) + "=([^\r\n]*)")
    if ($m.Success) { return $m.Groups[1].Value.Trim() }
    return ""
}

function Set-EnvValue {
    param([string]$Path, [string]$Name, [string]$Value)
    $content = [System.IO.File]::ReadAllText($Path)
    $pattern = "(?m)^(" + [regex]::Escape($Name) + "=)[^\r\n]*(\r?)$"
    if ([regex]::IsMatch($content, $pattern)) {
        $content = [regex]::Replace($content, $pattern, {
            param($m) $m.Groups[1].Value + $Value + $m.Groups[2].Value
        })
    } else {
        if ($content.Length -gt 0 -and -not $content.EndsWith("`n")) { $content += "`r`n" }
        $content += "$Name=$Value`r`n"
    }
    [System.IO.File]::WriteAllText($Path, $content, (New-Object System.Text.UTF8Encoding($false)))
}

# 主密钥指纹: 记录"当前密文是为哪个主密钥生成的", 主密钥被修改时可自动重新生成密文
function Get-KeyFingerprint {
    param([string]$Key)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $hash = $sha.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($Key))
    } finally {
        $sha.Dispose()
    }
    return ([System.BitConverter]::ToString($hash).Replace("-", "").ToLower()).Substring(0, 16)
}

# 生成指定长度的随机 hex 字符串(逐位取随机, 不受候选字符集大小限制)
function New-RandomHex {
    param([int]$Length)
    $chars = '0123456789abcdef'.ToCharArray()
    $sb = New-Object System.Text.StringBuilder
    for ($i = 0; $i -lt $Length; $i++) {
        [void]$sb.Append($chars[(Get-Random -Maximum $chars.Length)])
    }
    return $sb.ToString()
}

# ---- 为指定主密钥生成配套敏感配置密文并写入 .env ----
# 代码内置密文由演示主密钥加密, 随机主密钥与之不匹配会导致启动失败;
# 本函数解压 jar 内 MasterKeySetupTool, 解出内置明文后以当前主密钥重新加密。
function Set-LicenseCiphers {
    param([string]$Path, [string]$masterKey)

    $jar = Get-ChildItem $root -Filter "crm-system*.jar" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $jar) {
        Write-Host "[警告] 未找到 crm-system*.jar, 跳过配套密文生成" -ForegroundColor Yellow
        return $false
    }

    $java = Get-Command java -ErrorAction SilentlyContinue
    if (-not $java -and $env:JAVA_HOME) {
        $jh = Join-Path $env:JAVA_HOME "bin\java.exe"
        if (Test-Path $jh) { $java = Get-Item $jh }
    }
    if (-not $java) {
        Write-Host "[警告] 未找到 Java, 跳过配套密文生成" -ForegroundColor Yellow
        return $false
    }
    if ($java -is [System.Management.Automation.ApplicationInfo]) { $javaPath = $java.Source } else { $javaPath = $java.FullName }

    # 解压 jar 内 BOOT-INF/classes 到临时目录
    $tmpDir = Join-Path $env:TEMP ("crm-masterkey-" + [guid]::NewGuid().ToString("N"))
    New-Item -ItemType Directory -Force -Path $tmpDir | Out-Null
    try {
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $zip = [System.IO.Compression.ZipFile]::OpenRead($jar.FullName)
        try {
            foreach ($entry in $zip.Entries) {
                if ($entry.FullName -like "BOOT-INF/classes/*" -and -not [string]::IsNullOrEmpty($entry.Name)) {
                    $dest = Join-Path $tmpDir $entry.FullName
                    $dir = Split-Path $dest -Parent
                    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
                    [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $dest, $true)
                }
            }
        } finally {
            $zip.Dispose()
        }
    } catch {
        Write-Host "[警告] 解压 jar 类目录失败, 跳过配套密文生成" -ForegroundColor Yellow
        Remove-Item -Recurse -Force $tmpDir -ErrorAction SilentlyContinue
        return $false
    }

    $classesPath = Join-Path $tmpDir "BOOT-INF\classes"
    $out = & $javaPath -cp $classesPath com.crm.utils.MasterKeySetupTool $masterKey 2>$null
    $exitCode = $LASTEXITCODE
    Remove-Item -Recurse -Force $tmpDir -ErrorAction SilentlyContinue

    if ($exitCode -ne 0 -or -not $out) {
        Write-Host "[警告] 生成配套密文失败, 跳过" -ForegroundColor Yellow
        return $false
    }
    # 兼容 $out 为单行字符串或字符串数组(多行输出)
    $lines = ($out | Out-String) -split "`r?`n" | Where-Object { $_ }
    $secret = ($lines | Where-Object { $_ -match '^SECRET=' } | Select-Object -First 1) -replace '^SECRET=' , ''
    $file = ($lines | Where-Object { $_ -match '^FILE=' } | Select-Object -First 1) -replace '^FILE=' , ''
    if (-not $secret -or -not $file) {
        Write-Host "[警告] 生成配套密文输出异常, 跳过" -ForegroundColor Yellow
        return $false
    }

    Set-EnvValue $Path "CRM_LICENSE_SECRET_CIPHER" $secret
    Set-EnvValue $Path "CRM_LICENSE_FILE_CIPHER" $file
    Set-EnvValue $Path "CRM_LICENSE_CIPHER_KEY_FP" (Get-KeyFingerprint $masterKey)
    Write-Host "[配置] 已为主密钥生成配套敏感配置密文" -ForegroundColor Green
    return $true
}

# ---- 回退: 主密钥改为内置演示主密钥, 并清空配套密文(回退到代码内置密文) ----
# 与 Linux start.sh 的回退策略一致: 当配套密文生成失败(如 MasterKeySetupTool 不可用)时使用。
function Use-DemoKeyFallback {
    param([string]$Path)
    Set-EnvValue $Path "CRM_LICENSE_MASTER_KEY" $demoKey
    Set-EnvValue $Path "CRM_LICENSE_SECRET_CIPHER" ""
    Set-EnvValue $Path "CRM_LICENSE_FILE_CIPHER" ""
    Set-EnvValue $Path "CRM_LICENSE_CIPHER_KEY_FP" (Get-KeyFingerprint $demoKey)
    Write-Host "[配置] 已回退主密钥为内置演示主密钥 (Crm2026@MasterKey!X8zQwL9p), 使用代码内置密文" -ForegroundColor Green
}

# ---- 首次运行: 由模板生成 .env(随机主密钥 + 随机 JWT 密钥 + 配套密文) ----
function New-EnvFile {
    if (-not (Test-Path $template)) {
        Write-Host "[错误] 缺少 .env.example 模板, 无法自动生成配置" -ForegroundColor Red
        exit 1
    }
    # 随机授权主密钥: Crm + 32位hex; 随机 JWT 密钥: 64位hex(512 bit, 满足 jjwt 0.12 要求)
    $masterKey = "Crm" + (New-RandomHex 32)
    $jwtSecret = New-RandomHex 64

    $content = [System.IO.File]::ReadAllText($template)
    $content = $content.Replace("please-change-me-to-a-random-master-key", $masterKey)
    $content = $content.Replace("please-change-me-to-a-long-random-jwt-secret", $jwtSecret)
    [System.IO.File]::WriteAllText($envFile, $content, (New-Object System.Text.UTF8Encoding($false)))

    # 生成与主密钥匹配的配套密文, 避免随机主密钥与内置密文不匹配导致启动失败
    if (-not (Set-LicenseCiphers $envFile $masterKey)) {
        Write-Host "[警告] 配套密文自动生成失败, 回退使用内置演示主密钥以保证可启动" -ForegroundColor Yellow
        Write-Host "[警告] 如需自定义主密钥, 请手动确保 CRM_LICENSE_SECRET_CIPHER/FILE_CIPHER 与主密钥匹配" -ForegroundColor Yellow
        Use-DemoKeyFallback $envFile
    }
    Write-Host "[配置] 已自动生成 $envFile" -ForegroundColor Green
    Write-Host "[配置] 授权主密钥: $masterKey (请妥善保管, 生成 License 时需使用)" -ForegroundColor Yellow
    Write-Host "[配置] 如需自定义数据库/Redis, 请编辑 .env 后重启" -ForegroundColor Yellow
}

# ---- 校验 JWT_SECRET 长度(jjwt 0.12 HS256 要求 >= 32 字符 / 256 bit) ----
function Test-JwtSecret {
    param([string]$Path)
    $existing = Get-EnvValue $Path "JWT_SECRET"
    if ([string]::IsNullOrEmpty($existing) -or $existing.Length -lt 32) {
        Write-Host "[警告] .env 中 JWT_SECRET 长度不足 ($($existing.Length) 字符), jjwt 0.12 要求 >= 32 字符(256 bit), 登录将报 WeakKeyException" -ForegroundColor Red
        Write-Host "       请编辑 $Path 将 JWT_SECRET 改为 32+ 字符的随机字符串, 或删除 .env 后重新运行本脚本" -ForegroundColor Yellow
    }
}

# ---- 保证 .env 存在, 且主密钥与配套密文配套(每次启动调用) ----
function Ensure-LicenseConfig {
    if (-not (Test-Path $envFile)) {
        New-EnvFile
        return
    }

    $key = Get-EnvValue $envFile "CRM_LICENSE_MASTER_KEY"
    if (-not $key) {
        $key = "Crm" + (New-RandomHex 32)
        Set-EnvValue $envFile "CRM_LICENSE_MASTER_KEY" $key
        Write-Host "[配置] .env 缺少授权主密钥, 已生成随机主密钥" -ForegroundColor Yellow
    }

    $secret = Get-EnvValue $envFile "CRM_LICENSE_SECRET_CIPHER"
    $file = Get-EnvValue $envFile "CRM_LICENSE_FILE_CIPHER"
    $fp = Get-EnvValue $envFile "CRM_LICENSE_CIPHER_KEY_FP"

    # 演示主密钥: 必须与代码内置密文配套, 因此清空 .env 中的自定义密文
    if ($key -eq $demoKey) {
        if ($secret -or $file -or ($fp -and $fp -ne (Get-KeyFingerprint $demoKey))) {
            Set-EnvValue $envFile "CRM_LICENSE_SECRET_CIPHER" ""
            Set-EnvValue $envFile "CRM_LICENSE_FILE_CIPHER" ""
            Set-EnvValue $envFile "CRM_LICENSE_CIPHER_KEY_FP" (Get-KeyFingerprint $demoKey)
            Write-Host "[配置] 主密钥为内置演示主密钥, 已清空 .env 配套密文(改用代码内置密文)" -ForegroundColor Green
        }
        return
    }

    # 判定是否需要重新生成密文: 密文缺失, 或主密钥已被修改(指纹不一致)
    $reason = ""
    if (-not $secret -or -not $file) {
        $reason = ".env 配套密文缺失(升级遗留或手工编辑)"
    } elseif ($fp -and $fp -ne (Get-KeyFingerprint $key)) {
        $reason = "授权主密钥已变更, 现有密文不再配套"
    }
    if (-not $reason) { return }

    Write-Host "[配置] 检测到 $reason, 正在为当前主密钥生成配套密文..."
    if (-not (Set-LicenseCiphers $envFile $key)) {
        Write-Host "[警告] 配套密文生成失败, 回退使用内置演示主密钥以保证可启动" -ForegroundColor Yellow
        Use-DemoKeyFallback $envFile
    }
}

# ---- 强制为现有主密钥重新生成配套密文(start.bat configure) ----
if ($Reencrypt) {
    if (-not (Test-Path $envFile)) {
        Write-Host "[错误] 未找到 $envFile, 请先启动一次生成配置" -ForegroundColor Red
        exit 1
    }
    $key = Get-EnvValue $envFile "CRM_LICENSE_MASTER_KEY"
    if (-not $key) {
        Write-Host "[错误] $envFile 中未设置 CRM_LICENSE_MASTER_KEY" -ForegroundColor Red
        exit 1
    }
    if ($key -eq $demoKey) {
        Set-EnvValue $envFile "CRM_LICENSE_SECRET_CIPHER" ""
        Set-EnvValue $envFile "CRM_LICENSE_FILE_CIPHER" ""
        Set-EnvValue $envFile "CRM_LICENSE_CIPHER_KEY_FP" (Get-KeyFingerprint $demoKey)
        Write-Host "[配置] 主密钥为内置演示主密钥, 已清空配套密文(使用代码内置密文)" -ForegroundColor Green
        exit 0
    }
    if (Set-LicenseCiphers $envFile $key) {
        Write-Host "[配置] 配套密文已更新, 请执行 restart.bat 重启服务" -ForegroundColor Green
    } else {
        Write-Host "[警告] 重新生成配套密文失败, 回退使用内置演示主密钥以保证可启动" -ForegroundColor Yellow
        Use-DemoKeyFallback $envFile
    }
    exit 0
}

# ---- 每次启动前调用: 保证 .env 与授权主密钥可用 ----
if ($Ensure) {
    Ensure-LicenseConfig
    Test-JwtSecret $envFile
    exit 0
}

# ---- 缺省(无参数): 生成 / 校正 .env ----
if (-not (Test-Path $envFile)) {
    New-EnvFile
    exit 0
}
Write-Host "[配置] .env 已存在: $envFile" -ForegroundColor Green
Ensure-LicenseConfig
Test-JwtSecret $envFile
exit 0
