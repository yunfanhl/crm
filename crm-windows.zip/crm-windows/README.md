# 云帆智能客户管理系统 - Windows 部署说明

## 1. 环境要求

| 组件 | 版本 | 说明 |
|------|------|------|
| JDK | 17+ | 需配置 PATH 环境变量(`java -version` 可执行) |
| MySQL | 8.0+ | 本地安装, 建议 root/root（首次启动自动建库建表，无需手动导入 SQL） |
| Redis | 6.0+ | 本地安装(Windows 版) |

> 应用内嵌前端页面与 Tomcat，只需暴露 8080 端口即可访问。

## 2. 目录结构

```
crm-system-<版本>-windows/
├── crm-system.jar        # 后端可执行包(内嵌前端页面、默认配置与建表 SQL)
├── application.yml             # 部署配置(数据库连接等在此修改, 修改后重启生效)
├── init.sql                    # 建库建表 SQL(自动建表已内置, 供手动初始化/审计)
├── demo-data.sql               # 可选: 演示业务数据(每个功能 15 条, 建表完成后按需导入)
├── start.bat                   # 启动(首次自动生成配置)
├── stop.bat                    # 停止
├── restart.bat                 # 重启
├── configure.ps1               # 自动生成 .env(随机授权主密钥)
├── .env.example                # 环境变量模板(授权主密钥/JWT/Redis 等; 数据库连接见 application.yml)
└── VERSION
```

## 3. 部署步骤

### 3.1 解压并启动

将部署包解压到任意目录（如 `D:\crm`），双击 `start.bat` 或命令行执行：

```bat
cd D:\crm
start.bat
```

首次启动会自动生成 `.env`（随机授权主密钥 + 配套敏感配置密文），随后**自动建库建表**并后台启动应用。就绪后访问：

```
http://127.0.0.1:8080
```

> **配置优先级（高 → 低）**：
> 1. 包根 `application.yml`（Spring Boot 自动加载，修改后重启生效，推荐常规参数）
> 2. jar 内置默认值
>
> 未设置项使用内置默认值（数据库 `localhost:3306/crm_db` root/root，Redis `localhost:6379` 无密码）。
>
> **修改数据库连接**：统一编辑包根 `application.yml` 的 `spring.datasource` 段——
> `password` 为数据库密码，`url` 为地址/端口/库名，`username` 为账号，保存后 `restart.bat` 生效。
> 注意与 MySQL 实际账号密码保持一致。
>
> **数据库初始化**：应用首次启动自动建库建表，无需手动导入。包根 `init.sql` 为完整建表脚本，
> 供手工初始化其他环境或审计表结构使用：`mysql -uroot -proot < init.sql`
>
> **可选测试数据**：新部署默认不含业务数据。如需预置演示客户/线索/合同等测试数据，
> 首次启动建表完成后执行（建议空库/演示环境）：
> ```
> mysql -uroot -proot crm_db --default-character-set=utf8mb4 < demo-data.sql
> ```
> 脚本内置幂等防重，可重复执行不会翻倍；若历史库演示数据已膨胀，用 `fix-dup-data.sql` 清理。

### 3.2 停止 / 重启

```bat
stop.bat
restart.bat
```

### 3.3 修复主密钥不匹配（升级场景）

旧版本部署后 `.env` 已存在但主密钥与代码内置密文不匹配时，应用会启动失败。

- **自动修复（默认）**：`start.bat` 每次启动都会先校正 `.env`——主密钥缺失会生成、配套密文缺失或主密钥被改过会自动重新生成，
  `restart.bat` / 双击启动即会自愈，无需手工干预。
- **手工强制修复**：确需强制为当前主密钥重新生成配套密文时执行：

```bat
start.bat configure
```

无需更换主密钥即可正常启动。若 `.env` 已损坏，也可直接删除 `.env` 后重新双击 `start.bat` 自动生成。

### 3.4 注册为 Windows 服务（可选）

使用 [NSSM](https://nssm.cc) 将 `java -jar D:\crm\crm-system.jar` 注册为开机自启服务。

## 4. 修改数据库 / Redis 账号密码

**数据库（MySQL）**：编辑包根 `application.yml` 的 `spring.datasource` 段：

- `password` — MySQL 账号密码（默认 root）
- `url` — MySQL 地址 / 端口 / 库名（默认 `jdbc:mysql://localhost:3306/crm_db?...`）
- `username` — MySQL 账号（默认 root）

保存后运行 `restart.bat` 生效。

**Redis**：如启用了 Redis 密码，编辑 `.env` 中的 `REDIS_PASSWORD` 后运行 `restart.bat` 生效。

## 5. 授权激活

- 首次登录后按弹窗提示"免费试用"（14 天）或上传正式 License Key
- 授权记录管理：`admin` 登录 → 系统管理 → 授权管理（查看/生成 License）
- 机器码基于部署机器的**硬件序列号 + MAC 地址**生成，请确保部署机器硬件稳定，更换机器需重新申请授权

## 6. 登录账号

| 账号 | 密码 | 角色 |
|------|------|------|
| `admin` | `123456` | 超级管理员 |
| `sales01` | `123456` | 销售经理 |
| `sales02` | `123456` | 销售员 |

> 登录页**默认展示上述内置账号提示**（点击标签即可填充账号密码，本部署包默认开启）；如需隐藏，
> 登录后进入 系统管理 → 系统设置 → 功能开关，关闭「登录页默认账号提示」即可。

> 生产环境请登录后立即修改默认密码。

## 7. 常见问题排查

### 7.1 启动即退出 / 日志报 `Unable to connect to Redis`（Connection refused localhost:6379）

- **现象**：`start.bat` 启动后应用很快退出，日志末尾出现
  `Caused by: java.net.ConnectException: Connection refused: localhost/127.0.0.1:6379`
  （或 `io.lettuce.core.RedisConnectionException: Unable to connect to localhost/<unresolved>:6379`）。
- **原因**：**Redis 未安装或未启动**。Redis 是本系统的硬依赖（登录态、会话、缓存均依赖它），
  启动阶段 `WebMvcConfig` 会读取系统配置，redis 连不上就会中断 Spring 容器初始化。
- **解决**：安装并启动 Redis：
  - **推荐（Windows 原生服务）**：安装 [Memurai](https://www.memurai.com)（Redis 6 兼容的 Windows 版，
    免费开发授权），安装完成后自动作为 Windows 服务运行，开机自启；验证 `redis-cli ping` 返回 `PONG`。
  - **使用 WSL**：`wsl -e sudo apt install redis-server -y && wsl -e sudo service redis-server start`
    （Win10 2004+/Win11 默认把 `localhost:6379` 转发给 Windows 上的 jar）。
  - Redis 在其它机器或改了端口/密码：编辑 `.env` 的 `REDIS_HOST / REDIS_PORT / REDIS_PASSWORD` 后运行 `restart.bat`。
- **说明（2.6.1+）**：自 2.6.1 起 `RedisService` 已对 Redis 不可用做降级——`get` 失败返回 `null` 走数据库兜底、
  `set/delete` 等降级为 no-op，因此**应用可以正常启动且能扛住运行期 Redis 抖动**；但登录、会话、缓存
  仍需要 Redis 真正在运行，否则登录写入被忽略、`isTokenValid` 校验失败，登录仍通不过。日志里若出现
  `Redis 不可用, 已降级处理...` 即表示已触发降级（功能会受限），请先确保 Redis 已启动。

### 7.2 双击 start.bat 报“不是内部或外部命令”/ 中文乱码（如 `鋸扔敘…`）

- **现象**：黑窗口一闪而过，报 `'M' 不是内部或外部命令`、`'ver' 不是...`、`'""'`、`'{'`、
  `PIDOLDlPID" >nul && (` 等，或大量 GBK 乱码。
- **原因**：`.bat` / `.ps1` 脚本以 **UTF-8 无 BOM + LF 换行**保存，`cmd.exe` 解析错位——把整段当一行乱读、
  中文被当乱码、续行符 `^` 与括号配对全部失效，于是被切成“独立命令”执行。
- **解决**：使用发行包内已修复（UTF-8 BOM + CRLF）的脚本即可。若自行用编辑器修改过脚本，
  请保存为 **UTF-8 BOM** 且换行用 **CRLF**（Windows 格式）；用 VS Code 右下角可切换。

### 7.3 启动失败：`授权主密钥与配套密文不匹配` / `AEADBadTagException: Tag mismatch!`

- **现象**：`logs/app.log` 末尾出现

  ```
  Caused by: java.lang.IllegalStateException: 授权主密钥与配套密文不匹配...
  Caused by: javax.crypto.AEADBadTagException: Tag mismatch!
  ```

- **原因**：`.env` 中的 `CRM_LICENSE_MASTER_KEY` 与代码内置密文（由演示主密钥加密）不是同一套。
  常见于：旧版本升级后 `.env` 已存在但配套密文为空、手工修改了主密钥、或手工创建了 `.env`。
- **解决**（任选其一）：
  1. 执行 `start.bat configure`，为当前主密钥重新生成配套密文，再 `restart.bat`；
  2. 删除 `.env` 后重新双击 `start.bat`，脚本会重新生成（随机主密钥 + 配套密文）；
  3. 若不需要自定义主密钥，编辑 `.env` 把 `CRM_LICENSE_MASTER_KEY` 改为
     包初始预置的内置演示主密钥（即首次解压时 `.env` 中 `CRM_LICENSE_MASTER_KEY` 的默认值），并把 `CRM_LICENSE_SECRET_CIPHER` / `CRM_LICENSE_FILE_CIPHER` 两行清空。
- **说明**：重新生成配套密文只改变密文的加密外壳，License 签名密钥等明文不变，已签发的 License 不受影响。
