#!/usr/bin/env bash
# ==========================================================
#  云帆智能客户管理系统 - Docker 停止脚本(macOS / Linux)
#  用法:
#    ./stop.sh              # 停止并删除容器(数据卷保留, 再次 ./start.sh 数据仍在)
#    ./stop.sh -v           # 停止并删除容器 + 删除数据卷(危险: 业务数据与内置数据库全部清空, 需二次确认)
#    ./stop.sh logs -f app  # 其余参数原样透传给 docker compose
#
#  说明:
#    1. 等价于 ./start.sh down —— 内置 MySQL/Redis 属于 bundled profile,
#       是否启用由 .env 的 COMPOSE_PROFILES 决定, 交给 start.sh 统一处理, 避免漏停容器
#    2. 默认只删容器不动数据卷: 业务数据(MySQL/Redis/uploads)与授权文件(data/license.dat)均保留
# ==========================================================

cd "$(dirname "$0")" || exit 1

info() { echo "[提示] $*"; }
err()  { echo "[错误] $*"; }

if ! command -v docker >/dev/null 2>&1; then
    err "未检测到 docker 命令, 请先安装 Docker Desktop: https://www.docker.com/products/docker-desktop/"
    exit 1
fi

if [ ! -f "docker-compose.yml" ]; then
    err "当前目录未找到 docker-compose.yml, 请在部署包根目录执行本脚本"
    exit 1
fi

if ! docker info >/dev/null 2>&1; then
    err "无法连接 Docker daemon, 请先启动 Docker Desktop(状态变为 Running 后重试)"
    exit 1
fi

if ! docker compose version >/dev/null 2>&1; then
    err "未检测到 docker compose v2, 请升级 Docker Desktop 至支持 docker compose 的版本"
    exit 1
fi

# .env 中的 COMPOSE_PROFILES 需导出到环境, 否则删除数据卷时可能漏掉 bundled 服务的卷
if [ -f ".env" ]; then
    _profiles=$(sed -n 's/^[[:space:]]*COMPOSE_PROFILES[[:space:]]*=[[:space:]]*//p' .env | tail -n 1 | tr -d '"' | tr -d "'")
    if [ -n "$_profiles" ]; then
        export COMPOSE_PROFILES="$_profiles"
    fi
fi

echo "=========================================================="
echo " 停止前容器状态"
echo "=========================================================="
docker compose ps 2>/dev/null
echo "----------------------------------------------------------"

# -v / --volumes: 连同数据卷一起删除(业务数据不可恢复, 需显式确认)
if [ "${1:-}" = "-v" ] || [ "${1:-}" = "--volumes" ]; then
    echo "[警告] 即将删除容器与数据卷: 业务数据(客户/线索/文章等)、内置 MySQL/Redis 数据将全部清空且不可恢复!"
    printf "确认请输入 yes (区分大小写): "
    read -r _confirm
    if [ "$_confirm" != "yes" ]; then
        info "已取消, 未做任何操作"
        exit 0
    fi
    info "执行: docker compose down -v"
    docker compose down -v
    _rc=$?
    if [ $_rc -ne 0 ]; then
        err "停止失败(退出码 $_rc), 请查看上方输出"
        exit "$_rc"
    fi
    echo "=========================================================="
    info "容器与数据卷已删除(数据不可恢复)"
    info "重新部署: ./start.sh"
    echo "=========================================================="
    exit 0
fi

info "执行: docker compose down (数据卷保留)"
docker compose down
_rc=$?
if [ $_rc -ne 0 ]; then
    err "停止失败(退出码 $_rc), 请查看上方输出"
    exit "$_rc"
fi

echo "=========================================================="
info "已停止并移除容器, 数据卷保留(业务数据 / 授权文件均不受影响)"
info "查看数据卷: docker volume ls | grep crm"
info "重新启动  : ./start.sh"
echo "=========================================================="
