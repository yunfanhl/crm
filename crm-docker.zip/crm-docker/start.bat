@echo off
chcp 65001 >nul
cd /d "%~dp0"
setlocal

REM ==========================================================
REM  CRM Docker 预检 + 依赖探测 + 启动包装脚本(Windows)
REM  用法: start.bat              # 预检/探测后: docker compose up -d --build
REM        start.bat down         # 停止并删除容器(数据卷保留)
REM        start.bat logs -f app  # 其余参数原样透传给 docker compose
REM
REM  依赖解析(由 resolve-deps.ps1 完成):
REM    默认                  -> 自建独立容器 crm-mysql / crm-redis, 不读取也不改动宿主现有 MySQL/Redis
REM    USE_EXTERNAL_DB=1 等  -> 复用宿主现有实例(探测不到则回退自建)
REM    宿主端口被其他程序占用 -> 自动改用空闲端口(WEB_PORT / MYSQL_HOST_PORT / REDIS_HOST_PORT)
REM  结果写入 .env: COMPOSE_PROFILES / DB_* / REDIS_* / WEB_PORT / *_HOST_PORT, 原生命令同样生效
REM ==========================================================

where docker >nul 2>nul
if errorlevel 1 (
    echo.
    echo [错误] 未检测到 docker 命令, 请先安装 Docker Desktop:
    echo        https://www.docker.com/products/docker-desktop/
    echo.
    pause
    exit /b 1
)

if not exist "docker-compose.yml" (
    echo.
    echo [错误] 当前目录未找到 docker-compose.yml, 请在部署包根目录执行本脚本
    echo.
    pause
    exit /b 1
)

docker info >nul 2>nul
if errorlevel 1 (
    echo.
    echo [错误] 无法连接 Docker daemon, 请先启动 Docker Desktop
    echo   → 双击桌面 Docker Desktop 图标, 等待左下角状态变为 Running 后重试
    echo   → 若已启动仍报此错: Settings → General → 勾选 Start Docker Desktop when you sign in
    echo     并确保 Settings → General → "Use the WSL 2 based engine" 已启用
    echo.
    pause
    exit /b 1
)

docker compose version >nul 2>nul
if errorlevel 1 (
    echo.
    echo [错误] 未检测到 Docker Compose v2 插件, 请升级 Docker Desktop
    echo.
    pause
    exit /b 1
)

REM ---------- 依赖来源解析 ----------
if exist "resolve-deps.ps1" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0resolve-deps.ps1"
) else (
    echo [警告] 未找到 resolve-deps.ps1, 跳过依赖探测, 将直接使用内置 MySQL/Redis 容器
)

REM ---------- 端口说明 ----------
REM WEB_PORT / MYSQL_HOST_PORT / REDIS_HOST_PORT 的占用检测与自动避让已由 resolve-deps.ps1 完成
REM (冲突时自动改用空闲端口并写回 .env), 此处无需重复检查。

if "%~1"=="" (
    echo [提示] 执行: docker compose up -d --build
    docker compose up -d --build
) else (
    echo [提示] 执行: docker compose %*
    docker compose %*
)

if errorlevel 1 (
    echo.
    echo [错误] 命令执行失败, 请查看上方输出; 常见原因: 宿主端口被占用(端口见上方"访问地址/MySQL 端口/Redis 端口")
    echo.
    pause
    exit /b 1
)

REM ---------- 启动后展示系统运行情况 ----------
if "%~1"=="" call :show_status
if /i "%~1"=="up" call :show_status
if /i "%~1"=="start" call :show_status
if /i "%~1"=="restart" call :show_status

pause
exit /b 0

:show_status
echo.
echo ==========================================================
echo  容器状态
echo ==========================================================
docker compose ps
echo ==========================================================
echo  访问信息
echo ==========================================================
set "WEB_PORT_VAL=8080"
if exist ".env" (
    for /f "usebackq tokens=1,* delims==" %%A in (".env") do (
        if "%%A"=="WEB_PORT" set "WEB_PORT_VAL=%%B"
    )
)
echo [提示] 访问地址: http://localhost:%WEB_PORT_VAL%
echo [提示] 默认账号: admin / 123456  (生产环境请登录后立即修改密码)
echo ----------------------------------------------------------
echo  常用命令:  查看日志 docker compose logs -f app
echo             停止     start.bat down
echo             重启     start.bat restart
echo ----------------------------------------------------------
exit /b 0
