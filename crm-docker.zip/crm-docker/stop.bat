@echo off
chcp 65001 >nul
cd /d "%~dp0"
setlocal

REM ==========================================================
REM  云帆智能客户管理系统 - Docker 停止脚本(Windows)
REM  用法: stop.bat              # 停止并删除容器(数据卷保留, 再次 start.bat 数据仍在)
REM        stop.bat -v           # 停止并删除容器 + 删除数据卷(危险: 业务数据与内置数据库全部清空, 需二次确认)
REM        stop.bat logs -f app  # 其余参数原样透传给 docker compose
REM
REM  说明:
REM    1. 等价于 start.bat down —— 内置 MySQL/Redis 属于 bundled profile,
REM       是否启用由 .env 的 COMPOSE_PROFILES 决定, 交给 start.bat 统一处理, 避免漏停容器
REM    2. 默认只删容器不动数据卷: 业务数据(MySQL/Redis/uploads)与授权文件(data/license.dat)均保留
REM ==========================================================

where docker >nul 2>nul
if errorlevel 1 (
    echo.
    echo [错误] 未检测到 docker 命令, 请先安装 Docker Desktop:
    echo        https://www.docker.com/products/docker-desktop/
    echo.
    pause
    exit /b 1
)

if not exist "docker-compose.yml" (
    echo.
    echo [错误] 当前目录未找到 docker-compose.yml, 请在部署包根目录执行本脚本
    echo.
    pause
    exit /b 1
)

docker info >nul 2>nul
if errorlevel 1 (
    echo.
    echo [错误] 无法连接 Docker daemon, 请先启动 Docker Desktop
    echo   → 双击桌面 Docker Desktop 图标, 等待左下角状态变为 Running 后重试
    echo.
    pause
    exit /b 1
)

docker compose version >nul 2>nul
if errorlevel 1 (
    echo.
    echo [错误] 未检测到 docker compose v2, 请升级 Docker Desktop 至支持 docker compose 的版本
    echo.
    pause
    exit /b 1
)

echo ==========================================================
echo  停止前容器状态
echo ==========================================================
docker compose ps
echo ----------------------------------------------------------

REM -v / --volumes: 连同数据卷一起删除
if /i "%1"=="-v" goto REMOVE_VOLUMES
if /i "%1"=="--volumes" goto REMOVE_VOLUMES

echo [提示] 执行: docker compose down ^(数据卷保留^)
docker compose down
if errorlevel 1 (
    echo.
    echo [错误] 停止失败, 请查看上方输出
    echo.
    pause
    exit /b 1
)
echo ==========================================================
echo [提示] 已停止并移除容器, 数据卷保留^(业务数据 / 授权文件均不受影响^)
echo [提示] 查看数据卷: docker volume ls
echo [提示] 重新启动  : start.bat
echo ==========================================================
pause
exit /b 0

:REMOVE_VOLUMES
echo [警告] 即将删除容器与数据卷: 业务数据^(客户/线索/文章等^)、内置 MySQL/Redis 数据将全部清空且不可恢复!
set CONFIRM=
set /p CONFIRM=确认请输入 yes (区分大小写): 
if not "%CONFIRM%"=="yes" (
    echo [提示] 已取消, 未做任何操作
    pause
    exit /b 0
)
echo [提示] 执行: docker compose down -v
docker compose down -v
if errorlevel 1 (
    echo.
    echo [错误] 停止失败, 请查看上方输出
    echo.
    pause
    exit /b 1
)
echo ==========================================================
echo [提示] 容器与数据卷已删除^(数据不可恢复^)
echo [提示] 重新部署: start.bat
echo ==========================================================
pause
exit /b 0
