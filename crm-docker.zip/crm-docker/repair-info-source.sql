-- =====================================================
-- 信息来源默认数据来源补齐：企查查开放平台 / 爱企查
-- 场景：删库重建或旧包部署后「信息来源」页面为空时，直接执行本脚本即可补齐，无需换包。
-- 幂等：按名称防重，可重复执行；用户主动删除（逻辑删除）的来源不会被复活。
-- 执行：mysql -uroot -p --default-character-set=utf8mb4 < sql/repair-info-source.sql
-- =====================================================
CREATE DATABASE IF NOT EXISTS `crm_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `crm_db`;
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS `crm_info_source` (
  `id` varchar(36) NOT NULL DEFAULT (uuid()) COMMENT '主键',
  `source_name` varchar(100) NOT NULL COMMENT '数据源名称',
  `source_type` varchar(20) NOT NULL DEFAULT 'custom' COMMENT '类型：custom-自定义API qichacha-企查查 aiqicha-爱企查',
  `base_url` varchar(500) DEFAULT NULL COMMENT '接口地址',
  `app_key` varchar(200) DEFAULT NULL COMMENT 'AppKey',
  `app_secret` varchar(200) DEFAULT NULL COMMENT 'AppSecret',
  `enabled` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用 0-停用 1-启用',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `last_crawl_time` datetime DEFAULT NULL COMMENT '最近抓取时间',
  `last_result` text COMMENT '最近抓取结果',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '逻辑删除 0-否 1-是',
  PRIMARY KEY (`id`),
  KEY `idx_enabled` (`enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='信息来源（平台来源）';

-- 密钥留空：需在「信息来源 - 编辑数据源」中填写 Key/Secrect 或接口地址 + APPCODE 后才能抓取真实数据
INSERT IGNORE INTO `crm_info_source` (`id`, `source_name`, `source_type`, `base_url`, `enabled`, `remark`)
SELECT s.id, s.name, s.type, s.url, 1, s.remark FROM (
  SELECT 'b9d7a13cd67611f1925b1d4813846157' AS id, '企查查开放平台' AS name, 'qichacha' AS type,
         'https://api.qichacha.com/FuzzySearch/GetList' AS url,
         '需在企查查开放平台购买接口服务后填写 Key 与 Secrect' AS remark
  UNION ALL
  SELECT 'b9d7b3cad67611f1925b1d4813846157', '爱企查', 'aiqicha', NULL,
         '需购买云市场爱企查接口后填写接口地址与 APPCODE'
) s
WHERE NOT EXISTS (SELECT 1 FROM `crm_info_source` WHERE `source_name` = s.name);

-- 诊断：正常情况应看到企查查（qichacha）与爱企查（aiqicha）两条
SELECT `source_name`, `source_type`, `enabled`, `deleted`, IFNULL(`base_url`, '未配置') AS `base_url`
FROM `crm_info_source` ORDER BY `source_type`;
