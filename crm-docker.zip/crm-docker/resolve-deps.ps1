﻿<#
 ==========================================================
  云帆智能客户管理系统 - Docker 依赖(MySQL/Redis)来源解析
  由 start.bat 调用, 用户无需手工执行。

  作用:
    1. 决定 MySQL / Redis 的来源(默认自建独立容器, 不读取也不改动宿主现有实例):
       - 默认(no/bundled 及未配置): 随 compose 新建 crm-mysql / crm-redis
       - USE_EXTERNAL_DB=1 / USE_EXTERNAL_REDIS=1: 复用宿主现有实例(探测不到则回退自建)
       - EXTERNAL_DB_HOST + EXTERNAL_DB_PORT: 直连指定的外部实例(优先级最高)
    2. 把连接信息写入 .env:
         DB_* / REDIS_*      应用连接信息
         COMPOSE_PROFILES   决定是否启用内置 MySQL/Redis 容器(bundled profile)
 ==========================================================
#>

$ErrorActionPreference = 'Stop'

$BaseFile       = 'docker-compose.yml'
$BundledProfile = 'bundled'   # 内置 MySQL/Redis 容器所在的 compose profile
$EnvFile    = '.env'
$EnvExample = '.env.example'

function Write-Info($msg) { Write-Host "[提示] $msg" }
function Write-Warn($msg) { Write-Host "[警告] $msg" -ForegroundColor Yellow }

# ---------------- .env 读写 ----------------
function Get-DotEnvValue($name) {
    if (-not (Test-Path $EnvFile)) { return $null }
    $regex = "^\s*" + [regex]::Escape($name) + "\s*="
    $line = Get-Content $EnvFile | Where-Object { $_ -match $regex } | Select-Object -Last 1
    if (-not $line) { return $null }
    return ($line -replace $regex, '').TrimEnd("`r")
}

function Get-Config($name, $default) {
    $v = [Environment]::GetEnvironmentVariable($name)
    if ([string]::IsNullOrWhiteSpace($v)) { $v = Get-DotEnvValue $name }
    if ([string]::IsNullOrWhiteSpace($v)) { return $default }
    return $v
}

function Set-DotEnvValue($name, $value) {
    if (-not (Test-Path $EnvFile)) {
        if (Test-Path $EnvExample) {
            Copy-Item $EnvExample $EnvFile | Out-Null
            Write-Info "已由 $EnvExample 生成 $EnvFile"
        } else {
            New-Item -ItemType File -Path $EnvFile | Out-Null
        }
    }
    $pattern = "^\s*" + [regex]::Escape($name) + "\s*="
    $found = $false
    $out = New-Object System.Collections.Generic.List[string]
    foreach ($l in (Get-Content $EnvFile)) {
        if ($l -match $pattern) { $out.Add("$name=$value"); $found = $true } else { $out.Add($l) }
    }
    if (-not $found) { $out.Add("$name=$value") }
    # 用无 BOM UTF8 写入, 避免 Windows PowerShell 的 BOM 导致 compose 读不到第一行的 COMPOSE_PROFILES
    [System.IO.File]::WriteAllLines(
        (Resolve-Path $EnvFile),
        $out.ToArray(),
        (New-Object System.Text.UTF8Encoding($false)))
}

# 从 .env 删除某个键: 用于清理旧版本遗留、现已不再使用的变量
function Remove-DotEnvKey($name) {
    if (-not (Test-Path $EnvFile)) { return }
    $pattern = "^\s*" + [regex]::Escape($name) + "\s*="
    $out = New-Object System.Collections.Generic.List[string]
    foreach ($l in (Get-Content $EnvFile)) {
        if ($l -notmatch $pattern) { $out.Add($l) }
    }
    [System.IO.File]::WriteAllLines(
        (Resolve-Path $EnvFile),
        $out.ToArray(),
        (New-Object System.Text.UTF8Encoding($false)))
}

# ---------------- 端口 / 服务探测 ----------------
function Test-PortOpen($port) {
    try {
        $client = New-Object System.Net.Sockets.TcpClient
        $task = $client.BeginConnect('127.0.0.1', [int]$port, $null, $null)
        if (-not $task.AsyncWaitHandle.WaitOne(1500)) { $client.Close(); return $false }
        $client.EndConnect($task) | Out-Null
        $ok = $client.Connected
        $client.Close()
        return $ok
    } catch { return $false }
}

function Test-MySqlService($port) {
    if (-not (Test-PortOpen $port)) { return $false }
    if (Get-Command mysqladmin -ErrorAction SilentlyContinue) {
        $out = (& mysqladmin --connect-timeout=2 -h 127.0.0.1 -P $port ping 2>&1 | Out-String)
        if ($out -match 'is alive' -or $out -match 'Access denied') { return $true }
    }
    # 无客户端时读取服务端主动推送的握手包(含版本串)
    try {
        $client = New-Object System.Net.Sockets.TcpClient('127.0.0.1', [int]$port)
        $stream = $client.GetStream()
        $stream.ReadTimeout = 3000
        $buf = New-Object byte[] 64
        $n = $stream.Read($buf, 0, 64)
        $text = [Text.Encoding]::ASCII.GetString($buf, 0, $n)
        $client.Close()
        if ($text -match '\d\.\d') { return $true }
    } catch {}
    return $false
}

# 返回 Ready / NeedAuth / None
function Test-RedisService($port) {
    if (-not (Test-PortOpen $port)) { return 'None' }
    if (Get-Command redis-cli -ErrorAction SilentlyContinue) {
        $out = (& redis-cli -h 127.0.0.1 -p $port ping 2>$null | Out-String)
        if ($out -match 'PONG') { return 'Ready' }
        if ($out -match 'NOAUTH|WRONGPASS') { return 'NeedAuth' }
    }
    try {
        $client = New-Object System.Net.Sockets.TcpClient('127.0.0.1', [int]$port)
        $stream = $client.GetStream()
        $stream.ReadTimeout = 3000
        $bytes = [Text.Encoding]::ASCII.GetBytes("PING`r`n")
        $stream.Write($bytes, 0, $bytes.Length)
        $buf = New-Object byte[] 64
        $n = $stream.Read($buf, 0, $buf.Length)
        $text = [Text.Encoding]::ASCII.GetString($buf, 0, $n)
        $client.Close()
        if ($text -match 'PONG') { return 'Ready' }
        if ($text -match 'NOAUTH|WRONGPASS|ERR') { return 'NeedAuth' }
    } catch {}
    return 'None'
}

function Test-ContainerExists($name) {
    try {
        $names = & docker ps -a --format '{{.Names}}' 2>$null
        return ($names -contains $name)
    } catch { return $false }
}

# ---------------- 交互辅助 ----------------
function Confirm-OrDefault($prompt, $defaultYes = $true) {
    $hint = if ($defaultYes) { 'Y/n' } else { 'y/N' }
    if (-not [Environment]::UserInteractive) {
        Write-Info "$prompt [$hint] 非交互环境, 取默认值"
        return $defaultYes
    }
    $answer = Read-Host "$prompt [$hint]"
    if ([string]::IsNullOrWhiteSpace($answer)) { return $defaultYes }
    return ($answer -match '^(y|Y)')
}

function Ask-OrDefault($prompt, $default) {
    if (-not [Environment]::UserInteractive) { return $default }
    $answer = Read-Host "$prompt [$default]"
    if ([string]::IsNullOrWhiteSpace($answer)) { return $default }
    return $answer
}

# ---------------- MySQL 来源解析 ----------------
$mysqlMode   = 'bundled'
$redisMode   = 'bundled'
$mysqlDetail = '内置容器 crm-mysql'
$redisDetail = '内置容器 crm-redis'
$mysqlHost = 'mysql'; $mysqlPort = '3306'; $mysqlUser = 'root'; $mysqlPass = 'root'; $mysqlDb = 'crm_db'
$redisHost = 'redis'; $redisPort = '6379'; $redisPass = ''
$mysqlLocal = $false; $redisLocal = $false; $redisAuthRequired = $false

if (Test-ContainerExists 'crm-mysql') {
    $mysqlMode = 'bundled'
    $mysqlDetail = '内置容器 crm-mysql(已存在)'
} else {
    $mode = (Get-Config 'USE_EXTERNAL_DB' 'bundled').ToLower()
    $explicitHost = Get-Config 'EXTERNAL_DB_HOST' ''
    $explicitPort = Get-Config 'EXTERNAL_DB_PORT' ''
    $forced = ($mode -in @('1', 'true', 'yes', 'on', 'external'))

    if ($explicitHost -ne '' -and $explicitPort -ne '') {
        # 显式指定了外部实例地址(如云数据库) -> 直接使用, 优先级最高
        $mysqlMode = 'external'
        $mysqlHost = $explicitHost; $mysqlPort = $explicitPort
        $mysqlDetail = "$explicitHost`:$explicitPort (外部实例, 按 .env 指定)"
    } elseif ($forced) {
        # 显式要求复用宿主实例: 探测宿主端口, 探测不到则回退为内置容器
        $found = $false
        foreach ($p in ((Get-Config 'MYSQL_DETECT_PORTS' '3306') -split '\s+')) {
            if ([string]::IsNullOrWhiteSpace($p)) { continue }
            if (Test-MySqlService $p) {
                $found = $true
                $mysqlPort = $p
                break
            }
        }
        if (-not $found) {
            Write-Warn "USE_EXTERNAL_DB=$mode, 但未探测到宿主 MySQL, 回退为新建内置容器 crm-mysql"
            $mysqlMode = 'bundled'
        } else {
            $mysqlMode = 'external'
            $mysqlHost = 'host.docker.internal'
            $mysqlLocal = $true
            $mysqlDetail = "127.0.0.1:$mysqlPort (宿主现有)"
        }
    } else {
        # 默认(no/bundled 及未配置): 自建独立容器, 宿主现有 MySQL 既不被读取也不被修改
        $mysqlMode = 'bundled'
        $mysqlDetail = '内置容器 crm-mysql(自建, 宿主现有 MySQL 不受影响)'
    }
}

if ($mysqlMode -eq 'external') {
    $mysqlUser = Get-Config 'EXTERNAL_DB_USER' (Get-Config 'DB_USERNAME' 'root')
    $mysqlDb   = Get-Config 'EXTERNAL_DB_NAME' (Get-Config 'DB_NAME' 'crm_db')
    $mysqlPass = Get-Config 'EXTERNAL_DB_PASSWORD' ''
    if ([string]::IsNullOrWhiteSpace($mysqlPass) -and (Get-Config 'CRM_DB_SOURCE' '') -eq 'external') {
        $mysqlPass = Get-DotEnvValue 'DB_PASSWORD'
    }
    if ([string]::IsNullOrWhiteSpace($mysqlPass)) {
        $mysqlPass = Ask-OrDefault "宿主 MySQL 用户 $mysqlUser 的密码" (Get-Config 'DB_PASSWORD' 'root')
    }
    # 本机实例: 校验账号可用性, 失败可回退为内置容器
    if ($mysqlLocal -and (Get-Command mysqladmin -ErrorAction SilentlyContinue)) {
        $out = (& mysqladmin --connect-timeout=3 -h 127.0.0.1 -P $mysqlPort -u $mysqlUser "-p$mysqlPass" ping 2>&1 | Out-String)
        if ($out -match 'is alive') {
            Write-Info "宿主 MySQL 账号校验通过($mysqlUser@127.0.0.1:$mysqlPort)"
        } else {
            Write-Warn "用 $mysqlUser 连接宿主 MySQL(127.0.0.1:$mysqlPort) 失败: 账号或密码不正确"
            Write-Host "  → 可直接修改 $EnvFile 的 EXTERNAL_DB_USER / EXTERNAL_DB_PASSWORD 后执行 docker compose restart app"
            # 非交互环境(脚本/CI/一键部署)无法确认或重输密码: 直接回退内置容器,
            # 避免写出连不上的外部配置, 导致 crm-app 启动即报 Access denied
            if (-not [Environment]::UserInteractive) {
                Write-Warn '非交互环境, 自动回退为新建内置容器 crm-mysql(不改动宿主 MySQL)'
                $mysqlMode = 'bundled'
                $mysqlDetail = '内置容器 crm-mysql(连接校验失败后回退)'
            } elseif (Confirm-OrDefault "是否改为新建内置容器 crm-mysql(不改动宿主 MySQL)?" $false) {
                $mysqlMode = 'bundled'
                $mysqlDetail = '内置容器 crm-mysql(连接校验失败后回退)'
            }
        }
    }
}

# ---------------- Redis 来源解析 ----------------
if (Test-ContainerExists 'crm-redis') {
    $redisMode = 'bundled'
    $redisDetail = '内置容器 crm-redis(已存在)'
} else {
    $mode = (Get-Config 'USE_EXTERNAL_REDIS' 'bundled').ToLower()
    $explicitHost = Get-Config 'EXTERNAL_REDIS_HOST' ''
    $explicitPort = Get-Config 'EXTERNAL_REDIS_PORT' ''
    $forced = ($mode -in @('1', 'true', 'yes', 'on', 'external'))

    if ($explicitHost -ne '' -and $explicitPort -ne '') {
        # 显式指定了外部实例地址(如云数据库) -> 直接使用, 优先级最高
        $redisMode = 'external'
        $redisHost = $explicitHost; $redisPort = $explicitPort
        $redisDetail = "$explicitHost`:$explicitPort (外部实例, 按 .env 指定)"
    } elseif ($forced) {
        # 显式要求复用宿主实例: 探测宿主端口, 探测不到则回退为内置容器
        $found = $false
        foreach ($p in ((Get-Config 'REDIS_DETECT_PORTS' '6379') -split '\s+')) {
            if ([string]::IsNullOrWhiteSpace($p)) { continue }
            $state = Test-RedisService $p
            if ($state -ne 'None') {
                $found = $true
                $redisPort = $p
                $redisAuthRequired = ($state -eq 'NeedAuth')
                break
            }
        }
        if (-not $found) {
            Write-Warn "USE_EXTERNAL_REDIS=$mode, 但未探测到宿主 Redis, 回退为新建内置容器 crm-redis"
            $redisMode = 'bundled'
        } else {
            $redisMode = 'external'
            $redisHost = 'host.docker.internal'
            $redisLocal = $true
            $redisDetail = "127.0.0.1:$redisPort (宿主现有)"
        }
    } else {
        # 默认(no/bundled 及未配置): 自建独立容器, 宿主现有 Redis 既不被读取也不被修改
        $redisMode = 'bundled'
        $redisDetail = '内置容器 crm-redis(自建, 宿主现有 Redis 不受影响)'
    }
}

if ($redisMode -eq 'external') {
    $redisPass = Get-Config 'EXTERNAL_REDIS_PASSWORD' ''
    if ([string]::IsNullOrWhiteSpace($redisPass) -and (Get-Config 'CRM_REDIS_SOURCE' '') -eq 'external') {
        $redisPass = Get-DotEnvValue 'REDIS_PASSWORD'
    }
    if ([string]::IsNullOrWhiteSpace($redisPass) -and $redisAuthRequired) {
        $redisPass = Ask-OrDefault "宿主 Redis 要求密码认证, 请输入密码" ''
    }
    if ($redisLocal -and (Get-Command redis-cli -ErrorAction SilentlyContinue)) {
        if ([string]::IsNullOrWhiteSpace($redisPass)) {
            $out = (& redis-cli -h 127.0.0.1 -p $redisPort ping 2>$null | Out-String)
        } else {
            $out = (& redis-cli -h 127.0.0.1 -p $redisPort -a $redisPass --no-auth-warning ping 2>$null | Out-String)
        }
        if ($out -match 'PONG') {
            Write-Info "宿主 Redis 连接校验通过(127.0.0.1:$redisPort)"
        } else {
            Write-Warn "连接宿主 Redis(127.0.0.1:$redisPort) 失败: Redis 要求密码认证或密码不正确"
            Write-Host "  → 可直接修改 $EnvFile 的 EXTERNAL_REDIS_PASSWORD 后执行 docker compose restart app"
            # 非交互环境无法确认或重输密码: 直接回退内置容器
            if (-not [Environment]::UserInteractive) {
                Write-Warn '非交互环境, 自动回退为新建内置容器 crm-redis(不改动宿主 Redis)'
                $redisMode = 'bundled'
                $redisDetail = '内置容器 crm-redis(连接校验失败后回退)'
            } elseif (Confirm-OrDefault "是否改为新建内置容器 crm-redis(不改动宿主 Redis)?" $false) {
                $redisMode = 'bundled'
                $redisDetail = '内置容器 crm-redis(连接校验失败后回退)'
            }
        }
    }
}

# ---------------- Web 宿主端口(被占用时自动避让) ----------------
function Test-PortListening($port) {
    try {
        $conns = Get-NetTCPConnection -State Listen -LocalPort ([int]$port) -ErrorAction Stop
        if ($conns) { return $true }
    } catch {}
    $out = & netstat -ano 2>$null | Select-String -Pattern "[:.]$port\s" | Select-String -Pattern 'LISTENING'
    return [bool]$out
}

function Get-PortHolder($port) {
    try {
        $conn = Get-NetTCPConnection -State Listen -LocalPort ([int]$port) -ErrorAction Stop | Select-Object -First 1
        $proc = Get-Process -Id $conn.OwningProcess -ErrorAction SilentlyContinue
        if ($proc) { return "$($proc.ProcessName) (PID $($proc.Id))" }
    } catch {}
    return ''
}

# 端口是否被本项目自身容器占用(自身占用不算冲突, 避免重复执行时端口来回漂移)
function Test-OwnPort($port) {
    foreach ($c in @('crm-app', 'crm-mysql', 'crm-redis')) {
        try {
            $mapped = & docker port $c 2>$null
            if ($mapped -and ($mapped | Select-String -Pattern ":$port$" -Quiet)) { return $true }
        } catch {}
    }
    return $false
}

# 对外暴露的宿主端口(Web 8080 / 内置 MySQL 3306 / 内置 Redis 6379):
# 被其他程序占用时自动避让到空闲端口
function Resolve-BundledPort($key, $default, $label) {
    $want = Get-Config $key $default
    if ((-not (Test-PortListening $want)) -or (Test-OwnPort $want)) { return $want }
    $holder = Get-PortHolder $want
    if ($holder) { Write-Warn "$label 宿主端口 $want 已被占用: $holder" } else { Write-Warn "$label 宿主端口 $want 已被占用" }
    for ($i = 1; $i -le 50; $i++) {
        $candidate = [int]$want + $i
        if (-not (Test-PortListening $candidate)) {
            Write-Info "$label 已自动改用宿主端口 $candidate"
            Write-Info "如需固定端口: 关闭占用 $want 的程序, 或在 $EnvFile 中设置 $key=$want"
            return $candidate
        }
    }
    Write-Warn "未找到空闲端口, 保留 $want(可在 $EnvFile 中设置 $key 手动指定)"
    return $want
}

# Web 宿主端口(默认 8080, 被其他程序占用时自动避让)
$webPort = Resolve-BundledPort 'WEB_PORT' '8080' 'Web'

# 内置 MySQL/Redis 的宿主端口(3306 / 6379, 被其他程序占用时自动避让)
$mysqlHostPort = Get-Config 'MYSQL_HOST_PORT' '3306'
$redisHostPort = Get-Config 'REDIS_HOST_PORT' '6379'
if ($mysqlMode -eq 'bundled') { $mysqlHostPort = Resolve-BundledPort 'MYSQL_HOST_PORT' '3306' '内置 MySQL' }
if ($redisMode -eq 'bundled') { $redisHostPort = Resolve-BundledPort 'REDIS_HOST_PORT' '6379' '内置 Redis' }

# ---------------- 授权主密钥清理 ----------------
# 留空/占位符一律清空: docker-compose 对空值回退为内置演示主密钥(与代码内置密文配套, 解压即可运行)。
# 注意: 此处不做随机替换 —— 随机主密钥必须配套重新生成 CRM_LICENSE_*_CIPHER(需 JDK),
# 否则应用解密失败启动即退; 自定义主密钥请用原生包 ./start.sh configure 生成配套密文
$masterKey = Get-DotEnvValue 'CRM_LICENSE_MASTER_KEY'
if ($null -eq $masterKey -or $masterKey -eq '' -or $masterKey -like 'please-change-me*') {
    Set-DotEnvValue 'CRM_LICENSE_MASTER_KEY' ''
}

# ---------------- 写入 .env ----------------
if ($mysqlMode -eq 'external') {
    Set-DotEnvValue 'EXTERNAL_DB_USER' $mysqlUser
    Set-DotEnvValue 'EXTERNAL_DB_PASSWORD' $mysqlPass
    Set-DotEnvValue 'EXTERNAL_DB_NAME' $mysqlDb
    Set-DotEnvValue 'DB_HOST' $mysqlHost
    Set-DotEnvValue 'DB_PORT' $mysqlPort
    Set-DotEnvValue 'DB_USERNAME' $mysqlUser
    Set-DotEnvValue 'DB_PASSWORD' $mysqlPass
    Set-DotEnvValue 'DB_NAME' $mysqlDb
} else {
    $mysqlPass = Get-Config 'BUNDLED_MYSQL_ROOT_PASSWORD' 'root'
    Set-DotEnvValue 'DB_HOST' 'mysql'
    Set-DotEnvValue 'DB_PORT' '3306'
    Set-DotEnvValue 'DB_USERNAME' 'root'
    Set-DotEnvValue 'DB_PASSWORD' $mysqlPass
    Set-DotEnvValue 'DB_NAME' (Get-Config 'DB_NAME' 'crm_db')
}

if ($redisMode -eq 'external') {
    Set-DotEnvValue 'EXTERNAL_REDIS_PASSWORD' $redisPass
    Set-DotEnvValue 'REDIS_HOST' $redisHost
    Set-DotEnvValue 'REDIS_PORT' $redisPort
    Set-DotEnvValue 'REDIS_PASSWORD' $redisPass
} else {
    Set-DotEnvValue 'REDIS_HOST' 'redis'
    Set-DotEnvValue 'REDIS_PORT' '6379'
    Set-DotEnvValue 'REDIS_PASSWORD' ''
}

# 内置容器对外暴露的宿主端口(容器内仍是 3306 / 6379)
if ($mysqlMode -eq 'bundled') { Set-DotEnvValue 'MYSQL_HOST_PORT' $mysqlHostPort }
if ($redisMode -eq 'bundled') { Set-DotEnvValue 'REDIS_HOST_PORT' $redisHostPort }

# 清理旧版本遗留的 COMPOSE_FILE(编排文件已合并为单文件, 保留会让 compose 去找已删除的 docker-compose.db.yml)
Remove-DotEnvKey 'COMPOSE_FILE'
# 只有用到内置实例时才启用 bundled profile: 纯外部时不会创建 mysql/redis 容器
if ($mysqlMode -eq 'bundled' -or $redisMode -eq 'bundled') {
    Set-DotEnvValue 'COMPOSE_PROFILES' $BundledProfile
} else {
    Set-DotEnvValue 'COMPOSE_PROFILES' ''
}
Set-DotEnvValue 'CRM_DB_SOURCE' $mysqlMode
Set-DotEnvValue 'CRM_REDIS_SOURCE' $redisMode
Set-DotEnvValue 'WEB_PORT' $webPort

Write-Host '----------------------------------------------------------'
Write-Info "MySQL 来源: $mysqlDetail"
Write-Info "Redis 来源: $redisDetail"
if ($mysqlMode -eq 'bundled') { Write-Info "MySQL 端口: 宿主 $mysqlHostPort → 容器内 3306(与宿主既有 MySQL 互不影响)" }
if ($redisMode -eq 'bundled') { Write-Info "Redis 端口: 宿主 $redisHostPort → 容器内 6379(与宿主既有 Redis 互不影响)" }
if (Get-DotEnvValue 'COMPOSE_PROFILES') {
    Write-Info "编排文件  : $BaseFile (内置容器 profile: $(Get-DotEnvValue 'COMPOSE_PROFILES'))"
} else {
    Write-Info "编排文件  : $BaseFile (未启用内置容器, 复用宿主实例)"
}
Write-Info "访问地址  : http://localhost:$webPort"
Write-Host '----------------------------------------------------------'
