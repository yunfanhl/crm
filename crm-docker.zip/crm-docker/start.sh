#!/usr/bin/env bash
# ==========================================================
#  云帆智能客户管理系统 - Docker 预检 + 依赖探测 + 启动包装脚本
#  用法:
#    ./start.sh                  # 预检/探测后执行: docker compose up -d --build
#    ./start.sh deps             # 仅显示依赖(MySQL/Redis)来源解析结果, 不启动
#    ./start.sh down             # 停止并删除容器(数据卷保留)
#    ./start.sh logs -f app      # 其余参数原样透传给 docker compose
#
#  预检项:
#    1. docker 命令 / Docker daemon / docker compose v2 是否可用
#    2. ★ 依赖来源解析(MySQL/Redis):
#         - 默认                       -> 自建独立容器 crm-mysql / crm-redis(启用 bundled profile 拉取镜像),
#                                        不读取也不改动宿主已有的 MySQL/Redis, 宿主 3306/6379 上的实例不受影响
#         - USE_EXTERNAL_DB=1(yes)     -> 复用宿主现有 MySQL(探测不到则回退自建)
#         - USE_EXTERNAL_REDIS=1(yes)  -> 复用宿主现有 Redis(探测不到则回退自建)
#       解析结果写入 .env: COMPOSE_PROFILES 决定是否启用内置 MySQL/Redis 容器, DB_*/REDIS_* 决定连接信息
#    3. 宿主端口被本机其他程序占用时自动改用空闲端口, 避免 "bind: address already in use":
#         - Web             : .env 的 WEB_PORT(默认 8080)
#         - 内置 MySQL/Redis: .env 的 MYSQL_HOST_PORT / REDIS_HOST_PORT(默认 3306 / 6379)
#       本项目自身容器已占用的端口不算冲突, 重复执行不会反复改端口
# ==========================================================
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
JAR="$SCRIPT_DIR/crm-system.jar"   # 用于调用 MasterKeySetupTool 生成配套密文

BASE_COMPOSE_FILE="docker-compose.yml"
BUNDLED_PROFILE="bundled"   # 内置 MySQL/Redis 容器所在的 compose profile(在 .env 的 COMPOSE_PROFILES 中启用)
ENV_FILE=".env"
ENV_EXAMPLE=".env.example"
WAIT_SECONDS=90
APP_WAIT_SECONDS=180   # 启动后等待应用就绪的上限(首次启动含建库建表)

info() { printf '[提示] %s\n' "$*"; }
warn() { printf '[警告] %s\n' "$*" >&2; }
err()  { printf '[错误] %s\n' "$*" >&2; }

case "$(uname -s)" in
    Darwin)               OS_KIND="macos" ;;
    Linux)                OS_KIND="linux" ;;
    MINGW*|MSYS*|CYGWIN*) OS_KIND="win" ;;
    *)                    OS_KIND="unknown" ;;
esac

lower() { printf '%s' "$1" | tr '[:upper:]' '[:lower:]'; }

daemon_up() { docker info >/dev/null 2>&1; }

# daemon 未运行时给出对应平台的启动指引
daemon_hint() {
    err "无法连接 Docker daemon(守护进程未运行)"
    case "$OS_KIND" in
        macos)
            echo "  → 请先启动 Docker Desktop: 双击 /Applications/Docker.app, 或执行 open -a Docker" >&2
            echo "  → 等待菜单栏鲸鱼图标不再显示 Starting 之后重试" >&2
            echo "  → 已启动仍失败: Docker Desktop → Settings → Advanced → 勾选 Allow the default Docker socket to be used" >&2
            ;;
        linux)
            echo "  → 请启动 docker 服务: sudo systemctl start docker   (或 sudo service docker start)" >&2
            echo "  → 并设置开机自启: sudo systemctl enable docker" >&2
            ;;
        win)
            echo "  → 请先启动 Docker Desktop, 并确保已启用 WSL2 后端" >&2
            ;;
        *)
            echo "  → 请启动 Docker Desktop / docker 守护进程后重试" >&2
            ;;
    esac
}

# 尝试拉起 daemon: 返回 0 表示已发起启动(不代表就绪)
try_start_daemon() {
    case "$OS_KIND" in
        macos)
            if [ -d /Applications/Docker.app ]; then
                info "已检测到 Docker Desktop, 正在启动..."
                open -a Docker 2>/dev/null || true
                return 0
            fi
            ;;
        linux)
            if command -v systemctl >/dev/null 2>&1; then
                info "正在启动 docker 服务(sudo systemctl start docker)..."
                sudo systemctl start docker 2>/dev/null || true
                return 0
            fi
            if command -v service >/dev/null 2>&1; then
                info "正在启动 docker 服务(sudo service docker start)..."
                sudo service docker start 2>/dev/null || true
                return 0
            fi
            ;;
    esac
    return 1
}

check_compose_file() {
    [ -f "$BASE_COMPOSE_FILE" ] || {
        err "当前目录未找到 $BASE_COMPOSE_FILE, 请在部署包根目录执行本脚本"
        exit 1
    }
}

# ==========================================================
# .env 读写工具
# ==========================================================
dotenv_get() {
    local key="$1" line
    [ -f "$ENV_FILE" ] || return 1
    line="$(grep -E "^[[:space:]]*${key}[[:space:]]*=" "$ENV_FILE" 2>/dev/null | tail -n 1)" || return 1
    [ -n "$line" ] || return 1
    line="${line#*=}"
    line="$(printf '%s' "$line" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' -e 's/\r$//')"
    line="${line%\"}"; line="${line#\"}"
    line="${line%\'}"; line="${line#\'}"
    printf '%s' "$line"
}

# 取值优先级: 进程环境变量 > .env > 默认值
cfg() {
    local key="$1" default="${2:-}" val
    val="${!key:-}"
    if [ -n "$val" ]; then printf '%s' "$val"; return; fi
    val="$(dotenv_get "$key")" && [ -n "$val" ] && { printf '%s' "$val"; return; }
    printf '%s' "$default"
}

# 写入/更新 .env 中的配置项(值可含任意特殊字符)
upsert_env() {
    local key="$1" value="$2" tmp="${ENV_FILE}.tmp.$$"
    [ -f "$ENV_FILE" ] || : >"$ENV_FILE"
    awk -v k="$key" -v v="$value" '
        { if ($0 ~ "^[[:space:]]*" k "[[:space:]]*=") { print k "=" v; found = 1 } else print }
        END { if (!found) print k "=" v }
    ' "$ENV_FILE" >"$tmp" 2>/dev/null || { rm -f "$tmp"; return 1; }
    mv "$tmp" "$ENV_FILE"
}

# ==========================================================
# 授权主密钥初始化: 首次部署自动生成独立随机密钥 + 配套密文
# ==========================================================
# 生成 n 个十六进制字符(优先 openssl, 回退 /dev/urandom)
random_hex() {
    local h="$1"
    openssl rand -hex $((h / 2)) 2>/dev/null \
        || head -c "$h" /dev/urandom 2>/dev/null | od -An -tx1 | tr -d ' \n'
}

# 为指定主密钥生成配套敏感配置密文并写回 .env
# 优先使用宿主 java + jar; 宿主无 JDK 时回退到 docker 临时运行 eclipse-temurin:17(自带 jar/java)
# 调用 jar 内的 MasterKeySetupTool: 解出内置明文后以当前主密钥重新加密, 输出 SECRET=/FILE=
gen_license_ciphers() {
    local env_file="$1" master_key="$2" out secret file tmp
    [ -z "$master_key" ] && return 1
    if command -v java >/dev/null 2>&1 && command -v jar >/dev/null 2>&1 && [ -f "$JAR" ]; then
        tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' RETURN
        ( cd "$tmp" && jar xf "$JAR" BOOT-INF/classes >/dev/null 2>&1 ) \
            || { echo "[警告] 解压 jar 类目录失败, 无法自动生成配套密文" >&2; return 1; }
        out="$(java -cp "$tmp/BOOT-INF/classes" com.crm.utils.MasterKeySetupTool "$master_key" 2>/dev/null)" \
            || { echo "[警告] 生成配套密文失败" >&2; return 1; }
    else
        command -v docker >/dev/null 2>&1 || {
            echo "[警告] 未找到 java/jar/docker, 无法自动生成配套密文" >&2; return 1; }
        out="$(docker run --rm -v "$SCRIPT_DIR/$JAR:/app.jar" eclipse-temurin:17 \
                sh -c 'cd /tmp && jar xf /app.jar BOOT-INF/classes >/dev/null 2>&1 && java -cp BOOT-INF/classes com.crm.utils.MasterKeySetupTool "$1"' \
                sh "$master_key" 2>/dev/null)" \
            || { echo "[警告] 容器内生成配套密文失败(可能离线无法拉取 JDK 镜像)" >&2; return 1; }
    fi
    secret="$(printf '%s' "$out" | sed -n 's/^SECRET=//p')"
    file="$(printf '%s' "$out" | sed -n 's/^FILE=//p')"
    [ -n "$secret" ] && [ -n "$file" ] || return 1
    upsert_env CRM_LICENSE_SECRET_CIPHER "$secret"
    upsert_env CRM_LICENSE_FILE_CIPHER "$file"
    return 0
}

# 授权主密钥初始化(首次部署调用)
#  - 默认/占位符/演示密钥: 自动替换为独立随机密钥 + 配套密文(与 linux/windows 原生包一致)
#  - 用户自定义密钥: 确保配套密文存在, 缺失则尝试生成
#  - 任意生成失败: 回退内置演示主密钥(使用代码内置密文), 保证服务可启动
init_license_key() {
    local mk new_mk new_jwt
    mk="$(dotenv_get CRM_LICENSE_MASTER_KEY)"
    if [ -z "$mk" ] || [ "$mk" = "please-change-me-to-a-random-master-key" ] || [ "$mk" = "Crm2026@MasterKey!X8zQwL9p" ]; then
        new_mk="Crm$(random_hex 32)"
        new_jwt="$(random_hex 64)"
        upsert_env CRM_LICENSE_MASTER_KEY "$new_mk"
        upsert_env JWT_SECRET "$new_jwt"
        if gen_license_ciphers "$ENV_FILE" "$new_mk"; then
            info "已为本次部署生成独立随机授权主密钥(请妥善保管, 后续生成 License 时需使用)"
        else
            warn "配套密文自动生成失败, 已回退为内置演示主密钥以保证可启动"
            warn "如需自定义主密钥, 请手动确保 CRM_LICENSE_SECRET_CIPHER/FILE_CIPHER 与主密钥匹配"
            upsert_env CRM_LICENSE_MASTER_KEY "Crm2026@MasterKey!X8zQwL9p"
            upsert_env CRM_LICENSE_SECRET_CIPHER ""
            upsert_env CRM_LICENSE_FILE_CIPHER ""
        fi
    else
        # 用户自定义主密钥: 配套密文缺失则尝试生成
        if [ -z "$(dotenv_get CRM_LICENSE_SECRET_CIPHER)" ] && [ -z "$(dotenv_get CRM_LICENSE_FILE_CIPHER)" ]; then
            gen_license_ciphers "$ENV_FILE" "$mk" \
                || warn "未检测到与主密钥配套的密文且无法自动生成, 应用可能因密钥不匹配启动失败(请用 ./start.sh configure 或保持默认主密钥)"
        fi
        # JWT_SECRET 若仍为占位符则生成随机
        [ "$(dotenv_get JWT_SECRET)" = "please-change-me-to-a-long-random-jwt-secret" ] \
            && upsert_env JWT_SECRET "$(random_hex 64)"
    fi
}

# 从 .env 删除某个键: 用于清理旧版本遗留、现已不再使用的变量
# (例如旧的 COMPOSE_FILE=docker-compose.yml:docker-compose.db.yml, 单文件化后该文件已不存在)
remove_env_key() {
    local key="$1" tmp="${ENV_FILE}.tmp.$$"
    [ -f "$ENV_FILE" ] || return 0
    awk -v k="$key" '$0 !~ "^[[:space:]]*" k "[[:space:]]*="' "$ENV_FILE" >"$tmp" 2>/dev/null || { rm -f "$tmp"; return 1; }
    mv "$tmp" "$ENV_FILE"
}

# ==========================================================
# 端口 / 服务探测
# ==========================================================
port_open() {
    local host="$1" port="$2"
    if command -v nc >/dev/null 2>&1; then
        nc -z -G 2 "$host" "$port" >/dev/null 2>&1 && return 0
        nc -z -w 2 "$host" "$port" >/dev/null 2>&1 && return 0
    fi
    (exec 3<>/dev/tcp/"$host"/"$port") >/dev/null 2>&1 && return 0
    return 1
}

# 宿主端口是否已被本地进程监听(贴近 "bind: address already in use" 的判定)
port_listening() {
    local port="$1"
    if command -v lsof >/dev/null 2>&1; then
        # 注意: 非root的 lsof 看不到其他用户进程的监听(如 macOS 官方安装包的 mysqld 以 _mysql 运行),
        # 单靠它会误判端口空闲, 导致 Docker 绑定 0.0.0.0 时报 "address already in use",
        # 故 lsof 未命中时再向下用 TCP 连接探测兜底
        lsof -nP -iTCP:"$port" -sTCP:LISTEN >/dev/null 2>&1 && return 0
    elif command -v ss >/dev/null 2>&1; then
        ss -lnt 2>/dev/null | grep -q "[:.]$port[[:space:]]" && return 0
    fi
    (exec 3<>/dev/tcp/127.0.0.1/"$port") >/dev/null 2>&1 && return 0
    return 1
}

# 打印占用者, 例如: java (PID 91637)
port_holder() {
    local port="$1" line=""
    command -v lsof >/dev/null 2>&1 || return 0
    line="$(lsof -nP -iTCP:"$port" -sTCP:LISTEN 2>/dev/null | awk 'NR == 2 { print $1 " (PID " $2 ")" }')"
    [ -n "$line" ] && printf '%s' "$line"
}

# 从 $1+1 开始找第一个空闲端口
find_free_port() {
    local start="$1" i
    for i in $(seq 1 50); do
        port_listening "$((start + i))" || { printf '%s' "$((start + i))"; return 0; }
    done
    return 1
}

# 端口是否被本项目自身的容器占用(自身占用不算冲突, 避免重复执行时端口来回漂移)
own_port() {
    local port="$1" c
    for c in crm-app crm-mysql crm-redis; do
        docker port "$c" 2>/dev/null | grep -q ":${port}\$" && return 0
    done
    return 1
}

# 对外暴露的宿主端口(Web 8080 / 内置 MySQL 3306 / 内置 Redis 6379):
# 被本机其他程序占用时自动避让到空闲端口, 避免 "bind: address already in use";
# 结果写入全局 DEP_PORT
DEP_PORT=""
resolve_bundled_port() {
    local key="$1" def="$2" name="$3" want owner free
    want="$(cfg "$key" "$def")"
    if ! port_listening "$want" || own_port "$want"; then
        DEP_PORT="$want"
        return 0
    fi
    owner="$(port_holder "$want")"
    warn "$name 宿主端口 $want 已被占用${owner:+: $owner}"
    if free="$(find_free_port "$want")"; then
        info "$name 已自动改用宿主端口 $free"
        info "如需固定端口: 关闭占用 $want 的程序, 或在 $ENV_FILE 中设置 $key=$want"
        DEP_PORT="$free"
        return 0
    fi
    warn "未找到空闲端口, 保留 $want(可在 $ENV_FILE 中设置 $key 手动指定)"
    DEP_PORT="$want"
}

# 探测 MySQL: 成功打印版本提示串, 失败返回非 0
probe_mysql() {
    local host="$1" port="$2" out=""
    port_open "$host" "$port" || return 1
    if command -v mysqladmin >/dev/null 2>&1; then
        out="$(mysqladmin --connect-timeout=2 -h"$host" -P"$port" ping 2>&1)"
        case "$out" in
            *"is alive"*|*"Access denied"*) printf 'mysql'; return 0 ;;
        esac
    fi
    # 无客户端时读取服务端主动推送的握手包(含版本串, 如 8.0.36)
    exec 9<>/dev/tcp/"$host"/"$port" 2>/dev/null || return 1
    IFS= read -r -t 3 -N 48 out <&9 2>/dev/null
    exec 9<&- 2>/dev/null || true
    exec 9>&- 2>/dev/null || true
    case "$out" in
        *[0-9]"."[0-9]*) printf '%s' "$(printf '%s' "$out" | LC_ALL=C tr -cd '[:print:]' | sed -E 's/^[^0-9]*//' | awk '{print $1}')"; return 0 ;;
    esac
    return 1
}

# 探测 Redis: 0=可连通, 3=需要密码, 1=不是 Redis / 不可达
probe_redis() {
    local host="$1" port="$2" resp=""
    port_open "$host" "$port" || return 1
    if command -v redis-cli >/dev/null 2>&1; then
        resp="$(redis-cli -h "$host" -p "$port" ping 2>/dev/null)"
        case "$resp" in
            *PONG*) return 0 ;;
            *NOAUTH*|*WRONGPASS*|*ERR*) return 3 ;;
        esac
    fi
    exec 9<>/dev/tcp/"$host"/"$port" 2>/dev/null || return 1
    printf 'PING\r\n' >&9 2>/dev/null
    IFS= read -r -t 3 resp <&9 2>/dev/null
    exec 9<&- 2>/dev/null || true
    exec 9>&- 2>/dev/null || true
    case "$resp" in
        *PONG*) return 0 ;;
        *NOAUTH*|*WRONGPASS*|*ERR*) return 3 ;;
    esac
    return 1
}

container_exists()  { docker ps -a --format '{{.Names}}' 2>/dev/null | grep -qx "$1"; }
container_running() { docker ps    --format '{{.Names}}' 2>/dev/null | grep -qx "$1"; }

# 交互式确认(非交互式环境取默认值; $1=提示语, $2=默认 y/n)
confirm() {
    local prompt="$1" def="${2:-y}" ans hint
    case "$(lower "$def")" in
        n|no) hint="y/N" ;;
        *)    hint="Y/n" ;;
    esac
    if [ ! -t 0 ]; then
        printf '%s [%s] ' "$prompt" "$hint"
        info "非交互环境, 取默认值 $hint"
        case "$hint" in y/N) return 1 ;; *) return 0 ;; esac
    fi
    printf '%s [%s] ' "$prompt" "$hint"
    read -r ans || true
    case "$(lower "${ans:-$def}")" in
        n|no) return 1 ;;
        *) return 0 ;;
    esac
}

# 交互式输入(非交互环境返回默认值)
ask() {
    local prompt="$1" default="$2" ans
    [ -t 0 ] || { printf '%s\n' "$default"; return 0; }
    printf '%s [%s] ' "$prompt" "$default"
    read -r ans || true
    printf '%s' "${ans:-$default}"
}

# ==========================================================
# 依赖来源解析: 决定 MySQL / Redis 用宿主现有实例还是新建容器
# ==========================================================
MYSQL_MODE="bundled"      # bundled | external
REDIS_MODE="bundled"
MYSQL_DETAIL="内置容器 crm-mysql"
REDIS_DETAIL="内置容器 crm-redis"
# 宿主端口(Web / 内置 MySQL / 内置 Redis)不在此预设默认值 —— cfg 的优先级是
# "进程环境变量 > .env > 默认值", 预设值(哪怕是空串)会遮蔽 .env / 环境变量中的同名配置。
# 三者均由 resolve_bundled_port 解析后赋值: WEB_PORT / MYSQL_HOST_PORT / REDIS_HOST_PORT

# 返回值: 0=外部实例可用, 1=不可用
# 输出全局变量: EXT_MYSQL_HOST / EXT_MYSQL_PORT / EXT_MYSQL_VER
scan_local_mysql() {
    local ports p ver
    ports="$(cfg MYSQL_DETECT_PORTS '3306')"
    for p in $ports; do
        if ver="$(probe_mysql 127.0.0.1 "$p" 2>/dev/null)" && [ -n "$ver" ]; then
            EXT_MYSQL_HOST="host.docker.internal"
            EXT_MYSQL_PORT="$p"
            EXT_MYSQL_VER="$ver"
            EXT_MYSQL_LOCAL=1
            return 0
        fi
    done
    return 1
}

# 校验宿主现有实例的账号是否可用(只能校验本机实例)
# 返回: 0=通过, 1=账号/密码不正确, 2=本机缺少客户端工具, 跳过校验
verify_mysql_conn() {
    local port="$1" user="$2" pass="$3"
    command -v mysqladmin >/dev/null 2>&1 || return 2
    mysqladmin --connect-timeout=3 -h127.0.0.1 -P"$port" -u"$user" -p"$pass" ping 2>&1 | grep -q "is alive" && return 0
    return 1
}

verify_redis_conn() {
    local port="$1" pass="$2" out
    command -v redis-cli >/dev/null 2>&1 || return 2
    # 注意: redis-cli 要求 -h / -p 与取值分开, 不能写成 -h127.0.0.1
    if [ -n "$pass" ]; then
        out="$(redis-cli -h 127.0.0.1 -p "$port" -a "$pass" --no-auth-warning ping 2>/dev/null)"
    else
        out="$(redis-cli -h 127.0.0.1 -p "$port" ping 2>/dev/null)"
    fi
    [ "$out" = "PONG" ] && return 0
    return 1
}

scan_local_redis() {
    local ports p rc
    ports="$(cfg REDIS_DETECT_PORTS '6379')"
    for p in $ports; do
        rc=1
        probe_redis 127.0.0.1 "$p" >/dev/null 2>&1
        rc=$?
        [ "$rc" = "1" ] && continue
        EXT_REDIS_HOST="host.docker.internal"
        EXT_REDIS_PORT="$p"
        EXT_REDIS_RC="$rc"
        EXT_REDIS_LOCAL=1
        return 0
    done
    return 1
}

resolve_mysql() {
    local mode
    mode="$(lower "$(cfg USE_EXTERNAL_DB bundled)")"

    # 本项目自带的 crm-mysql 容器已存在 -> 延续使用内置实例
    if container_exists crm-mysql; then
        MYSQL_MODE=bundled
        MYSQL_DETAIL="内置容器 crm-mysql(已存在)"
        return
    fi
    # 显式指定了外部实例地址(如云数据库) -> 直接使用, 优先级最高
    local explicit_host explicit_port
    explicit_host="$(cfg EXTERNAL_DB_HOST '')"
    explicit_port="$(cfg EXTERNAL_DB_PORT '')"
    if [ -n "$explicit_host" ] && [ -n "$explicit_port" ]; then
        MYSQL_MODE=external
        EXT_MYSQL_HOST="$explicit_host"
        EXT_MYSQL_PORT="$explicit_port"
        EXT_MYSQL_VER="?"
        EXT_MYSQL_LOCAL=0
        MYSQL_DETAIL="$explicit_host:$explicit_port (外部实例, 按 .env 指定)"
        return
    fi

    # 只有显式 1/true/yes/on/external 才复用宿主实例; 其余取值(no/bundled/未配置/未识别)
    # 一律自建独立容器 —— 宿主 3306 上已有的 MySQL 既不被读取也不被修改
    case "$mode" in
        1|true|yes|on|external)
            if scan_local_mysql; then
                MYSQL_MODE=external
                MYSQL_DETAIL="127.0.0.1:$EXT_MYSQL_PORT (宿主现有 $EXT_MYSQL_VER)"
                return
            fi
            warn "USE_EXTERNAL_DB=$mode, 但未探测到宿主 MySQL(已试端口: $(cfg MYSQL_DETECT_PORTS '3306'))"
            warn "将回退为新建内置容器 crm-mysql; 如需直连外部主机请在 .env 配置 EXTERNAL_DB_HOST / EXTERNAL_DB_PORT"
            ;;
    esac

    MYSQL_MODE=bundled
    MYSQL_DETAIL="内置容器 crm-mysql(自建, 宿主现有 MySQL 不受影响)"
}

resolve_redis() {
    local mode
    mode="$(lower "$(cfg USE_EXTERNAL_REDIS bundled)")"

    if container_exists crm-redis; then
        REDIS_MODE=bundled
        REDIS_DETAIL="内置容器 crm-redis(已存在)"
        return
    fi
    # 显式指定了外部实例地址(如云数据库) -> 直接使用, 优先级最高
    local explicit_host explicit_port
    explicit_host="$(cfg EXTERNAL_REDIS_HOST '')"
    explicit_port="$(cfg EXTERNAL_REDIS_PORT '')"
    if [ -n "$explicit_host" ] && [ -n "$explicit_port" ]; then
        REDIS_MODE=external
        EXT_REDIS_HOST="$explicit_host"
        EXT_REDIS_PORT="$explicit_port"
        EXT_REDIS_RC=0
        EXT_REDIS_LOCAL=0
        REDIS_DETAIL="$explicit_host:$explicit_port (外部实例, 按 .env 指定)"
        return
    fi

    # 只有显式 1/true/yes/on/external 才复用宿主实例; 其余取值(no/bundled/未配置/未识别)
    # 一律自建独立容器 —— 宿主 6379 上已有的 Redis 既不被读取也不被修改
    case "$mode" in
        1|true|yes|on|external)
            if scan_local_redis; then
                REDIS_MODE=external
                REDIS_DETAIL="127.0.0.1:$EXT_REDIS_PORT (宿主现有)"
                return
            fi
            warn "USE_EXTERNAL_REDIS=$mode, 但未探测到宿主 Redis(已试端口: $(cfg REDIS_DETECT_PORTS '6379'))"
            warn "将回退为新建内置容器 crm-redis; 如需直连外部主机请在 .env 配置 EXTERNAL_REDIS_HOST / EXTERNAL_REDIS_PORT"
            ;;
    esac

    REDIS_MODE=bundled
    REDIS_DETAIL="内置容器 crm-redis(自建, 宿主现有 Redis 不受影响)"
}

# 收集外部 MySQL 连接信息, 并校验账号可用性(失败可回退为内置容器)
MYSQL_USER=""
MYSQL_PASS=""
MYSQL_DBNAME=""
collect_mysql() {
    [ "$MYSQL_MODE" = "external" ] || return 0
    local user pass dbname rc tries=0
    user="$(cfg EXTERNAL_DB_USER "$(cfg DB_USERNAME root)")"
    dbname="$(cfg EXTERNAL_DB_NAME "$(cfg DB_NAME crm_db)")"
    pass="$(cfg EXTERNAL_DB_PASSWORD '')"
    # 上一轮已选过外部实例时复用当时的密码, 避免每次启动重复询问
    if [ -z "$pass" ] && [ "$(cfg CRM_DB_SOURCE '')" = "external" ]; then
        pass="$(dotenv_get DB_PASSWORD)" || pass=""
    fi
    [ -n "$pass" ] || pass="$(ask "宿主 MySQL 用户 $user 的密码" "$(cfg DB_PASSWORD root)")"

    while [ "${EXT_MYSQL_LOCAL:-0}" = "1" ]; do
        rc=0; verify_mysql_conn "$EXT_MYSQL_PORT" "$user" "$pass" || rc=$?
        [ "$rc" = "0" ] && { info "宿主 MySQL 账号校验通过($user@127.0.0.1:$EXT_MYSQL_PORT)"; break; }
        [ "$rc" = "2" ] && { info "本机未安装 mysqladmin, 跳过账号校验"; break; }
        warn "用 $user 连接宿主 MySQL(127.0.0.1:$EXT_MYSQL_PORT) 失败: 账号或密码不正确"
        echo "  → 可直接修改 $ENV_FILE 的 EXTERNAL_DB_USER / EXTERNAL_DB_PASSWORD 后执行 docker compose restart app" >&2
        # 非交互环境(脚本/CI/一键部署)无法确认或重输密码: 直接回退内置容器,
        # 避免写出连不上的外部配置, 导致 crm-app 启动即报 Access denied
        if [ ! -t 0 ]; then
            warn "非交互环境, 自动回退为新建内置容器 crm-mysql(不改动宿主 MySQL)"
            MYSQL_MODE=bundled
            MYSQL_DETAIL="内置容器 crm-mysql(连接校验失败后回退)"
            return 0
        fi
        if confirm "是否改为新建内置容器 crm-mysql(不改动宿主 MySQL)?" "n"; then
            MYSQL_MODE=bundled
            MYSQL_DETAIL="内置容器 crm-mysql(连接校验失败后回退)"
            return 0
        fi
        tries=$((tries + 1))
        [ "$tries" -ge 2 ] && { warn "仍按外部实例写入, 请手动修正 $ENV_FILE 中的数据库账号密码"; break; }
        pass="$(ask "请重新输入 $user 的密码" "$(cfg DB_PASSWORD root)")"
    done
    MYSQL_USER="$user"; MYSQL_PASS="$pass"; MYSQL_DBNAME="$dbname"
}

# 收集外部 Redis 连接信息, 并校验连通性(失败可回退为内置容器)
REDIS_PASS_OUT=""
collect_redis() {
    [ "$REDIS_MODE" = "external" ] || return 0
    local pass rc tries=0
    pass="$(cfg EXTERNAL_REDIS_PASSWORD '')"
    if [ -z "$pass" ] && [ "$(cfg CRM_REDIS_SOURCE '')" = "external" ]; then
        pass="$(dotenv_get REDIS_PASSWORD)" || pass=""
    fi
    if [ -z "$pass" ] && [ "${EXT_REDIS_RC:-0}" = "3" ]; then
        pass="$(ask "宿主 Redis 要求密码认证, 请输入密码" "")"
    fi
    while [ "${EXT_REDIS_LOCAL:-0}" = "1" ]; do
        rc=0; verify_redis_conn "$EXT_REDIS_PORT" "$pass" || rc=$?
        [ "$rc" = "0" ] && { info "宿主 Redis 连接校验通过(127.0.0.1:$EXT_REDIS_PORT)"; break; }
        [ "$rc" = "2" ] && { info "本机未安装 redis-cli, 跳过连接校验"; break; }
        warn "连接宿主 Redis(127.0.0.1:$EXT_REDIS_PORT) 失败: Redis 要求密码认证或密码不正确"
        echo "  → 可直接修改 $ENV_FILE 的 EXTERNAL_REDIS_PASSWORD 后执行 docker compose restart app" >&2
        # 非交互环境无法确认或重输密码: 直接回退内置容器
        if [ ! -t 0 ]; then
            warn "非交互环境, 自动回退为新建内置容器 crm-redis(不改动宿主 Redis)"
            REDIS_MODE=bundled
            REDIS_DETAIL="内置容器 crm-redis(连接校验失败后回退)"
            return 0
        fi
        if confirm "是否改为新建内置容器 crm-redis(不改动宿主 Redis)?" "n"; then
            REDIS_MODE=bundled
            REDIS_DETAIL="内置容器 crm-redis(连接校验失败后回退)"
            return 0
        fi
        tries=$((tries + 1))
        [ "$tries" -ge 1 ] && { warn "仍按外部实例写入, 请手动修正 $ENV_FILE 中的 Redis 密码"; break; }
        pass="$(ask "请输入宿主 Redis 密码" "")"
    done
    REDIS_PASS_OUT="$pass"
}

# 依据解析结果生成 .env 中的连接配置与编排文件清单
persist_resolution() {
    collect_mysql
    collect_redis

    if [ "$MYSQL_MODE" = "external" ]; then
        upsert_env EXTERNAL_DB_USER "$MYSQL_USER"
        upsert_env EXTERNAL_DB_PASSWORD "$MYSQL_PASS"
        upsert_env EXTERNAL_DB_NAME "$MYSQL_DBNAME"
        upsert_env DB_HOST "$EXT_MYSQL_HOST"
        upsert_env DB_PORT "$EXT_MYSQL_PORT"
        upsert_env DB_USERNAME "$MYSQL_USER"
        upsert_env DB_PASSWORD "$MYSQL_PASS"
        upsert_env DB_NAME "$MYSQL_DBNAME"
    else
        upsert_env DB_HOST mysql
        upsert_env DB_PORT 3306
        upsert_env DB_USERNAME root
        upsert_env DB_PASSWORD "$(cfg BUNDLED_MYSQL_ROOT_PASSWORD root)"
        upsert_env DB_NAME "$(cfg DB_NAME crm_db)"
    fi

    if [ "$REDIS_MODE" = "external" ]; then
        upsert_env EXTERNAL_REDIS_PASSWORD "$REDIS_PASS_OUT"
        upsert_env REDIS_HOST "$EXT_REDIS_HOST"
        upsert_env REDIS_PORT "$EXT_REDIS_PORT"
        upsert_env REDIS_PASSWORD "$REDIS_PASS_OUT"
    else
        upsert_env REDIS_HOST redis
        upsert_env REDIS_PORT 6379
        upsert_env REDIS_PASSWORD ""
    fi

    # 清理旧版本遗留的 COMPOSE_FILE(编排文件已合并为单文件, 保留会让 compose 去找已删除的 docker-compose.db.yml)
    remove_env_key COMPOSE_FILE
    # 只有用到内置实例时才启用 bundled profile: 纯外部时不会创建 mysql/redis 容器, 也不会拉取其镜像
    if [ "$MYSQL_MODE" = "bundled" ] || [ "$REDIS_MODE" = "bundled" ]; then
        upsert_env COMPOSE_PROFILES "$BUNDLED_PROFILE"
    else
        upsert_env COMPOSE_PROFILES ""
    fi
    upsert_env CRM_DB_SOURCE "$MYSQL_MODE"
    upsert_env CRM_REDIS_SOURCE "$REDIS_MODE"
}

# Linux 上宿主 MySQL/Redis 若只监听 127.0.0.1, 容器内 host.docker.internal 访问会被拒绝
warn_service_bind() {
    local port="$1" name="$2" line
    command -v ss >/dev/null 2>&1 || return 0
    line="$(ss -lnt 2>/dev/null | grep ":$port " | head -n 1)"
    case "$line" in
        *127.0.0.1*|*"[::1]"*)
            warn "宿主 $name 仅监听回环地址($line)"
            echo "  → 容器内将通过 host.docker.internal 访问宿主网络, 可能被拒绝; 如需复用请让其监听 0.0.0.0" >&2
            echo "  → MySQL: my.cnf 中设置 bind-address = 0.0.0.0; Redis: redis.conf 中注释 bind 并设置 protected-mode no" >&2
            ;;
    esac
}

# 应用是否已可访问: 只要能拿到 HTTP 响应(任意状态码)即视为已监听
app_http_ok() {
    local port="$1"
    if command -v curl >/dev/null 2>&1; then
        curl -sS -o /dev/null --max-time 3 "http://127.0.0.1:${port}/" >/dev/null 2>&1 && return 0
    fi
    (exec 3<>/dev/tcp/127.0.0.1/"$port") >/dev/null 2>&1 && return 0
    return 1
}

# 启动成功后汇总展示系统运行情况: 等待就绪 + 容器状态 + 访问信息 + 常用命令
report_runtime() {
    local port="${WEB_PORT:-8080}" i=0 ready=0
    info "等待应用启动就绪(最多 ${APP_WAIT_SECONDS}s, 首次启动需建库建表)..."
    while [ "$i" -lt "$APP_WAIT_SECONDS" ]; do
        if app_http_ok "$port"; then ready=1; break; fi
        i=$((i + 1))
        sleep 1
        [ $((i % 15)) -eq 0 ] && info "  已等待 ${i}s, 仍在启动中..."
    done

    echo "=========================================================="
    echo " 容器状态"
    echo "=========================================================="
    docker compose ps

    echo "=========================================================="
    echo " 访问信息"
    echo "=========================================================="
    if [ "$ready" -eq 1 ]; then
        info "访问地址  : http://localhost:${port}"
        info "默认账号  : admin / 123456 (登录页可直接点选填充; 生产环境请登录后立即修改密码)"
    else
        warn "等待 ${APP_WAIT_SECONDS}s 后应用仍未响应, 请查看日志: docker compose logs -f app"
    fi
    if [ "${MYSQL_MODE:-bundled}" = "bundled" ]; then
        info "MySQL     : 内置容器 crm-mysql, 宿主端口 ${MYSQL_HOST_PORT:-3306} → 容器内 3306"
    else
        info "MySQL     : 复用宿主实例 ${EXT_MYSQL_HOST:-host.docker.internal}:${EXT_MYSQL_PORT:-3306}"
    fi
    if [ "${REDIS_MODE:-bundled}" = "bundled" ]; then
        info "Redis     : 内置容器 crm-redis, 宿主端口 ${REDIS_HOST_PORT:-6379} → 容器内 6379"
    else
        info "Redis     : 复用宿主实例 ${EXT_REDIS_HOST:-host.docker.internal}:${EXT_REDIS_PORT:-6379}"
    fi
    echo "----------------------------------------------------------"
    echo " 常用命令:  查看日志 docker compose logs -f app"
    echo "            停止     ./start.sh down     (数据卷保留)"
    echo "            重启     ./start.sh restart"
    echo "----------------------------------------------------------"
}

print_summary() {
    echo "----------------------------------------------------------"
    info "MySQL 来源: $MYSQL_DETAIL"
    info "Redis 来源: $REDIS_DETAIL"
    [ "$MYSQL_MODE" = "bundled" ] && info "MySQL 端口: 宿主 ${MYSQL_HOST_PORT:-3306} → 容器内 3306(与宿主既有 MySQL 互不影响)"
    [ "$REDIS_MODE" = "bundled" ] && info "Redis 端口: 宿主 ${REDIS_HOST_PORT:-6379} → 容器内 6379(与宿主既有 Redis 互不影响)"
    if [ -n "$(dotenv_get COMPOSE_PROFILES)" ]; then
        info "编排文件  : $BASE_COMPOSE_FILE (内置容器 profile: $(dotenv_get COMPOSE_PROFILES))"
    else
        info "编排文件  : $BASE_COMPOSE_FILE (未启用内置容器, 复用宿主实例)"
    fi
    info "访问地址  : http://localhost:${WEB_PORT:-8080}"
    echo "----------------------------------------------------------"
}

main() {
    if ! command -v docker >/dev/null 2>&1; then
        err "未检测到 docker 命令, 请先安装 Docker Desktop: https://www.docker.com/products/docker-desktop/"
        exit 1
    fi

    check_compose_file

    if ! daemon_up; then
        daemon_hint
        if try_start_daemon; then
            info "等待 Docker daemon 就绪(最多 ${WAIT_SECONDS}s)..."
            local i=0
            while [ "$i" -lt "$WAIT_SECONDS" ]; do
                if daemon_up; then
                    info "Docker daemon 已就绪"
                    break
                fi
                i=$((i + 1))
                sleep 1
            done
        fi
        if ! daemon_up; then
            err "Docker daemon 仍未就绪, 请手动启动 Docker Desktop 后重新执行本脚本"
            exit 1
        fi
    fi

    if ! docker compose version >/dev/null 2>&1; then
        err "未检测到 Docker Compose v2 插件(docker compose), 请升级 Docker Desktop 或安装 compose 插件"
        exit 1
    fi

    # 依赖来源解析(结果写入 .env, 后续原生 docker compose 命令同样生效)
    [ -f "$ENV_FILE" ] || { [ -f "$ENV_EXAMPLE" ] && cp "$ENV_EXAMPLE" "$ENV_FILE" && info "已由 $ENV_EXAMPLE 生成 $ENV_FILE"; }
    init_license_key
    resolve_mysql
    resolve_redis
    persist_resolution
    # 内置容器的宿主端口: 默认 3306/6379, 被其他程序占用时自动避让并写回 .env
    if [ "$MYSQL_MODE" = "bundled" ]; then
        resolve_bundled_port MYSQL_HOST_PORT 3306 "内置 MySQL"
        MYSQL_HOST_PORT="$DEP_PORT"
        upsert_env MYSQL_HOST_PORT "$MYSQL_HOST_PORT"
    fi
    if [ "$REDIS_MODE" = "bundled" ]; then
        resolve_bundled_port REDIS_HOST_PORT 6379 "内置 Redis"
        REDIS_HOST_PORT="$DEP_PORT"
        upsert_env REDIS_HOST_PORT "$REDIS_HOST_PORT"
    fi
    # Web 宿主端口: 被本机其他程序占用时自动避让并写回 .env
    resolve_bundled_port WEB_PORT 8080 "Web"
    WEB_PORT="$DEP_PORT"
    upsert_env WEB_PORT "$WEB_PORT"
    print_summary

    if [ "${1:-}" = "deps" ]; then
        echo "已显示依赖解析结果(未启动容器); 可调整 $ENV_FILE 的 WEB_PORT / MYSQL_HOST_PORT / REDIS_HOST_PORT"
        echo "如需复用宿主现有 MySQL/Redis, 设置 USE_EXTERNAL_DB=1 / USE_EXTERNAL_REDIS=1 后重跑本脚本"
        exit 0
    fi

    # 内置容器端口已在上文自动避让(冲突则改用空闲端口), 故此处只需提示复用宿主实例时的监听地址问题
    case "${1:-}" in
        up|start|restart)
            [ "$MYSQL_MODE" = "external" ] && warn_service_bind "${EXT_MYSQL_PORT:-3306}" "MySQL"
            [ "$REDIS_MODE" = "external" ] && warn_service_bind "${EXT_REDIS_PORT:-6379}" "Redis"
            ;;
    esac

    info "执行: docker compose $*"
    docker compose "$@"
    local rc=$?
    if [ "$rc" -ne 0 ]; then
        err "命令执行失败(退出码 $rc), 请查看上方输出; 常见原因: 宿主端口被占用(端口见上方提示)"
        exit "$rc"
    fi
    # up / start / restart 后展示系统运行情况(等待就绪 + 容器状态 + 访问信息)
    case "${1:-}" in
        up|start|restart) report_runtime ;;
    esac
}

if [ "$#" -eq 0 ]; then
    main up -d --build
else
    main "$@"
fi
